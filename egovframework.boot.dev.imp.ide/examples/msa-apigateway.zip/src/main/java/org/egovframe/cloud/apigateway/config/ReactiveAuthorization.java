package org.egovframe.cloud.apigateway.config;

import java.time.Duration;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.server.RequestPath;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.access.AuthorizationServiceException;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.ReactiveAuthorizationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.server.authorization.AuthorizationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;


/**
 * org.egovframe.cloud.apigateway.config.ReactiveAuthorization
 * <p>
 * Spring Security 에 의해 요청 url에 대한 사용자 인가 서비스를 수행하는 클래스 요청에 대한 사용자의 권한여부 체크하여 true/false 리턴한다
 *
 * @author 표준프레임워크센터 jaeyeolkim
 * @version 1.0
 * @since 2021/07/19
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *     수정일        수정자           수정내용
 *  ----------    --------    ---------------------------
 *  2021/07/19    jaeyeolkim  최초 생성
 * </pre>
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class ReactiveAuthorization implements ReactiveAuthorizationManager<AuthorizationContext> {

    /** 인가 서버가 응답하지 않을 때 무한 대기하지 않도록 하는 응답 제한 시간 */
    private static final Duration AUTHORIZATION_TIMEOUT = Duration.ofSeconds(30);


    private final WebClient.Builder webClientBuilder;

    @Value("${apigateway.host:http://localhost:8000}")
    private String APIGATEWAY_HOST;

    @Value("${token.secret}")
    private String TOKEN_SECRET;

    // org.egovframe.cloud.common.config.GlobalConstant 값도 같이 변경해주어야 한다.
    public static final String AUTHORIZATION_URI = "/user-service" + "/api/v1/authorizations/check";
    public static final String REFRESH_TOKEN_URI = "/user-service" + "/api/v1/users/token/refresh";

    private SecretKey verificationKey() {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(TOKEN_SECRET.getBytes(StandardCharsets.UTF_8));
            return Keys.hmacShaKeyFor(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * 요청에 대한 사용자의 권한여부 체크하여 true/false 리턴한다 헤더에 토큰이 있으면 유효성을 체크한다.
     *
     * @param authentication
     * @param context
     * @return
     * @see WebFluxSecurityConfig
     */
    @Override
    public Mono<AuthorizationDecision> check(Mono<Authentication> authentication,
        AuthorizationContext context) {
        ServerHttpRequest request = context.getExchange().getRequest();
        RequestPath requestPath = request.getPath();
        HttpMethod httpMethod = request.getMethod();

        String baseUrl =
            APIGATEWAY_HOST + AUTHORIZATION_URI + "?httpMethod=" + httpMethod + "&requestPath="
                + requestPath;
        log.info("baseUrl={}", baseUrl);

        String authorizationHeader = "";

        List<String> authorizations =
            request.getHeaders().containsKey(HttpHeaders.AUTHORIZATION) ?
                request.getHeaders().get(HttpHeaders.AUTHORIZATION) : null;

        if (authorizations != null && authorizations.size() > 0
            && StringUtils.hasLength(authorizations.get(0))
            && !"undefined".equals(authorizations.get(0))
        ) {
            try {
                authorizationHeader = authorizations.get(0);
                String raw = authorizationHeader.trim();
                String jwt = raw.startsWith("Bearer ") ? raw.substring(7).trim() : raw;
                SecretKey key = verificationKey();
                String subject = Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(jwt)
                    .getPayload()
                    .getSubject();

                // refresh token 요청 시 토큰 검증만 하고 인가 처리 한다.
                if (REFRESH_TOKEN_URI.equals(requestPath + "")) {
                    return Mono.just(new AuthorizationDecision(true));
                }
                if (subject == null || subject.isEmpty()) {
                    log.error("토큰 인증 오류");
                    throw new AuthorizationServiceException("토큰 인증 오류");
                }
            } catch (IllegalArgumentException e) {
                log.error("토큰 헤더 오류 : {}", e.getMessage());
                throw new AuthorizationServiceException("토큰 인증 오류");
            } catch (ExpiredJwtException e) {
                log.error("토큰 유효기간이 만료되었습니다. : {}", e.getMessage());
                throw new AuthorizationServiceException("토큰 유효기간 만료");
            } catch (Exception e) {
                log.error("토큰 인증 오류 Exception : {}", e.getMessage());
                throw new AuthorizationServiceException("토큰 인증 오류");
            }
        }

        String token = authorizationHeader;
        return webClientBuilder.clone()
            .baseUrl(baseUrl)
            .build()
            .get()
            .headers(httpHeaders -> httpHeaders.add(HttpHeaders.AUTHORIZATION, token))
            .retrieve()
            .bodyToMono(Boolean.class)
            .timeout(AUTHORIZATION_TIMEOUT)
            .defaultIfEmpty(false)
            .doOnNext(granted -> log.info("Security AuthorizationDecision granted={}", granted))
            .map(AuthorizationDecision::new)
            .onErrorMap(e -> {
                log.error("인가 서버에 요청 중 오류 : {}", e.getMessage());
                return new AuthorizationServiceException("인가 요청시 오류 발생", e);
            });
    }

}
