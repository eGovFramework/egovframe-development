package egovframework.let.cop.bbs.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import egovframework.let.cop.bbs.dto.request.BbsManageDetailBoardRequestDTO;
import egovframework.let.cop.bbs.dto.response.BbsManageDetailResponseDTO;
import egovframework.let.cop.bbs.dto.response.BbsManageListResponseDTO;
import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.ResponseCode;
import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.EgovFileMngUtil;
import egovframework.com.cmm.service.FileVO;
import egovframework.com.cmm.service.IntermediateResultVO;
import egovframework.com.cmm.service.ResultVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.cmm.util.ResultVoHelper;
import egovframework.let.cop.bbs.domain.model.BoardVO;
import egovframework.let.cop.bbs.dto.request.BbsSearchRequestDTO;
import egovframework.let.cop.bbs.dto.request.BbsManageDeleteBoardRequestDTO;
import egovframework.let.cop.bbs.dto.response.BbsFileAtchResponseDTO;
import egovframework.let.cop.bbs.enums.BbsDetailRequestType;
import egovframework.let.cop.bbs.service.EgovBBSAttributeManageService;
import egovframework.let.cop.bbs.service.EgovBBSManageService;
import egovframework.let.utl.sim.service.EgovFileScrty;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * 게시물 관리를 위한 컨트롤러 클래스
 * @author 공통 서비스 개발팀 이삼섭
 * @since 2009.03.19
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자             수정내용
 *  -------    --------        ---------------------------
 *  2009.03.19  이삼섭            최초 생성
 *  2009.06.29  한성곤	         2단계 기능 추가 (댓글관리, 만족도조사)
 *  2011.08.31  JJY              경량환경 템플릿 커스터마이징버전 생성
 *  2024.04.06  김재섭(nirsa)     생성자 주입 전환, 불필요한 필드 제거, ResultVoHelper 적용 및 1차 코드 리팩토링
 *  2026.05.13  PHJ              보안취약점 대응
 *
 *  </pre>
 */
@RestController
@RequiredArgsConstructor
@Tag(name="EgovBBSManageApiController",description = "게시물 관리")
public class EgovBBSManageApiController {
    private final EgovFileMngUtil fileUtil;
    private final ResultVoHelper resultVoHelper;
    private final EgovBBSManageService bbsMngService;
    private final EgovFileMngService fileMngService;
    private final EgovPropertyService propertyService;
    private final EgovBBSAttributeManageService bbsAttrbService;
	
	/**
	 * 게시판 마스터 상세내용을 조회한다.
	 * 파일 첨부 가능 여부 조회용
	 *
	 * @param bbsId
	 * @return BbsDetailResponse
	 * @throws Exception
	 */
	@Operation(
			summary = "게시판 파일 첨부 관련 정보 조회",
			description = "게시판의 파일 첨부가능 여부 및 첨부가능 파일 수 조회",
			tags = {"EgovBBSManageApiController"}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "조회 성공", content = @Content(
				    schema = @Schema(oneOf = {
							BbsFileAtchResponseDTO.class
				        })
				    )),
			@ApiResponse(
					responseCode = "403",
					description = "인가된 사용자가 아님",
			        content = @Content(
				            mediaType = "application/json",
				            examples = @ExampleObject(
				                name = "403 응답 예시",
				                summary = "Forbidden",
				                value = "{\n" +
				                        "  \"resultCode\": 403,\n" +
				                        "  \"resultMessage\": \"인가된 사용자가 아님\"\n" +
				                        "}"
				            )
				        )),
	})
	@GetMapping(value = "/boardFileAtch/{bbsId}")
	public IntermediateResultVO<BbsFileAtchResponseDTO> selectUserBBSMasterInf(
			@Parameter(name = "bbsId", description = "게시판 Id", in = ParameterIn.PATH, example="BBSMSTR_AAAAAAAAAAAA")
			@PathVariable("bbsId") String bbsId)
		throws Exception {
		
		BbsFileAtchResponseDTO response = bbsAttrbService.selectBBSMasterInf(bbsId, null, BbsDetailRequestType.FILE_ATCH);

		return IntermediateResultVO.success(response);
	}
	/**
	 * 게시물에 대한 목록을 조회한다.
	 *
	 * @param boardVO
	 * @return resultVO
	 * @throws Exception
	 */
	@Operation(
			summary = "게시물 목록 조회",
			description = "게시물에 대한 목록을 조회",
			tags = {"EgovBBSManageApiController"}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "조회 성공")
	})
	@GetMapping(value = "/board")
	public IntermediateResultVO<BbsManageListResponseDTO> selectBoardArticles(@ModelAttribute BbsSearchRequestDTO bbsSearchRequestDTO,
																				 @Parameter(hidden = true) @AuthenticationPrincipal LoginVO user)
		throws Exception {
		// permitAll 경로 — 익명 접근 가능, user 가 null 일 수 있음
		String uniqId = (user != null) ? user.getUniqId() : null;
		BbsFileAtchResponseDTO attributeDetailResponse = bbsAttrbService.selectBBSMasterInf(bbsSearchRequestDTO.getBbsId(), uniqId, BbsDetailRequestType.DETAIL);

		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(bbsSearchRequestDTO.getPageIndex());
		paginationInfo.setRecordCountPerPage(propertyService.getInt("Globals.pageUnit"));
		paginationInfo.setPageSize(propertyService.getInt("Globals.pageSize"));

		BbsManageListResponseDTO response = bbsMngService.selectBoardArticles(bbsSearchRequestDTO, paginationInfo, "");
		paginationInfo.setTotalRecordCount(response.getResultCnt());
		response.setPaginationInfo(paginationInfo);
		response.setUser(user);
		response.setBrdMstrVO(attributeDetailResponse);

		return IntermediateResultVO.success(response);
	}

	/**
	 * 게시물에 대한 상세 정보를 조회한다.
	 *
	 * @param boardVO
	 * @return resultVO
	 * @throws Exception
	 */
	@Operation(
			summary = "게시물 상세 조회",
			description = "게시물에 대한 상세 정보를 조회",
			tags = {"EgovBBSManageApiController"}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "조회 성공")
	})
	@GetMapping(value = "/board/{bbsId}/{nttId}")
	public IntermediateResultVO<BbsManageDetailResponseDTO> selectBoardArticle(
			@Parameter(name = "bbsId", description = "게시판 Id", in = ParameterIn.PATH, example="BBSMSTR_AAAAAAAAAAAA")
			@PathVariable("bbsId") String bbsId,
			@Parameter(name = "nttId", description = "게시글 Id", in = ParameterIn.PATH, example="1")
			@PathVariable("nttId") String nttId,
			@Parameter(hidden = true) @AuthenticationPrincipal LoginVO user)
		throws Exception {
		// permitAll 경로 — 익명 접근 가능, user 가 null 일 수 있음
		String uniqId = (user != null) ? user.getUniqId() : null;
		BbsManageDetailBoardRequestDTO bbsManageDetailBoardRequestDTO = BbsManageDetailBoardRequestDTO.builder()
				.bbsId(bbsId)
				.nttId(Long.parseLong(nttId))
				.plusCount(true)
				.lastUpdusrId(uniqId)
				.build();
		
		//---------------------------------
		// 2009.06.29 : 2단계 기능 추가
		//---------------------------------
		if (bbsManageDetailBoardRequestDTO.getSubPageIndex() != null && !bbsManageDetailBoardRequestDTO.getSubPageIndex().isEmpty()) {
			bbsManageDetailBoardRequestDTO.setPlusCount(false);
		}
		////-------------------------------

		//----------------------------
		// template 처리 (기본 BBS template 지정  포함)
		//----------------------------
		BbsFileAtchResponseDTO bbsFileAtchResponseDTO = bbsAttrbService.selectBBSMasterInf(bbsManageDetailBoardRequestDTO.getBbsId(), uniqId, BbsDetailRequestType.LIST);

		BbsManageDetailResponseDTO bbsManageDetailResponseDTO = bbsMngService.selectBoardArticle(bbsManageDetailBoardRequestDTO)
				.toBuilder()
				.brdMstrVO(bbsFileAtchResponseDTO)
				.sessionUniqId(uniqId)
				.user(user)
				.build();

		return IntermediateResultVO.success(bbsManageDetailResponseDTO);
	}

	/**
	 * 게시물에 대한 내용을 수정한다.
	 *
	 * @param boardVO
	 * @param multiRequest
	 * @param bindingResult
	 * @param request
	 * @return resultVO
	 * @throws Exception
	 */
	@Operation(
			summary = "게시물 수정",
			description = "게시물에 대한 내용을 수정",
			security = {@SecurityRequirement(name = "Authorization")},
			tags = {"EgovBBSManageApiController"}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "수정 성공"),
			@ApiResponse(responseCode = "403", description = "인가된 사용자가 아님"),
			@ApiResponse(responseCode = "900", description = "입력값 무결성 오류")
	})
	@PutMapping(value ="/board/{nttId}")
	public ResultVO updateBoardArticle(final MultipartHttpServletRequest multiRequest,
		HttpServletRequest request,
		@ModelAttribute BoardVO boardVO,
		@Parameter(name = "nttId", description = "게시글 Id", in = ParameterIn.PATH, example="1")
		@PathVariable("nttId") String nttId,
		BindingResult bindingResult)
		throws Exception {
		LoginVO user = extractUserFromJwt(request);
		// 26.03.04 KISA 보안취약점 조치
		// null check 추가
		String rawAtchFileId = boardVO.getAtchFileId();
		String atchFileId = rawAtchFileId != null ? rawAtchFileId.replaceAll("\\s", "") : "";

		if (bindingResult.hasErrors()) {
			return resultVoHelper.buildFromResultVO(new ResultVO(), ResponseCode.INPUT_CHECK_ERROR);
		}

		// 소유권 검증: 작성자 본인 또는 ADMIN만 수정 가능
		BbsManageDetailBoardRequestDTO ownerCheckRequest = BbsManageDetailBoardRequestDTO.builder()
				.bbsId(boardVO.getBbsId())
				.nttId(Long.parseLong(nttId))
				.plusCount(false)
				.lastUpdusrId(user.getUniqId())
				.build();
		BbsManageDetailResponseDTO article = bbsMngService.selectBoardArticle(ownerCheckRequest);
		boolean isAdmin = EgovUserDetailsHelper.getAuthorities().contains("ROLE_ADMIN");
		if (article == null || article.getBoardVO() == null
				|| (!user.getUniqId().equals(article.getBoardVO().getFrstRegisterId()) && !isAdmin)) {
			return resultVoHelper.buildFromResultVO(new ResultVO(), ResponseCode.AUTH_ERROR);
		}

		final Map<String, MultipartFile> files = multiRequest.getFileMap();
		if (!files.isEmpty()) {
			if ("".equals(atchFileId)) {
				List<FileVO> result = fileUtil.parseFileInf(files, "BBS_", 0, atchFileId, "");
				atchFileId = fileMngService.insertFileInfs(result);
				boardVO.setAtchFileId(atchFileId);
			} else {
				FileVO fvo = new FileVO();
				fvo.setAtchFileId(atchFileId);
				int cnt = fileMngService.getMaxFileSN(fvo);
				List<FileVO> _result = fileUtil.parseFileInf(files, "BBS_", cnt, atchFileId, "");
				fileMngService.updateFileInfs(_result);
			}
		}

		boardVO.setNttId(Long.parseLong(nttId));
		boardVO.setLastUpdusrId(user.getUniqId());
		boardVO.setNtcrNm(user.getName()); // jwt토큰값으로 추가. dummy 오류 수정 (익명이 아닌 경우 validator 처리를 위해 dummy로 지정됨) 
		boardVO.setPassword(EgovFileScrty.encryptPassword("", user.getUniqId())); // dummy 오류 수정 (익명이 아닌 경우 validator 처리를 위해 dummy로 지정됨)
		// XSS 방지: HTMLTagFilter 가 모든 폼 입력 파라미터(<, >, &, ", ')를 자동 escape

		bbsMngService.updateBoardArticle(boardVO);

		return resultVoHelper.buildFromMap(new HashMap<String, Object>(), ResponseCode.SUCCESS);
	}

	/**
	 * 게시물을 등록한다.
	 *
	 * @param multiRequest
	 * @param boardVO
	 * @param bindingResult
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@Operation(
			summary = "게시물 등록",
			description = "게시물을 등록",
			security = {@SecurityRequirement(name = "Authorization")},
			tags = {"EgovBBSManageApiController"}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "등록 성공"),
			@ApiResponse(responseCode = "403", description = "인가된 사용자가 아님"),
			@ApiResponse(responseCode = "900", description = "입력값 무결성 오류")
	})
	@PostMapping(value ="/board")
	public ResultVO insertBoardArticle(final MultipartHttpServletRequest multiRequest,
		@ModelAttribute BoardVO boardVO,
		BindingResult bindingResult,
		HttpServletRequest request)
		throws Exception {
		LoginVO user = extractUserFromJwt(request);
		
		if (bindingResult.hasErrors()) {
			return resultVoHelper.buildFromResultVO(new ResultVO(), ResponseCode.INPUT_CHECK_ERROR);
		}
	
		List<FileVO> result = null;
		String atchFileId = "";

		final Map<String, MultipartFile> files = multiRequest.getFileMap();
		if (!files.isEmpty()) {
			result = fileUtil.parseFileInf(files, "BBS_", 0, "", "");
			atchFileId = fileMngService.insertFileInfs(result);
		}
		boardVO.setAtchFileId(atchFileId);
		boardVO.setFrstRegisterId(user.getUniqId());
		boardVO.setBbsId(boardVO.getBbsId());
		boardVO.setNtcrNm(user.getName()); //jwt토큰값으로 추가. dummy 오류 수정 (익명이 아닌 경우 validator 처리를 위해 dummy로 지정됨)
		boardVO.setPassword(EgovFileScrty.encryptPassword("", user.getUniqId())); // dummy 오류 수정 (익명이 아닌 경우 validator 처리를 위해 dummy로 지정됨)
		// XSS 방지: HTMLTagFilter 가 모든 폼 입력 파라미터(<, >, &, ", ')를 자동 escape

		bbsMngService.insertBoardArticle(boardVO);

		return resultVoHelper.buildFromMap(new HashMap<String, Object>(), ResponseCode.SUCCESS);
	}

	/**
	 * 게시물에 대한 답변을 등록한다.
	 *
	 * @param multiRequest
	 * @param boardVO
	 * @param bindingResult
	 * @param request 
	 * @return resultVO
	 * @throws Exception
	 */
	@Operation(
			summary = "게시물 답변 등록",
			description = "게시물에 대한 답변을 등록",
			security = {@SecurityRequirement(name = "Authorization")},
			tags = {"EgovBBSManageApiController"}
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "등록 성공"),
			@ApiResponse(responseCode = "403", description = "인가된 사용자가 아님"),
			@ApiResponse(responseCode = "900", description = "입력값 무결성 오류")
	})
	@PostMapping(value ="/boardReply")
	public ResultVO replyBoardArticle(final MultipartHttpServletRequest multiRequest,
		@ModelAttribute BoardVO boardVO,
		BindingResult bindingResult,
		HttpServletRequest request)
		throws Exception {
		ResultVO resultVO = new ResultVO();
		LoginVO user = extractUserFromJwt(request);

		if (bindingResult.hasErrors()) {
			resultVO.setResultCode(ResponseCode.INPUT_CHECK_ERROR.getCode());
			resultVO.setResultMessage(ResponseCode.INPUT_CHECK_ERROR.getMessage());

			return resultVoHelper.buildFromResultVO(resultVO, ResponseCode.INPUT_CHECK_ERROR);
		}
		
		final Map<String, MultipartFile> files = multiRequest.getFileMap();
		String atchFileId = "";

		if (!files.isEmpty()) {
			List<FileVO> result = fileUtil.parseFileInf(files, "BBS_", 0, "", "");
			atchFileId = fileMngService.insertFileInfs(result);
		}

		boardVO.setAtchFileId(atchFileId);
		boardVO.setReplyAt("Y");
		boardVO.setFrstRegisterId(user.getUniqId());
		boardVO.setBbsId(boardVO.getBbsId());
		boardVO.setParnts(Long.toString(boardVO.getNttId()));
		boardVO.setSortOrdr(boardVO.getSortOrdr());
		boardVO.setReplyLc(Integer.toString(Integer.parseInt(boardVO.getReplyLc()) + 1));

		boardVO.setNtcrNm(user.getName()); //jwt토큰값으로 추가. dummy 오류 수정 (익명이 아닌 경우 validator 처리를 위해 dummy로 지정됨)
		boardVO.setPassword(EgovFileScrty.encryptPassword("", user.getUniqId())); // dummy 오류 수정 (익명이 아닌 경우 validator 처리를 위해 dummy로 지정됨)
		// XSS 방지: HTMLTagFilter 가 모든 폼 입력 파라미터(<, >, &, ", ')를 자동 escape

		bbsMngService.insertBoardArticle(boardVO);

		return resultVoHelper.buildFromMap(new HashMap<String, Object>(), ResponseCode.SUCCESS);
	}

	/**
	 * 게시물에 대한 내용을 삭제한다.
	 *
	 * @param boardVO
	 * @param nttId
	 * @param request
	 * @return resultVO
	 * @throws Exception
	 */
	@Operation(
			summary = "게시물 삭제",
			description = "게시물에 대한 내용을 삭제",
			security = {@SecurityRequirement(name = "Authorization")},
			tags = {"EgovBBSManageApiController"}
	)
	@ApiResponses(value = {
		    @ApiResponse(
		        responseCode = "200",
		        description = "삭제 성공",
		        content = @Content(
			            mediaType = "application/json",
			            examples = @ExampleObject(
			                name = "200 응답 예시",
			                summary = "Forbidden",
			                value = "{\n" +
			                        "  \"resultCode\": 200,\n" +
			                        "  \"resultMessage\": \"성공했습니다.\"\n" +
			                        "}"
			            )
			        )),
		    @ApiResponse(
		        responseCode = "403",
		        description = "인가된 사용자가 아님",
		        content = @Content(
		            mediaType = "application/json",
		            examples = @ExampleObject(
		                name = "403 응답 예시",
		                summary = "Forbidden",
		                value = "{\n" +
		                        "  \"resultCode\": 403,\n" +
		                        "  \"resultMessage\": \"인가된 사용자가 아님\"\n" +
		                        "}"
		            )
		        ))
			}) 
	@PatchMapping(value = "/board/{bbsId}/{nttId}")
	public IntermediateResultVO<Object> deleteBoardArticle(
		@Parameter(name = "bbsId", description = "게시판 Id", in = ParameterIn.PATH, example="BBSMSTR_AAAAAAAAAAAA")	
		@PathVariable("bbsId") String bbsId,
		@Parameter(name = "nttId", description = "게시글 Id", in = ParameterIn.PATH, example="1")
		@PathVariable("nttId") String nttId,
		@RequestBody BbsManageDeleteBoardRequestDTO bbsDeleteBoardRequestDTO,
		@Parameter(hidden = true) @AuthenticationPrincipal LoginVO user)
		throws Exception {
		// 소유권 검증: 작성자 본인 또는 ADMIN만 삭제 가능
		BbsManageDetailBoardRequestDTO ownerCheckRequest = BbsManageDetailBoardRequestDTO.builder()
				.bbsId(bbsId)
				.nttId(Long.parseLong(nttId))
				.plusCount(false)
				.lastUpdusrId(user.getUniqId())
				.build();
		BbsManageDetailResponseDTO article = bbsMngService.selectBoardArticle(ownerCheckRequest);
		boolean isAdmin = EgovUserDetailsHelper.getAuthorities().contains("ROLE_ADMIN");
		if (article == null || article.getBoardVO() == null
				|| (!user.getUniqId().equals(article.getBoardVO().getFrstRegisterId()) && !isAdmin)) {
			IntermediateResultVO<Object> authError = new IntermediateResultVO<>();
			authError.setResultCode(ResponseCode.AUTH_ERROR.getCode());
			authError.setResultMessage(ResponseCode.AUTH_ERROR.getMessage());
			return authError;
		}

		bbsDeleteBoardRequestDTO.setBbsId(bbsId);
		bbsDeleteBoardRequestDTO.setNttId(Long.parseLong(nttId));
		bbsDeleteBoardRequestDTO.setNttSj("이 글은 작성자에 의해서 삭제되었습니다.");

		bbsMngService.deleteBoardArticle(bbsDeleteBoardRequestDTO, user);

		return IntermediateResultVO.success(null);
	}

	/**
	 * XSS 방지 처리.
	 *
	 * @param data
	 * @return
	 */
	/**
	 * SecurityContext에서 인증된 사용자 정보를 LoginVO로 반환한다.
	 * JwtAuthenticationFilter가 이미 SecurityContext에 LoginVO를 설정하므로
	 * Authorization 헤더를 직접 파싱하지 않는다.
	 */
	private LoginVO extractUserFromJwt(HttpServletRequest request) {
	    Object principal = EgovUserDetailsHelper.getAuthenticatedUser();
	    if (principal instanceof LoginVO) {
	        return (LoginVO) principal;
	    }
	    return new LoginVO();
	}

}