package org.egovframe.cloud.reactive.exception;

import io.jsonwebtoken.ExpiredJwtException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.egovframe.cloud.common.exception.BusinessException;
import org.egovframe.cloud.common.exception.BusinessMessageException;
import org.egovframe.cloud.common.exception.dto.ErrorCode;
import org.egovframe.cloud.common.exception.dto.ErrorResponse;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.reactive.resource.NoResourceFoundException;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

/**
 * org.egovframe.cloud.reactive.exception.ExceptionHandlerAdvice
 * <p>
 * WebFlux 컨트롤러에 적용되는 예외 처리 어드바이스 클래스
 * 오류 응답은 서블릿 서비스와 동일한 {@link ErrorResponse}(timestamp, message, status, code, errors) 형식을 따른다.
 *
 * @author 표준프레임워크센터 shinmj
 * @version 1.0
 * @since 2021/09/06
 *
 * <pre>
 * ===== 개정이력(Modification Information) =====
 *
 *     수정일        수정자           수정내용
 *  ----------    --------    ---------------------------
 *  2021/09/06    shinmj      최초 생성
 *  2026/10/13    eGovFrame   공통모듈에서 서비스 템플릿으로 이동(기존에는 컴포넌트 스캔 대상이 아니어서 비활성 상태였음),
 *                            NotFoundException(webjars) → NoResourceFoundException, ResponseStatusException 처리 추가
 * </pre>
 */
@Slf4j
@RequiredArgsConstructor
@RestControllerAdvice
public class ExceptionHandlerAdvice {

    private final MessageSource messageSource;

    /**
     * javax.validation.Valid or @Validated 으로 binding error 발생시 발생한다.
     * HttpMessageConverter 에서 등록한 HttpMessageConverter binding 못할경우 발생
     * 주로 @RequestBody, @RequestPart 어노테이션에서 발생
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected Mono<ErrorResponse> handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        log.error("handleMethodArgumentNotValidException", e);
        final ErrorResponse response = ErrorResponse.of(ErrorCode.INVALID_INPUT_VALUE, e.getBindingResult(), messageSource);
        return Mono.just(response);
    }

    /**
     * 바인딩 객체 @ModelAttribute 으로 binding error 발생시 BindException 발생한다.
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected Mono<ErrorResponse> handleBindException(BindException e) {
        log.error("handleBindException", e);
        final ErrorResponse response = ErrorResponse.of(ErrorCode.INVALID_INPUT_VALUE, e.getBindingResult(), messageSource);
        return Mono.just(response);
    }

    /**
     * 요청은 잘 만들어졌지만, 문법 오류로 인하여 따를 수 없습니다
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(HttpClientErrorException.UnprocessableEntity.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected Mono<ErrorResponse> handleUnprocessableEntityException(HttpClientErrorException.UnprocessableEntity e) {
        log.error("handleUnprocessableEntityException", e);
        final ErrorResponse response = ErrorResponse.of(ErrorCode.UNPROCESSABLE_ENTITY, messageSource);
        return Mono.just(response);
    }

    /**
     * enum type 일치하지 않아 binding 못할 경우 발생
     * 주로 @RequestParam enum으로 binding 못했을 경우 발생
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected Mono<ErrorResponse> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException e) {
        log.error("handleMethodArgumentTypeMismatchException", e);
        final ErrorResponse response = ErrorResponse.of(e, messageSource);
        return Mono.just(response);
    }

    /**
     * 요청한 페이지가 존재하지 않는 경우
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(NoResourceFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    protected Mono<ErrorResponse> handleNotFoundException(NoResourceFoundException e) {
        log.error("handleNotFoundException", e);
        final ErrorResponse response = ErrorResponse.of(ErrorCode.NOT_FOUND, messageSource);
        return Mono.just(response);
    }

    /**
     * 프레임워크/컨트롤러에서 상태코드를 지정하여 던진 예외(ResponseStatusException)는 해당 상태코드를 유지한다.
     * (default exception 처리에서 500 으로 바뀌지 않도록 한다)
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(ResponseStatusException.class)
    protected Mono<ResponseEntity<ErrorResponse>> handleResponseStatusException(ResponseStatusException e) {
        log.error("handleResponseStatusException", e);
        final ErrorCode errorCode = switch (e.getStatusCode().value()) {
            case 400 -> ErrorCode.INVALID_INPUT_VALUE;
            case 401 -> ErrorCode.UNAUTHORIZED;
            case 403 -> ErrorCode.ACCESS_DENIED;
            case 404 -> ErrorCode.NOT_FOUND;
            case 405 -> ErrorCode.METHOD_NOT_ALLOWED;
            case 422 -> ErrorCode.UNPROCESSABLE_ENTITY;
            default -> ErrorCode.INTERNAL_SERVER_ERROR;
        };
        final ErrorResponse response = ErrorResponse.of(errorCode, messageSource);
        return Mono.just(ResponseEntity.status(e.getStatusCode()).body(response));
    }

    /**
     * Authentication 객체가 필요한 권한을 보유하지 않은 경우 발생
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(AccessDeniedException.class)
    protected Mono<ResponseEntity<ErrorResponse>> handleAccessDeniedException(AccessDeniedException e) {
        log.error("handleAccessDeniedException", e);
        final ErrorResponse response = ErrorResponse.of(ErrorCode.ACCESS_DENIED, messageSource);
        return Mono.just(ResponseEntity.status(HttpStatus.valueOf(ErrorCode.ACCESS_DENIED.getStatus())).body(response));
    }

    /**
     * 사용자 인증되지 않은 경우 발생
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(HttpClientErrorException.Unauthorized.class)
    protected Mono<ResponseEntity<ErrorResponse>> handleUnauthorizedException(HttpClientErrorException.Unauthorized e) {
        log.error("handleUnauthorizedException", e);
        final ErrorResponse response = ErrorResponse.of(ErrorCode.UNAUTHORIZED, messageSource);
        return Mono.just(ResponseEntity.status(HttpStatus.valueOf(ErrorCode.ACCESS_DENIED.getStatus())).body(response));
    }

    /**
     * JWT 인증 만료
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(ExpiredJwtException.class)
    protected Mono<ResponseEntity<ErrorResponse>> handleExpiredJwtException(ExpiredJwtException e) {
        log.error("handleExpiredJwtException", e);
        final ErrorResponse response = ErrorResponse.of(ErrorCode.JWT_EXPIRED, messageSource);
        return Mono.just(ResponseEntity.status(HttpStatus.valueOf(ErrorCode.ACCESS_DENIED.getStatus())).body(response));
    }

    /**
     * 사용자에게 표시할 다양한 메시지를 직접 정의하여 처리하는 Business RuntimeException Handler
     * 개발자가 만들어 던지는 런타임 오류를 처리
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(BusinessMessageException.class)
    protected Mono<ResponseEntity<ErrorResponse>> handleBusinessMessageException(BusinessMessageException e) {
        log.error("handleBusinessMessageException", e);
        final ErrorCode errorCode = e.getErrorCode();
        final String customMessage = e.getCustomMessage();
        final ErrorResponse response = ErrorResponse.of(errorCode, customMessage);
        return Mono.just(ResponseEntity.status(HttpStatus.valueOf(errorCode.getStatus())).body(response));
    }

    /**
     * 개발자 정의 ErrorCode 를 처리하는 Business RuntimeException Handler
     * 개발자가 만들어 던지는 런타임 오류를 처리
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(BusinessException.class)
    protected Mono<ResponseEntity<ErrorResponse>> handleBusinessException(BusinessException e) {
        log.error("handleBusinessException", e);
        final ErrorCode errorCode = e.getErrorCode();
        final ErrorResponse response = ErrorResponse.of(errorCode, messageSource);
        return Mono.just(ResponseEntity.status(HttpStatus.valueOf(errorCode.getStatus()))
                .body(response));
    }

    /**
     * default exception
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    protected Mono<ErrorResponse> handleException(Exception e) {
        log.error("handleException", e);
        final ErrorResponse response = ErrorResponse.of(ErrorCode.INTERNAL_SERVER_ERROR, messageSource);
        return Mono.just(response);
    }

    /**
     * javax.validation.Valid or @Validated 으로 binding error 발생시 발생한다.
     *
     * @return ResponseEntity with ErrorResponse
     */
    @ExceptionHandler(WebExchangeBindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected Mono<ErrorResponse> handleWebExchangeBindException(WebExchangeBindException e) {
        log.error("handleWebExchangeBindException", e);
        final ErrorResponse response = ErrorResponse.of(ErrorCode.INVALID_INPUT_VALUE, e.getBindingResult(), messageSource);
        return Mono.just(response);
    }

}
