package org.egovframe.cloud.reserverequestservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles(profiles = "test")
class ReserveRequestServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
