/**
 * 서블릿(JPA) 서비스 공통 도메인 패키지
 * <p>
 * {@link org.egovframe.cloud.servlet.domain.BaseEntity} 가 상속하는 실행환경 {@link org.egovframe.rte.psl.data.jpa.entity.EgovBaseEntity} 는
 * 외부 jar 에 있어 QueryDSL 이 Q클래스를 만들지 않으므로 {@link com.querydsl.core.annotations.QueryEntities} 로 생성 대상에 포함한다.
 */
@QueryEntities(EgovBaseEntity.class)
package org.egovframe.cloud.servlet.domain;

import com.querydsl.core.annotations.QueryEntities;
import org.egovframe.rte.psl.data.jpa.entity.EgovBaseEntity;
