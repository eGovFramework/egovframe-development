package org.egovframe.cloud.servlet.domain;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import org.egovframe.rte.psl.data.jpa.entity.EgovBaseEntity;

/**
 * org.egovframe.cloud.servlet.domain.BaseEntity
 * <p>
 * JPA Entity 클래스들이 BaseEntity 를 상속할 경우 생성자/생성일시/수정자/수정일시 필드가 컬럼으로 인식된다.
 * 표준프레임워크 실행환경 {@link EgovBaseEntity}(egovframe-rte-psl-data-jpa)의 감사(Auditing) 필드를 그대로 사용하고,
 * 기존 테이블 컬럼명(last_modified_by)과의 호환을 위해 수정자 컬럼만 재정의한다.
 *
 * <pre>
 * | 필드         | 컬럼             | 비고                              |
 * |--------------|------------------|-----------------------------------|
 * | createdBy    | created_by       | EgovBaseEntity                    |
 * | createdDate  | created_date     | EgovBaseEntity                    |
 * | modifiedBy   | last_modified_by | EgovBaseEntity(modified_by) 재정의 |
 * | modifiedDate | modified_date    | EgovBaseEntity                    |
 * </pre>
 *
 * @author 표준프레임워크센터 jaeyeolkim
 * @version 1.0
 * @since 2021/06/30
 *
 * <pre>
 * ===== 개정이력(Modification Information) =====
 *
 *     수정일        수정자           수정내용
 *  ----------    --------    ---------------------------
 *  2021/06/30    jaeyeolkim  최초 생성
 *  2026/10/13    eGovFrame   공통모듈(egovframe-cloud-module-common)에서 서비스 템플릿으로 이동, 실행환경 EgovBaseEntity 상속으로 변경
 * </pre>
 */
@MappedSuperclass
@AttributeOverride(name = "modifiedBy", column = @Column(name = "last_modified_by", length = 100))
public abstract class BaseEntity extends EgovBaseEntity {

}
