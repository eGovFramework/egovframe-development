package egovframework.example;

import java.util.List;

import org.egovframe.rte.bat.core.launch.support.EgovSchedulerRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;

/**
 * 배치 Scheduler(Quartz) 실행 애플리케이션
 * - context-batch-scheduler.xml : Trigger(cron) 설정
 * - context-scheduler-job.xml   : Trigger 가 실행할 Job(jobName) 설정
 */
public class EgovBootApplication implements CommandLineRunner {

	/** 스케줄러 실행 유지 시간(ms) 후 종료 */
	private static final long DELAY_TIME = 30000L;

	private static final List<String> JOB_PATHS = List.of(
			"/egovframework/batch/job/delimitedToDelimitedJob.xml",
			"/egovframework/batch/job/fixedLengthToFixedLengthJob.xml",
			"/egovframework/batch/job/fixedLengthToMybatisJob.xml",
			"/egovframework/batch/job/fixedLengthToJdbcJob.xml");

	public static void main(String[] args) {
		SpringApplication application = new SpringApplication(EgovBootApplication.class);
		application.setWebApplicationType(WebApplicationType.NONE);
		application.run(args);
	}

	@Override
	public void run(String... args) {
		EgovSchedulerRunner runner = new EgovSchedulerRunner("/egovframework/batch/context-batch-scheduler.xml",
				"/egovframework/batch/context-scheduler-job.xml", JOB_PATHS, DELAY_TIME);
		runner.start();
	}

}
