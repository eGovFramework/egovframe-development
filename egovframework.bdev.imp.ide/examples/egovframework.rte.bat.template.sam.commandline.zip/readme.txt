Run As > Run Configuration 선택
Arguments 탭에 다음중 하나 입력
/egovframework/batch/context-commandline.xml delimitedToDelimitedJob inputFile=egovframework/batch/data/inputs/csvData.csv
/egovframework/batch/context-commandline.xml fixedLengthToFixedLengthJob inputFile=egovframework/batch/data/inputs/csvData.csv
/egovframework/batch/context-commandline.xml fixedLengthToMybatisJob inputFile=egovframework/batch/data/inputs/csvData.csv
/egovframework/batch/context-commandline.xml fixedLengthToJdbcJob inputFile=egovframework/batch/data/inputs/csvData.csv
