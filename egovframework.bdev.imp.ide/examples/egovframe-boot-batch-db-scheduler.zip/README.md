# Template-Batch-DB_Scheduler

eGovFrame Boot 5.1.0 기반 Quartz Scheduler 배치 템플릿 (DB → DB/파일)

## 환경 설정

| 항목 | 버전 |
| :--- | :--- |
| JDK | 17 |
| eGovFrame Parent | egovframe-boot-starter-parent 5.1.0 |
| Spring Boot / Spring Framework | 3.5.16 / 6.2.19 |
| Spring Batch | 5.2.6 |
| 커넥션 풀 | HikariCP |
| DB | HSQLDB 2.7 (내장 메모리 DB, 기동 시 `db/hsql` 스크립트 적재) |
| 로깅 | Log4j2 (`src/main/resources/log4j2.xml`) |

## 빌드 / 실행

```bash
mvn clean package
java -jar target/egovframe-boot-batch-db-scheduler-5.1.0.jar
```

- 실행 주기(cron) : `context-batch-scheduler.xml` (기본 10초)
- 실행 Job : `context-scheduler-job.xml` 의 `jobName`
- 기본 30초 동안 실행 후 종료 (`EgovBootApplication.DELAY_TIME`)
- 결과 파일 : `./target/test-outputs/`

## 데이터베이스

기본 설정은 **HSQL 인메모리 DB**(`Globals.DbType = hsql`, `Globals.Hsql.AutoInit = true`)로, 별도 DB 설치 없이 기동하면
`src/main/resources/db/hsql` 의 DDL · 데이터가 자동 적재됩니다(재기동 시 초기화).
다른 DB를 사용하려면 `src/main/resources/egovframework/batch/properties/globals.properties` 를 변경합니다.

```properties
Globals.DbType = mysql            # hsql, mysql, maria, postgres, oracle, tibero, altibase, cubrid, goldilocks
Globals.DriverClassName = com.mysql.cj.jdbc.Driver
Globals.Url = jdbc:mysql://127.0.0.1:3306/egovbatch
```

- `Globals.*` 값은 환경변수(`GLOBALS_DBTYPE`, `GLOBALS_DRIVERCLASSNAME`, `GLOBALS_URL`, `GLOBALS_USERNAME`, `GLOBALS_PASSWORD`, `GLOBALS_HSQL_AUTOINIT`)
  또는 `-D` 시스템 프로퍼티로 덮어쓸 수 있습니다. **DB 계정 · 비밀번호는 파일에 두지 말고 이 방식으로 주입**합니다.
- `Globals.DbType` 으로 다음이 함께 결정됩니다.
  - DataSource : `hsql` → 인메모리, 그 외 → `Globals.DriverClassName` · `Globals.Url` 외부 DB
  - Mapper : `egovframework/mapper/example/bat/Egov_Example_SQL_{DbType}.xml` (DB별 페이징 SQL)
  - Batch 메타 DB 유형 : `EgovBatchDbType` (Tibero · Altibase · Cubrid · Goldilocks 는 Oracle 호환 시퀀스, Cubrid 는 전용 Incrementer)
- HSQL · MySQL 외 DB는 JDBC 드라이버를 `pom.xml` 에 `runtime` 스코프로 추가합니다(MariaDB · PostgreSQL · Oracle 은 버전을 Parent 가 관리).

  ```xml
  <dependency>
      <groupId>org.postgresql</groupId>
      <artifactId>postgresql</artifactId>
      <scope>runtime</scope>
  </dependency>
  ```

### DB 스크립트

| 파일 | 내용 |
| :--- | :--- |
| `DATABASE/<dbms>/all_batch_ddl_<dbms>.sql` | 기존 테이블 삭제 · 테이블 생성 · 테이블/컬럼 주석 |
| `DATABASE/<dbms>/all_batch_data_<dbms>.sql` | 고객 샘플 데이터 |

- 대상 : Spring Batch 메타 테이블 6종 · 시퀀스 3종, `CUSTOMER`
- 지원 DBMS : altibase, cubrid, goldilocks, hsql, maria, mysql, oracle, postgres, tibero
  - 기동 검증 : HSQL 2.7, MySQL 8.4, MariaDB 11.4, PostgreSQL 16, Oracle 23ai Free
  - Tibero · Altibase · Cubrid · Goldilocks : 각 DB 문법 기준 작성(실 DB 미검증)
- 실행 순서 : `all_batch_ddl_<dbms>.sql` → `all_batch_data_<dbms>.sql`
- Spring Batch 메타 테이블은 Spring Batch 5.2 스키마(`PARAMETER_NAME/TYPE/VALUE` 등) 기준이며, MySQL 은 시퀀스 테이블 초기값을 데이터 스크립트에서 입력합니다.
- `src/main/resources/db/hsql` 은 `DATABASE/hsql` 사본입니다(수정 시 함께 반영).
