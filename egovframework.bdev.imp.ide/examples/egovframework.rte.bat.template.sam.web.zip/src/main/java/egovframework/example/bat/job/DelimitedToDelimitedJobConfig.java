package egovframework.example.bat.job;

import java.net.MalformedURLException;

import org.egovframe.rte.bat.core.item.file.mapping.EgovObjectMapper;
import org.egovframe.rte.bat.core.item.file.transform.EgovFieldExtractor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

import egovframework.example.bat.transform.EgovDelimitedLineTokenizer;
import egovframework.example.bat.transform.EgovLineTokenizer;
import egovframework.example.bat.transform.EgovDefaultLineMapper;

@Configuration
public class DelimitedToDelimitedJobConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(DelimitedToDelimitedJobConfig.class);
	
	@Autowired
    private JobBuilderFactory jobBuilderFactory;
	@Autowired
    private StepBuilderFactory stepBuilderFactory;
	
    @Bean
    public Job delimitedToDelimitedJob() {
        return jobBuilderFactory.get("delimitedToDelimitedJob")
                .start(delimitedToDelimitedStep())
                .build();
    }

    @Bean
    public Step delimitedToDelimitedStep() {
        return stepBuilderFactory.get("delimitedToDelimitedStep")
                .<CustomerCredit,CustomerCredit>chunk(2)
                .reader(delimitedItemReader(null,null))
                .processor(itemProcessor())
                .writer(delimitedItemWriter(null,null))
                .build();
    }
    
    @Bean
    @StepScope
    public FlatFileItemReader<CustomerCredit> delimitedItemReader(@Qualifier("delimitedToDelimitedJob.delimitedLineMapper") EgovDefaultLineMapper<CustomerCredit> defaultLineMapper
    		, @Value("#{jobParameters[inputFile]}") String inputFile) {
    	
    	LOGGER.debug("===>>> inputFile = "+inputFile);
    	
    	Resource resource = null;
		try {
			resource = new UrlResource(inputFile);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
    	
        return new FlatFileItemReaderBuilder<CustomerCredit>()
        		.name("delimitedItemReader")
        		.resource(resource)
        		.lineMapper(defaultLineMapper)
        		.saveState(false)
        		.build();
    }

    @Bean(name="delimitedToDelimitedJob.delimitedLineTokenizer")
    public EgovDelimitedLineTokenizer lineTokenizer() {
        EgovDelimitedLineTokenizer lineTokenizer = new EgovDelimitedLineTokenizer();
    	lineTokenizer.setDelimiter(",");
    	return lineTokenizer;
    }
    
    @Bean(name="delimitedToDelimitedJob.objectMapper")
    public EgovObjectMapper<CustomerCredit> objectMapper() {
    	EgovObjectMapper<CustomerCredit> objectMapper = new EgovObjectMapper<>();
		objectMapper.setType(CustomerCredit.class);
		objectMapper.setNames(new String[] {"name","credit"});
		return objectMapper;
    }
    
    @Bean(name="delimitedToDelimitedJob.delimitedLineMapper")
    public EgovDefaultLineMapper<CustomerCredit> defaultLineMapper(@Qualifier("delimitedToDelimitedJob.delimitedLineTokenizer") EgovDelimitedLineTokenizer lineTokenizer
    		,@Qualifier("delimitedToDelimitedJob.objectMapper") EgovObjectMapper<CustomerCredit> objectMapper) {
    	EgovDefaultLineMapper<CustomerCredit> lineMapper = new EgovDefaultLineMapper<>();
    	lineMapper.setLineTokenizer((EgovLineTokenizer) lineTokenizer);
    	lineMapper.setObjectMapper(objectMapper);
    	return lineMapper;
    }
    
    @Bean
    public CustomerCreditIncreaseProcessor itemProcessor() {
        return new CustomerCreditIncreaseProcessor();
    }

    @Bean
    @StepScope
    public FlatFileItemWriter<CustomerCredit> delimitedItemWriter(@Qualifier("delimitedToDelimitedJob.delimitedLineAggregator") DelimitedLineAggregator<CustomerCredit> lineAggregator
    		, @Value("#{jobParameters[outputFile]}") String outputFile) {
    	
    	Resource resource = null;
		try {
			resource = new UrlResource(outputFile);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
    	
    	return new FlatFileItemWriterBuilder<CustomerCredit>()
    			.name("delimitedItemWriter")
    			.resource(resource)
    			.lineAggregator(lineAggregator)
    			.saveState(false)
    			.build();
    }
    
    @Bean(name="delimitedToDelimitedJob.fieldExtractor")
    public EgovFieldExtractor<CustomerCredit> fieldExtractor() {
    	EgovFieldExtractor<CustomerCredit> fieldExtractor = new EgovFieldExtractor<>();
    	fieldExtractor.setNames(new String[] {"name","credit"});
    	return fieldExtractor;
    }
    
    @Bean(name="delimitedToDelimitedJob.delimitedLineAggregator")
    public DelimitedLineAggregator<CustomerCredit> lineAggregator(@Qualifier("delimitedToDelimitedJob.fieldExtractor") EgovFieldExtractor<CustomerCredit> fieldExtractor) {
    	DelimitedLineAggregator<CustomerCredit> lineAggregator = new DelimitedLineAggregator<>();
    	lineAggregator.setDelimiter(",");
    	lineAggregator.setFieldExtractor(fieldExtractor);
    	return lineAggregator;
    }
}
