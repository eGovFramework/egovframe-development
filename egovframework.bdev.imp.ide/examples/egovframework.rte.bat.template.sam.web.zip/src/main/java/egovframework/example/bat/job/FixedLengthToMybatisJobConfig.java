package egovframework.example.bat.job;

import java.net.MalformedURLException;

import org.egovframe.rte.bat.core.item.database.EgovMyBatisBatchItemWriter;
import org.egovframe.rte.bat.core.item.file.mapping.EgovObjectMapper;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

import egovframework.example.bat.transform.EgovDefaultLineMapper;
import egovframework.example.bat.transform.EgovFixedLengthTokenizer;

@Configuration
public class FixedLengthToMybatisJobConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(FixedLengthToMybatisJobConfig.class);
	
	@Autowired
    private JobBuilderFactory jobBuilderFactory;
	@Autowired
    private StepBuilderFactory stepBuilderFactory;
	
    @Bean
    public Job fixedLengthToMybatisJob() {
        return jobBuilderFactory.get("fixedLengthToMybatisJob")
                .start(fixedLengthToFixedLengthStep())
                .build();
    }

    @Bean
    public Step fixedLengthToFixedLengthStep() {
        return stepBuilderFactory.get("fixedLengthToMybatisStep")
                .<CustomerCredit,CustomerCredit>chunk(2)
                .reader(fixedLengthItemReader(null))
                .processor(itemProcessor())
                .writer(myBatisBatchItemWriter(null))
                .build();
    }
    
    @Bean
    @StepScope
    @Value("#{jobParameters[inputFile]}")
    public FlatFileItemReader<CustomerCredit> fixedLengthItemReader(String inputFile) {
    	
    	LOGGER.debug("===>>> inputFile = "+inputFile);
    	Resource resource = null;
		try {
			resource = new UrlResource(inputFile);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
    	
        return new FlatFileItemReaderBuilder<CustomerCredit>()
        		.name("fixedLengthItemReader")
        		.resource(resource)
        		.lineMapper(defaultLineMapper())
        		.saveState(false)
        		.build();
    }

    @Bean
    public EgovFixedLengthTokenizer lineTokenizer() {
    	EgovFixedLengthTokenizer fixedLengthTokenizer = new EgovFixedLengthTokenizer();
    	fixedLengthTokenizer.setColumns(new Range[]{new Range(1, 9), new Range(10, 11)});
    	return fixedLengthTokenizer;
    }
    
    @Bean
    public EgovObjectMapper<CustomerCredit> objectMapper() {
    	EgovObjectMapper<CustomerCredit> objectMapper = new EgovObjectMapper<>();
		objectMapper.setType(CustomerCredit.class);
		objectMapper.setNames(new String[] {"name","credit"});
		return objectMapper;
    }
    
    @Bean
    public EgovDefaultLineMapper<CustomerCredit> defaultLineMapper() {
    	EgovDefaultLineMapper<CustomerCredit> lineMapper = new EgovDefaultLineMapper<>();
    	lineMapper.setLineTokenizer(lineTokenizer());
    	lineMapper.setObjectMapper(objectMapper());
    	return lineMapper;
    }
    
    @Bean
    public CustomerCreditIncreaseProcessor itemProcessor() {
        return new CustomerCreditIncreaseProcessor();
    }

    @Bean
    @StepScope
    public EgovMyBatisBatchItemWriter<CustomerCredit> myBatisBatchItemWriter(SqlSessionFactoryBean sqlSessionFactoryBean) {
    	
    	EgovMyBatisBatchItemWriter<CustomerCredit> myBatisBatchItemWriter	= new EgovMyBatisBatchItemWriter<>();
    	try {
			myBatisBatchItemWriter.setSqlSessionFactory(sqlSessionFactoryBean.getObject());
		} catch (Exception e) {
			e.printStackTrace();
		}
    	myBatisBatchItemWriter.setStatementId("Customer.updateCredit");
		
    	return myBatisBatchItemWriter;
    }
    
}
