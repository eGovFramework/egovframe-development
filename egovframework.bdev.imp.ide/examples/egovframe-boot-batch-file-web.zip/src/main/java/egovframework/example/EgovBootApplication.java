package egovframework.example;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.Banner;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;

/**
 * @author 배치실행개발팀
 * @since 2021. 11.25
 * @version 1.0
 * @see
 *  <pre>
 *      개정이력(Modification Information)
 *
 *  수정일         수정자          수정내용
 *  ----------   -----------   ---------------------------
 *  2021.11.25   신용호          최초 생성
 *  2023.03.15   신용호          java Config 및 Annotation 적용
 *  
 *  </pre>
 */

@SpringBootApplication
@ComponentScan(basePackages="egovframework")
@Import(EgovBootInitialization.class)
@EnableBatchProcessing
public class EgovBootApplication {

	public static void main(String[] args) {
		System.out.println("##### EgovSampleBootApplication Start #####");

		new SpringApplicationBuilder(EgovBootApplication.class)
                .headless(false)
                .bannerMode(Banner.Mode.CONSOLE)
                .web(WebApplicationType.SERVLET)
                .run(args);

		System.out.println("##### EgovSampleBootApplication End #####");
	}
	
}
