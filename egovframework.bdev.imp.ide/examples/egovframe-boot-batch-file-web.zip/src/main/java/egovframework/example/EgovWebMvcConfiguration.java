package egovframework.example;

import java.util.List;
import java.util.Properties;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

@Configuration
public class EgovWebMvcConfiguration implements WebMvcConfigurer {

    @Override
    public void configureHandlerExceptionResolvers(@NonNull List<HandlerExceptionResolver> exceptionResolvers) {
        Properties prop = new Properties();
        prop.setProperty("org.springframework.dao.DataAccessException", "cmmn/dataAccessFailure");
        prop.setProperty("org.springframework.transaction.TransactionException", "cmmn/transactionFailure");
        prop.setProperty("org.egovframe.rte.fdl.cmmn.exception.EgovBizException", "cmmn/egovError");
        prop.setProperty("org.springframework.security.AccessDeniedException", "cmmn/egovError");
        prop.setProperty("java.lang.Throwable", "cmmn/bizError");

        SimpleMappingExceptionResolver smer = new SimpleMappingExceptionResolver();
        smer.setDefaultErrorView("cmmn/bizError");
        smer.setExceptionMappings(prop);
        exceptionResolvers.add(smer);
    }

    @Bean
    public FilterRegistrationBean<CharacterEncodingFilter> encodingFilterBean() {
        FilterRegistrationBean<CharacterEncodingFilter> registrationBean = new FilterRegistrationBean<>();
        CharacterEncodingFilter filter = new CharacterEncodingFilter();
        filter.setForceEncoding(true);
        filter.setEncoding("UTF-8");
        registrationBean.setFilter(filter);
        registrationBean.addUrlPatterns("*.do");
        return registrationBean;
    }
}
