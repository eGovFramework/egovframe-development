package egovframework.example.bat.job;

import org.egovframe.rte.bat.core.item.file.mapping.EgovDefaultLineMapper;
import org.egovframe.rte.bat.core.item.file.mapping.EgovObjectMapper;
import org.egovframe.rte.bat.core.item.file.transform.EgovFieldExtractor;
import org.egovframe.rte.bat.core.item.file.transform.EgovFixedLengthLineAggregator;
import org.egovframe.rte.bat.core.item.file.transform.EgovFixedLengthTokenizer;
import org.egovframe.rte.bat.core.item.file.transform.EgovLineTokenizer;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

/**
 * 고정길이 파일 → 고정길이 파일 Job
 */
@Configuration
public class FixedLengthToFixedLengthJobConfig {

	@Bean
	public Job fixedLengthToFixedLengthJob(JobRepository jobRepository, Step fixedLengthToFixedLengthStep) {
		return new JobBuilder("fixedLengthToFixedLengthJob", jobRepository)
				.start(fixedLengthToFixedLengthStep)
				.build();
	}

	@Bean
	public Step fixedLengthToFixedLengthStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			FlatFileItemReader<CustomerCredit> fixedLengthToFixedLengthItemReader, FlatFileItemWriter<CustomerCredit> fixedLengthToFixedLengthItemWriter) {
		return new StepBuilder("fixedLengthToFixedLengthStep", jobRepository)
				.<CustomerCredit, CustomerCredit>chunk(2, transactionManager)
				.reader(fixedLengthToFixedLengthItemReader)
				.processor(new CustomerCreditIncreaseProcessor())
				.writer(fixedLengthToFixedLengthItemWriter)
				.build();
	}

	@Bean
	@StepScope
	public FlatFileItemReader<CustomerCredit> fixedLengthToFixedLengthItemReader(@Value("#{jobParameters['inputFile']}") String inputFile,
			ResourceLoader resourceLoader, EgovDefaultLineMapper<CustomerCredit> fixedLengthToFixedLengthLineMapper) {
		return new FlatFileItemReaderBuilder<CustomerCredit>()
				.name("fixedLengthToFixedLengthItemReader")
				.resource(resourceLoader.getResource(inputFile))
				.lineMapper(fixedLengthToFixedLengthLineMapper)
				.saveState(false)
				.build();
	}

	@Bean
	public EgovObjectMapper<CustomerCredit> fixedLengthToFixedLengthObjectMapper() {
		EgovObjectMapper<CustomerCredit> objectMapper = new EgovObjectMapper<>();
		objectMapper.setType(CustomerCredit.class);
		objectMapper.setNames(new String[] {"name", "credit"});
		return objectMapper;
	}

	@Bean
	@SuppressWarnings({"unchecked", "rawtypes"})
	public EgovDefaultLineMapper<CustomerCredit> fixedLengthToFixedLengthLineMapper(EgovObjectMapper<CustomerCredit> fixedLengthToFixedLengthObjectMapper) {
		EgovFixedLengthTokenizer tokenizer = new EgovFixedLengthTokenizer();
		tokenizer.setColumns(new Range[] {new Range(1, 9), new Range(10, 11)});

		EgovDefaultLineMapper<CustomerCredit> lineMapper = new EgovDefaultLineMapper<>();
		// rte 토크나이저는 EgovLineTokenizer<Object> 로 선언되어 있어 형변환 필요
		lineMapper.setLineTokenizer((EgovLineTokenizer) tokenizer);
		lineMapper.setObjectMapper(fixedLengthToFixedLengthObjectMapper);
		return lineMapper;
	}

	/** outputFile: 서버에서 지정한 경로만 사용 (BatchRunController) */
	@Bean
	@StepScope
	public FlatFileItemWriter<CustomerCredit> fixedLengthToFixedLengthItemWriter(@Value("#{jobParameters['outputFile']}") String outputFile,
			EgovFixedLengthLineAggregator<CustomerCredit> fixedLengthToFixedLengthLineAggregator) {
		return new FlatFileItemWriterBuilder<CustomerCredit>()
				.name("fixedLengthToFixedLengthItemWriter")
				.resource(new FileSystemResource(outputFile))
				.lineAggregator(fixedLengthToFixedLengthLineAggregator)
				.saveState(false)
				.build();
	}

	@Bean
	public EgovFieldExtractor<CustomerCredit> fixedLengthToFixedLengthFieldExtractor() {
		EgovFieldExtractor<CustomerCredit> fieldExtractor = new EgovFieldExtractor<>();
		fieldExtractor.setNames(new String[] {"name", "credit"});
		return fieldExtractor;
	}

	@Bean
	public EgovFixedLengthLineAggregator<CustomerCredit> fixedLengthToFixedLengthLineAggregator(EgovFieldExtractor<CustomerCredit> fixedLengthToFixedLengthFieldExtractor) {
		EgovFixedLengthLineAggregator<CustomerCredit> lineAggregator = new EgovFixedLengthLineAggregator<>();
		lineAggregator.setFieldRanges(new int[] {9, 2});
		lineAggregator.setFieldExtractor(fixedLengthToFixedLengthFieldExtractor);
		return lineAggregator;
	}

}
