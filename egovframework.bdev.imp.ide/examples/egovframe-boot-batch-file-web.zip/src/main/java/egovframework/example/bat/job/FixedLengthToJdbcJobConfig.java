package egovframework.example.bat.job;

import javax.sql.DataSource;

import org.egovframe.rte.bat.core.item.database.EgovJdbcBatchItemWriter;
import org.egovframe.rte.bat.core.item.database.support.EgovMethodMapItemPreparedStatementSetter;
import org.egovframe.rte.bat.core.item.file.mapping.EgovDefaultLineMapper;
import org.egovframe.rte.bat.core.item.file.mapping.EgovObjectMapper;
import org.egovframe.rte.bat.core.item.file.transform.EgovFixedLengthTokenizer;
import org.egovframe.rte.bat.core.item.file.transform.EgovLineTokenizer;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

/**
 * 고정길이 파일 → JDBC 갱신 Job
 */
@Configuration
public class FixedLengthToJdbcJobConfig {

	@Bean
	public Job fixedLengthToJdbcJob(JobRepository jobRepository, Step fixedLengthToJdbcStep) {
		return new JobBuilder("fixedLengthToJdbcJob", jobRepository)
				.start(fixedLengthToJdbcStep)
				.build();
	}

	@Bean
	public Step fixedLengthToJdbcStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			FlatFileItemReader<CustomerCredit> fixedLengthToJdbcItemReader, EgovJdbcBatchItemWriter<CustomerCredit> fixedLengthToJdbcItemWriter) {
		return new StepBuilder("fixedLengthToJdbcStep", jobRepository)
				.<CustomerCredit, CustomerCredit>chunk(2, transactionManager)
				.reader(fixedLengthToJdbcItemReader)
				.processor(new CustomerCreditIncreaseProcessor())
				.writer(fixedLengthToJdbcItemWriter)
				.build();
	}

	@Bean
	@StepScope
	public FlatFileItemReader<CustomerCredit> fixedLengthToJdbcItemReader(@Value("#{jobParameters['inputFile']}") String inputFile,
			ResourceLoader resourceLoader, EgovDefaultLineMapper<CustomerCredit> fixedLengthToJdbcLineMapper) {
		return new FlatFileItemReaderBuilder<CustomerCredit>()
				.name("fixedLengthToJdbcItemReader")
				.resource(resourceLoader.getResource(inputFile))
				.lineMapper(fixedLengthToJdbcLineMapper)
				.saveState(false)
				.build();
	}

	@Bean
	public EgovObjectMapper<CustomerCredit> fixedLengthToJdbcObjectMapper() {
		EgovObjectMapper<CustomerCredit> objectMapper = new EgovObjectMapper<>();
		objectMapper.setType(CustomerCredit.class);
		objectMapper.setNames(new String[] {"name", "credit"});
		return objectMapper;
	}

	@Bean
	@SuppressWarnings({"unchecked", "rawtypes"})
	public EgovDefaultLineMapper<CustomerCredit> fixedLengthToJdbcLineMapper(EgovObjectMapper<CustomerCredit> fixedLengthToJdbcObjectMapper) {
		EgovFixedLengthTokenizer tokenizer = new EgovFixedLengthTokenizer();
		tokenizer.setColumns(new Range[] {new Range(1, 9), new Range(10, 11)});

		EgovDefaultLineMapper<CustomerCredit> lineMapper = new EgovDefaultLineMapper<>();
		// rte 토크나이저는 EgovLineTokenizer<Object> 로 선언되어 있어 형변환 필요
		lineMapper.setLineTokenizer((EgovLineTokenizer) tokenizer);
		lineMapper.setObjectMapper(fixedLengthToJdbcObjectMapper);
		return lineMapper;
	}

	/** PreparedStatement 바인딩으로 SQL 삽입 방지 */
	@Bean
	@StepScope
	public EgovJdbcBatchItemWriter<CustomerCredit> fixedLengthToJdbcItemWriter(DataSource dataSource) {
		EgovJdbcBatchItemWriter<CustomerCredit> writer = new EgovJdbcBatchItemWriter<>();
		writer.setAssertUpdates(true);
		writer.setItemPreparedStatementSetter(new EgovMethodMapItemPreparedStatementSetter<>());
		writer.setSql("UPDATE CUSTOMER SET CREDIT = ? WHERE NAME = ?");
		writer.setParams(new String[] {"credit", "name"});
		writer.setDataSource(dataSource);
		return writer;
	}

}
