package egovframework.example.bat.job;

import org.apache.ibatis.session.SqlSessionFactory;
import org.egovframe.rte.bat.core.item.database.EgovMyBatisBatchItemWriter;
import org.egovframe.rte.bat.core.item.file.mapping.EgovDefaultLineMapper;
import org.egovframe.rte.bat.core.item.file.mapping.EgovObjectMapper;
import org.egovframe.rte.bat.core.item.file.transform.EgovFixedLengthTokenizer;
import org.egovframe.rte.bat.core.item.file.transform.EgovLineTokenizer;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

/**
 * 고정길이 파일 → MyBatis 갱신 Job
 */
@Configuration
public class FixedLengthToMybatisJobConfig {

	@Bean
	public Job fixedLengthToMybatisJob(JobRepository jobRepository, Step fixedLengthToMybatisStep) {
		return new JobBuilder("fixedLengthToMybatisJob", jobRepository)
				.start(fixedLengthToMybatisStep)
				.build();
	}

	@Bean
	public Step fixedLengthToMybatisStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			FlatFileItemReader<CustomerCredit> fixedLengthToMybatisItemReader, EgovMyBatisBatchItemWriter<CustomerCredit> fixedLengthToMybatisItemWriter) {
		return new StepBuilder("fixedLengthToMybatisStep", jobRepository)
				.<CustomerCredit, CustomerCredit>chunk(2, transactionManager)
				.reader(fixedLengthToMybatisItemReader)
				.processor(new CustomerCreditIncreaseProcessor())
				.writer(fixedLengthToMybatisItemWriter)
				.build();
	}

	@Bean
	@StepScope
	public FlatFileItemReader<CustomerCredit> fixedLengthToMybatisItemReader(@Value("#{jobParameters['inputFile']}") String inputFile,
			ResourceLoader resourceLoader, EgovDefaultLineMapper<CustomerCredit> fixedLengthToMybatisLineMapper) {
		return new FlatFileItemReaderBuilder<CustomerCredit>()
				.name("fixedLengthToMybatisItemReader")
				.resource(resourceLoader.getResource(inputFile))
				.lineMapper(fixedLengthToMybatisLineMapper)
				.saveState(false)
				.build();
	}

	@Bean
	public EgovObjectMapper<CustomerCredit> fixedLengthToMybatisObjectMapper() {
		EgovObjectMapper<CustomerCredit> objectMapper = new EgovObjectMapper<>();
		objectMapper.setType(CustomerCredit.class);
		objectMapper.setNames(new String[] {"name", "credit"});
		return objectMapper;
	}

	@Bean
	@SuppressWarnings({"unchecked", "rawtypes"})
	public EgovDefaultLineMapper<CustomerCredit> fixedLengthToMybatisLineMapper(EgovObjectMapper<CustomerCredit> fixedLengthToMybatisObjectMapper) {
		EgovFixedLengthTokenizer tokenizer = new EgovFixedLengthTokenizer();
		tokenizer.setColumns(new Range[] {new Range(1, 9), new Range(10, 11)});

		EgovDefaultLineMapper<CustomerCredit> lineMapper = new EgovDefaultLineMapper<>();
		// rte 토크나이저는 EgovLineTokenizer<Object> 로 선언되어 있어 형변환 필요
		lineMapper.setLineTokenizer((EgovLineTokenizer) tokenizer);
		lineMapper.setObjectMapper(fixedLengthToMybatisObjectMapper);
		return lineMapper;
	}

	@Bean
	@StepScope
	public EgovMyBatisBatchItemWriter<CustomerCredit> fixedLengthToMybatisItemWriter(SqlSessionFactory sqlSessionFactory) {
		EgovMyBatisBatchItemWriter<CustomerCredit> writer = new EgovMyBatisBatchItemWriter<>();
		writer.setSqlSessionFactory(sqlSessionFactory);
		writer.setStatementId("Customer.updateCredit");
		return writer;
	}

}
