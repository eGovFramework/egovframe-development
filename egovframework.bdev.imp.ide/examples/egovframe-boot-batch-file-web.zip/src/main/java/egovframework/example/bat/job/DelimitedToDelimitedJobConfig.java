package egovframework.example.bat.job;

import org.egovframe.rte.bat.core.item.file.mapping.EgovDefaultLineMapper;
import org.egovframe.rte.bat.core.item.file.mapping.EgovObjectMapper;
import org.egovframe.rte.bat.core.item.file.transform.EgovDelimitedLineTokenizer;
import org.egovframe.rte.bat.core.item.file.transform.EgovFieldExtractor;
import org.egovframe.rte.bat.core.item.file.transform.EgovLineTokenizer;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

/**
 * 구분자(CSV) 파일 → 구분자(CSV) 파일 Job
 */
@Configuration
public class DelimitedToDelimitedJobConfig {

	@Bean
	public Job delimitedToDelimitedJob(JobRepository jobRepository, Step delimitedToDelimitedStep) {
		return new JobBuilder("delimitedToDelimitedJob", jobRepository)
				.start(delimitedToDelimitedStep)
				.build();
	}

	@Bean
	public Step delimitedToDelimitedStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			FlatFileItemReader<CustomerCredit> delimitedToDelimitedItemReader, FlatFileItemWriter<CustomerCredit> delimitedToDelimitedItemWriter) {
		return new StepBuilder("delimitedToDelimitedStep", jobRepository)
				.<CustomerCredit, CustomerCredit>chunk(2, transactionManager)
				.reader(delimitedToDelimitedItemReader)
				.processor(new CustomerCreditIncreaseProcessor())
				.writer(delimitedToDelimitedItemWriter)
				.build();
	}

	@Bean
	@StepScope
	public FlatFileItemReader<CustomerCredit> delimitedToDelimitedItemReader(@Value("#{jobParameters['inputFile']}") String inputFile,
			ResourceLoader resourceLoader, EgovDefaultLineMapper<CustomerCredit> delimitedToDelimitedLineMapper) {
		return new FlatFileItemReaderBuilder<CustomerCredit>()
				.name("delimitedToDelimitedItemReader")
				.resource(resourceLoader.getResource(inputFile))
				.lineMapper(delimitedToDelimitedLineMapper)
				.saveState(false)
				.build();
	}

	@Bean
	public EgovObjectMapper<CustomerCredit> delimitedToDelimitedObjectMapper() {
		EgovObjectMapper<CustomerCredit> objectMapper = new EgovObjectMapper<>();
		objectMapper.setType(CustomerCredit.class);
		objectMapper.setNames(new String[] {"name", "credit"});
		return objectMapper;
	}

	@Bean
	@SuppressWarnings({"unchecked", "rawtypes"})
	public EgovDefaultLineMapper<CustomerCredit> delimitedToDelimitedLineMapper(EgovObjectMapper<CustomerCredit> delimitedToDelimitedObjectMapper) {
		EgovDelimitedLineTokenizer tokenizer = new EgovDelimitedLineTokenizer();
		tokenizer.setDelimiter(",");

		EgovDefaultLineMapper<CustomerCredit> lineMapper = new EgovDefaultLineMapper<>();
		// rte 토크나이저는 EgovLineTokenizer<Object> 로 선언되어 있어 형변환 필요
		lineMapper.setLineTokenizer((EgovLineTokenizer) tokenizer);
		lineMapper.setObjectMapper(delimitedToDelimitedObjectMapper);
		return lineMapper;
	}

	/** outputFile: 서버에서 지정한 경로만 사용 (BatchRunController) */
	@Bean
	@StepScope
	public FlatFileItemWriter<CustomerCredit> delimitedToDelimitedItemWriter(@Value("#{jobParameters['outputFile']}") String outputFile,
			DelimitedLineAggregator<CustomerCredit> delimitedToDelimitedLineAggregator) {
		return new FlatFileItemWriterBuilder<CustomerCredit>()
				.name("delimitedToDelimitedItemWriter")
				.resource(new FileSystemResource(outputFile))
				.lineAggregator(delimitedToDelimitedLineAggregator)
				.saveState(false)
				.build();
	}

	@Bean
	public EgovFieldExtractor<CustomerCredit> delimitedToDelimitedFieldExtractor() {
		EgovFieldExtractor<CustomerCredit> fieldExtractor = new EgovFieldExtractor<>();
		fieldExtractor.setNames(new String[] {"name", "credit"});
		return fieldExtractor;
	}

	@Bean
	public DelimitedLineAggregator<CustomerCredit> delimitedToDelimitedLineAggregator(EgovFieldExtractor<CustomerCredit> delimitedToDelimitedFieldExtractor) {
		DelimitedLineAggregator<CustomerCredit> lineAggregator = new DelimitedLineAggregator<>();
		lineAggregator.setDelimiter(",");
		lineAggregator.setFieldExtractor(delimitedToDelimitedFieldExtractor);
		return lineAggregator;
	}

}
