package egovframework.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.egovframe.rte.bat.core.launch.support.EgovCommandLineRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.util.StringUtils;

/**
 * 배치 CommandLine 실행 애플리케이션
 * <pre>
 * java -jar {jar} [jobPath] [jobIdentifier] [key=value ...] [-restart|-next]
 *  - jobPath       : Job 정의 context xml (기본 /egovframework/batch/context-commandline.xml)
 *  - jobIdentifier : mybatisToDelimitedJob, mybatisToFixedLengthJob, mybatisToMybatisJob, jdbcToJdbcJob
 * </pre>
 */
public class EgovBootApplication implements CommandLineRunner {

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovBootApplication.class);

	private static final String DEFAULT_JOB_PATH = "/egovframework/batch/context-commandline.xml";
	private static final String DEFAULT_JOB_IDENTIFIER = "jdbcToJdbcJob";

	public static void main(String[] args) {
		SpringApplication application = new SpringApplication(EgovBootApplication.class);
		application.setWebApplicationType(WebApplicationType.NONE);
		application.run(args);
	}

	@Override
	public void run(String... args) {
		List<String> arguments = new ArrayList<>(Arrays.asList(args));
		arguments.addAll(readStdinArguments());

		Set<String> opts = new HashSet<>();
		List<String> params = new ArrayList<>();
		String jobPath = null;
		String jobIdentifier = null;

		for (String arg : arguments) {
			if (arg.startsWith("-")) {
				opts.add(arg);
			} else if (jobPath == null) {
				jobPath = arg;
			} else if (jobIdentifier == null) {
				jobIdentifier = arg;
			} else {
				params.add(arg);
			}
		}

		if (jobPath == null) {
			jobPath = DEFAULT_JOB_PATH;
		}
		if (jobIdentifier == null) {
			jobIdentifier = DEFAULT_JOB_IDENTIFIER;
		}
		LOGGER.info("jobPath={}, jobIdentifier={}", jobPath, jobIdentifier);

		// 재실행 가능하도록 유일 파라미터 추가
		params.add("timestamp=" + System.currentTimeMillis());

		EgovCommandLineRunner command = new EgovCommandLineRunner();
		int result = command.start(jobPath, jobIdentifier, params.toArray(new String[0]), opts);
		command.exit(result);
	}

	/** 표준입력으로 전달된 인수(파이프), '#' 주석 줄 제외 */
	private List<String> readStdinArguments() {
		List<String> result = new ArrayList<>();
		try {
			if (System.in.available() > 0) {
				BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
				String line;
				while ((line = reader.readLine()) != null && StringUtils.hasLength(line)) {
					if (!line.startsWith("#") && StringUtils.hasText(line)) {
						result.add(line.trim());
					}
				}
			}
		} catch (IOException e) {
			LOGGER.warn("Could not read arguments from stdin");
		}
		return result;
	}

}
