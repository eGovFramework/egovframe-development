java -cp ./hsqldb-2.3.2.jar org.hsqldb.util.DatabaseManager -url jdbc:hsqldb:hsql://localhost/sampledb
