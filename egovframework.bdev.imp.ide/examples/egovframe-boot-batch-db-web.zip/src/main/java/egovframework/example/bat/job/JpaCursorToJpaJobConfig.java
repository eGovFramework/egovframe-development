package egovframework.example.bat.job;

import java.util.Map;

import jakarta.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JpaCursorItemReader;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.batch.item.database.builder.JpaCursorItemReaderBuilder;
import org.springframework.batch.item.database.builder.JpaItemWriterBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.domain.jpa.Customer;
import egovframework.example.bat.domain.jpa.CustomerIncreaseProcessor;

/**
 * JPA Cursor 조회 → JPA 저장 Job
 */
@Configuration
public class JpaCursorToJpaJobConfig {

	@Bean
	public Job jpaCursorToJpaJob(JobRepository jobRepository, Step jpaCursorToJpaStep) {
		return new JobBuilder("jpaCursorToJpaJob", jobRepository)
				.start(jpaCursorToJpaStep)
				.build();
	}

	@Bean
	public Step jpaCursorToJpaStep(JobRepository jobRepository,
			@Qualifier("jpaTransactionManager") PlatformTransactionManager transactionManager,
			JpaCursorItemReader<Customer> jpaCursorItemReader, JpaItemWriter<Customer> jpaCursorBatchItemWriter) {
		return new StepBuilder("jpaCursorToJpaStep", jobRepository)
				.<Customer, Customer>chunk(2, transactionManager)
				.reader(jpaCursorItemReader)
				.processor(new CustomerIncreaseProcessor())
				.writer(jpaCursorBatchItemWriter)
				.build();
	}

	/** 조회 조건은 바인딩 파라미터로 전달 */
	@Bean
	@StepScope
	public JpaCursorItemReader<Customer> jpaCursorItemReader(EntityManagerFactory entityManagerFactory) {
		return new JpaCursorItemReaderBuilder<Customer>()
				.name("jpaCursorItemReader")
				.entityManagerFactory(entityManagerFactory)
				.queryString("select c from Customer c where c.id < 1000 and c.name like :name")
				.parameterValues(Map.of("name", "%"))
				.build();
	}

	@Bean
	@StepScope
	public JpaItemWriter<Customer> jpaCursorBatchItemWriter(EntityManagerFactory entityManagerFactory) {
		return new JpaItemWriterBuilder<Customer>()
				.entityManagerFactory(entityManagerFactory)
				.usePersist(true)
				.build();
	}

}
