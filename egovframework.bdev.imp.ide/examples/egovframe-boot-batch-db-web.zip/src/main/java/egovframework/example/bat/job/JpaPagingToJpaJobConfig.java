package egovframework.example.bat.job;

import jakarta.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.batch.item.database.builder.JpaItemWriterBuilder;
import org.springframework.batch.item.database.builder.JpaPagingItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.domain.jpa.Customer;
import egovframework.example.bat.domain.jpa.Customer2;
import egovframework.example.bat.domain.jpa.CustomerIncreaseProcessor2;

/**
 * JPA Paging 조회(CUSTOMER) → JPA 저장(CUSTOMER2) Job
 */
@Configuration
public class JpaPagingToJpaJobConfig {

	@Bean
	public Job jpaPagingToJpaJob(JobRepository jobRepository, Step jpaPagingToJpaStep) {
		return new JobBuilder("jpaPagingToJpaJob", jobRepository)
				.start(jpaPagingToJpaStep)
				.build();
	}

	@Bean
	public Step jpaPagingToJpaStep(JobRepository jobRepository,
			@Qualifier("jpaTransactionManager") PlatformTransactionManager transactionManager,
			JpaPagingItemReader<Customer> jpaPagingItemReader, JpaItemWriter<Customer2> jpaPagingBatchItemWriter) {
		return new StepBuilder("jpaPagingToJpaStep", jobRepository)
				.<Customer, Customer2>chunk(2, transactionManager)
				.reader(jpaPagingItemReader)
				.processor(new CustomerIncreaseProcessor2())
				.writer(jpaPagingBatchItemWriter)
				.build();
	}

	@Bean
	@StepScope
	public JpaPagingItemReader<Customer> jpaPagingItemReader(EntityManagerFactory entityManagerFactory) {
		return new JpaPagingItemReaderBuilder<Customer>()
				.name("jpaPagingItemReader")
				.entityManagerFactory(entityManagerFactory)
				.pageSize(2)
				.queryString("select c from Customer c")
				.build();
	}

	@Bean
	@StepScope
	public JpaItemWriter<Customer2> jpaPagingBatchItemWriter(EntityManagerFactory entityManagerFactory) {
		return new JpaItemWriterBuilder<Customer2>()
				.entityManagerFactory(entityManagerFactory)
				.usePersist(true)
				.build();
	}

}
