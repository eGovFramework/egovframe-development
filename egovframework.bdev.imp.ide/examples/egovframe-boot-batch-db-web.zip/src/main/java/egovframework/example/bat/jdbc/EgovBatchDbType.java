package egovframework.example.bat.jdbc;

import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.batch.item.database.support.DataFieldMaxValueIncrementerFactory;
import org.springframework.batch.item.database.support.DefaultDataFieldMaxValueIncrementerFactory;

import egovframework.example.bat.jdbc.cubrid.incrementer.CubridDataFieldMaxValueIncrementerFactory;

/**
 * Globals.DbType → Spring Batch 메타 DB 유형 · 시퀀스 Incrementer · 생성 격리수준 매핑
 * (Tibero · Altibase · Cubrid · Goldilocks 는 Oracle 호환 시퀀스로 처리)
 */
public final class EgovBatchDbType {

	private static final Map<String, String> DATABASE_TYPES = Map.of(
			"hsql", "HSQL",
			"mysql", "MYSQL",
			"maria", "MARIADB",
			"postgres", "POSTGRES",
			"oracle", "ORACLE",
			"tibero", "ORACLE",
			"altibase", "ORACLE",
			"cubrid", "ORACLE",
			"goldilocks", "ORACLE");

	/** SERIALIZABLE 미지원/제약 DB : 메타 데이터 생성 시 READ_COMMITTED 사용 */
	private static final Set<String> READ_COMMITTED_DBS = Set.of("tibero", "altibase", "cubrid", "goldilocks");

	private EgovBatchDbType() {
	}

	public static String databaseType(String dbType) {
		String type = DATABASE_TYPES.get(dbType);
		if (type == null) {
			throw new IllegalArgumentException("Unsupported Globals.DbType: " + dbType);
		}
		return type;
	}

	public static DataFieldMaxValueIncrementerFactory incrementerFactory(DataSource dataSource, String dbType) {
		return "cubrid".equals(dbType) ? new CubridDataFieldMaxValueIncrementerFactory(dataSource)
				: new DefaultDataFieldMaxValueIncrementerFactory(dataSource);
	}

	public static String isolationLevelForCreate(String dbType) {
		return READ_COMMITTED_DBS.contains(dbType) ? "ISOLATION_READ_COMMITTED" : "ISOLATION_SERIALIZABLE";
	}

}
