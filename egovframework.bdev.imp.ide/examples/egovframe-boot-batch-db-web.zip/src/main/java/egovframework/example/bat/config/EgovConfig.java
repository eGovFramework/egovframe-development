package egovframework.example.bat.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * 공통 프로퍼티(globals.properties) 로딩
 */
@Configuration
@PropertySource(value = "classpath:/egovframework/egovProps/globals.properties", encoding = "UTF-8")
public class EgovConfig {

}
