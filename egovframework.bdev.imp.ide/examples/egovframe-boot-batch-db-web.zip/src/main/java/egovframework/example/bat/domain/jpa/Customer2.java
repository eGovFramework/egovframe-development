package egovframework.example.bat.domain.jpa;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * CUSTOMER2 테이블 JPA 엔티티
 */
@Entity
@Table(name = "CUSTOMER2")
public class Customer2 {

	@Id
	@Column(name = "ID")
	private long id;
	private long version;
	private String name;
	private BigDecimal credit;

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getVersion() {
		return version;
	}
	public void setVersion(long version) {
		this.version = version;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getCredit() {
		return credit;
	}
	public void setCredit(BigDecimal credit) {
		this.credit = credit;
	}

}