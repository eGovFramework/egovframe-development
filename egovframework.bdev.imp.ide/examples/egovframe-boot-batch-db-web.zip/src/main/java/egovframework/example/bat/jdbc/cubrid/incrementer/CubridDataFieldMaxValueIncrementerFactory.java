package egovframework.example.bat.jdbc.cubrid.incrementer;

import javax.sql.DataSource;

import org.springframework.batch.item.database.support.DefaultDataFieldMaxValueIncrementerFactory;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;

/**
 * Cubrid 용 Batch 메타 테이블 Incrementer Factory
 */
public class CubridDataFieldMaxValueIncrementerFactory extends DefaultDataFieldMaxValueIncrementerFactory {
	private DataSource dataSource;

	public CubridDataFieldMaxValueIncrementerFactory(DataSource dataSource) {
		super(dataSource);
		this.dataSource = dataSource;
	}

	@Override
	public DataFieldMaxValueIncrementer getIncrementer(String incrementerType, String incrementerName) {

		return new CubridSequenceMaxValueIncrementer(dataSource, incrementerName);
	}

}
