package egovframework.example.bat.job;

import org.apache.ibatis.session.SqlSessionFactory;
import org.egovframe.rte.bat.core.item.database.EgovMyBatisPagingItemReader;
import org.egovframe.rte.bat.core.item.file.transform.EgovFieldExtractor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

/**
 * MyBatis 조회 → 구분자(CSV) 파일 저장 Job
 */
@Configuration
public class MybatisToDelimitedJobConfig {

	@Bean
	public Job mybatisToDelimitedJob(JobRepository jobRepository, Step mybatisToDelimitedStep) {
		return new JobBuilder("mybatisToDelimitedJob", jobRepository)
				.start(mybatisToDelimitedStep)
				.build();
	}

	@Bean
	public Step mybatisToDelimitedStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			EgovMyBatisPagingItemReader<CustomerCredit> mybatisToDelimitedPagingItemReader,
			FlatFileItemWriter<CustomerCredit> delimitedItemWriter) {
		return new StepBuilder("mybatisToDelimitedStep", jobRepository)
				.<CustomerCredit, CustomerCredit>chunk(2, transactionManager)
				.reader(mybatisToDelimitedPagingItemReader)
				.processor(new CustomerCreditIncreaseProcessor())
				.writer(delimitedItemWriter)
				.build();
	}

	@Bean
	@StepScope
	public EgovMyBatisPagingItemReader<CustomerCredit> mybatisToDelimitedPagingItemReader(SqlSessionFactory sqlSessionFactory) {
		EgovMyBatisPagingItemReader<CustomerCredit> reader = new EgovMyBatisPagingItemReader<>();
		reader.setSqlSessionFactory(sqlSessionFactory);
		reader.setQueryId("Customer.getAllCustomerCredits");
		reader.setPageSize(10);
		return reader;
	}

	/** outputFile: 서버에서 지정한 경로만 사용 (BatchRunController) */
	@Bean
	@StepScope
	public FlatFileItemWriter<CustomerCredit> delimitedItemWriter(@Value("#{jobParameters['outputFile']}") String outputFile,
			DelimitedLineAggregator<CustomerCredit> delimitedLineAggregator) {
		return new FlatFileItemWriterBuilder<CustomerCredit>()
				.name("delimitedItemWriter")
				.resource(new FileSystemResource(outputFile))
				.lineAggregator(delimitedLineAggregator)
				.saveState(false)
				.build();
	}

	@Bean
	public EgovFieldExtractor<CustomerCredit> delimitedFieldExtractor() {
		EgovFieldExtractor<CustomerCredit> fieldExtractor = new EgovFieldExtractor<>();
		fieldExtractor.setNames(new String[] {"name", "credit"});
		return fieldExtractor;
	}

	@Bean
	public DelimitedLineAggregator<CustomerCredit> delimitedLineAggregator(EgovFieldExtractor<CustomerCredit> delimitedFieldExtractor) {
		DelimitedLineAggregator<CustomerCredit> lineAggregator = new DelimitedLineAggregator<>();
		lineAggregator.setDelimiter(",");
		lineAggregator.setFieldExtractor(delimitedFieldExtractor);
		return lineAggregator;
	}

}
