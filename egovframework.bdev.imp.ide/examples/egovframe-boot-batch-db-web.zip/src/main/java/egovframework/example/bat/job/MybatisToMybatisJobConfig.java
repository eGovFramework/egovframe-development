package egovframework.example.bat.job;

import org.apache.ibatis.session.SqlSessionFactory;
import org.egovframe.rte.bat.core.item.database.EgovMyBatisBatchItemWriter;
import org.egovframe.rte.bat.core.item.database.EgovMyBatisPagingItemReader;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

/**
 * MyBatis 조회 → MyBatis 갱신 Job
 */
@Configuration
public class MybatisToMybatisJobConfig {

	@Bean
	public Job myBatisToMybatisJob(JobRepository jobRepository, Step myBatisToMybatisJobStep) {
		return new JobBuilder("myBatisToMybatisJob", jobRepository)
				.start(myBatisToMybatisJobStep)
				.build();
	}

	@Bean
	public Step myBatisToMybatisJobStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			EgovMyBatisPagingItemReader<CustomerCredit> mybatisToMybatisPagingItemReader,
			EgovMyBatisBatchItemWriter<CustomerCredit> myBatisBatchItemWriter) {
		return new StepBuilder("myBatisToMybatisStep", jobRepository)
				.<CustomerCredit, CustomerCredit>chunk(2, transactionManager)
				.reader(mybatisToMybatisPagingItemReader)
				.processor(new CustomerCreditIncreaseProcessor())
				.writer(myBatisBatchItemWriter)
				.build();
	}

	@Bean
	@StepScope
	public EgovMyBatisPagingItemReader<CustomerCredit> mybatisToMybatisPagingItemReader(SqlSessionFactory sqlSessionFactory) {
		EgovMyBatisPagingItemReader<CustomerCredit> reader = new EgovMyBatisPagingItemReader<>();
		reader.setSqlSessionFactory(sqlSessionFactory);
		reader.setQueryId("Customer.getAllCustomerCredits");
		reader.setPageSize(10);
		return reader;
	}

	@Bean
	@StepScope
	public EgovMyBatisBatchItemWriter<CustomerCredit> myBatisBatchItemWriter(SqlSessionFactory sqlSessionFactory) {
		EgovMyBatisBatchItemWriter<CustomerCredit> writer = new EgovMyBatisBatchItemWriter<>();
		writer.setSqlSessionFactory(sqlSessionFactory);
		writer.setStatementId("Customer.updateCredit");
		return writer;
	}

}
