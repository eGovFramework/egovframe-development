package egovframework.example.bat.config;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

/**
 * MyBatis 설정 (Globals.DbType 별 Mapper : Egov_Example_SQL_{DbType}.xml)
 */
@Configuration
public class EgovConfigMapper {

	private static final String MAPPER_PATH = "egovframework/mapper/example/bat/";

	@Bean(name = "egov.sqlSession")
	public SqlSessionFactoryBean sqlSessionFactory(DataSource dataSource, @Value("${Globals.DbType}") String dbType) {
		SqlSessionFactoryBean factory = new SqlSessionFactoryBean();
		factory.setDataSource(dataSource);
		factory.setConfigLocation(new ClassPathResource("egovframework/mapper/config/mapper-config.xml"));
		factory.setMapperLocations(new ClassPathResource(MAPPER_PATH + "Egov_Example_SQL_" + dbType + ".xml"));
		return factory;
	}

}
