package egovframework.example;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

/**
 * Web MVC 설정
 */
@Configuration
public class EgovWebMvcConfiguration implements WebMvcConfigurer {

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addRedirectViewController("/", "/batchList.do");
		registry.setOrder(Ordered.HIGHEST_PRECEDENCE);
	}

	/** 예외 → 공통 오류 화면 매핑 (상세 메시지 미노출) */
	@Bean
	public SimpleMappingExceptionResolver simpleMappingExceptionResolver() {
		Properties mappings = new Properties();
		mappings.setProperty("org.springframework.dao.DataAccessException", "cmmn/dataAccessFailure");
		mappings.setProperty("org.springframework.transaction.TransactionException", "cmmn/transactionFailure");
		mappings.setProperty("org.egovframe.rte.fdl.cmmn.exception.EgovBizException", "cmmn/egovError");

		SimpleMappingExceptionResolver resolver = new SimpleMappingExceptionResolver();
		resolver.setExceptionMappings(mappings);
		resolver.setDefaultErrorView("cmmn/bizError");
		resolver.setDefaultStatusCode(500);
		return resolver;
	}

}
