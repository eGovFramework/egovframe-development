package egovframework.example.bat.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import com.zaxxer.hikari.HikariDataSource;

/**
 * DataSource 설정 (Globals.DbType : hsql → 인메모리, 그 외 → 외부 DB)
 */
@Configuration
public class EgovConfigDatasource {

	private final Environment env;

	public EgovConfigDatasource(Environment env) {
		this.env = env;
	}

	@Bean(name = "dataSource", destroyMethod = "close")
	public HikariDataSource dataSource() {
		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setMaximumPoolSize(10);
		if (!"hsql".equals(env.getRequiredProperty("Globals.DbType"))) {
			dataSource.setDriverClassName(env.getRequiredProperty("Globals.DriverClassName"));
			dataSource.setJdbcUrl(env.getRequiredProperty("Globals.Url"));
			dataSource.setUsername(env.getProperty("Globals.UserName"));
			dataSource.setPassword(env.getProperty("Globals.Password"));
			return dataSource;
		}

		dataSource.setDriverClassName("org.hsqldb.jdbc.JDBCDriver");
		dataSource.setJdbcUrl(env.getRequiredProperty("Globals.Hsql.Url"));
		dataSource.setUsername(env.getProperty("Globals.Hsql.UserName"));
		dataSource.setPassword(env.getProperty("Globals.Hsql.Password"));
		// 보안 모듈 등이 기동 중 조회하므로 생성 시점에 적재 (DATABASE/hsql 사본)
		if (env.getProperty("Globals.Hsql.AutoInit", Boolean.class, false)) {
			ResourceDatabasePopulator populator = new ResourceDatabasePopulator(
					new ClassPathResource("db/hsql/all_batch_ddl_hsql.sql"),
					new ClassPathResource("db/hsql/all_batch_data_hsql.sql"));
			populator.setSqlScriptEncoding("UTF-8");
			populator.setIgnoreFailedDrops(true);
			DatabasePopulatorUtils.execute(populator, dataSource);
		}
		return dataSource;
	}

}
