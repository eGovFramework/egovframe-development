package egovframework.example.bat.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

/**
 * 트랜잭션 설정 (JDBC/MyBatis 및 Batch 메타 저장용)
 */
@Configuration
public class EgovConfigTransaction {

	@Bean
	@Primary
	public DataSourceTransactionManager transactionManager(DataSource dataSource) {
		return new DataSourceTransactionManager(dataSource);
	}

}
