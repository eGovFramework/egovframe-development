package egovframework.example.bat.config;

import javax.sql.DataSource;

import org.egovframe.rte.bat.core.launch.support.EgovBatchRunner;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.support.MapJobRegistry;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.support.SimpleJobOperator;
import org.springframework.batch.core.launch.support.TaskExecutorJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.jdbc.EgovBatchDbType;

/**
 * Spring Batch 실행 인프라(JobRepository, JobLauncher, JobOperator) 및 EgovBatchRunner 설정
 */
@Configuration
public class EgovConfigJobLauncher {

	@Bean
	public EgovBatchRunner batchRunner(JobOperator jobOperator, JobExplorer jobExplorer, JobRepository jobRepository) {
		return new EgovBatchRunner(jobOperator, jobExplorer, jobRepository);
	}

	@Bean
	public TaskExecutorJobLauncher jobLauncher(JobRepository jobRepository) {
		TaskExecutorJobLauncher jobLauncher = new TaskExecutorJobLauncher();
		jobLauncher.setJobRepository(jobRepository);
		return jobLauncher;
	}

	/** Batch 메타 DB 유형 · 시퀀스 Incrementer · 생성 격리수준은 Globals.DbType 으로 결정 */
	@Bean
	public JobRepositoryFactoryBean jobRepository(DataSource dataSource, PlatformTransactionManager transactionManager,
			@Value("${Globals.DbType}") String dbType) {
		JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
		factory.setDataSource(dataSource);
		factory.setTransactionManager(transactionManager);
		factory.setDatabaseType(EgovBatchDbType.databaseType(dbType));
		factory.setIncrementerFactory(EgovBatchDbType.incrementerFactory(dataSource, dbType));
		factory.setIsolationLevelForCreate(EgovBatchDbType.isolationLevelForCreate(dbType));
		return factory;
	}

	@Bean
	public SimpleJobOperator jobOperator(JobLauncher jobLauncher, JobExplorer jobExplorer, JobRepository jobRepository, JobRegistry jobRegistry) {
		SimpleJobOperator jobOperator = new SimpleJobOperator();
		jobOperator.setJobLauncher(jobLauncher);
		jobOperator.setJobExplorer(jobExplorer);
		jobOperator.setJobRepository(jobRepository);
		jobOperator.setJobRegistry(jobRegistry);
		return jobOperator;
	}

	@Bean
	public JobExplorerFactoryBean jobExplorer(DataSource dataSource, PlatformTransactionManager transactionManager) {
		JobExplorerFactoryBean jobExplorer = new JobExplorerFactoryBean();
		jobExplorer.setDataSource(dataSource);
		jobExplorer.setTransactionManager(transactionManager);
		return jobExplorer;
	}

	@Bean
	public MapJobRegistry jobRegistry() {
		return new MapJobRegistry();
	}

}
