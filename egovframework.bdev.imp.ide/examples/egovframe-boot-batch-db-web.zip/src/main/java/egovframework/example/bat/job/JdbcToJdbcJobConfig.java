package egovframework.example.bat.job;

import javax.sql.DataSource;

import org.egovframe.rte.bat.core.item.database.EgovJdbcBatchItemWriter;
import org.egovframe.rte.bat.core.item.database.support.EgovMethodMapItemPreparedStatementSetter;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;
import egovframework.example.bat.domain.trade.CustomerCreditRowMapper;

/**
 * JDBC 조회 → JDBC 갱신 Job
 */
@Configuration
public class JdbcToJdbcJobConfig {

	@Bean
	public Job jdbcToJdbcJob(JobRepository jobRepository, Step jdbcToJdbcStep) {
		return new JobBuilder("jdbcToJdbcJob", jobRepository)
				.start(jdbcToJdbcStep)
				.build();
	}

	@Bean
	public Step jdbcToJdbcStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			JdbcCursorItemReader<CustomerCredit> jdbcCursorItemReader,
			EgovJdbcBatchItemWriter<CustomerCredit> jdbcBatchItemWriter) {
		return new StepBuilder("jdbcToJdbcStep", jobRepository)
				.<CustomerCredit, CustomerCredit>chunk(2, transactionManager)
				.reader(jdbcCursorItemReader)
				.processor(new CustomerCreditIncreaseProcessor())
				.writer(jdbcBatchItemWriter)
				.build();
	}

	@Bean
	@StepScope
	public JdbcCursorItemReader<CustomerCredit> jdbcCursorItemReader(DataSource dataSource) {
		return new JdbcCursorItemReaderBuilder<CustomerCredit>()
				.name("jdbcCursorItemReader")
				.dataSource(dataSource)
				.sql("SELECT ID, NAME, CREDIT FROM CUSTOMER")
				.verifyCursorPosition(true)
				.rowMapper(new CustomerCreditRowMapper())
				.build();
	}

	/** PreparedStatement 바인딩으로 SQL 삽입 방지 */
	@Bean
	@StepScope
	public EgovJdbcBatchItemWriter<CustomerCredit> jdbcBatchItemWriter(DataSource dataSource) {
		EgovJdbcBatchItemWriter<CustomerCredit> writer = new EgovJdbcBatchItemWriter<>();
		writer.setAssertUpdates(true);
		writer.setItemPreparedStatementSetter(new EgovMethodMapItemPreparedStatementSetter<>());
		writer.setSql("UPDATE CUSTOMER SET CREDIT = ? WHERE NAME = ?");
		writer.setParams(new String[] {"credit", "name"});
		writer.setDataSource(dataSource);
		return writer;
	}

}
