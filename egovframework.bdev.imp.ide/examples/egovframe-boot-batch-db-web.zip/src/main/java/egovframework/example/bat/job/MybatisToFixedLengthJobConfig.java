package egovframework.example.bat.job;

import org.apache.ibatis.session.SqlSessionFactory;
import org.egovframe.rte.bat.core.item.database.EgovMyBatisPagingItemReader;
import org.egovframe.rte.bat.core.item.file.transform.EgovFieldExtractor;
import org.egovframe.rte.bat.core.item.file.transform.EgovFixedLengthLineAggregator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

/**
 * MyBatis 조회 → 고정길이 파일 저장 Job
 */
@Configuration
public class MybatisToFixedLengthJobConfig {

	@Bean
	public Job mybatisToFixedLengthJob(JobRepository jobRepository, Step mybatisToFixedLengthStep) {
		return new JobBuilder("mybatisToFixedLengthJob", jobRepository)
				.start(mybatisToFixedLengthStep)
				.build();
	}

	@Bean
	public Step mybatisToFixedLengthStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			EgovMyBatisPagingItemReader<CustomerCredit> mybatisToFixedLengthPagingItemReader,
			FlatFileItemWriter<CustomerCredit> fixedLengthItemWriter) {
		return new StepBuilder("mybatisToFixedLengthStep", jobRepository)
				.<CustomerCredit, CustomerCredit>chunk(2, transactionManager)
				.reader(mybatisToFixedLengthPagingItemReader)
				.processor(new CustomerCreditIncreaseProcessor())
				.writer(fixedLengthItemWriter)
				.build();
	}

	@Bean
	@StepScope
	public EgovMyBatisPagingItemReader<CustomerCredit> mybatisToFixedLengthPagingItemReader(SqlSessionFactory sqlSessionFactory) {
		EgovMyBatisPagingItemReader<CustomerCredit> reader = new EgovMyBatisPagingItemReader<>();
		reader.setSqlSessionFactory(sqlSessionFactory);
		reader.setQueryId("Customer.getAllCustomerCredits");
		reader.setPageSize(10);
		return reader;
	}

	/** outputFile: 서버에서 지정한 경로만 사용 (BatchRunController) */
	@Bean
	@StepScope
	public FlatFileItemWriter<CustomerCredit> fixedLengthItemWriter(@Value("#{jobParameters['outputFile']}") String outputFile,
			EgovFixedLengthLineAggregator<CustomerCredit> fixedLengthLineAggregator) {
		return new FlatFileItemWriterBuilder<CustomerCredit>()
				.name("fixedLengthItemWriter")
				.resource(new FileSystemResource(outputFile))
				.lineAggregator(fixedLengthLineAggregator)
				.saveState(false)
				.build();
	}

	@Bean
	public EgovFieldExtractor<CustomerCredit> fixedLengthFieldExtractor() {
		EgovFieldExtractor<CustomerCredit> fieldExtractor = new EgovFieldExtractor<>();
		fieldExtractor.setNames(new String[] {"name", "credit"});
		return fieldExtractor;
	}

	@Bean
	public EgovFixedLengthLineAggregator<CustomerCredit> fixedLengthLineAggregator(EgovFieldExtractor<CustomerCredit> fixedLengthFieldExtractor) {
		EgovFixedLengthLineAggregator<CustomerCredit> lineAggregator = new EgovFixedLengthLineAggregator<>();
		lineAggregator.setFieldRanges(new int[] {9, 9});
		lineAggregator.setFieldExtractor(fixedLengthFieldExtractor);
		return lineAggregator;
	}

}
