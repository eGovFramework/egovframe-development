package egovframework.example.bat.web;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.egovframe.rte.bat.core.launch.support.EgovBatchRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 배치 Job 목록 조회/실행
 */
@Controller
public class BatchRunController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BatchRunController.class);

	private final EgovBatchRunner egovBatchRunner;

	/** 결과 파일 저장 경로 (Globals.OutputDir) */
	private final File outputDirectory;

	public BatchRunController(EgovBatchRunner egovBatchRunner, @Value("${Globals.OutputDir}") String outputDir) {
		this.egovBatchRunner = egovBatchRunner;
		this.outputDirectory = new File(outputDir).getAbsoluteFile();
	}

	@GetMapping("/batchList.do")
	public String getBatchList(Model model) {
		model.addAttribute("jobList", egovBatchRunner.getJobNames());
		return "bat/web/EgovBatchList";
	}

	@PostMapping("/batchRun.do")
	public String batchRun(@RequestParam(value = "jobName", required = false) String jobName, Model model) {
		// 등록된 Job 만 실행 허용
		if (jobName == null || !egovBatchRunner.getJobNames().contains(jobName)) {
			model.addAttribute("errorMessage", "실행할 수 없는 Job 입니다.");
			return "bat/web/EgovBatchRunResult";
		}

		try {
			Long executionId = egovBatchRunner.start(jobName, getUniqueJobParameters(jobName));
			JobExecution jobExecution = egovBatchRunner.getJobExecution(executionId);

			Map<String, Object> jobInstance = new HashMap<>();
			jobInstance.put("id", jobExecution.getJobInstance().getId());
			jobInstance.put("name", jobExecution.getJobInstance().getJobName());
			jobInstance.put("parameters", jobExecution.getJobParameters());
			jobInstance.put("startTime", jobExecution.getStartTime());
			jobInstance.put("endTime", jobExecution.getEndTime());
			jobInstance.put("isRunning", jobExecution.getStatus().isRunning());
			jobInstance.put("exitStatus", jobExecution.getExitStatus().getExitCode());

			List<Map<String, Object>> stepsInfo = new ArrayList<>();
			for (StepExecution stepExecution : jobExecution.getStepExecutions()) {
				Map<String, Object> stepInfo = new HashMap<>();
				stepInfo.put("stepId", stepExecution.getId());
				stepInfo.put("stepName", stepExecution.getStepName());
				stepInfo.put("readCount", stepExecution.getReadCount());
				stepInfo.put("writeCount", stepExecution.getWriteCount());
				stepInfo.put("readSkipCount", stepExecution.getReadSkipCount());
				stepInfo.put("processSkipCount", stepExecution.getProcessSkipCount());
				stepInfo.put("writeSkipCount", stepExecution.getWriteSkipCount());
				stepInfo.put("totalSkipCount", stepExecution.getSkipCount());
				stepInfo.put("commitCount", stepExecution.getCommitCount());
				stepInfo.put("rollbackCount", stepExecution.getRollbackCount());
				stepInfo.put("exitStatus", stepExecution.getExitStatus().getExitCode());
				stepsInfo.add(stepInfo);
			}

			model.addAttribute("jobInstances", jobInstance);
			model.addAttribute("stepsInfo", stepsInfo);
		} catch (Exception e) {
			// 상세 오류는 로그로만 기록
			LOGGER.error("Batch job execution failed: {}", jobName, e);
			model.addAttribute("errorMessage", "Job 실행 중 오류가 발생했습니다.");
		}

		return "bat/web/EgovBatchRunResult";
	}

	/** Job 파라미터: 실행시각(유일값) + 서버 지정 출력 파일 */
	private Properties getUniqueJobParameters(String jobName) {
		Properties properties = egovBatchRunner.createUniqueJobParameters();

		String outputFileName;
		if ("mybatisToFixedLengthJob".equals(jobName)) {
			outputFileName = "txtOutput.txt";
		} else if ("mybatisToDelimitedJob".equals(jobName)) {
			outputFileName = "csvOutput.csv";
		} else {
			return properties;
		}

		if (!outputDirectory.isDirectory() && !outputDirectory.mkdirs()) {
			throw new IllegalStateException("Cannot create output directory");
		}
		properties.setProperty("outputFile", new File(outputDirectory, outputFileName).getPath());
		return properties;
	}

}
