package egovframework.example.bat.jdbc.cubrid.incrementer;

import javax.sql.DataSource;

import org.springframework.jdbc.support.incrementer.AbstractSequenceMaxValueIncrementer;

/**
 * Cubrid 시퀀스 Incrementer (SELECT {serial}.nextval FROM db_root)
 */
public class CubridSequenceMaxValueIncrementer extends AbstractSequenceMaxValueIncrementer {

	public CubridSequenceMaxValueIncrementer() {
	}

	public CubridSequenceMaxValueIncrementer(DataSource dataSource, String incrementerName) {
		super(dataSource, incrementerName);
	}

	@Override
	protected String getSequenceQuery() {
		return "select " + getIncrementerName() + ".nextval from db_root";
	}

}
