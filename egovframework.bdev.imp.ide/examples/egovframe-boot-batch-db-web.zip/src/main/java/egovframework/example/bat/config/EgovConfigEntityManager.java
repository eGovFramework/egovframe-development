package egovframework.example.bat.config;

import java.util.Map;

import javax.sql.DataSource;

import jakarta.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

/**
 * JPA 설정 (JPA Job 전용 jpaTransactionManager, 테이블은 DATABASE 스크립트로 생성)
 */
@Configuration
public class EgovConfigEntityManager {

	/** 메타데이터로 판별되지 않는 Oracle 호환 DB 의 Hibernate Dialect */
	private static final Map<String, String> DIALECTS = Map.of(
			"tibero", "org.hibernate.dialect.OracleDialect",
			"goldilocks", "org.hibernate.dialect.OracleDialect");

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource,
			@Value("${Globals.DbType}") String dbType) {
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		vendorAdapter.setGenerateDdl(false);
		if (DIALECTS.containsKey(dbType)) {
			vendorAdapter.setDatabasePlatform(DIALECTS.get(dbType));
		}

		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
		factory.setJpaVendorAdapter(vendorAdapter);
		factory.setPackagesToScan("egovframework.example.bat.domain.jpa");
		factory.setDataSource(dataSource);
		return factory;
	}

	@Bean
	public JpaTransactionManager jpaTransactionManager(EntityManagerFactory entityManagerFactory) {
		return new JpaTransactionManager(entityManagerFactory);
	}

}
