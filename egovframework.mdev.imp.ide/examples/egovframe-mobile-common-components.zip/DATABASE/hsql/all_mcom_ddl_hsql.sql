-- HSQLDB MySQL 호환 설정 (DDL/DML 이전 실행)
SET DATABASE SQL SYNTAX MYS TRUE;

-- MySQL DATE_FORMAT 호환 함수 (매퍼 SQL 공용)
CREATE FUNCTION DATE_FORMAT(P_DT TIMESTAMP, P_FMT VARCHAR(100)) RETURNS VARCHAR(100)
	DETERMINISTIC CONTAINS SQL
	RETURN TO_CHAR(P_DT, REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(P_FMT,
		'%Y', 'YYYY'), '%m', 'MM'), '%d', 'DD'), '%H', 'HH24'), '%i', 'MI'), '%s', 'SS'), '%S', 'SS'));

CREATE FUNCTION DATE_FORMAT(P_DT DATE, P_FMT VARCHAR(100)) RETURNS VARCHAR(100)
	DETERMINISTIC CONTAINS SQL
	RETURN DATE_FORMAT(CAST(P_DT AS TIMESTAMP), P_FMT);

-- 문자열 일자(YYYYMMDD, YYYYMMDDHH24MISS, YYYY-MM-DD[ HH:MI:SS])
CREATE FUNCTION DATE_FORMAT(P_DT VARCHAR(40), P_FMT VARCHAR(100)) RETURNS VARCHAR(100)
	DETERMINISTIC CONTAINS SQL
	RETURN CASE
		WHEN P_DT IS NULL OR TRIM(P_DT) = '' THEN NULL
		WHEN REGEXP_MATCHES(TRIM(P_DT), '[0-9]{14}') THEN DATE_FORMAT(TO_TIMESTAMP(TRIM(P_DT), 'YYYYMMDDHH24MISS'), P_FMT)
		WHEN REGEXP_MATCHES(TRIM(P_DT), '[0-9]{8}') THEN DATE_FORMAT(TO_TIMESTAMP(TRIM(P_DT), 'YYYYMMDD'), P_FMT)
		ELSE DATE_FORMAT(CAST(TRIM(P_DT) AS TIMESTAMP), P_FMT)
	END;

-- MySQL/Oracle DUAL 호환
CREATE VIEW DUAL AS SELECT 'X' AS DUMMY FROM (VALUES(0));

-- eGovFrame 모바일 공통컴포넌트 HSQLDB DDL (src/script/mysql 기반 변환)

CREATE TABLE COMTECOPSEQ
(
	TABLE_NAME                     VARCHAR(20) NOT NULL,
	NEXT_ID                        NUMERIC(30),
	PRIMARY KEY (TABLE_NAME)
);

CREATE TABLE COMTCCMMNCLCODE
(
	CL_CODE                        CHAR(3) NOT NULL,
	CL_CODE_NM                     VARCHAR(60),
	CL_CODE_DC                     VARCHAR(200),
	USE_AT                         CHAR(1),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (CL_CODE)
);

CREATE TABLE COMTCCMMNCODE
(
	CODE_ID                        VARCHAR(6) NOT NULL,
	CODE_ID_NM                     VARCHAR(60),
	CODE_ID_DC                     VARCHAR(200),
	USE_AT                         CHAR(1),
	CL_CODE                        CHAR(3),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (CODE_ID)
);

CREATE TABLE COMTCCMMNDETAILCODE
(
	CODE_ID                        VARCHAR(6) NOT NULL,
	CODE                           VARCHAR(15) NOT NULL,
	CODE_NM                        VARCHAR(60),
	CODE_DC                        VARCHAR(200),
	USE_AT                         CHAR(1),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (CODE_ID,CODE)
);

CREATE TABLE COMTNAUTHORGROUPINFO
(
	GROUP_ID                       CHAR(20) NOT NULL,
	GROUP_NM                       VARCHAR(60) NOT NULL,
	GROUP_CREAT_DE                 CHAR(20) NOT NULL,
	GROUP_DC                       VARCHAR(100),
	PRIMARY KEY (GROUP_ID)
);

CREATE TABLE COMTNGNRLMBER
(
	MBER_ID                        VARCHAR(20) NOT NULL,
	PASSWORD                       VARCHAR(200) NOT NULL,
	PASSWORD_HINT                  VARCHAR(100),
	PASSWORD_CNSR                  VARCHAR(100),
	IHIDNUM                        VARCHAR(200),
	MBER_NM                        VARCHAR(50) NOT NULL,
	ZIP                            VARCHAR(6) NOT NULL,
	ADRES                          VARCHAR(100) NOT NULL,
	AREA_NO                        VARCHAR(4) NOT NULL,
	MBER_STTUS                     VARCHAR(15),
	DETAIL_ADRES                   VARCHAR(100),
	END_TELNO                      VARCHAR(4) NOT NULL,
	MBTLNUM                        VARCHAR(20) NOT NULL,
	GROUP_ID                       CHAR(20),
	MBER_FXNUM                     VARCHAR(20),
	MBER_EMAIL_ADRES               VARCHAR(50),
	MIDDLE_TELNO                   VARCHAR(4) NOT NULL,
	SBSCRB_DE                      TIMESTAMP,
	SEXDSTN_CODE                   CHAR(1),
	ESNTL_ID                       CHAR(20) NOT NULL,
	PRIMARY KEY (MBER_ID)
);

CREATE TABLE COMTNORGNZTINFO
(
	ORGNZT_ID                      CHAR(20) NOT NULL,
	ORGNZT_NM                      VARCHAR(20) NOT NULL,
	ORGNZT_DC                      VARCHAR(100),
	PRIMARY KEY (ORGNZT_ID)
);

CREATE TABLE COMTNEMPLYRINFO
(
	EMPLYR_ID                      VARCHAR(20) NOT NULL,
	ORGNZT_ID                      CHAR(20),
	USER_NM                        VARCHAR(60) NOT NULL,
	PASSWORD                       VARCHAR(200) NOT NULL,
	EMPL_NO                        VARCHAR(20),
	IHIDNUM                        VARCHAR(200),
	SEXDSTN_CODE                   CHAR(1),
	BRTHDY                         CHAR(20),
	FXNUM                          VARCHAR(20),
	HOUSE_ADRES                    VARCHAR(100) NOT NULL,
	PASSWORD_HINT                  VARCHAR(100) NOT NULL,
	PASSWORD_CNSR                  VARCHAR(100) NOT NULL,
	HOUSE_END_TELNO                VARCHAR(4) NOT NULL,
	AREA_NO                        VARCHAR(4) NOT NULL,
	DETAIL_ADRES                   VARCHAR(100),
	ZIP                            VARCHAR(6) NOT NULL,
	OFFM_TELNO                     VARCHAR(20),
	MBTLNUM                        VARCHAR(20),
	EMAIL_ADRES                    VARCHAR(50),
	OFCPS_NM                       VARCHAR(60),
	HOUSE_MIDDLE_TELNO             VARCHAR(4) NOT NULL,
	GROUP_ID                       CHAR(20),
	PSTINST_CODE                   CHAR(8),
	EMPLYR_STTUS_CODE              CHAR(1) NOT NULL,
	ESNTL_ID                       CHAR(20) NOT NULL,
	CRTFC_DN_VALUE                 VARCHAR(100),
	SBSCRB_DE                      TIMESTAMP,
	PRIMARY KEY (EMPLYR_ID)
);

CREATE TABLE COMTNENTRPRSMBER
(
	ENTRPRS_MBER_ID                VARCHAR(20) NOT NULL,
	ENTRPRS_SE_CODE                CHAR(8),
	BIZRNO                         VARCHAR(10),
	JURIRNO                        VARCHAR(13),
	CMPNY_NM                       VARCHAR(60) NOT NULL,
	CXFC                           VARCHAR(50),
	ZIP                            VARCHAR(6) NOT NULL,
	ADRES                          VARCHAR(100) NOT NULL,
	ENTRPRS_MIDDLE_TELNO           VARCHAR(4) NOT NULL,
	FXNUM                          VARCHAR(20),
	INDUTY_CODE                    CHAR(1),
	APPLCNT_NM                     VARCHAR(50) NOT NULL,
	APPLCNT_IHIDNUM                VARCHAR(200),
	SBSCRB_DE                      TIMESTAMP,
	ENTRPRS_MBER_STTUS             VARCHAR(15),
	ENTRPRS_MBER_PASSWORD          VARCHAR(200),
	ENTRPRS_MBER_PASSWORD_HINT     VARCHAR(100) NOT NULL,
	ENTRPRS_MBER_PASSWORD_CNSR     VARCHAR(100) NOT NULL,
	GROUP_ID                       CHAR(20),
	DETAIL_ADRES                   VARCHAR(100),
	ENTRPRS_END_TELNO              VARCHAR(4) NOT NULL,
	AREA_NO                        VARCHAR(4) NOT NULL,
	APPLCNT_EMAIL_ADRES            VARCHAR(50) NOT NULL,
	ESNTL_ID                       CHAR(20) NOT NULL,
	PRIMARY KEY (ENTRPRS_MBER_ID)
);

CREATE TABLE COMTNFILE
(
	ATCH_FILE_ID                   CHAR(20) NOT NULL,
	CREAT_DT                       TIMESTAMP NOT NULL,
	USE_AT                         CHAR(1),
	PRIMARY KEY (ATCH_FILE_ID)
);

CREATE TABLE COMTNFILEDETAIL
(
	ATCH_FILE_ID                   CHAR(20) NOT NULL,
	FILE_SN                        NUMERIC(10) NOT NULL,
	FILE_STRE_COURS                VARCHAR(2000) NOT NULL,
	STRE_FILE_NM                   VARCHAR(255) NOT NULL,
	ORIGNL_FILE_NM                 VARCHAR(255),
	FILE_EXTSN                     VARCHAR(20) NOT NULL,
	FILE_CN                        LONGVARCHAR,
	FILE_SIZE                      NUMERIC(8),
	PRIMARY KEY (ATCH_FILE_ID,FILE_SN)
);

CREATE TABLE COMTHEMAILDSPTCHMANAGE
(
	MSSAGE_ID                      VARCHAR(20) NOT NULL,
	EMAIL_CN                       LONGVARCHAR,
	SNDR                           VARCHAR(50) NOT NULL,
	RCVER                          VARCHAR(50) NOT NULL,
	SJ                             VARCHAR(60) NOT NULL,
	SNDNG_RESULT_CODE              CHAR(1),
	DSPTCH_DT                      CHAR(20) NOT NULL,
	ATCH_FILE_ID                   CHAR(20),
	PRIMARY KEY (MSSAGE_ID)
);

CREATE TABLE COMTNTMPLATINFO
(
	TMPLAT_ID                      CHAR(20) NOT NULL,
	TMPLAT_NM                      VARCHAR(255),
	TMPLAT_COURS                   VARCHAR(2000),
	USE_AT                         CHAR(1),
	TMPLAT_SE_CODE                 CHAR(6),
	FRST_REGISTER_ID               VARCHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	PRIMARY KEY (TMPLAT_ID)
);

CREATE TABLE COMTNRESTDE
(
	RESTDE_NO                      NUMERIC(6) NOT NULL,
	RESTDE                         CHAR(8),
	RESTDE_NM                      VARCHAR(60),
	RESTDE_DC                      VARCHAR(200),
	RESTDE_SE_CODE                 VARCHAR(2),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (RESTDE_NO)
);

CREATE TABLE COMTNBBSMASTER
(
	BBS_ID                         CHAR(20) NOT NULL,
	BBS_NM                         VARCHAR(255) NOT NULL,
	BBS_INTRCN                     VARCHAR(2400),
	BBS_TY_CODE                    CHAR(6) NOT NULL,
	BBS_ATTRB_CODE                 CHAR(6) NOT NULL,
	REPLY_POSBL_AT                 CHAR(1),
	FILE_ATCH_POSBL_AT             CHAR(1) NOT NULL,
	ATCH_POSBL_FILE_NUMBER         NUMERIC(2) NOT NULL,
	ATCH_POSBL_FILE_SIZE           NUMERIC(8),
	USE_AT                         CHAR(1) NOT NULL,
	TMPLAT_ID                      CHAR(20),
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	LAST_UPDUSR_ID                 VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	PRIMARY KEY (BBS_ID)
);

CREATE TABLE COMTNBBSUSE
(
	BBS_ID                         CHAR(20) NOT NULL,
	TRGET_ID                       CHAR(20) NOT NULL,
	USE_AT                         CHAR(1) NOT NULL,
	REGIST_SE_CODE                 CHAR(6),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (BBS_ID,TRGET_ID)
);

CREATE TABLE COMTNBBS
(
	NTT_ID                         NUMERIC(20) NOT NULL,
	BBS_ID                         CHAR(20) NOT NULL,
	NTT_NO                         NUMERIC(20),
	NTT_SJ                         VARCHAR(2000),
	NTT_CN                         LONGVARCHAR,
	ANSWER_AT                      CHAR(1),
	PARNTSCTT_NO                   NUMERIC(10),
	ANSWER_LC                      NUMERIC(8),
	SORT_ORDR                      NUMERIC(8),
	RDCNT                          NUMERIC(10),
	USE_AT                         CHAR(1) NOT NULL,
	NTCE_BGNDE                     CHAR(20),
	NTCE_ENDDE                     CHAR(20),
	NTCR_ID                        VARCHAR(20),
	NTCR_NM                        VARCHAR(20),
	PASSWORD                       VARCHAR(200),
	ATCH_FILE_ID                   CHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (NTT_ID,BBS_ID)
);

CREATE TABLE COMTNCMMNTY
(
	CMMNTY_ID                      CHAR(20) NOT NULL,
	CMMNTY_NM                      VARCHAR(255) NOT NULL,
	CMMNTY_INTRCN                  VARCHAR(2400),
	USE_AT                         CHAR(1) NOT NULL,
	REGIST_SE_CODE                 CHAR(6),
	TMPLAT_ID                      CHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (CMMNTY_ID)
);

CREATE TABLE COMTNCLUB
(
	CLB_ID                         CHAR(20) NOT NULL,
	CMMNTY_ID                      CHAR(20) NOT NULL,
	CLB_NM                         VARCHAR(255) NOT NULL,
	CLB_INTRCN                     VARCHAR(2400),
	USE_AT                         CHAR(1) NOT NULL,
	REGIST_SE_CODE                 CHAR(6),
	TMPLAT_ID                      CHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (CLB_ID,CMMNTY_ID)
);

CREATE TABLE COMTNBBSMASTEROPTN
(
	BBS_ID                         CHAR(20) NOT NULL,
	ANSWER_AT                      CHAR(1) NOT NULL,
	STSFDG_AT                      CHAR(1) NOT NULL,
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (BBS_ID)
);

CREATE TABLE COMTNCOMMENT
(
	NTT_ID                         NUMERIC(20) NOT NULL,
	BBS_ID                         CHAR(20) NOT NULL,
	ANSWER_NO                      NUMERIC(20) NOT NULL,
	WRTER_ID                       VARCHAR(20),
	WRTER_NM                       VARCHAR(20),
	ANSWER                         VARCHAR(200),
	USE_AT                         CHAR(1) NOT NULL,
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PASSWORD                       VARCHAR(200),
	PRIMARY KEY (NTT_ID,BBS_ID,ANSWER_NO)
);

CREATE TABLE COMTNSCRAP
(
	SCRAP_ID                       CHAR(20) NOT NULL,
	NTT_ID                         NUMERIC(20) NOT NULL,
	BBS_ID                         CHAR(20) NOT NULL,
	SCRAP_NM                       VARCHAR(100) NOT NULL,
	USE_AT                         CHAR(1) NOT NULL,
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (SCRAP_ID)
);

CREATE TABLE COMTNSTSFDG
(
	STSFDG_NO                      NUMERIC(20) NOT NULL,
	NTT_ID                         NUMERIC(20) NOT NULL,
	BBS_ID                         CHAR(20) NOT NULL,
	WRTER_ID                       VARCHAR(20),
	WRTER_NM                       VARCHAR(20),
	PASSWORD                       VARCHAR(200),
	STSFDG                         NUMERIC(1) NOT NULL,
	STSFDG_CN                      VARCHAR(200),
	USE_AT                         CHAR(1) NOT NULL,
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (STSFDG_NO)
);

CREATE TABLE COMTHCONFMHISTORY
(
	CONFM_NO                       NUMERIC(8) NOT NULL,
	CONFM_RQESTER_ID               VARCHAR(20) NOT NULL,
	CONFMER_ID                     VARCHAR(20),
	CONFM_DE                       CHAR(20),
	CONFM_TY_CODE                  CHAR(4) NOT NULL,
	CONFM_STTUS_CODE               CHAR(4) NOT NULL,
	OPERT_TY_CODE                  CHAR(4),
	OPERT_ID                       VARCHAR(20),
	TRGET_JOB_TY_CODE              CHAR(3),
	TRGET_JOB_ID                   CHAR(20),
	PRIMARY KEY (CONFM_NO)
);

CREATE TABLE COMTNCMMNTYUSER
(
	CMMNTY_ID                      CHAR(20) NOT NULL,
	EMPLYR_ID                      VARCHAR(20) NOT NULL,
	MNGR_AT                        CHAR(1) NOT NULL,
	SBSCRB_DE                      TIMESTAMP,
	SECSN_DE                       CHAR(20),
	USE_AT                         CHAR(1),
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (CMMNTY_ID,EMPLYR_ID)
);

CREATE TABLE COMTNCLUBUSER
(
	CLB_ID                         CHAR(20) NOT NULL,
	CMMNTY_ID                      CHAR(20) NOT NULL,
	OPRTR_AT                       CHAR(1) NOT NULL,
	SBSCRB_DE                      TIMESTAMP,
	SECSN_DE                       CHAR(20),
	USE_AT                         CHAR(1) NOT NULL,
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	EMPLYR_ID                      VARCHAR(20) NOT NULL,
	PRIMARY KEY (CLB_ID,CMMNTY_ID,EMPLYR_ID)
);

CREATE TABLE COMTNMTGINFO
(
	MTG_ID                         CHAR(20) NOT NULL,
	MTG_NM                         VARCHAR(255),
	MTG_MTR_CN                     VARCHAR(1000),
	MTG_SN                         NUMERIC(10),
	MTG_CO                         NUMERIC(5),
	MTG_DE                         CHAR(20),
	MTG_PLACE                      VARCHAR(255),
	MTG_BEGIN_TM                   VARCHAR(14),
	MTG_END_TM                     VARCHAR(14),
	CLSDR_MTG_AT                   CHAR(1),
	READNG_BGNDE                   CHAR(20),
	READNG_AT                      CHAR(1),
	MTG_RESULT_CN                  VARCHAR(1000),
	MTG_RESULT_ENNC                CHAR(1),
	ETC_MATTER                     VARCHAR(1000),
	MNGT_DEPT_ID                   VARCHAR(20),
	MNAER_ID                       VARCHAR(20),
	MNAER_DEPT_ID                  VARCHAR(20),
	MTG_AT                         CHAR(1),
	NONATDRN_CO                    NUMERIC(10),
	ATDRN_CO                       NUMERIC(10),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (MTG_ID)
);

CREATE TABLE COMTNSCHDULINFO
(
	SCHDUL_ID                      CHAR(20) NOT NULL,
	SCHDUL_SE                      CHAR(1),
	SCHDUL_DEPT_ID                 VARCHAR(20),
	SCHDUL_KND_CODE                CHAR(1),
	SCHDUL_BGNDE                   CHAR(20),
	SCHDUL_ENDDE                   CHAR(20),
	SCHDUL_NM                      VARCHAR(255),
	SCHDUL_CN                      VARCHAR(2500),
	SCHDUL_PLACE                   VARCHAR(255),
	SCHDUL_IPCR_CODE               CHAR(1),
	SCHDUL_CHARGER_ID              VARCHAR(20),
	ATCH_FILE_ID                   CHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	REPTIT_SE_CODE                 CHAR(1),
	PRIMARY KEY (SCHDUL_ID)
);

CREATE TABLE COMTNDIARYINFO
(
	SCHDUL_ID                      CHAR(20) NOT NULL,
	DIARY_ID                       CHAR(20) NOT NULL,
	DIARY_PROGRSRT                 NUMERIC(3),
	DIARY_NM                       VARCHAR(255),
	DRCT_MATTER                    VARCHAR(2500),
	PARTCLR_MATTER                 VARCHAR(2500),
	ATCH_FILE_ID                   CHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (SCHDUL_ID,DIARY_ID)
);

CREATE TABLE COMTNINDVDLPGECNTNTS
(
	CNTNTS_ID                      VARCHAR(20) NOT NULL,
	CNTNTS_NM                      VARCHAR(100) NOT NULL,
	CNTC_URL                       VARCHAR(255) NOT NULL,
	CNTNTS_USE_AT                  CHAR(1) NOT NULL,
	CNTNTS_LINK_URL                VARCHAR(1000),
	CNTNTS_DC                      VARCHAR(250),
	PRIMARY KEY (CNTNTS_ID)
);

CREATE TABLE COMTNINDVDLPGEESTBS
(
	EMPLYR_ID                      VARCHAR(20) NOT NULL,
	UPEND_IMAGE                    VARCHAR(1024),
	TITLEBAR_COLOR                 CHAR(7),
	ALGN_MTHD                      CHAR(1),
	ALGN_CO                        NUMERIC(10),
	PRIMARY KEY (EMPLYR_ID)
);

CREATE TABLE COMTNCNTNTSLIST
(
	CNTNTS_ID                      VARCHAR(20) NOT NULL,
	EMPLYR_ID                      VARCHAR(20) NOT NULL,
	PRIMARY KEY (CNTNTS_ID,EMPLYR_ID)
);

CREATE TABLE COMTNSTPLATINFO
(
	USE_STPLAT_ID                  CHAR(20) NOT NULL,
	USE_STPLAT_NM                  VARCHAR(100),
	USE_STPLAT_CN                  LONGVARCHAR,
	INFO_PROVD_AGRE_CN             LONGVARCHAR,
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (USE_STPLAT_ID)
);

CREATE TABLE COMTNHPCMINFO
(
	HPCM_ID                        CHAR(20) NOT NULL,
	HPCM_SE_CODE                   CHAR(1),
	HPCM_DFN                       VARCHAR(1000),
	HPCM_DC                        VARCHAR(2500),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (HPCM_ID)
);

CREATE TABLE COMTNWORDDICARYINFO
(
	WORD_ID                        CHAR(20) NOT NULL,
	WORD_NM                        VARCHAR(255),
	ENG_NM                         VARCHAR(60),
	WORD_DC                        VARCHAR(4000),
	SYNONM                         VARCHAR(100),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (WORD_ID)
);

CREATE TABLE COMTNFAQINFO
(
	FAQ_ID                         CHAR(20) NOT NULL,
	QESTN_SJ                       VARCHAR(255),
	QESTN_CN                       VARCHAR(2500),
	ANSWER_CN                      VARCHAR(2500),
	RDCNT                          NUMERIC(10),
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP NOT NULL,
	LAST_UPDUSR_ID                 VARCHAR(20) NOT NULL,
	ATCH_FILE_ID                   CHAR(20),
	QNA_PROCESS_STTUS_CODE         CHAR(1),
	PRIMARY KEY (FAQ_ID)
);

CREATE TABLE COMTNQAINFO
(
	QA_ID                          CHAR(20) NOT NULL,
	QESTN_SJ                       VARCHAR(255),
	QESTN_CN                       VARCHAR(2500),
	WRITNG_DE                      CHAR(20),
	RDCNT                          NUMERIC(10),
	EMAIL_ADRES                    VARCHAR(50),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	QNA_PROCESS_STTUS_CODE         CHAR(1),
	WRTER_NM                       VARCHAR(20),
	ANSWER_CN                      VARCHAR(2500),
	WRITNG_PASSWORD                VARCHAR(20),
	ANSWER_DE                      CHAR(20),
	EMAIL_ANSWER_AT                CHAR(1),
	AREA_NO                        VARCHAR(4),
	MIDDLE_TELNO                   VARCHAR(4),
	END_TELNO                      VARCHAR(4),
	PRIMARY KEY (QA_ID)
);

CREATE TABLE COMTNADBKMANAGE
(
	ADBK_ID                        CHAR(20) NOT NULL,
	ADBK_NM                        VARCHAR(50) NOT NULL,
	OTHBC_SCOPE                    VARCHAR(20) NOT NULL,
	USE_AT                         CHAR(1) NOT NULL,
	WRTER_ID                       VARCHAR(20),
	TRGET_ORGNZT_ID                CHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (ADBK_ID)
);

CREATE TABLE COMTNADBK
(
	EMPLYR_ID                      VARCHAR(20),
	NCRD_ID                        CHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	LAST_UPDT_PNTTM                TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDUSR_ID                 VARCHAR(20),
	ADBK_CONSTNT_ID                CHAR(20) NOT NULL,
	NM                             VARCHAR(50),
	EMAIL_ADRES                    VARCHAR(50),
	MBTLNUM                        VARCHAR(20),
	FXNUM                          VARCHAR(20),
	OFFM_TELNO                     VARCHAR(20),
	HOUSE_TELNO                    VARCHAR(20),
	ADBK_ID                        CHAR(20) NOT NULL,
	PRIMARY KEY (ADBK_CONSTNT_ID,ADBK_ID)
);

CREATE TABLE COMTNRECOMENDSITEINFO
(
	RECOMEND_SITE_ID               CHAR(20) NOT NULL,
	RECOMEND_SITE_NM               VARCHAR(100),
	RECOMEND_SITE_URL              VARCHAR(255),
	RECOMEND_SITE_DC               VARCHAR(1000),
	RECOMEND_RESN_CN               VARCHAR(1000),
	RECOMEND_CONFM_AT              CHAR(1),
	CONFM_DE                       CHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (RECOMEND_SITE_ID)
);

CREATE TABLE COMTNROLEINFO
(
	ROLE_CODE                      VARCHAR(50) NOT NULL,
	ROLE_NM                        VARCHAR(60) NOT NULL,
	ROLE_PTTRN                     VARCHAR(300),
	ROLE_DC                        VARCHAR(200),
	ROLE_TY                        VARCHAR(80),
	ROLE_SORT                      VARCHAR(10),
	ROLE_CREAT_DE                  CHAR(20) NOT NULL,
	PRIMARY KEY (ROLE_CODE)
);

CREATE TABLE COMTNAUTHORINFO
(
	AUTHOR_CODE                    VARCHAR(30) NOT NULL,
	AUTHOR_NM                      VARCHAR(60) NOT NULL,
	AUTHOR_DC                      VARCHAR(200),
	AUTHOR_CREAT_DE                CHAR(20) NOT NULL,
	PRIMARY KEY (AUTHOR_CODE)
);

CREATE TABLE COMTNAUTHORROLERELATE
(
	AUTHOR_CODE                    VARCHAR(30) NOT NULL,
	ROLE_CODE                      VARCHAR(50) NOT NULL,
	CREAT_DT                       TIMESTAMP,
	PRIMARY KEY (AUTHOR_CODE,ROLE_CODE)
);

CREATE TABLE COMTNADMINISTRATIONWORD
(
	ADMINIST_WORD_ID               CHAR(20) NOT NULL,
	ADMINIST_WORD_NM               VARCHAR(255),
	ADMINIST_WORD_ENG_NM           VARCHAR(255),
	ADMINIST_WORD_ABRV_NM          VARCHAR(255),
	THEMA_RELM                     VARCHAR(255),
	WORD_SE                        VARCHAR(255),
	RELATE_STD_WORD                VARCHAR(255),
	ADMINIST_WORD_DFN              VARCHAR(2500),
	ADMINIST_WORD_DC               VARCHAR(4000),
	FRST_REGISTER_ID               VARCHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	PRIMARY KEY (ADMINIST_WORD_ID)
);

CREATE TABLE COMTNONLINEMANUAL
(
	ONLINE_MNL_ID                  CHAR(20) NOT NULL,
	ONLINE_MNL_SE_CODE             CHAR(3),
	ONLINE_MNL_DFN                 LONGVARCHAR,
	ONLINE_MNL_DC                  LONGVARCHAR,
	FRST_REGISTER_ID               VARCHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	ONLINE_MNL_NM                  VARCHAR(255),
	PRIMARY KEY (ONLINE_MNL_ID)
);

CREATE TABLE COMTNCNSLTLIST
(
	CNSLT_ID                       CHAR(20) NOT NULL,
	CNSLT_SJ                       VARCHAR(255),
	OTHBC_AT                       CHAR(1),
	EMAIL_ADRES                    VARCHAR(50),
	CNSLT_CN                       VARCHAR(2500),
	MANAGT_CN                      VARCHAR(2500),
	MANAGT_DE                      CHAR(20),
	RDCNT                          NUMERIC(10),
	ATCH_FILE_ID                   CHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	AREA_NO                        VARCHAR(4),
	MIDDLE_TELNO                   VARCHAR(4),
	END_TELNO                      VARCHAR(4),
	FRST_MBTLNUM                   VARCHAR(4),
	MIDDLE_MBTLNUM                 VARCHAR(4),
	END_MBTLNUM                    VARCHAR(4),
	WRITNG_DE                      CHAR(20),
	WRTER_NM                       VARCHAR(20),
	EMAIL_ANSWER_AT                CHAR(1),
	QNA_PROCESS_STTUS_CODE         CHAR(1),
	WRITNG_PASSWORD                VARCHAR(20),
	PRIMARY KEY (CNSLT_ID)
);

CREATE TABLE COMTNQUSTNRTMPLAT
(
	QUSTNR_TMPLAT_ID               CHAR(20) NOT NULL,
	QUSTNR_TMPLAT_TY               VARCHAR(100),
	QUSTNR_TMPLAT_DC               VARCHAR(2000),
	QUSTNR_TMPLAT_PATH_NM          VARCHAR(100),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	QUSTNR_TMPLAT_IMAGE_INFO       BLOB,
	PRIMARY KEY (QUSTNR_TMPLAT_ID)
);

CREATE TABLE COMTNQESTNRINFO
(
	QUSTNR_TMPLAT_ID               CHAR(20) NOT NULL,
	QESTNR_ID                      CHAR(20) NOT NULL,
	QUSTNR_SJ                      VARCHAR(255),
	QUSTNR_PURPS                   VARCHAR(1000),
	QUSTNR_WRITNG_GUIDANCE_CN      VARCHAR(2000),
	QUSTNR_TRGET                   VARCHAR(1000),
	QUSTNR_BGNDE                   CHAR(20),
	QUSTNR_ENDDE                   CHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (QUSTNR_TMPLAT_ID,QESTNR_ID)
);

CREATE TABLE COMTNQUSTNRRESPONDINFO
(
	QUSTNR_TMPLAT_ID               CHAR(20) NOT NULL,
	QESTNR_ID                      CHAR(20) NOT NULL,
	QUSTNR_RESPOND_ID              CHAR(20) NOT NULL,
	SEXDSTN_CODE                   CHAR(1),
	OCCP_TY_CODE                   CHAR(1),
	RESPOND_NM                     VARCHAR(50),
	BRTHDY                         CHAR(20),
	AREA_NO                        VARCHAR(4),
	MIDDLE_TELNO                   VARCHAR(4),
	END_TELNO                      VARCHAR(4),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (QUSTNR_TMPLAT_ID,QESTNR_ID,QUSTNR_RESPOND_ID)
);

CREATE TABLE COMTNQUSTNRQESITM
(
	QESTNR_ID                      CHAR(20) NOT NULL,
	QUSTNR_QESITM_ID               CHAR(20) NOT NULL,
	QUSTNR_TMPLAT_ID               CHAR(20) NOT NULL,
	QESTN_SN                       NUMERIC(10),
	QESTN_TY_CODE                  CHAR(1),
	QESTN_CN                       VARCHAR(2500),
	MXMM_CHOISE_CO                 NUMERIC(5),
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP NOT NULL,
	LAST_UPDUSR_ID                 VARCHAR(20) NOT NULL,
	PRIMARY KEY (QESTNR_ID,QUSTNR_QESITM_ID,QUSTNR_TMPLAT_ID)
);

CREATE TABLE COMTNQUSTNRRSPNSRESULT
(
	QUSTNR_RSPNS_RESULT_ID         CHAR(20) NOT NULL,
	QESTNR_ID                      CHAR(20) NOT NULL,
	QUSTNR_QESITM_ID               CHAR(20) NOT NULL,
	QUSTNR_TMPLAT_ID               CHAR(20) NOT NULL,
	RESPOND_ANSWER_CN              VARCHAR(1000),
	ETC_ANSWER_CN                  VARCHAR(1000),
	RESPOND_NM                     VARCHAR(50),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	QUSTNR_IEM_ID                  VARCHAR(20),
	PRIMARY KEY (QUSTNR_RSPNS_RESULT_ID,QESTNR_ID,QUSTNR_QESITM_ID,QUSTNR_TMPLAT_ID)
);

CREATE TABLE COMTNQUSTNRIEM
(
	QUSTNR_TMPLAT_ID               CHAR(20) NOT NULL,
	QESTNR_ID                      CHAR(20) NOT NULL,
	QUSTNR_QESITM_ID               CHAR(20) NOT NULL,
	QUSTNR_IEM_ID                  VARCHAR(20) NOT NULL,
	IEM_SN                         NUMERIC(5),
	IEM_CN                         VARCHAR(1000),
	ETC_ANSWER_AT                  CHAR(1),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (QUSTNR_TMPLAT_ID,QESTNR_ID,QUSTNR_QESITM_ID,QUSTNR_IEM_ID)
);

CREATE TABLE COMTNONLINEPOLLMANAGE
(
	POLL_ID                        CHAR(20) NOT NULL,
	POLL_NM                        VARCHAR(255),
	POLL_BGNDE                     CHAR(10),
	POLL_ENDDE                     CHAR(10),
	POLL_KND                       CHAR(3),
	POLL_DSUSE_ENNC                CHAR(1),
	POLL_ATMC_DSUSE_ENNC           CHAR(1),
	FRST_REGISTER_ID               VARCHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	PRIMARY KEY (POLL_ID)
);

CREATE TABLE COMTNONLINEPOLLIEM
(
	POLL_IEM_NM                    VARCHAR(255),
	FRST_REGISTER_ID               VARCHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	POLL_IEM_ID                    CHAR(20) NOT NULL,
	POLL_ID                        CHAR(20) NOT NULL,
	PRIMARY KEY (POLL_ID,POLL_IEM_ID)
);

CREATE TABLE COMTNONLINEPOLLRESULT
(
	POLL_RESULT_ID                 CHAR(20) NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	POLL_IEM_ID                    CHAR(20) NOT NULL,
	POLL_ID                        CHAR(20) NOT NULL,
	PRIMARY KEY (POLL_RESULT_ID,POLL_IEM_ID,POLL_ID)
);

CREATE TABLE COMTNNEWSINFO
(
	NEWS_ID                        CHAR(20) NOT NULL,
	NEWS_SJ                        VARCHAR(100),
	NEWS_CN                        VARCHAR(2500),
	NEWS_ORIGIN                    VARCHAR(250),
	NTCE_AT                        CHAR(1),
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20) NOT NULL,
	LAST_UPDT_PNTTM                TIMESTAMP NOT NULL,
	LAST_UPDUSR_ID                 VARCHAR(20) NOT NULL,
	NTCE_DE                        CHAR(20),
	ATCH_FILE_ID                   CHAR(20),
	PRIMARY KEY (NEWS_ID)
);

CREATE TABLE COMTNEVENTINFO
(
	EVENT_ID                       CHAR(20) NOT NULL,
	BSNS_YEAR                      CHAR(4),
	BSNS_CODE                      VARCHAR(2),
	EVENT_CN                       VARCHAR(1000),
	EVENT_SVC_BGNDE                CHAR(20),
	SVC_USE_NMPR_CO                NUMERIC(10),
	CHARGER_NM                     VARCHAR(50),
	PRPARETG_CN                    VARCHAR(2500),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	EVENT_SVC_ENDDE                CHAR(20),
	EVENT_TY_CODE                  CHAR(1),
	EVENT_CONFM_AT                 CHAR(1),
	EVENT_CONFM_DE                 CHAR(20),
	PRIMARY KEY (EVENT_ID)
);

CREATE TABLE COMTNEXTRLHRINFO
(
	EVENT_ID                       CHAR(20) NOT NULL,
	EXTRL_HR_ID                    CHAR(20) NOT NULL,
	SEXDSTN_CODE                   CHAR(1),
	EXTRL_HR_NM                    VARCHAR(60),
	OCCP_TY_CODE                   CHAR(1),
	PSITN_INSTT_NM                 VARCHAR(100),
	BRTHDY                         CHAR(20),
	AREA_NO                        VARCHAR(4),
	MIDDLE_TELNO                   VARCHAR(4),
	END_TELNO                      VARCHAR(4),
	EMAIL_ADRES                    VARCHAR(50),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (EVENT_ID,EXTRL_HR_ID)
);

CREATE TABLE COMTCZIP
(
	ZIP                            VARCHAR(6) NOT NULL,
	SN                             NUMERIC(10) NOT NULL,
	CTPRVN_NM                      VARCHAR(20),
	SIGNGU_NM                      VARCHAR(20),
	EMD_NM                         VARCHAR(60),
	LI_BULD_NM                     VARCHAR(60),
	LNBR_DONG_HO                   VARCHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (ZIP,SN)
);

CREATE TABLE COMTRDNMADRZIP
(
	RDMN_CODE                      VARCHAR(12) NOT NULL,
	SN                             NUMERIC(10) NOT NULL,
	CTPRVN_NM                      VARCHAR(20),
	SIGNGU_NM                      VARCHAR(20),
	RDMN                           VARCHAR(60),
	BDNBR_MNNM                     VARCHAR(5),
	BDNBR_SLNO                     VARCHAR(5),
	BULD_NM                        VARCHAR(60),
	DETAIL_BULD_NM                 VARCHAR(60),
	ZIP                            VARCHAR(6) NOT NULL,
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNBKMKMENUMANAGERESULT
(
	MENU_ID                        NUMERIC(20) NOT NULL,
	EMPLYR_ID                      VARCHAR(20) NOT NULL,
	MENU_NM                        VARCHAR(60) NOT NULL,
	PROGRM_STRE_PATH               VARCHAR(100) NOT NULL,
	PRIMARY KEY (MENU_ID,EMPLYR_ID)
);

CREATE TABLE COMTNEMPLYRSCRTYESTBS
(
	SCRTY_DTRMN_TRGET_ID           VARCHAR(20) NOT NULL,
	MBER_TY_CODE                   CHAR(5),
	AUTHOR_CODE                    VARCHAR(30) NOT NULL,
	PRIMARY KEY (SCRTY_DTRMN_TRGET_ID)
);

CREATE TABLE COMTNSITEMAP
(
	MAPNG_CREAT_ID                 VARCHAR(30) NOT NULL,
	CREATR_ID                      VARCHAR(20) NOT NULL,
	MAPNG_FILE_NM                  VARCHAR(60) NOT NULL,
	MAPNG_FILE_PATH                VARCHAR(100) NOT NULL,
	PRIMARY KEY (MAPNG_CREAT_ID)
);

CREATE TABLE COMTNROLES_HIERARCHY
(
	PARNTS_ROLE                    VARCHAR(30) NOT NULL,
	CHLDRN_ROLE                    VARCHAR(30) NOT NULL,
	PRIMARY KEY (PARNTS_ROLE,CHLDRN_ROLE)
);

CREATE TABLE COMTNPROGRMLIST
(
	PROGRM_FILE_NM                 VARCHAR(60) NOT NULL,
	PROGRM_STRE_PATH               VARCHAR(100) NOT NULL,
	PROGRM_KOREAN_NM               VARCHAR(60),
	PROGRM_DC                      VARCHAR(200),
	URL                            VARCHAR(100) NOT NULL,
	PRIMARY KEY (PROGRM_FILE_NM)
);

CREATE TABLE COMTHPROGRMCHANGEDTLS
(
	PROGRM_FILE_NM                 VARCHAR(60) NOT NULL,
	REQUST_NO                      NUMERIC(10) NOT NULL,
	RQESTER_ID                     VARCHAR(20) NOT NULL,
	CHANGE_REQUST_CN               VARCHAR(1000),
	REQUST_PROCESS_CN              LONGVARCHAR,
	OPETR_ID                       VARCHAR(20),
	PROCESS_STTUS_CODE             VARCHAR(15) NOT NULL,
	PROCESS_DE                     CHAR(20),
	RQESTDE                        CHAR(20),
	REQUST_SJ                      VARCHAR(60) NOT NULL,
	PRIMARY KEY (PROGRM_FILE_NM,REQUST_NO)
);

CREATE TABLE COMTNMENUINFO
(
	MENU_NM                        VARCHAR(60) NOT NULL,
	PROGRM_FILE_NM                 VARCHAR(60) NOT NULL,
	MENU_NO                        NUMERIC(20) NOT NULL,
	UPPER_MENU_NO                  NUMERIC(20),
	MENU_ORDR                      NUMERIC(5) NOT NULL,
	MENU_DC                        VARCHAR(250),
	RELATE_IMAGE_PATH              VARCHAR(100),
	RELATE_IMAGE_NM                VARCHAR(60),
	PRIMARY KEY (MENU_NO)
);

CREATE TABLE COMTNMENUCREATDTLS
(
	MENU_NO                        NUMERIC(20) NOT NULL,
	AUTHOR_CODE                    VARCHAR(30) NOT NULL,
	MAPNG_CREAT_ID                 VARCHAR(30),
	PRIMARY KEY (MENU_NO,AUTHOR_CODE)
);

CREATE TABLE COMTNREALTIMENOTICE
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	NOTICE_SJ                      VARCHAR(256),
	NOTICE_CN                      VARCHAR(2048),
	RECENT_CODE_ID                 VARCHAR(6),
	RECENT_CODE                    VARCHAR(15),
	NOTICE_BGNDT                   DATE NOT NULL,
	NOTICE_ENDDT                   DATE NOT NULL,
	CREAT_DT                       DATE NOT NULL,
	UPDT_DT                        DATE NOT NULL,
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNSYNC
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	SYNC_SJ                        VARCHAR(256),
	SYNC_CN                        VARCHAR(2048),
	SYNC_DT                        DATE,
	CREAT_DT                       DATE NOT NULL,
	UPDT_DT                        DATE NOT NULL,
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNOFFLINEWEB
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	OFFLINE_SJ                     VARCHAR(256),
	OFFLINE_CN                     VARCHAR(2048),
	CREAT_DT                       DATE NOT NULL,
	UPDT_DT                        DATE NOT NULL,
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNCHARTGRAPH
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	XAXIS                          INTEGER,
	YAXIS                          INTEGER,
	LGD_NM                         VARCHAR(20),
	CREAT_DT                       DATE NOT NULL,
	UPDT_DT                        DATE NOT NULL,
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNDEVICE
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	UAGENT_INFO                    VARCHAR(1024),
	BROWSER_CODE_ID                VARCHAR(128),
	BROWSER_CODE                   VARCHAR(15),
	OS_CODE_ID                     VARCHAR(128),
	OS_CODE                        VARCHAR(15),
	RECENT_CODE_ID                 VARCHAR(6),
	RECENT_CODE                    VARCHAR(15),
	CREAT_DT                       DATE NOT NULL,
	UPDT_DT                        DATE NOT NULL,
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNPHOTOALBUM
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	PHOTO_SJ                       VARCHAR(256),
	ATCH_FILE_ID                   CHAR(20),
	CREAT_DT                       DATE,
	UPDT_DT                        DATE,
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNMLTMD
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	ATCH_FILE_ID                   CHAR(20),
	MLTMD_CODE_ID                  VARCHAR(6),
	MLTMD_CODE                     VARCHAR(15),
	MLTMD_SJ                       VARCHAR(256),
	BROWSER_NM                     VARCHAR(128),
	CREAT_DT                       DATE NOT NULL,
	UPDT_DT                        DATE NOT NULL,
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNMMS
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	TRNSMIS_NO                     VARCHAR(32),
	RECPTN_NO                      VARCHAR(32),
	MSSAGE_SJ                      VARCHAR(32) NOT NULL,
	MSSAGE_CN                      VARCHAR(1000),
	MSSAGE_ID                      VARCHAR(52),
	RQESTER_RESULT_CODE_ID         VARCHAR(6),
	RQESTER_RESULT_CODE            VARCHAR(15),
	TRNSMIS_RESULT_CODE_ID         VARCHAR(6),
	TRNSMIS_RESULT_CODE            VARCHAR(15),
	TRNSMIS_DT                     DATE NOT NULL,
	TRNSMIS_CONFIRM_DT             DATE,
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNMMSATTACH
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	ATCH_FILE_ID                   CHAR(20),
	MMS_ATCH_FILE_SJ               VARCHAR(256),
	CREAT_DT                       DATE NOT NULL,
	UPDT_DT                        DATE NOT NULL,
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNGEOLOCATION
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	BULD_NM                        VARCHAR(60),
	LA                             VARCHAR(48),
	LO                             VARCHAR(48),
	TELNO                          VARCHAR(20),
	ADRES                          VARCHAR(100),
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNOPENAPI
(
	SN                             INTEGER NOT NULL,
	MBER_ID                        VARCHAR(20) NOT NULL,
	OPEN_API_SVC_CODE_ID           VARCHAR(6),
	OPEN_API_SVC_CODE              VARCHAR(15),
	OPEN_API_SVC_CN                VARCHAR(4000),
	OPENAPI_PROVD_INSTT_CODE_ID    VARCHAR(6),
	OPENAPI_PROVD_INSTT_CODE       VARCHAR(15),
	COLLECT_DT                     DATE NOT NULL,
	PRIMARY KEY (SN)
);

CREATE TABLE COMTNMOBILEMENUINFO
(
	MENU_CODE                      VARCHAR(20) NOT NULL,
	MENU_NM                        VARCHAR(60),
	MENU_LVL                       NUMERIC(5),
	CNNC_URL                       VARCHAR(255),
	MENU_DC                        VARCHAR(250),
	ACTVTY_AT                      CHAR(1),
	UPPER_MENU_ID                  VARCHAR(20),
	FRST_REGIST_PNTTM              TIMESTAMP,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (MENU_CODE)
);

CREATE TABLE COMTHEMPLYRINFOCHANGEDTLS
(
	EMPLYR_ID                      VARCHAR(20) NOT NULL,
	CHANGE_DE                      CHAR(20) NOT NULL,
	ORGNZT_ID                      CHAR(20),
	GROUP_ID                       CHAR(20),
	EMPL_NO                        VARCHAR(20),
	SEXDSTN_CODE                   CHAR(1),
	BRTHDY                         CHAR(20),
	FXNUM                          VARCHAR(20),
	HOUSE_ADRES                    VARCHAR(100),
	HOUSE_END_TELNO                VARCHAR(4),
	AREA_NO                        VARCHAR(4),
	DETAIL_ADRES                   VARCHAR(100),
	ZIP                            VARCHAR(6),
	OFFM_TELNO                     VARCHAR(20),
	MBTLNUM                        VARCHAR(20),
	EMAIL_ADRES                    VARCHAR(50),
	HOUSE_MIDDLE_TELNO             VARCHAR(4),
	PSTINST_CODE                   CHAR(8),
	EMPLYR_STTUS_CODE              CHAR(1),
	ESNTL_ID                       CHAR(20),
	PRIMARY KEY (EMPLYR_ID,CHANGE_DE)
);

CREATE TABLE COMTNNCRD
(
	NCRD_ID                        CHAR(20) NOT NULL,
	NCRD_TRGTER_ID                 VARCHAR(20),
	NM                             VARCHAR(50) NOT NULL,
	TELNO                          VARCHAR(20),
	NATION_NO                      VARCHAR(10),
	AREA_NO                        VARCHAR(4),
	MIDDLE_TELNO                   VARCHAR(4),
	END_TELNO                      VARCHAR(4),
	MBTLNUM                        VARCHAR(20),
	IDNTFC_NO                      VARCHAR(10),
	MIDDLE_MBTLNUM                 VARCHAR(4),
	END_MBTLNUM                    VARCHAR(4),
	EMAIL_ADRES                    VARCHAR(50),
	CMPNY_NM                       VARCHAR(60),
	DEPT_NM                        VARCHAR(60),
	ADRES                          VARCHAR(100),
	DETAIL_ADRES                   VARCHAR(100),
	OFCPS_NM                       VARCHAR(60),
	CLSF_NM                        VARCHAR(60),
	EXTRL_USER_AT                  CHAR(1),
	OTHBC_AT                       CHAR(1) NOT NULL,
	RM                             VARCHAR(2500),
	FRST_REGIST_PNTTM              TIMESTAMP NOT NULL,
	FRST_REGISTER_ID               VARCHAR(20),
	LAST_UPDT_PNTTM                TIMESTAMP,
	LAST_UPDUSR_ID                 VARCHAR(20),
	PRIMARY KEY (NCRD_ID)
);

-- 인덱스
CREATE INDEX COMTCCMMNCODE_I01 ON COMTCCMMNCODE (CL_CODE);
CREATE INDEX COMTCCMMNDETAILCODE_I01 ON COMTCCMMNDETAILCODE (CODE_ID);
CREATE INDEX COMTNGNRLMBER_I01 ON COMTNGNRLMBER (GROUP_ID);
CREATE INDEX COMTNEMPLYRINFO_I01 ON COMTNEMPLYRINFO (ORGNZT_ID);
CREATE INDEX COMTNEMPLYRINFO_I02 ON COMTNEMPLYRINFO (GROUP_ID);
CREATE INDEX COMTNENTRPRSMBER_I01 ON COMTNENTRPRSMBER (GROUP_ID);
CREATE INDEX COMTNFILEDETAIL_I01 ON COMTNFILEDETAIL (ATCH_FILE_ID);
CREATE INDEX COMTHEMAILDSPTCHMANAGE_I01 ON COMTHEMAILDSPTCHMANAGE (SNDR);
CREATE INDEX COMTHEMAILDSPTCHMANAGE_I02 ON COMTHEMAILDSPTCHMANAGE (ATCH_FILE_ID);
CREATE INDEX COMTNBBSUSE_I01 ON COMTNBBSUSE (BBS_ID);
CREATE INDEX COMTNBBS_I01 ON COMTNBBS (BBS_ID);
CREATE INDEX COMTNCOMMENT_I01 ON COMTNCOMMENT (NTT_ID,BBS_ID);
CREATE INDEX COMTNCMMNTYUSER_I01 ON COMTNCMMNTYUSER (CMMNTY_ID);
CREATE INDEX COMTNCLUBUSER_I01 ON COMTNCLUBUSER (CLB_ID,CMMNTY_ID);
CREATE INDEX COMTNDIARYINFO_I01 ON COMTNDIARYINFO (SCHDUL_ID);
CREATE INDEX COMTNCNTNTSLIST_I01 ON COMTNCNTNTSLIST (CNTNTS_ID);
CREATE INDEX COMTNCNTNTSLIST_I02 ON COMTNCNTNTSLIST (EMPLYR_ID);
CREATE INDEX COMTNFAQINFO_I01 ON COMTNFAQINFO (ATCH_FILE_ID);
CREATE INDEX COMTNADBK_I01 ON COMTNADBK (ADBK_ID);
CREATE INDEX COMTNAUTHORROLERELATE_I01 ON COMTNAUTHORROLERELATE (AUTHOR_CODE);
CREATE INDEX COMTNAUTHORROLERELATE_I02 ON COMTNAUTHORROLERELATE (ROLE_CODE);
CREATE INDEX COMTNQESTNRINFO_I01 ON COMTNQESTNRINFO (QUSTNR_TMPLAT_ID);
CREATE INDEX COMTNQUSTNRRESPONDINFO_I01 ON COMTNQUSTNRRESPONDINFO (QESTNR_ID,QUSTNR_TMPLAT_ID);
CREATE INDEX COMTNQUSTNRQESITM_I02 ON COMTNQUSTNRQESITM (QESTNR_ID,QUSTNR_TMPLAT_ID);
CREATE INDEX COMTNQUSTNRRSPNSRESULT_I01 ON COMTNQUSTNRRSPNSRESULT (QESTNR_ID,QUSTNR_QESITM_ID,QUSTNR_TMPLAT_ID);
CREATE INDEX COMTNQUSTNRIEM_I01 ON COMTNQUSTNRIEM (QUSTNR_QESITM_ID,QESTNR_ID,QUSTNR_TMPLAT_ID);
CREATE INDEX COMTNONLINEPOLLIEM_I01 ON COMTNONLINEPOLLIEM (POLL_ID);
CREATE INDEX COMTNONLINEPOLLRESULT_I01 ON COMTNONLINEPOLLRESULT (POLL_IEM_ID,POLL_ID);
CREATE INDEX COMTNNEWSINFO_I01 ON COMTNNEWSINFO (ATCH_FILE_ID);
CREATE INDEX COMTNEXTRLHRINFO_I01 ON COMTNEXTRLHRINFO (EVENT_ID);
CREATE UNIQUE INDEX COMTRDNMADRZIP_PK ON COMTRDNMADRZIP (RDMN_CODE,SN);
CREATE INDEX COMTNEMPLYRSCRTYESTBS_I04 ON COMTNEMPLYRSCRTYESTBS (AUTHOR_CODE);
CREATE UNIQUE INDEX COMTNROLES_HIERARCHY_I01 ON COMTNROLES_HIERARCHY (PARNTS_ROLE);
CREATE INDEX COMTHPROGRMCHANGEDTLS_I01 ON COMTHPROGRMCHANGEDTLS (PROGRM_FILE_NM);
CREATE INDEX COMTNMENUINFO_I02 ON COMTNMENUINFO (UPPER_MENU_NO);
CREATE INDEX COMTNMENUCREATDTLS_I02 ON COMTNMENUCREATDTLS (MENU_NO);
CREATE INDEX COMTNMENUCREATDTLS_I03 ON COMTNMENUCREATDTLS (MAPNG_CREAT_ID);
CREATE INDEX COMTNMENUCREATDTLS_I04 ON COMTNMENUCREATDTLS (AUTHOR_CODE);

-- 외래키
ALTER TABLE COMTCCMMNCODE ADD CONSTRAINT COMTCCMMNCODE_FK1 FOREIGN KEY (CL_CODE) REFERENCES COMTCCMMNCLCODE (CL_CODE);
ALTER TABLE COMTCCMMNDETAILCODE ADD CONSTRAINT COMTCCMMNDETAILCODE_FK1 FOREIGN KEY (CODE_ID) REFERENCES COMTCCMMNCODE (CODE_ID);
ALTER TABLE COMTNGNRLMBER ADD CONSTRAINT COMTNGNRLMBER_FK1 FOREIGN KEY (GROUP_ID) REFERENCES COMTNAUTHORGROUPINFO (GROUP_ID) ON DELETE SET NULL;
ALTER TABLE COMTNEMPLYRINFO ADD CONSTRAINT COMTNEMPLYRINFO_FK2 FOREIGN KEY (ORGNZT_ID) REFERENCES COMTNORGNZTINFO (ORGNZT_ID) ON DELETE SET NULL;
ALTER TABLE COMTNEMPLYRINFO ADD CONSTRAINT COMTNEMPLYRINFO_FK1 FOREIGN KEY (GROUP_ID) REFERENCES COMTNAUTHORGROUPINFO (GROUP_ID) ON DELETE SET NULL;
ALTER TABLE COMTNENTRPRSMBER ADD CONSTRAINT COMTNENTRPRSMBER_FK1 FOREIGN KEY (GROUP_ID) REFERENCES COMTNAUTHORGROUPINFO (GROUP_ID) ON DELETE SET NULL;
ALTER TABLE COMTNFILEDETAIL ADD CONSTRAINT COMTNFILEDETAIL_FK1 FOREIGN KEY (ATCH_FILE_ID) REFERENCES COMTNFILE (ATCH_FILE_ID);
ALTER TABLE COMTHEMAILDSPTCHMANAGE ADD CONSTRAINT COMTHEMAILDSPTCHMANAGE_FK1 FOREIGN KEY (SNDR) REFERENCES COMTNEMPLYRINFO (EMPLYR_ID);
ALTER TABLE COMTHEMAILDSPTCHMANAGE ADD CONSTRAINT COMTHEMAILDSPTCHMANAGE_FK2 FOREIGN KEY (ATCH_FILE_ID) REFERENCES COMTNFILE (ATCH_FILE_ID);
ALTER TABLE COMTNBBSUSE ADD CONSTRAINT COMTNBBSUSE_FK1 FOREIGN KEY (BBS_ID) REFERENCES COMTNBBSMASTER (BBS_ID);
ALTER TABLE COMTNBBS ADD CONSTRAINT COMTNBBS_FK1 FOREIGN KEY (BBS_ID) REFERENCES COMTNBBSMASTER (BBS_ID);
ALTER TABLE COMTNCOMMENT ADD CONSTRAINT COMTNCOMMENT_FK1 FOREIGN KEY (NTT_ID,BBS_ID) REFERENCES COMTNBBS (NTT_ID,BBS_ID);
ALTER TABLE COMTNCMMNTYUSER ADD CONSTRAINT COMTNCMMNTYUSER_FK1 FOREIGN KEY (CMMNTY_ID) REFERENCES COMTNCMMNTY (CMMNTY_ID);
ALTER TABLE COMTNCLUBUSER ADD CONSTRAINT COMTNCLUBUSER_FK1 FOREIGN KEY (CLB_ID,CMMNTY_ID) REFERENCES COMTNCLUB (CLB_ID,CMMNTY_ID);
ALTER TABLE COMTNDIARYINFO ADD CONSTRAINT COMTNDIARYINFO_FK1 FOREIGN KEY (SCHDUL_ID) REFERENCES COMTNSCHDULINFO (SCHDUL_ID);
ALTER TABLE COMTNCNTNTSLIST ADD CONSTRAINT COMTNCNTNTSLIST_FK1 FOREIGN KEY (CNTNTS_ID) REFERENCES COMTNINDVDLPGECNTNTS (CNTNTS_ID);
ALTER TABLE COMTNCNTNTSLIST ADD CONSTRAINT COMTNCNTNTSLIST_FK2 FOREIGN KEY (EMPLYR_ID) REFERENCES COMTNINDVDLPGEESTBS (EMPLYR_ID);
ALTER TABLE COMTNFAQINFO ADD CONSTRAINT COMTNFAQINFO_FK1 FOREIGN KEY (ATCH_FILE_ID) REFERENCES COMTNFILE (ATCH_FILE_ID);
ALTER TABLE COMTNADBK ADD CONSTRAINT COMTNADBK_FK1 FOREIGN KEY (ADBK_ID) REFERENCES COMTNADBKMANAGE (ADBK_ID) ON DELETE CASCADE;
ALTER TABLE COMTNAUTHORROLERELATE ADD CONSTRAINT COMTNAUTHORROLERELATE_FK1 FOREIGN KEY (AUTHOR_CODE) REFERENCES COMTNAUTHORINFO (AUTHOR_CODE) ON DELETE CASCADE;
ALTER TABLE COMTNAUTHORROLERELATE ADD CONSTRAINT COMTNAUTHORROLERELATE_FK2 FOREIGN KEY (ROLE_CODE) REFERENCES COMTNROLEINFO (ROLE_CODE) ON DELETE CASCADE;
ALTER TABLE COMTNQESTNRINFO ADD CONSTRAINT COMTNQESTNRINFO_FK1 FOREIGN KEY (QUSTNR_TMPLAT_ID) REFERENCES COMTNQUSTNRTMPLAT (QUSTNR_TMPLAT_ID);
ALTER TABLE COMTNQUSTNRRESPONDINFO ADD CONSTRAINT COMTNQUSTNRRESPONDINFO_FK1 FOREIGN KEY (QUSTNR_TMPLAT_ID,QESTNR_ID) REFERENCES COMTNQESTNRINFO (QUSTNR_TMPLAT_ID,QESTNR_ID);
ALTER TABLE COMTNQUSTNRQESITM ADD CONSTRAINT COMTNQUSTNRQESITM_FK1 FOREIGN KEY (QUSTNR_TMPLAT_ID,QESTNR_ID) REFERENCES COMTNQESTNRINFO (QUSTNR_TMPLAT_ID,QESTNR_ID);
ALTER TABLE COMTNQUSTNRRSPNSRESULT ADD CONSTRAINT COMTNQUSTNRRSPNSRESULT_FK1 FOREIGN KEY (QESTNR_ID,QUSTNR_QESITM_ID,QUSTNR_TMPLAT_ID) REFERENCES COMTNQUSTNRQESITM (QESTNR_ID,QUSTNR_QESITM_ID,QUSTNR_TMPLAT_ID);
ALTER TABLE COMTNQUSTNRIEM ADD CONSTRAINT COMTNQUSTNRIEM_FK1 FOREIGN KEY (QESTNR_ID,QUSTNR_QESITM_ID,QUSTNR_TMPLAT_ID) REFERENCES COMTNQUSTNRQESITM (QESTNR_ID,QUSTNR_QESITM_ID,QUSTNR_TMPLAT_ID);
ALTER TABLE COMTNONLINEPOLLIEM ADD CONSTRAINT COMTNONLINEPOLLIEM_FK1 FOREIGN KEY (POLL_ID) REFERENCES COMTNONLINEPOLLMANAGE (POLL_ID);
ALTER TABLE COMTNONLINEPOLLRESULT ADD CONSTRAINT COMTNONLINEPOLLRESULT_FK1 FOREIGN KEY (POLL_ID,POLL_IEM_ID) REFERENCES COMTNONLINEPOLLIEM (POLL_ID,POLL_IEM_ID);
ALTER TABLE COMTNNEWSINFO ADD CONSTRAINT COMTNNEWSINFO_FK1 FOREIGN KEY (ATCH_FILE_ID) REFERENCES COMTNFILE (ATCH_FILE_ID) ON DELETE SET NULL;
ALTER TABLE COMTNEXTRLHRINFO ADD CONSTRAINT COMTNEXTRLHRINFO_FK1 FOREIGN KEY (EVENT_ID) REFERENCES COMTNEVENTINFO (EVENT_ID);
ALTER TABLE COMTNROLES_HIERARCHY ADD CONSTRAINT COMTNROLES_HIERARCHY_FK1 FOREIGN KEY (PARNTS_ROLE) REFERENCES COMTNAUTHORINFO (AUTHOR_CODE) ON DELETE CASCADE;
ALTER TABLE COMTNROLES_HIERARCHY ADD CONSTRAINT COMTNROLES_HIERARCHY_FK2 FOREIGN KEY (CHLDRN_ROLE) REFERENCES COMTNAUTHORINFO (AUTHOR_CODE) ON DELETE CASCADE;
ALTER TABLE COMTHPROGRMCHANGEDTLS ADD CONSTRAINT COMTHPROGRMCHANGEDTLS_FK1 FOREIGN KEY (PROGRM_FILE_NM) REFERENCES COMTNPROGRMLIST (PROGRM_FILE_NM) ON DELETE CASCADE;
ALTER TABLE COMTNMENUINFO ADD CONSTRAINT COMTNMENUINFO_FK2 FOREIGN KEY (PROGRM_FILE_NM) REFERENCES COMTNPROGRMLIST (PROGRM_FILE_NM) ON DELETE CASCADE;
ALTER TABLE COMTNMENUINFO ADD CONSTRAINT COMTNMENUINFO_FK1 FOREIGN KEY (UPPER_MENU_NO) REFERENCES COMTNMENUINFO (MENU_NO) ON DELETE CASCADE;
ALTER TABLE COMTNMENUCREATDTLS ADD CONSTRAINT COMTNMENUCREATDTLS_FK2 FOREIGN KEY (MENU_NO) REFERENCES COMTNMENUINFO (MENU_NO) ON DELETE CASCADE;
ALTER TABLE COMTNMENUCREATDTLS ADD CONSTRAINT COMTNMENUCREATDTLS_FK3 FOREIGN KEY (MAPNG_CREAT_ID) REFERENCES COMTNSITEMAP (MAPNG_CREAT_ID) ON DELETE CASCADE;
ALTER TABLE COMTNMENUCREATDTLS ADD CONSTRAINT COMTNMENUCREATDTLS_FK1 FOREIGN KEY (AUTHOR_CODE) REFERENCES COMTNAUTHORINFO (AUTHOR_CODE);
ALTER TABLE COMTHEMPLYRINFOCHANGEDTLS ADD CONSTRAINT COMTHEMPLYRINFOCHANGEDTLS_FK1 FOREIGN KEY (EMPLYR_ID) REFERENCES COMTNEMPLYRINFO (EMPLYR_ID);

-- 뷰
CREATE VIEW COMVNUSERMASTER ( ESNTL_ID,USER_ID,PASSWORD,USER_NM,USER_ZIP,USER_ADRES,USER_EMAIL,GROUP_ID, USER_SE, ORGNZT_ID ) 
	AS 
	SELECT ESNTL_ID, MBER_ID,PASSWORD,MBER_NM,ZIP,ADRES,MBER_EMAIL_ADRES,' ','GNR' AS USER_SE, ' ' ORGNZT_ID
	FROM COMTNGNRLMBER
	UNION ALL
	SELECT ESNTL_ID,EMPLYR_ID,PASSWORD,USER_NM,ZIP,HOUSE_ADRES,EMAIL_ADRES,GROUP_ID ,'USR' AS USER_SE, ORGNZT_ID
	FROM COMTNEMPLYRINFO
	UNION ALL
	SELECT ESNTL_ID,ENTRPRS_MBER_ID,ENTRPRS_MBER_PASSWORD,CMPNY_NM,ZIP,ADRES,APPLCNT_EMAIL_ADRES,' ' ,'ENT' AS USER_SE, ' ' ORGNZT_ID
	FROM COMTNENTRPRSMBER;

-- 컬럼 설명
COMMENT ON COLUMN COMTNREALTIMENOTICE.SN IS '순번';
COMMENT ON COLUMN COMTNREALTIMENOTICE.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNREALTIMENOTICE.NOTICE_SJ IS '공지제목';
COMMENT ON COLUMN COMTNREALTIMENOTICE.NOTICE_CN IS '공지내용';
COMMENT ON COLUMN COMTNREALTIMENOTICE.RECENT_CODE_ID IS '최신구분코드ID';
COMMENT ON COLUMN COMTNREALTIMENOTICE.RECENT_CODE IS '최신구분코드';
COMMENT ON COLUMN COMTNREALTIMENOTICE.NOTICE_BGNDT IS '공지시작일시';
COMMENT ON COLUMN COMTNREALTIMENOTICE.NOTICE_ENDDT IS '공지종료일시';
COMMENT ON COLUMN COMTNREALTIMENOTICE.CREAT_DT IS '생성일시';
COMMENT ON COLUMN COMTNREALTIMENOTICE.UPDT_DT IS '수정일시';
COMMENT ON COLUMN COMTNSYNC.SN IS '순번';
COMMENT ON COLUMN COMTNSYNC.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNSYNC.SYNC_SJ IS '동기화글제목';
COMMENT ON COLUMN COMTNSYNC.SYNC_CN IS '동기화글내용';
COMMENT ON COLUMN COMTNSYNC.SYNC_DT IS '동기화일시';
COMMENT ON COLUMN COMTNSYNC.CREAT_DT IS '생성일시';
COMMENT ON COLUMN COMTNSYNC.UPDT_DT IS '수정일시';
COMMENT ON COLUMN COMTNOFFLINEWEB.SN IS '순번';
COMMENT ON COLUMN COMTNOFFLINEWEB.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNOFFLINEWEB.OFFLINE_SJ IS '오프라인제목';
COMMENT ON COLUMN COMTNOFFLINEWEB.OFFLINE_CN IS '오프라인내용';
COMMENT ON COLUMN COMTNOFFLINEWEB.CREAT_DT IS '생성일시';
COMMENT ON COLUMN COMTNOFFLINEWEB.UPDT_DT IS '수정일시';
COMMENT ON COLUMN COMTNCHARTGRAPH.SN IS '순번';
COMMENT ON COLUMN COMTNCHARTGRAPH.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNCHARTGRAPH.XAXIS IS 'X축값';
COMMENT ON COLUMN COMTNCHARTGRAPH.YAXIS IS 'Y축값';
COMMENT ON COLUMN COMTNCHARTGRAPH.LGD_NM IS '범례명';
COMMENT ON COLUMN COMTNCHARTGRAPH.CREAT_DT IS '생성일시';
COMMENT ON COLUMN COMTNCHARTGRAPH.UPDT_DT IS '수정일시';
COMMENT ON COLUMN COMTNDEVICE.SN IS '순번';
COMMENT ON COLUMN COMTNDEVICE.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNDEVICE.UAGENT_INFO IS 'UserAgent정보';
COMMENT ON COLUMN COMTNDEVICE.BROWSER_CODE_ID IS '브라우저코드ID';
COMMENT ON COLUMN COMTNDEVICE.BROWSER_CODE IS '브라우저코드';
COMMENT ON COLUMN COMTNDEVICE.OS_CODE_ID IS '운영체제코드ID';
COMMENT ON COLUMN COMTNDEVICE.OS_CODE IS '운영체제코드';
COMMENT ON COLUMN COMTNDEVICE.RECENT_CODE_ID IS '최신구분코드ID';
COMMENT ON COLUMN COMTNDEVICE.RECENT_CODE IS '최신구분코드';
COMMENT ON COLUMN COMTNDEVICE.CREAT_DT IS '생성일시';
COMMENT ON COLUMN COMTNDEVICE.UPDT_DT IS '수정일시';
COMMENT ON COLUMN COMTNPHOTOALBUM.SN IS '순번';
COMMENT ON COLUMN COMTNPHOTOALBUM.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNPHOTOALBUM.PHOTO_SJ IS '사진제목';
COMMENT ON COLUMN COMTNPHOTOALBUM.ATCH_FILE_ID IS '첨부파일ID';
COMMENT ON COLUMN COMTNPHOTOALBUM.CREAT_DT IS '생성일시';
COMMENT ON COLUMN COMTNPHOTOALBUM.UPDT_DT IS '수정일시';
COMMENT ON COLUMN COMTNMLTMD.SN IS '순번';
COMMENT ON COLUMN COMTNMLTMD.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNMLTMD.ATCH_FILE_ID IS '첨부파일ID';
COMMENT ON COLUMN COMTNMLTMD.MLTMD_CODE_ID IS '멀티미디어구분코드ID';
COMMENT ON COLUMN COMTNMLTMD.MLTMD_CODE IS '멀티미디어구분코드';
COMMENT ON COLUMN COMTNMLTMD.MLTMD_SJ IS '멀티미디어제목';
COMMENT ON COLUMN COMTNMLTMD.BROWSER_NM IS '브라우저명';
COMMENT ON COLUMN COMTNMLTMD.CREAT_DT IS '생성일시';
COMMENT ON COLUMN COMTNMLTMD.UPDT_DT IS '수정일시';
COMMENT ON COLUMN COMTNMMS.SN IS '순번';
COMMENT ON COLUMN COMTNMMS.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNMMS.TRNSMIS_NO IS '송신번호';
COMMENT ON COLUMN COMTNMMS.RECPTN_NO IS '회신번호';
COMMENT ON COLUMN COMTNMMS.MSSAGE_SJ IS 'MMS제목';
COMMENT ON COLUMN COMTNMMS.MSSAGE_CN IS 'MMS내용';
COMMENT ON COLUMN COMTNMMS.MSSAGE_ID IS '메시지ID';
COMMENT ON COLUMN COMTNMMS.RQESTER_RESULT_CODE_ID IS '요청결과코드ID';
COMMENT ON COLUMN COMTNMMS.RQESTER_RESULT_CODE IS '요청결과코드';
COMMENT ON COLUMN COMTNMMS.TRNSMIS_RESULT_CODE_ID IS '전송결과코드ID';
COMMENT ON COLUMN COMTNMMS.TRNSMIS_RESULT_CODE IS '전송결과코드';
COMMENT ON COLUMN COMTNMMS.TRNSMIS_DT IS '전송일시';
COMMENT ON COLUMN COMTNMMS.TRNSMIS_CONFIRM_DT IS '전송확인일시';
COMMENT ON COLUMN COMTNMMSATTACH.SN IS '순번';
COMMENT ON COLUMN COMTNMMSATTACH.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNMMSATTACH.ATCH_FILE_ID IS '첨부파일ID';
COMMENT ON COLUMN COMTNMMSATTACH.MMS_ATCH_FILE_SJ IS '첨부파일제목';
COMMENT ON COLUMN COMTNMMSATTACH.CREAT_DT IS '생성일시';
COMMENT ON COLUMN COMTNMMSATTACH.UPDT_DT IS '수정일시';
COMMENT ON COLUMN COMTNGEOLOCATION.SN IS '순번';
COMMENT ON COLUMN COMTNGEOLOCATION.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNGEOLOCATION.BULD_NM IS '건물명';
COMMENT ON COLUMN COMTNGEOLOCATION.LA IS '위도';
COMMENT ON COLUMN COMTNGEOLOCATION.LO IS '경도';
COMMENT ON COLUMN COMTNGEOLOCATION.TELNO IS '전화번호';
COMMENT ON COLUMN COMTNGEOLOCATION.ADRES IS '주소';
COMMENT ON COLUMN COMTNOPENAPI.SN IS '순번';
COMMENT ON COLUMN COMTNOPENAPI.MBER_ID IS '회원ID';
COMMENT ON COLUMN COMTNOPENAPI.OPEN_API_SVC_CODE_ID IS 'OPEN-API서비스구분코드ID';
COMMENT ON COLUMN COMTNOPENAPI.OPEN_API_SVC_CODE IS 'OPEN-API서비스구분코드';
COMMENT ON COLUMN COMTNOPENAPI.OPEN_API_SVC_CN IS 'OPEN-API서비스내용';
COMMENT ON COLUMN COMTNOPENAPI.OPENAPI_PROVD_INSTT_CODE_ID IS 'OPEN-API제공기관코드ID';
COMMENT ON COLUMN COMTNOPENAPI.OPENAPI_PROVD_INSTT_CODE IS 'OPEN-API제공기관코드';
COMMENT ON COLUMN COMTNOPENAPI.COLLECT_DT IS '수집일시';
