<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<%@ page isErrorPage="true" %>
<html lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>▒▒▒  eGovFrame Potal 온라인 지원 포탈  ▒▒▒</title>

<link href="<c:url value='/css/egovframework/com/cmm/com.css'/>" rel="stylesheet" type="text/css"/>

<script language="javascript">
function fncGoAfterErrorPage(){
    history.back(-2);
}
</script>
</head>

<body>
<!-- File Extension Error !!! -->
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="top"><br/>
    <br/>
    <br/>
    <table width="600" border="0" cellpadding="0" cellspacing="0" background="er_images/blue_bg.jpg'/>">
      <tr>
        <td align="center"><table width="100%" border="0" cellspacing="9" cellpadding="0">
          <tr>
            <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="left"><img src="<c:url value='/images/egovframework/com/cmm/er_logo.jpg'/>" width="379" height="57" alt="에러로고이미지"/></td>
              </tr>
              <tr>
                <td><br/>
                  <br/></td>
              </tr>
              <tr>
                <td align="center"><table width="520" border="0" cellspacing="2" cellpadding="2">
                  <tr>
                    <td width="74" rowspan="2" align="center"><img src="<c:url value='/images/egovframework/com/cmm/danger.jpg'/>" width="74" height="74" alt="경고이미지"/></td>
                    <td width="399" align="left" class="lt_text2">${exception.message}</td>
                  </tr>
                </table>
                  <table width="500" border="0" cellspacing="2" cellpadding="2">
                                  </table></td>
              </tr>
              <tr>
                <td><br/>
                  <br/></td>
              </tr>
              <tr>
                <td align="center"><a href="#LINK" onClick="fncGoAfterErrorPage();"><img src="<c:url value='/images/egovframework/com/cmm/go_history.jpg'/>" width="90" height="29" alt="바로가기 버튼이미지"/></a></td>
              </tr>
            </table>
              <br/></td>
          </tr>
        </table></td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</body>
</html>
