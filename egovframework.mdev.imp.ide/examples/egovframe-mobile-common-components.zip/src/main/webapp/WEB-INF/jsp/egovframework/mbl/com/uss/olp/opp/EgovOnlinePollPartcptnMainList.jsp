<%-- 온라인POLL 메인 목록 페이지 --%>
<%@ page contentType="text/html; charset=utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<c:set var="ImgUrl" value="/images/egovframework/com/uss/olp/opp/"/>
<c:set var="CssUrl" value="/css/egovframework/com/uss/olp/opp/"/>
<%--  자마스크립트 메세지 출력 --%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html>
<head>
<title>온라인POLL 메인리스트</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<script type="text/javaScript" language="javascript" defer="defer">
<!--
function fncSelectPoll(pollId) {
    document.pollForm.pollId.value = pollId;
    document.pollForm.submit();     
}
-->
</script>
</head>
<body>
<form name="pollForm" method="post" action="<c:url value='/uss/olp/opp/registOnlinePollPartcptn.do'/>">
<table width="200" cellpadding="0" class="table-line" border="0">
<tbody>
<%-- 데이터를 없을때 화면에 메세지를 출력해준다 --%>
<c:if test="${fn:length(resultList) == 0}">
<tr> 
<td class="lt_text6" colspan="2">
	<spring:message code="common.nodata.msg"/>
</td>
</tr>   	          				 			   
</c:if>
<%-- 데이터를 화면에 출력해준다 --%>
<c:forEach items="${resultList}" var="resultInfo" varStatus="status">
<c:if test="${status.count < 6}">
<tr>
    <td class="lt_text6" width="80">
    <div class="divDotText" style="width:80px; border:solid 0px;" align="center">
		<span class="link"><input type="text" size="14" value="<c:out value="${resultInfo.pollNm}"/>" onclick="fncSelectPoll('<c:out value="${resultInfo.pollId}"/>');" title="POLL선택"></span>	   	
    </div>
    </td>
    <td class="lt_text6" width="60px"><c:out value="${fn:substring(resultInfo.frstRegisterPnttm, 0, 10)}"/></td>
</tr>
</c:if>
</c:forEach>
</tbody>  
</table>
<input name="pollId" type="hidden" value="">
<input name="pageIndex" type="hidden" value="1"/>
</form>
</body>
</html>
