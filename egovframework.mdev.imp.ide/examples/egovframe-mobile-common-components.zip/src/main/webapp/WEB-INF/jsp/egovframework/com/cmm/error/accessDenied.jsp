<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%--
	접근 거부 화면
	- 실행환경 보안(egov-security-config.properties accessDeniedUrl/csrfAccessDeniedUrl) : 권한 없음, CSRF 토큰 오류
	- 등록자가 아닌 사용자의 수정/삭제 요청(EgovAccessDeniedException)
--%>
<% response.setStatus(HttpServletResponse.SC_FORBIDDEN); %>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>접근 권한 없음</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/egovframework/mbl/cmm/jquery.mobile-1.4.5.css"/>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/egovframework/mbl/cmm/EgovMobile-1.4.5.css"/>
<script type="text/javascript" src="${pageContext.request.contextPath}/js/egovframework/mbl/cmm/jquery-1.11.2.js"></script>
<script type="text/javascript" src="${pageContext.request.contextPath}/js/egovframework/mbl/cmm/jquery.mobile-1.4.5.js"></script>
</head>
<body>
<div data-role="page">
	<div data-role="header" data-theme="z" class="com-egovHeaderBar">
		<h1><img src="${pageContext.request.contextPath}/images/egovframework/mbl/bod/logo.png" alt="logo"></h1>
	</div>
	<div data-role="content">
		<h3>접근 권한이 없습니다.</h3>
		<p>요청한 기능을 사용할 권한이 없거나, 본인이 등록한 글만 수정/삭제할 수 있습니다.</p>
		<a href="javascript:history.back();" data-role="button" data-theme="c">이전 화면</a>
		<a href="${pageContext.request.contextPath}/" data-role="button" data-theme="b" rel="external">메인 화면</a>
	</div>
</div>
</body>
</html>
