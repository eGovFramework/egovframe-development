/**
 * eGovFrame Common Validation JavaScript Library
 * Spring Modules Validation을 대체하는 클라이언트사이드 검증 라이브러리
 */

const EgovValidation = {
    
    // 에러 메시지 설정
    messages: {
        required: '{0}은(는) 필수입력 항목입니다.',
        maxlength: '{0}은(는) {1}자를 초과할 수 없습니다.',
        minlength: '{0}은(는) {1}자 이상이어야 합니다.',
        integer: '{0}은(는) 숫자여야 합니다.',
        float: '{0}은(는) 실수여야 합니다.',
        email: '{0}은(는) 올바른 이메일 형식이 아닙니다.',
        date: '{0}은(는) 올바른 날짜 형식이 아닙니다.',
        mask: '{0}은(는) 올바른 형식이 아닙니다.',
        minInteger: '{0}은(는) {1} 이상이어야 합니다.',
        password1: '패스워드는 8~20자 이내여야 합니다.',
        password2: '패스워드에 특수문자를 사용할 수 없습니다.',
        password3: '연속된 문자나 순차적인 문자 4개 이상 사용할 수 없습니다.',
        password4: '반복문자나 숫자 연속 4개 이상 사용할 수 없습니다.',
        pwdCheckComb3: '영문자, 숫자, 특수문자의 최소 3가지 조합이어야 합니다.',
        pwdCheckComb4: '영대문자, 영소문자, 숫자, 특수문자의 최소 4가지 조합이어야 합니다.',
        pwdCheckSeries: '연속된 3개 이상의 문자나 숫자를 사용할 수 없습니다.',
        pwdCheckRepeat: '반복된 3개 이상의 문자나 숫자를 사용할 수 없습니다.',
        english: '{0}은(는) 영문자만 입력 가능합니다.'
    },
    
    // 기본 validation 규칙들
    rules: {
        // 필수입력 검사
        required: function(value) {
            return value !== null && value !== undefined && 
                   (typeof value === 'string' ? value.trim().length > 0 : true);
        },
        
        // 최대 길이 검사
        maxlength: function(value, max) {
            if (!value) return true;
            return value.length <= parseInt(max);
        },
        
        // 최소 길이 검사
        minlength: function(value, min) {
            if (!value) return true;
            return value.length >= parseInt(min);
        },
        
        // 숫자 검사
        integer: function(value) {
            if (!value) return true;
            return /^\d+$/.test(value);
        },
        
        // 실수 검사
        float: function(value) {
            if (!value) return true;
            return /^-?\d+(\.\d+)?$/.test(value);
        },
        
        // 최소 정수값 검사
        minInteger: function(value, min) {
            if (!value) return true;
            const num = parseInt(value);
            return !isNaN(num) && num >= parseInt(min);
        },
        
        // 이메일 검사
        email: function(value) {
            if (!value) return true;
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(value);
        },
        
        // 날짜 검사 (YYYYMMDD, YYYY-MM-DD 등)
        date: function(value) {
            if (!value) return true;
            // YYYYMMDD 형식
            if (/^\d{8}$/.test(value)) {
                const year = parseInt(value.substring(0, 4));
                const month = parseInt(value.substring(4, 6));
                const day = parseInt(value.substring(6, 8));
                const date = new Date(year, month - 1, day);
                return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
            }
            // YYYY-MM-DD 형식
            if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
                const date = new Date(value);
                return !isNaN(date.getTime());
            }
            return false;
        },
        
        // 정규식 패턴 검사
        mask: function(value, pattern) {
            if (!value) return true;
            const regex = new RegExp(pattern);
            return regex.test(value);
        },
        
        // 영문자만 허용
        english: function(value) {
            if (!value) return true;
            return /^[a-zA-Z]+$/.test(value);
        },
        
        // 패스워드 길이 검사 (8~20자)
        password1: function(value) {
            if (!value) return true;
            return value.length >= 8 && value.length <= 20;
        },
        
        // 패스워드 특수문자 제한
        password2: function(value) {
            if (!value) return true;
            // 특수문자 체크 (ASCII 33-47, 58-64, 91-96, 123-126)
            for (let i = 0; i < value.length; i++) {
                const ch = value.charCodeAt(i);
                if ((ch >= 33 && ch <= 47) || (ch >= 58 && ch <= 64) || 
                    (ch >= 91 && ch <= 96) || (ch >= 123 && ch <= 126)) {
                    return false;
                }
            }
            return true;
        },
        
        // 연속된 문자/순차적 문자 4개 이상 금지
        password3: function(value) {
            if (!value) return true;
            let cnt = 0, cnt2 = 1, cnt3 = 1;
            let temp = "";
            
            for (let i = 0; i < value.length; i++) {
                const ch = value.charAt(i);
                if (i > 0) {
                    const prevCh = value.charAt(i-1);
                    if (ch.charCodeAt(0) - prevCh.charCodeAt(0) === 1) {
                        cnt2++;
                        if (cnt2 >= 4) return false;
                    } else {
                        cnt2 = 1;
                    }
                    
                    if (ch.charCodeAt(0) - prevCh.charCodeAt(0) === -1) {
                        cnt3++;
                        if (cnt3 >= 4) return false;
                    } else {
                        cnt3 = 1;
                    }
                }
            }
            return true;
        },
        
        // 반복문자/숫자 연속 4개 이상 금지
        password4: function(value) {
            if (!value) return true;
            for (let i = 0; i < value.length - 3; i++) {
                if (value.charAt(i) === value.charAt(i+1) && 
                    value.charAt(i) === value.charAt(i+2) && 
                    value.charAt(i) === value.charAt(i+3)) {
                    return false;
                }
            }
            return true;
        },
        
        // 3가지 조합 (영문자, 숫자, 특수문자)
        pwdCheckComb3: function(value) {
            if (!value) return true;
            let hasAlpha = /[a-zA-Z]/.test(value);
            let hasNum = /\d/.test(value);
            let hasSpecial = /[~!@#$%^&*?]/.test(value);
            
            let count = 0;
            if (hasAlpha) count++;
            if (hasNum) count++;
            if (hasSpecial) count++;
            
            return count >= 3;
        },
        
        // 4가지 조합 (영대문자, 영소문자, 숫자, 특수문자)
        pwdCheckComb4: function(value) {
            if (!value) return true;
            let hasUpper = /[A-Z]/.test(value);
            let hasLower = /[a-z]/.test(value);
            let hasNum = /\d/.test(value);
            let hasSpecial = /[~!@#$%^&*?]/.test(value);
            
            let count = 0;
            if (hasUpper) count++;
            if (hasLower) count++;
            if (hasNum) count++;
            if (hasSpecial) count++;
            
            return count >= 4;
        },
        
        // 연속된 3개 이상의 문자나 숫자 금지
        pwdCheckSeries: function(value) {
            if (!value) return true;
            for (let i = 0; i < value.length - 2; i++) {
                const ch1 = value.charCodeAt(i);
                const ch2 = value.charCodeAt(i+1);
                const ch3 = value.charCodeAt(i+2);
                
                if ((ch2 - ch1 === 1 && ch3 - ch2 === 1) || 
                    (ch1 - ch2 === 1 && ch2 - ch3 === 1)) {
                    return false;
                }
            }
            return true;
        },
        
        // 반복된 3개 이상의 문자나 숫자 금지
        pwdCheckRepeat: function(value) {
            if (!value) return true;
            for (let i = 0; i < value.length - 2; i++) {
                if (value.charAt(i) === value.charAt(i+1) && 
                    value.charAt(i) === value.charAt(i+2)) {
                    return false;
                }
            }
            return true;
        }
    },
    
    // 폼 검증 함수
    validateForm: function(formElement, validationRules) {
        const errors = [];
        let firstErrorField = null;
        
        for (const fieldName in validationRules) {
            const field = formElement.elements[fieldName];
            if (!field) continue;
            
            const fieldRules = validationRules[fieldName];
            const fieldValue = this.getFieldValue(field);
            const fieldLabel = fieldRules.label || fieldName;
            
            // 각 규칙별로 검증
            for (const ruleName in fieldRules.rules) {
                if (ruleName === 'label') continue;
                
                const ruleValue = fieldRules.rules[ruleName];
                const ruleFunction = this.rules[ruleName];
                
                if (ruleFunction) {
                    let isValid = false;
                    
                    if (ruleValue === true) {
                        // 매개변수가 없는 규칙
                        isValid = ruleFunction(fieldValue);
                    } else {
                        // 매개변수가 있는 규칙
                        isValid = ruleFunction(fieldValue, ruleValue);
                    }
                    
                    if (!isValid) {
                        const errorMsg = this.formatMessage(this.messages[ruleName], fieldLabel, ruleValue);
                        errors.push(errorMsg);
                        
                        if (!firstErrorField) {
                            firstErrorField = field;
                        }
                        break; // 첫 번째 에러만 표시
                    }
                }
            }
        }
        
        if (errors.length > 0) {
            alert(errors.join('\n'));
            if (firstErrorField) {
                firstErrorField.focus();
            }
            return false;
        }
        
        return true;
    },
    
    // 필드 값 가져오기
    getFieldValue: function(field) {
        if (!field) return '';
        
        if (field.type === 'checkbox' || field.type === 'radio') {
            if (field.length) {
                // 배열인 경우
                for (let i = 0; i < field.length; i++) {
                    if (field[i].checked) {
                        return field[i].value;
                    }
                }
                return '';
            } else {
                return field.checked ? field.value : '';
            }
        } else if (field.type === 'select-one') {
            return field.selectedIndex >= 0 ? field.options[field.selectedIndex].value : '';
        } else if (field.type === 'select-multiple') {
            const values = [];
            for (let i = 0; i < field.options.length; i++) {
                if (field.options[i].selected) {
                    values.push(field.options[i].value);
                }
            }
            return values.join(',');
        } else {
            return field.value || '';
        }
    },
    
    // 메시지 포맷팅
    formatMessage: function(template, ...args) {
        return template.replace(/{(\d+)}/g, function(match, index) {
            return args[index] !== undefined ? args[index] : match;
        });
    },
    
    // 문자열 trim 유틸리티
    trim: function(str) {
        return str ? str.replace(/^\s+|\s+$/g, '') : '';
    }
};

// 전역 함수로 노출 (기존 코드 호환성을 위해)
window.EgovValidation = EgovValidation;

// 기존 Spring Modules validation 함수들을 대체하는 래퍼 함수들
function validateArticleVO(form) {
    const rules = {
        nttSj: {
            label: '제목',
            rules: {
                required: true,
                maxlength: 1200
            }
        },
        nttCn: {
            label: '내용',
            rules: {
                required: true
            }
        }
    };
    return EgovValidation.validateForm(form, rules);
}
// Auto-generated validation functions from XML files

function validateAdbk(form) {
    const rules = {
        adbkNm: {
            label: 'cop.adbkNm',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        othbcScope: {
            label: 'cop.othbcScope',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateBoardMaster(form) {
    const rules = {
        bbsNm: {
            label: 'cop.bbsNm',
            rules: {
                required: true,
                maxlength: 120,
            }
        },
        bbsIntrcn: {
            label: 'cop.bbsIntrcn',
            rules: {
                required: true,
                maxlength: 2000,
            }
        },
        bbsTyCode: {
            label: 'cop.bbsTyCode',
            rules: {
                required: true,
            }
        },
        bbsAttrbCode: {
            label: 'cop.bbsAttrbCode',
            rules: {
                required: true,
            }
        },
        replyPosblAt: {
            label: 'cop.replyPosblAt',
            rules: {
                required: true,
            }
        },
        fileAtchPosblAt: {
            label: 'cop.fileAtchPosblAt',
            rules: {
                required: true,
            }
        },
        posblAtchFileNumber: {
            label: 'cop.posblAtchFileNumber',
            rules: {
                required: true,
            }
        },
        tmplatId: {
            label: 'cop.tmplatId',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateComment(form) {
    const rules = {
        wrterNm: {
            label: 'cop.comment.wrterNm',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        commentCn: {
            label: 'cop.comment.commentCn',
            rules: {
                required: true,
                maxlength: 200,
            }
        },
        commentPassword: {
            label: 'cop.comment.commentPassword',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateGuestRegist(form) {
    const rules = {
        nttCn: {
            label: 'cop.nttCn',
            rules: {
                required: true,
            }
        },
        ntcrNm: {
            label: 'cop.ntcrNm',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateBoard(form) {
    const rules = {
        nttSj: {
            label: 'cop.nttSj',
            rules: {
                required: true,
                maxlength: 1200,
            }
        },
        nttCn: {
            label: 'cop.nttCn',
            rules: {
                required: true,
            }
        },
        ntceBgnde: {
            label: 'cop.ntceBgnde',
            rules: {
                required: true,
            }
        },
        ntceEndde: {
            label: 'cop.ntceEndde',
            rules: {
                required: true,
            }
        },
        ntcrNm: {
            label: 'cop.ntcrNm',
            rules: {
                required: true,
            }
        },
        password: {
            label: 'cop.password',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateSatisfaction(form) {
    const rules = {
        wrterNm: {
            label: 'cop.satisfaction.wrterNm',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        stsfdgCn: {
            label: 'cop.satisfaction.stsfdgCn',
            rules: {
                maxlength: 200,
            }
        },
        stsfdg: {
            label: 'cop.satisfaction.stsfdg',
            rules: {
                required: true,
            }
        },
        stsfdgPassword: {
            label: 'cop.satisfaction.stsfdgPassword',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateScrap(form) {
    const rules = {
        scrapNm: {
            label: 'cop.scrap.scrapNm',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateClub(form) {
    const rules = {
        cmmntyId: {
            label: 'cop.cmmntyNm',
            rules: {
                required: true,
            }
        },
        clbNm: {
            label: 'cop.clbNm',
            rules: {
                required: true,
                maxlength: 120,
            }
        },
        clbIntrcn: {
            label: 'cop.clbIntrcn',
            rules: {
                required: true,
                maxlength: 1200,
            }
        },
        tmplatId: {
            label: 'cop.tmplatId',
            rules: {
                required: true,
            }
        },
        emplyrId: {
            label: 'cop.clbOprtr',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateCommunity(form) {
    const rules = {
        cmmntyNm: {
            label: 'cop.cmmntyNm',
            rules: {
                required: true,
                maxlength: 120,
            }
        },
        cmmntyIntrcn: {
            label: 'cop.cmmntyIntrcn',
            rules: {
                required: true,
                maxlength: 1200,
            }
        },
        tmplatId: {
            label: 'cop.tmplatId',
            rules: {
                required: true,
            }
        },
        emplyrId: {
            label: 'cop.cmmntyMngr',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateTemplateInf(form) {
    const rules = {
        tmplatNm: {
            label: 'cop.tmplatNm',
            rules: {
                required: true,
                maxlength: 120,
            }
        },
        tmplatCours: {
            label: 'cop.tmplatCours',
            rules: {
                required: true,
                maxlength: 2000,
            }
        },
        tmplatSeCode: {
            label: 'cop.tmplatSeCode',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateBoardUseInf(form) {
    const rules = {
        bbsId: {
            label: 'cop.bbsNm',
            rules: {
                required: true,
            }
        },
        trgetId: {
            label: 'cop.trgetNm',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateSndngMailVO(form) {
    const rules = {
        recptnPerson: {
            label: '받는사람',
            rules: {
                required: true,
                email: true,
                maxlength: 50,
            }
        },
        sj: {
            label: '제목',
            rules: {
                required: true,
                maxlength: 60,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateDiaryManageVO(form) {
    const rules = {
        schdulCn: {
            label: '일정정보',
            rules: {
                required: true,
            }
        },
        diaryNm: {
            label: '일지명',
            rules: {
                required: true,
                maxlength: 255,
            }
        },
        drctMatter: {
            label: '지시사항',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
        partclrMatter: {
            label: '특이사항',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
        diaryProcsPte: {
            label: '진척율',
            rules: {
                required: true,
                integer: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateDeptSchdulManageVO(form) {
    const rules = {
        schdulSe: {
            label: '일정구분',
            rules: {
                required: true,
            }
        },
        schdulIpcrCode: {
            label: '중요도',
            rules: {
                required: true,
            }
        },
        schdulDeptName: {
            label: '부서',
            rules: {
                required: true,
            }
        },
        schdulNm: {
            label: '일정명',
            rules: {
                required: true,
                maxlength: 255,
            }
        },
        schdulCn: {
            label: '일정내용',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
        schdulBgndeYYYMMDD: {
            label: '일정시작일자',
            rules: {
                required: true,
            }
        },
        schdulEnddeYYYMMDD: {
            label: '일정종료일자',
            rules: {
                required: true,
            }
        },
        schdulBgndeHH: {
            label: '일정시작(시)',
            rules: {
                required: true,
            }
        },
        schdulEnddeHH: {
            label: '일정종료(시)',
            rules: {
                required: true,
            }
        },
        schdulChargerName: {
            label: '담당자',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateIndvdlSchdulManageVO(form) {
    const rules = {
        schdulSe: {
            label: '일정구분',
            rules: {
                required: true,
            }
        },
        schdulIpcrCode: {
            label: '중요도',
            rules: {
                required: true,
            }
        },
        schdulDeptName: {
            label: '부서',
            rules: {
                required: true,
            }
        },
        schdulNm: {
            label: '일정명',
            rules: {
                required: true,
                maxlength: 255,
            }
        },
        schdulCn: {
            label: '일정내용',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
        schdulBgndeYYYMMDD: {
            label: '일정시작일자',
            rules: {
                required: true,
            }
        },
        schdulEnddeYYYMMDD: {
            label: '일정종료일자',
            rules: {
                required: true,
            }
        },
        schdulBgndeHH: {
            label: '일정시작(시)',
            rules: {
                required: true,
            }
        },
        schdulEnddeHH: {
            label: '일정종료(시)',
            rules: {
                required: true,
            }
        },
        schdulChargerName: {
            label: '담당자',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateRestde(form) {
    const rules = {
        restdeDe: {
            label: '휴일일자',
            rules: {
                required: true,
                maxlength: 8,
            }
        },
        restdeNm: {
            label: '휴일명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        restdeDc: {
            label: '휴일설명',
            rules: {
                required: true,
                maxlength: 200,
            }
        },
        restdeSeCode: {
            label: '휴일구분코드',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateZip(form) {
    const rules = {
        zip: {
            label: '우편번호',
            rules: {
                required: true,
                maxlength: 6,
                integer: true,
            }
        },
        ctprvnNm: {
            label: '시도명',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        signguNm: {
            label: '시군구명',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        emdNm: {
            label: '읍면동명',
            rules: {
                required: true,
                maxlength: 30,
            }
        },
        liBuldNm: {
            label: '리건물명',
            rules: {
                maxlength: 60,
            }
        },
        lnbrDongHo: {
            label: '번지동호',
            rules: {
                maxlength: 20,
            }
        },
        rdmnCode: {
            label: '도로명코드',
            rules: {
                required: true,
                maxlength: 12,
                integer: true,
            }
        },
        rdmn: {
            label: '도로명',
            rules: {
                required: true,
                maxlength: 60,
            }
        },
        bdnbrMnnm: {
            label: '건물번호본번',
            rules: {
                maxlength: 5,
            }
        },
        bdnbrSlno: {
            label: '건물번호부번',
            rules: {
                maxlength: 5,
            }
        },
        buldNm: {
            label: '건물명',
            rules: {
                maxlength: 60,
            }
        },
        detailBuldNm: {
            label: '상세건물명',
            rules: {
                maxlength: 60,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateBkmk(form) {
    const rules = {
        menuNm: {
            label: '메뉴명',
            rules: {
                required: true,
                maxlength: 60,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateMenuCreatVO(form) {
    const rules = {
        menuNo: {
            label: '메뉴번호',
            rules: {
                required: true,
                integer: true,
            }
        },
        menuOrdr: {
            label: '메뉴순서',
            rules: {
                required: true,
                integer: true,
            }
        },
        menuNm: {
            label: '메뉴명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        upperMenuId: {
            label: '메뉴상위번호',
            rules: {
                required: true,
                integer: true,
            }
        },
        progrmFileNm: {
            label: '프로그램파일명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        menuDc: {
            label: '메뉴설명',
            rules: {
                maxlength: 100,
            }
        },
        relateImagePath: {
            label: '관련이미지경로',
            rules: {
                maxlength: 100,
            }
        },
        relateImageNm: {
            label: '관련이미지명',
            rules: {
                maxlength: 50,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateMenuSiteMapVO(form) {
    const rules = {
        menuNo: {
            label: '메뉴번호',
            rules: {
                required: true,
                integer: true,
            }
        },
        menuOrdr: {
            label: '메뉴순서',
            rules: {
                required: true,
                integer: true,
            }
        },
        menuNm: {
            label: '메뉴명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        upperMenuId: {
            label: '메뉴상위번호',
            rules: {
                required: true,
                integer: true,
            }
        },
        progrmFileNm: {
            label: '프로그램파일명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        menuDc: {
            label: '메뉴설명',
            rules: {
                maxlength: 100,
            }
        },
        relateImagePath: {
            label: '관련이미지경로',
            rules: {
                maxlength: 100,
            }
        },
        relateImageNm: {
            label: '관련이미지명',
            rules: {
                maxlength: 50,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateMenuManageVO(form) {
    const rules = {
        menuNo: {
            label: '메뉴번호',
            rules: {
                required: true,
                integer: true,
            }
        },
        menuOrdr: {
            label: '메뉴순서',
            rules: {
                required: true,
                integer: true,
            }
        },
        menuNm: {
            label: '메뉴명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        upperMenuId: {
            label: '메뉴상위번호',
            rules: {
                required: true,
                integer: true,
            }
        },
        progrmFileNm: {
            label: '프로그램파일명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        menuDc: {
            label: '메뉴설명',
            rules: {
                maxlength: 100,
            }
        },
        relateImagePath: {
            label: '관련이미지경로',
            rules: {
                maxlength: 100,
            }
        },
        relateImageNm: {
            label: '관련이미지명',
            rules: {
                maxlength: 50,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateProgrmManageVO(form) {
    const rules = {
        progrmFileNm: {
            label: '프로그램파일명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        progrmStrePath: {
            label: '프로그램저장경로',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        progrmKoreanNm: {
            label: '프로그램한글명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        URL: {
            label: 'URL',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        progrmDc: {
            label: '프로그램설명',
            rules: {
                maxlength: 100,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateProgrmManageDtlVO(form) {
    const rules = {
        progrmFileNm: {
            label: '프로그램파일명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        rqesterNo: {
            label: '요청번호',
            rules: {
                required: true,
                integer: true,
            }
        },
        rqesterPersonId: {
            label: '요청자ID',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        changerqesterCn: {
            label: '변경요청내용',
            rules: {
                maxlength: 1000,
            }
        },
        rqesterProcessCn: {
            label: '요청처리내용',
            rules: {
                maxlength: 1000,
            }
        },
        opetrId: {
            label: '처리자ID',
            rules: {
                maxlength: 20,
            }
        },
        processDe: {
            label: '처리일자',
            rules: {
                date: true,
            }
        },
        rqesterDe: {
            label: '요청일자',
            rules: {
                required: true,
                date: true,
            }
        },
        rqesterSj: {
            label: '요청제목',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validatePasswordVO(form) {
    const rules = {
        id: {
            label: '아이디',
            rules: {
                required: true,
            }
        },
        name: {
            label: '이름',
            rules: {
                required: true,
            }
        },
        email: {
            label: '이메일',
            rules: {
                required: true,
                email: true,
            }
        },
        passwordHint: {
            label: '비밀번호힌트',
            rules: {
                required: true,
            }
        },
        passwordCnsr: {
            label: '비밀번호정답',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateEventCmpgnVO(form) {
    const rules = {
        eventTyCode: {
            label: '행사유형',
            rules: {
                required: true,
            }
        },
        eventCn: {
            label: '행사내용',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
        eventSvcBeginDe: {
            label: '행사시작일자',
            rules: {
                required: true,
                date: true,
            }
        },
        eventSvcEndDe: {
            label: '행사종료일자',
            rules: {
                required: true,
                date: true,
            }
        },
        svcUseNmprCo: {
            label: '서비스이용인원수',
            rules: {
                maxlength: 10,
                integer: true,
            }
        },
        prparetgCn: {
            label: '준비물내용',
            rules: {
                maxlength: 1000,
            }
        },
        eventConfmDe: {
            label: '승인일',
            rules: {
                date: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateTnextrlHrInfoVO(form) {
    const rules = {
        sexdstnCode: {
            label: '성별',
            rules: {
                required: true,
            }
        },
        extrlHrNm: {
            label: '외부인사명',
            rules: {
                required: true,
            }
        },
        brthYYYY: {
            label: '생년월일(년)',
            rules: {
                required: true,
            }
        },
        brthMM: {
            label: '생년월일(월)',
            rules: {
                required: true,
            }
        },
        brthDD: {
            label: '생년월일(일)',
            rules: {
                required: true,
            }
        },
        occpTyCode: {
            label: '직업유형',
            rules: {
                required: true,
            }
        },
        areaNo: {
            label: '지역번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        middleTelno: {
            label: '중간전화번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        endTelno: {
            label: '마지막전화번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        emailAdres: {
            label: '이메일',
            rules: {
                required: true,
                email: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateNewsManageVO(form) {
    const rules = {
        newsSj: {
            label: 'newsManageVO.newsSj',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        newsCn: {
            label: 'newsManageVO.newsCn',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
        ntceDe: {
            label: 'newsManageVO.ntceDe',
            rules: {
                date: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateRecomendSiteManageVO(form) {
    const rules = {
        recomendSiteNm: {
            label: 'recomendSiteManageVO.recomendSiteNm',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        recomendSiteUrl: {
            label: 'recomendSiteManageVO.recomendSiteUrl',
            rules: {
                required: true,
                maxlength: 250,
            }
        },
        recomendSiteDc: {
            label: 'recomendSiteManageVO.recomendSiteDc',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
        recomendResnCn: {
            label: 'recomendSiteManageVO.recomendResnCn',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
        confmDe: {
            label: 'recomendSiteManageVO.confmDe',
            rules: {
                date: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateIndvdlpge(form) {
    const rules = {
        sortMthd: {
            label: '배열방식',
            rules: {
                required: true,
            }
        },
        sortCnt: {
            label: '배열개수',
            rules: {
                required: true,
                integer: true,
                minInteger: true,
            }
        },
        titleBarColor: {
            label: '타이틀 바 색상',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateIndvdlPgeManage(form) {
    const rules = {
        cntntsNm: {
            label: '컨텐츠 명',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        cntcUrl: {
            label: '컨텐츠 연계 URL',
            rules: {
                required: true,
                maxlength: 255,
            }
        },
        cntntsLinkUrl: {
            label: '상세보기 연결 URL',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
        cntntsUseAt: {
            label: '컨텐츠 사용 여부',
            rules: {
                required: true,
            }
        },
        cntntsDc: {
            label: '컨텐츠 설명',
            rules: {
                required: true,
                maxlength: 250,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateAdministrationWordManage(form) {
    const rules = {
        administWordNm: {
            label: '행정용어명',
            rules: {
                required: true,
                maxlength: 255,
            }
        },
        administWordEngNm: {
            label: '행정용어영문명',
            rules: {
                required: true,
                maxlength: 255,
                english: true,
            }
        },
        administWordAbrv: {
            label: '행정용어약어명',
            rules: {
                required: true,
                maxlength: 255,
            }
        },
        themaRelm: {
            label: '주제영역',
            rules: {
                required: true,
            }
        },
        wordDomn: {
            label: '용어구분',
            rules: {
                required: true,
            }
        },
        administWordDf: {
            label: '행정전문용어정의',
            rules: {
                maxlength: 2500,
            }
        },
        administWordDc: {
            label: '행정전문용어설명',
            rules: {
                maxlength: 2500,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateFaqManageVO(form) {
    const rules = {
        qestnSj: {
            label: 'faqManageVO.qestnSj',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
        qestnCn: {
            label: 'faqManageVO.qestnCn',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
        answerCn: {
            label: 'faqManageVO.answerCn',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateHpcmManageVO(form) {
    const rules = {
        hpcmSeCode: {
            label: 'hpcmManageVO.hpcmSeCode',
            rules: {
                required: true,
            }
        },
        hpcmDf: {
            label: 'hpcmManageVO.hpcmDf',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
        hpcmDc: {
            label: 'hpcmManageVO.hpcmDc',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateOnlineManual(form) {
    const rules = {
        onlineMnlNm: {
            label: '온라인메뉴얼명',
            rules: {
                required: true,
                maxlength: 255,
            }
        },
        onlineMnlSeCode: {
            label: '온라인메뉴얼구분',
            rules: {
                required: true,
            }
        },
        onlineMnlDf: {
            label: '온라인메뉴얼정의',
            rules: {
                required: true,
            }
        },
        onlineMnlDc: {
            label: '온라인 메뉴얼설명',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateQnaManageVO(form) {
    const rules = {
        wrterNm: {
            label: 'qnaManageVO.wrterNm',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        writngPassword: {
            label: 'qnaManageVO.writngPassword',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        areaNo: {
            label: 'qnaManageVO.areaNo',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        middleTelno: {
            label: 'qnaManageVO.middleTelno',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        endTelno: {
            label: 'qnaManageVO.endTelno',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        emailAdres: {
            label: 'qnaManageVO.emailAdres',
            rules: {
                email: true,
                maxlength: 50,
            }
        },
        qestnSj: {
            label: 'qnaManageVO.qestnSj',
            rules: {
                required: true,
                maxlength: 250,
            }
        },
        qestnCn: {
            label: 'qnaManageVO.qestnCn',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
        answerCn: {
            label: 'qnaManageVO.answerCn',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateWordDicaryVO(form) {
    const rules = {
        wordNm: {
            label: 'wordDicaryVO.wordNm',
            rules: {
                required: true,
                maxlength: 250,
            }
        },
        engNm: {
            label: 'wordDicaryVO.engNm',
            rules: {
                required: true,
                maxlength: 60,
                english: true,
            }
        },
        wordDc: {
            label: 'wordDicaryVO.wordDc',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
        synonm: {
            label: 'wordDicaryVO.synonm',
            rules: {
                maxlength: 100,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateCnsltManageVO(form) {
    const rules = {
        wrterNm: {
            label: 'cnsltManageVO.wrterNm',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        writngPassword: {
            label: 'cnsltManageVO.writngPassword',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        areaNo: {
            label: 'cnsltManageVO.areaNo',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        middleTelno: {
            label: 'cnsltManageVO.middleTelno',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        endTelno: {
            label: 'cnsltManageVO.endTelno',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        firstMoblphonNo: {
            label: 'cop.mbtlNum',
            rules: {
                maxlength: 4,
                integer: true,
            }
        },
        middleMbtlnum: {
            label: 'cop.mbtlNum',
            rules: {
                maxlength: 4,
                integer: true,
            }
        },
        endMbtlnum: {
            label: 'cop.mbtlNum',
            rules: {
                maxlength: 4,
                integer: true,
            }
        },
        emailAdres: {
            label: 'cnsltManageVO.emailAdres',
            rules: {
                email: true,
                maxlength: 50,
            }
        },
        cnsltSj: {
            label: 'cnsltManageVO.cnsltSj',
            rules: {
                required: true,
                maxlength: 250,
            }
        },
        cnsltCn: {
            label: 'cnsltManageVO.cnsltCn',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
        managtCn: {
            label: 'cnsltManageVO.managtCn',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateMeetingManageVO(form) {
    const rules = {
        mtgNm: {
            label: '회의제목',
            rules: {
                required: true,
                maxlength: 250,
            }
        },
        mtgMtrCn: {
            label: '회의 안건 내용',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
        mtgSn: {
            label: '회의순서',
            rules: {
                required: true,
                maxlength: 10,
                integer: true,
            }
        },
        mtgCo: {
            label: '회의회차',
            rules: {
                required: true,
                maxlength: 5,
                integer: true,
            }
        },
        mtgDe: {
            label: '회의일자',
            rules: {
                required: true,
                date: true,
            }
        },
        mtgPlace: {
            label: '회의장소',
            rules: {
                required: true,
                maxlength: 250,
            }
        },
        mtgBeginHH: {
            label: '회의시작시간(시간)',
            rules: {
                required: true,
            }
        },
        mtgBeginMM: {
            label: '회의시작시간(분)',
            rules: {
                required: true,
            }
        },
        mtgEndHH: {
            label: '회의종료시간(시간)',
            rules: {
                required: true,
            }
        },
        mtgEndMM: {
            label: '회의종료시간(분)',
            rules: {
                required: true,
            }
        },
        readngBeginDe: {
            label: '열람 개시일',
            rules: {
                required: true,
                date: true,
            }
        },
        mtgResultCn: {
            label: '회의결과 내용',
            rules: {
                maxlength: 1000,
            }
        },
        etcMatter: {
            label: '기타 사항',
            rules: {
                maxlength: 1000,
            }
        },
        nonatdrnCo: {
            label: '불참석자수',
            rules: {
                integer: true,
            }
        },
        atdrnCo: {
            label: '참석자수',
            rules: {
                integer: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateOnlinePollManage(form) {
    const rules = {
        pollNm: {
            label: 'POLL명',
            rules: {
                required: true,
                maxlength: 255,
            }
        },
        pollBeginDe: {
            label: 'POLL 시작일자',
            rules: {
                required: true,
                date: true,
            }
        },
        pollEndDe: {
            label: 'POLL 종료일자',
            rules: {
                required: true,
                date: true,
            }
        },
        pollKindCode: {
            label: 'POLL구분',
            rules: {
                required: true,
            }
        },
        pollDsuseYn: {
            label: 'POLL페기유무',
            rules: {
                required: true,
            }
        },
        pollAutoDsuseYn: {
            label: 'POLL자동페기유무',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateQustnrItemManageVO(form) {
    const rules = {
        iemSn: {
            label: '항목순번',
            rules: {
                required: true,
                maxlength: 5,
                integer: true,
            }
        },
        iemCn: {
            label: '항목내용',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateQustnrManageVO(form) {
    const rules = {
        qestnrSj: {
            label: '설문제목',
            rules: {
                required: true,
                maxlength: 250,
            }
        },
        qestnrPurps: {
            label: '설문목적',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
        qestnrWritngGuidanceCn: {
            label: '설문작성안내 내용',
            rules: {
                required: true,
                maxlength: 2000,
            }
        },
        qestnrTrget: {
            label: '설문대상',
            rules: {
                required: true,
            }
        },
        qestnrBeginDe: {
            label: '설문기간  시작일자',
            rules: {
                required: true,
                date: true,
            }
        },
        qestnrEndDe: {
            label: '설문기간  종료일자',
            rules: {
                required: true,
                date: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateQustnrQestnManageVO(form) {
    const rules = {
        qestnSn: {
            label: '질문순번',
            rules: {
                required: true,
                maxlength: 10,
                integer: true,
            }
        },
        qestnTyCode: {
            label: '질문유형',
            rules: {
                required: true,
            }
        },
        qestnCn: {
            label: '질문 내용',
            rules: {
                required: true,
                maxlength: 2500,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateQustnrRespondInfoVO(form) {
    const rules = {
        respondNm: {
            label: '응답자명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        respondAnswerCn: {
            label: '응답자답변내용(주관식)',
            rules: {
                maxlength: 1000,
            }
        },
        etcAnswerCn: {
            label: '기타답변내용',
            rules: {
                maxlength: 1000,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateQustnrRespondManageVO(form) {
    const rules = {
        sexdstnCode: {
            label: '성별',
            rules: {
                required: true,
            }
        },
        occpTyCode: {
            label: '직업',
            rules: {
                required: true,
            }
        },
        respondNm: {
            label: '응답자명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        areaNo: {
            label: '지역번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        middleTelno: {
            label: '중간전화번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        endTelno: {
            label: '마지막전화번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateQustnrTmplatManageVO(form) {
    const rules = {
        qestnrTmplatTy: {
            label: '템플릿유형',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        qestnrTmplatCn: {
            label: '템플릿설명',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
        qestnrTmplatCours: {
            label: '템플릿파일(경로)',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateStplatManageVO(form) {
    const rules = {
        useStplatNm: {
            label: 'stplatManageVO.useStplatNm',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        useStplatCn: {
            label: 'stplatManageVO.useStplatCn',
            rules: {
                required: true,
            }
        },
        infoProvdAgreCn: {
            label: 'stplatManageVO.infoProvdAgreCn',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateEntrprsManageVO(form) {
    const rules = {
        entrprsmberId: {
            label: '기업회원아이디',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        cmpnyNm: {
            label: '회사명',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        entrprsMberPassword: {
            label: '비밀번호',
            rules: {
                required: true,
                password1: true,
                password2: true,
                password3: true,
                password4: true,
            }
        },
        entrprsMberPasswordHint: {
            label: '비밀번호힌트',
            rules: {
                required: true,
            }
        },
        entrprsMberPasswordCnsr: {
            label: '비밀번호정답',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        bizrno: {
            label: '사업자등록번호',
            rules: {
                required: true,
            }
        },
        areaNo: {
            label: '회사지역번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        entrprsMiddleTelno: {
            label: '회사중간전화번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        entrprsEndTelno: {
            label: '회사마지막전화번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        zip: {
            label: '우편번호',
            rules: {
                required: true,
            }
        },
        adres: {
            label: '주소',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        applcntNm: {
            label: '신청자이름',
            rules: {
                required: true,
            }
        },
        applcntEmailAdres: {
            label: '신청자이메일주소',
            rules: {
                required: true,
                email: true,
                maxlength: 50,
            }
        },
        entrprsMberSttus: {
            label: '사용자상태코드',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateMberManageVO(form) {
    const rules = {
        mberId: {
            label: '일반회원아이디',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        mberNm: {
            label: '일반회원이름',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        password: {
            label: '비밀번호',
            rules: {
                required: true,
                password1: true,
                password2: true,
                password3: true,
                password4: true,
            }
        },
        passwordHint: {
            label: '비밀번호힌트',
            rules: {
                required: true,
            }
        },
        passwordCnsr: {
            label: '비밀번호정답',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        areaNo: {
            label: '집지역번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        middleTelno: {
            label: '집중간전화번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        endTelno: {
            label: '집마지막전화번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        mberFxnum: {
            label: '팩스번호',
            rules: {
                maxlength: 15,
            }
        },
        moblphonNo: {
            label: '핸드폰번호',
            rules: {
                required: true,
                maxlength: 15,
            }
        },
        mberEmailAdres: {
            label: '이메일주소',
            rules: {
                required: true,
                email: true,
                maxlength: 50,
            }
        },
        zip: {
            label: '우편번호',
            rules: {
                required: true,
            }
        },
        adres: {
            label: '주소',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        mberSttus: {
            label: '일반회원상태코드',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validatePasswordChgVO(form) {
    const rules = {
        newPassword: {
            label: '비밀번호',
            rules: {
                required: true,
                password1: true,
                password2: true,
                password3: true,
                password4: true,
            }
        },
        oldPassword: {
            label: '이전비밀번호',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateUserManageVO(form) {
    const rules = {
        emplyrId: {
            label: '사용자아이디',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        emplyrNm: {
            label: '사용자이름',
            rules: {
                required: true,
                maxlength: 50,
            }
        },
        password: {
            label: '비밀번호',
            rules: {
                required: true,
                password1: true,
                password2: true,
                password3: true,
                password4: true,
            }
        },
        passwordHint: {
            label: '비밀번호힌트',
            rules: {
                required: true,
            }
        },
        passwordCnsr: {
            label: '비밀번호정답',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        areaNo: {
            label: '집지역번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        homemiddleTelno: {
            label: '집중간전화번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        homeendTelno: {
            label: '집마지막전화번호',
            rules: {
                required: true,
                maxlength: 4,
                integer: true,
            }
        },
        offmTelno: {
            label: '사무실전화번호',
            rules: {
                maxlength: 15,
            }
        },
        fxnum: {
            label: '팩스번호',
            rules: {
                maxlength: 15,
            }
        },
        moblphonNo: {
            label: '핸드폰번호',
            rules: {
                maxlength: 15,
            }
        },
        emailAdres: {
            label: '이메일주소',
            rules: {
                required: true,
                email: true,
                maxlength: 50,
            }
        },
        zip: {
            label: '우편번호',
            rules: {
                required: true,
            }
        },
        homeadres: {
            label: '주소',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        groupId: {
            label: '그룹아이디',
            rules: {
                required: true,
            }
        },
        emplyrSttusCode: {
            label: '사용자상태코드',
            rules: {
                required: true,
            }
        },
        subDn: {
            label: '사용자DN',
            rules: {
                maxlength: 100,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateSysForm3(form) {
    const rules = {
        memory: {
            label: '메모리',
            rules: {
                required: true,
                integer: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateGeoLocation(form) {
    const rules = {
        buldNm: {
            label: '건물명',
            rules: {
                required: true,
                maxlength: 60,
            }
        },
        la: {
            label: '위도',
            rules: {
                required: true,
                maxlength: 48,
                float: true,
            }
        },
        lo: {
            label: '경도',
            rules: {
                required: true,
                maxlength: 48,
                float: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateChartGraph(form) {
    const rules = {
        lgdNm: {
            label: '범례명',
            rules: {
                required: true,
                maxlength: 60,
            }
        },
        xaxis: {
            label: 'X축 값',
            rules: {
                required: true,
                maxlength: 20,
            }
        },
        yaxis: {
            label: 'Y축 값',
            rules: {
                required: true,
                integer: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateDeviceIdent(form) {
    const rules = {
        browserCode: {
            label: '브라우저',
            rules: {
                required: true,
            }
        },
        osCode: {
            label: '운영체제',
            rules: {
                required: true,
            }
        },
        uagentInfo: {
            label: 'User-Agent',
            rules: {
                required: true,
                maxlength: 1000,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateMultimedia(form) {
    const rules = {
        mltmdSj: {
            label: '멀티미디어 제목',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        mltmdCode: {
            label: '멀티미디어 구분',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateAtchFile(form) {
    const rules = {
        mmsAtchFileSj: {
            label: '제목',
            rules: {
                required: true,
                maxlength: 256,
            }
        },
        file_1: {
            label: '첨부파일',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateMmsTransInfo(form) {
    const rules = {
        trnsmisNo: {
            label: '송신번호',
            rules: {
                required: true,
                minlength: 9,
                mask: '^0[0-9]{9,10}'
            }
        },
        recptnNo: {
            label: '수신번호',
            rules: {
                required: true,
                minlength: 9,
                mask: '^0[0-9]{9,10}'
            }
        },
        mssageSj: {
            label: '제목',
            rules: {
                required: true,
                maxlength: 30,
            }
        },
        mssageCn: {
            label: '전송내용내용',
            rules: {
                required: true,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validatePhoto(form) {
    const rules = {
        photoSj: {
            label: '사진 제목',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateOfflineWebForm(form) {
    const rules = {
        offlineWebSj: {
            label: '제목',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        offlineWebCn: {
            label: '내용',
            rules: {
                required: true,
                maxlength: 512,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}


function validateSyncForm(form) {
    const rules = {
        syncSj: {
            label: '제목',
            rules: {
                required: true,
                maxlength: 100,
            }
        },
        syncCn: {
            label: '내용',
            rules: {
                required: true,
                maxlength: 512,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}

function validateMenuVO(form) {
    const rules = {
        menuNm: {
            label: '메뉴명',
            rules: {
                required: true,
                maxlength: 60,
            }
        },
        cnncUrl: {
            label: '연결 URL',
            rules: {
                maxlength: 255,
            }
        },
        menuDc: {
            label: '메뉴설명',
            rules: {
                maxlength: 250,
            }
        },
    };
    return EgovValidation.validateForm(form, rules);
}
