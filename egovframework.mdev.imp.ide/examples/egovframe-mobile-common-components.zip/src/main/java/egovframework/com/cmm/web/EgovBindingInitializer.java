package egovframework.com.cmm.web;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.support.WebBindingInitializer;

/**
 * EgovBindingInitializer
 * - validator : @Valid / @Validated 가 선언된 @ModelAttribute 의 Bean Validation 검증기 (egov-mcom-servlet.xml)
 */

public class EgovBindingInitializer implements WebBindingInitializer {

	private Validator validator;

	public void setValidator(Validator validator) {
		this.validator = validator;
	}

	public void initBinder(WebDataBinder binder) {
		if (validator != null) {
			binder.setValidator(validator);
		}

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
		binder.registerCustomEditor(String.class, new StringTrimmerEditor(false));

		binder.registerCustomEditor(String.class, "atchFileId", new EgovAtchFileIdPropertyEditor());
	}

}
