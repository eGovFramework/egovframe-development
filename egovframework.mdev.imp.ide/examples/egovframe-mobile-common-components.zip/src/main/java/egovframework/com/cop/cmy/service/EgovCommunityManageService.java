package egovframework.com.cop.cmy.service;

import java.util.List;
import java.util.Map;

/** 커뮤니티 정보를 관리하기 위한 서비스 인터페이스 클래스 */
public interface EgovCommunityManageService {

    /** 커뮤니티 사용자 정보를 확인한다. */
    public String checkCommunityUserInf(CommunityUser cmmntyUser) throws Exception;

    /** 커뮤니티에 대한 특정 사용자 정보를 조회한다. */
    public Map<String, Object> selectCommunityInf(CommunityVO cmmntyVO) throws Exception;

    /** 커뮤니티 관리자 정보를 조회한다. */
    public CommunityUser selectManager(CommunityVO cmmntyVO) throws Exception;

    /** 포트릿을 위한 커뮤니티 정보 목록 정보를 조회한다. */
    public List<CommunityVO> selectCmmntyListPortlet(CommunityVO cmmntyVO) throws Exception;

    /** 커뮤니티용 템플릿 경로명을 조회한다. */
    public String selectCmmntyTemplat(CommunityVO cmmntyVO) throws Exception;
}
