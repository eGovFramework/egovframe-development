package egovframework.com.uss.olh.omm.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.uss.olh.omm.service.EgovOnlineManualService;
import egovframework.com.uss.olh.omm.service.OnlineManual;

import jakarta.annotation.Resource;

/** 온라인메뉴얼를 처리하는 ServiceImpl Class 구현 */
@Service("egovOnlineManualService")
public class EgovOnlineManualServiceImpl extends EgovAbstractServiceImpl
        implements EgovOnlineManualService {

    @Resource(name = "onlineOnlineManualDao")
    private OnlineManualDao dao;

    @Resource(name = "egovOnlineMenualIdGnrService")
    private EgovIdGnrService idgenService;

    /** 온라인메뉴얼를(을) 목록을 조회 한다. */
    @Override
	public List<?> selectOnlineManualList(ComDefaultVO searchVO) throws Exception {
        return dao.selectOnlineManualList(searchVO);
    }

    /** 온라인메뉴얼를(을) 목록 전체 건수를(을) 조회한다. */
    @Override
	public int selectOnlineManualListCnt(ComDefaultVO searchVO) throws Exception {
        return dao.selectOnlineManualListCnt(searchVO);
    }

    /** 온라인메뉴얼를(을) 상세조회 한다. */
    @Override
	public OnlineManual selectOnlineManualDetail( OnlineManual onlineManual) throws Exception {
        return dao.selectOnlineManualDetail(onlineManual);
    }

    /** 온라인메뉴얼를(을) 등록한다. */
    @Override
	public void insertOnlineManual(OnlineManual onlineManual)throws Exception {
        String sMakeId = idgenService.getNextStringId();
        onlineManual.setOnlineMnlId(sMakeId);
        dao.insertOnlineManual(onlineManual);
    }

    /** 온라인메뉴얼를(을) 수정한다. */
    @Override
	public void updateOnlineManual(OnlineManual onlineManual) throws Exception {
        dao.updateOnlineManual(onlineManual);
    }

    /** 온라인메뉴얼를(을) 삭제한다. */
    @Override
	public void deleteOnlineManual(OnlineManual onlineManual) throws Exception {
        dao.deleteOnlineManual(onlineManual);
    }

}
