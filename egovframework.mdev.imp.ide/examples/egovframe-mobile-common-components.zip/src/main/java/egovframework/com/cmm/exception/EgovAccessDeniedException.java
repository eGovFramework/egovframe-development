package egovframework.com.cmm.exception;

import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;

/**
 * 접근 거부 예외 : 등록자가 아닌 사용자의 수정/삭제 요청 (EgovOwnerCheck)
 * egov-mcom-servlet.xml 의 SimpleMappingExceptionResolver 에서 접근 거부 화면(accessDenied.jsp)으로 연결한다.
 */
public class EgovAccessDeniedException extends BaseRuntimeException {

	private static final long serialVersionUID = 1L;

	public EgovAccessDeniedException(String message) {
		this.messageKey = null;
		this.messageParameters = null;
		this.message = message;
		this.wrappedException = null;
	}

}
