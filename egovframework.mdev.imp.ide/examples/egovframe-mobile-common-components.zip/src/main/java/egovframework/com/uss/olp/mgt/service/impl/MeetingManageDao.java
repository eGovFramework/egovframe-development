package egovframework.com.uss.olp.mgt.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.olp.mgt.service.MeetingManageVO;

/** 회의관리를 처리하기 위한 Dao 구현 Class */
@Repository("meetingManageDao")
public class MeetingManageDao extends EgovComAbstractDAO {

    /** 부서 목록을 조회한다. */
	public List<?> egovMeetingManageLisAuthorGroupPopup(ComDefaultVO searchVO){
		return list("MeetingManage.EgovMeetingManageLisAuthorGroupPopup", searchVO);
	}

    /** 아이디 목록을 조회한다. */
	public List<?> egovMeetingManageLisEmpLyrPopup(ComDefaultVO searchVO){
		return list("MeetingManage.EgovMeetingManageLisEmpLyrPopup", searchVO);
	}

    /** 회의정보를 등록한다. */
	public void insertMeetingManage(MeetingManageVO meetingManageVO){
		insert("MeetingManage.insertMeetingManage", meetingManageVO);
	}

    /** 회의정보를 수정한다. */
	public void updateMeetingManage(MeetingManageVO meetingManageVO){
		insert("MeetingManage.updateMeetingManage", meetingManageVO);
	}

    /** 회의정보를 삭제한다. */
	public void deleteMeetingManage(MeetingManageVO meetingManageVO){
		insert("MeetingManage.deleteMeetingManage", meetingManageVO);
	}
}
