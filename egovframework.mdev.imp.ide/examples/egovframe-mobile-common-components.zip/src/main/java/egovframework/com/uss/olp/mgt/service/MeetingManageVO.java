package egovframework.com.uss.olp.mgt.service;

import java.io.Serializable;

/** 회의관리 Vo Class 구현 */
public class MeetingManageVO implements Serializable {

	private static final long serialVersionUID = -4820974750521985908L;

	/** 회의ID */
	private String mtgId = "";

	/** 회의명 */
	private String mtgNm = "";

	/** 회의안건내용 */
	private String mtgMtrCn = "";

	/** 회의순번 */
	private String mtgSn = "";

	/** 회의수 */
	private String mtgCo = "";

	/** 회의일자 */
	private String mtgDe = "";

	/** 회의장소 */
	private String mtgPlace = "";

	/** 회의시작시간 */
	private String mtgBeginTime = "";

	/** 회의종료시간 */
	private String mtgEndTime = "";

	/** 비공개회의여부 */
	private String clsdrMtgAt = "";

	/** 열람개시일자 */
	private String readngBeginDe = "";

	/** 열람여부 */
	private String readngAt = "";

	/** 회의결과내용 */
	private String mtgResultCn = "";

	/** 회의결과유무 */
	private String mtgResultEnnc = "";

	/** 기타사항 */
	private String etcMatter = "";

	/** 주관부서ID */
	private String mngtDeptId = "";

	/** 주관부서명 */
	private String mngtDeptNm = "";

	/** 주관자ID */
	private String mnaerId = "";

	/** 주관자명 */
	private String mnaerNm = "";

	/** 주관자명 */
	private String mnaerDeptId = "";

	/** 주관자부서명 */
	private String mnaerDeptNm = "";

	/** 주관자직위직급코드 */
	private String mnaerOfcpsClsfCode = "";

	/** 회의여부 */
	private String mtnAt = "";

	/** 불참석자수 */
	private String nonatdrnCo = "";

	/** 참석자수 */
	private String atdrnCo = "";

	/** 회의시작 시간 */
	private String mtgBeginHH = "";

	/** 회의시작 분 */
	private String mtgBeginMM = "";

	/** 회의종료 시간 */
	private String mtgEndHH = "";

	/** 회의종료 분 */
	private String mtgEndMM = "";

	/** 최초등록시점 */
	private String frstRegisterPnttm = "";

	/** 최초등록아이디 */
	private String frstRegisterId = "";

	private String lastUpdusrPnttm = "";

	/** 최종수정자 아이디 */
	private String lastUpdusrId = "";

	/** 화면 명령 처리 */
	private String cmd = "";

	public String getMtgId() {
		return mtgId;
	}
	public void setMtgId(String mtgId) {
		this.mtgId = mtgId;
	}
	public String getMtgNm() {
		return mtgNm;
	}
	public void setMtgNm(String mtgNm) {
		this.mtgNm = mtgNm;
	}
	public String getMtgMtrCn() {
		return mtgMtrCn;
	}
	public void setMtgMtrCn(String mtgMtrCn) {
		this.mtgMtrCn = mtgMtrCn;
	}
	public String getMtgSn() {
		return mtgSn;
	}
	public void setMtgSn(String mtgSn) {
		this.mtgSn = mtgSn;
	}
	public String getMtgCo() {
		return mtgCo;
	}
	public void setMtgCo(String mtgCo) {
		this.mtgCo = mtgCo;
	}
	public String getMtgDe() {
		return mtgDe;
	}
	public void setMtgDe(String mtgDe) {
		this.mtgDe = mtgDe;
	}
	public String getMtgPlace() {
		return mtgPlace;
	}
	public void setMtgPlace(String mtgPlace) {
		this.mtgPlace = mtgPlace;
	}
	public String getMtgBeginTime() {
		return mtgBeginTime;
	}
	public void setMtgBeginTime(String mtgBeginTime) {
		this.mtgBeginTime = mtgBeginTime;
	}
	public String getMtgEndTime() {
		return mtgEndTime;
	}
	public void setMtgEndTime(String mtgEndTime) {
		this.mtgEndTime = mtgEndTime;
	}
	public String getClsdrMtgAt() {
		return clsdrMtgAt;
	}
	public void setClsdrMtgAt(String clsdrMtgAt) {
		this.clsdrMtgAt = clsdrMtgAt;
	}
	public String getReadngBeginDe() {
		return readngBeginDe;
	}
	public void setReadngBeginDe(String readngBeginDe) {
		this.readngBeginDe = readngBeginDe;
	}
	public String getReadngAt() {
		return readngAt;
	}
	public void setReadngAt(String readngAt) {
		this.readngAt = readngAt;
	}
	public String getMtgResultCn() {
		return mtgResultCn;
	}
	public void setMtgResultCn(String mtgResultCn) {
		this.mtgResultCn = mtgResultCn;
	}
	public String getMtgResultEnnc() {
		return mtgResultEnnc;
	}
	public void setMtgResultEnnc(String mtgResultEnnc) {
		this.mtgResultEnnc = mtgResultEnnc;
	}
	public String getEtcMatter() {
		return etcMatter;
	}
	public void setEtcMatter(String etcMatter) {
		this.etcMatter = etcMatter;
	}
	public String getMngtDeptId() {
		return mngtDeptId;
	}
	public void setMngtDeptId(String mngtDeptId) {
		this.mngtDeptId = mngtDeptId;
	}
	public String getMngtDeptNm() {
		return mngtDeptNm;
	}
	public void setMngtDeptNm(String mngtDeptNm) {
		this.mngtDeptNm = mngtDeptNm;
	}
	public String getMnaerId() {
		return mnaerId;
	}
	public void setMnaerId(String mnaerId) {
		this.mnaerId = mnaerId;
	}
	public String getMnaerNm() {
		return mnaerNm;
	}
	public void setMnaerNm(String mnaerNm) {
		this.mnaerNm = mnaerNm;
	}
	public String getMnaerDeptId() {
		return mnaerDeptId;
	}
	public void setMnaerDeptId(String mnaerDeptId) {
		this.mnaerDeptId = mnaerDeptId;
	}
	public String getMnaerDeptNm() {
		return mnaerDeptNm;
	}
	public void setMnaerDeptNm(String mnaerDeptNm) {
		this.mnaerDeptNm = mnaerDeptNm;
	}
	public String getMnaerOfcpsClsfCode() {
		return mnaerOfcpsClsfCode;
	}
	public void setMnaerOfcpsClsfCode(String mnaerOfcpsClsfCode) {
		this.mnaerOfcpsClsfCode = mnaerOfcpsClsfCode;
	}
	public String getMtnAt() {
		return mtnAt;
	}
	public void setMtnAt(String mtnAt) {
		this.mtnAt = mtnAt;
	}
	public String getNonatdrnCo() {
		return nonatdrnCo;
	}
	public void setNonatdrnCo(String nonatdrnCo) {
		this.nonatdrnCo = nonatdrnCo;
	}
	public String getAtdrnCo() {
		return atdrnCo;
	}
	public void setAtdrnCo(String atdrnCo) {
		this.atdrnCo = atdrnCo;
	}
	public String getMtgBeginHH() {
		return mtgBeginHH;
	}
	public void setMtgBeginHH(String mtgBeginHH) {
		this.mtgBeginHH = mtgBeginHH;
	}
	public String getMtgBeginMM() {
		return mtgBeginMM;
	}
	public void setMtgBeginMM(String mtgBeginMM) {
		this.mtgBeginMM = mtgBeginMM;
	}
	public String getMtgEndHH() {
		return mtgEndHH;
	}
	public void setMtgEndHH(String mtgEndHH) {
		this.mtgEndHH = mtgEndHH;
	}
	public String getMtgEndMM() {
		return mtgEndMM;
	}
	public void setMtgEndMM(String mtgEndMM) {
		this.mtgEndMM = mtgEndMM;
	}
	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}
	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}
	public String getFrstRegisterId() {
		return frstRegisterId;
	}
	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}
	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}
	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}
	public String getLastUpdusrId() {
		return lastUpdusrId;
	}
	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}
	public String getCmd() {
		return cmd;
	}
	public void setCmd(String cmd) {
		this.cmd = cmd;
	}

}
