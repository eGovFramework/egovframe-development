package egovframework.com.cop.smt.sdm.service.impl;

import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cop.smt.sdm.service.DeptSchdulManageVO;
import egovframework.com.cop.smt.sdm.service.EgovDeptSchdulManageService;

import jakarta.annotation.Resource;

/** 부서일정관리를 처리하는 ServiceImpl Class 구현 */
@Service("egovDeptSchdulManageService")
public class EgovDeptSchdulManageServiceImpl extends EgovAbstractServiceImpl implements EgovDeptSchdulManageService{

	@Resource(name="deptSchdulManageDao")
	private DeptSchdulManageDao dao;

	@Resource(name="deptSchdulManageIdGnrService")
	private EgovIdGnrService idgenService;

    /** 부서일정 목록을 Map(map)형식으로 조회한다. */
	@Override
	public List<?> selectDeptSchdulManageRetrieve(Map<?, ?> map) throws Exception{
		return dao.selectDeptSchdulManageRetrieve(map);
	}

    /** 부서일정 목록을 조회한다. */
	@Override
	public List<?> selectDeptSchdulManageList(ComDefaultVO searchVO) throws Exception{
		return dao.selectDeptSchdulManageList(searchVO);
	}

    /** 부서일정를(을) 상세조회 한다. */
	@Override
	public List<?> selectDeptSchdulManageDetail(DeptSchdulManageVO deptSchdulManageVO) throws Exception{
		return dao.selectDeptSchdulManageDetail(deptSchdulManageVO);
	}

    /** 부서일정를(을) 목록 전체 건수를(을) 조회한다. */
	@Override
	public int selectDeptSchdulManageListCnt(ComDefaultVO searchVO) throws Exception{
		return dao.selectDeptSchdulManageListCnt(searchVO);
	}

    /** 부서일정를(을) 등록한다. */
	@Override
	public void insertDeptSchdulManage(DeptSchdulManageVO deptSchdulManageVO) throws Exception {
		String sMakeId = idgenService.getNextStringId();
		deptSchdulManageVO.setSchdulId(sMakeId);

		dao.insertDeptSchdulManage(deptSchdulManageVO);
	}

    /** 부서일정를(을) 수정한다. */
	@Override
	public void updateDeptSchdulManage(DeptSchdulManageVO deptSchdulManageVO) throws Exception{
		dao.updateDeptSchdulManage(deptSchdulManageVO);
	}

    /** 부서일정를(을) 삭제한다. */
	@Override
	public void deleteDeptSchdulManage(DeptSchdulManageVO deptSchdulManageVO) throws Exception{
		dao.deleteDeptSchdulManage(deptSchdulManageVO);
	}
}
