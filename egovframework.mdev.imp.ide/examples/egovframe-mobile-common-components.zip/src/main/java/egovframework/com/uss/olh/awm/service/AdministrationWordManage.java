package egovframework.com.uss.olh.awm.service;

import java.io.Serializable;

import egovframework.com.cmm.ComDefaultVO;

/** 행정전문용어사전관리 VO Class 구현 */
public class AdministrationWordManage extends ComDefaultVO implements Serializable {

	private static final long serialVersionUID = -5313141971613650852L;

	/** 행정용어사전 아이디 */
    private String administWordId;

    /** 행정용어사전 명 */
    private String administWordNm;

    /** 행정용어사전 영문명 */
    private String administWordEngNm;

    /** 행정용어사전 약어 */
    private String administWordAbrv;

    /** 주제영역 */
    private String themaRelm;

    /** 용어구분 */
    private String wordDomn;

    /** 관련표준용어 */
    private String stdWord;

    /** 행정용어사전 정의 */
    private String administWordDf;

    /** 행정용어사전 설명 */
    private String administWordDc;

    /** 최초등록시점 */
    private String frstRegisterPnttm;

    /** 최초등록아이디 */
    private String frstRegisterId;

    private String lastUpdusrPnttm;

    /** 최종수정자 아이디 */
    private String lastUpdusrId;

    /** 초성검색 */
    private String choseongA;

    /** 초성검색 */
    private String choseongB;

    /** 컨트롤 명령어 */
    private String cmd;

    public String getAdministWordId() {
        return administWordId;
    }

    public void setAdministWordId(String administWordId) {
        this.administWordId = administWordId;
    }

    public String getAdministWordNm() {
        return administWordNm;
    }

    public void setAdministWordNm(String administWordNm) {
        this.administWordNm = administWordNm;
    }

    public String getAdministWordEngNm() {
        return administWordEngNm;
    }

    public void setAdministWordEngNm(String administWordEngNm) {
        this.administWordEngNm = administWordEngNm;
    }

    public String getAdministWordAbrv() {
        return administWordAbrv;
    }

    public void setAdministWordAbrv(String administWordAbrv) {
        this.administWordAbrv = administWordAbrv;
    }

    public String getThemaRelm() {
        return themaRelm;
    }

    public void setThemaRelm(String themaRelm) {
        this.themaRelm = themaRelm;
    }

    public String getWordDomn() {
        return wordDomn;
    }

    public void setWordDomn(String wordDomn) {
        this.wordDomn = wordDomn;
    }

    public String getStdWord() {
        return stdWord;
    }

    public void setStdWord(String stdWord) {
        this.stdWord = stdWord;
    }

    public String getAdministWordDf() {
        return administWordDf;
    }

    public void setAdministWordDf(String administWordDf) {
        this.administWordDf = administWordDf;
    }

    public String getAdministWordDc() {
        return administWordDc;
    }

    public void setAdministWordDc(String administWordDc) {
        this.administWordDc = administWordDc;
    }

    public String getFrstRegisterPnttm() {
        return frstRegisterPnttm;
    }

    public void setFrstRegisterPnttm(String frstRegisterPnttm) {
        this.frstRegisterPnttm = frstRegisterPnttm;
    }

    public String getFrstRegisterId() {
        return frstRegisterId;
    }

    public void setFrstRegisterId(String frstRegisterId) {
        this.frstRegisterId = frstRegisterId;
    }

    public String getLastUpdusrPnttm() {
        return lastUpdusrPnttm;
    }

    public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
        this.lastUpdusrPnttm = lastUpdusrPnttm;
    }

    public String getLastUpdusrId() {
        return lastUpdusrId;
    }

    public void setLastUpdusrId(String lastUpdusrId) {
        this.lastUpdusrId = lastUpdusrId;
    }

    public String getChoseongA() {
        return choseongA;
    }

    public void setChoseongA(String choseongA) {
        this.choseongA = choseongA;
    }

    public String getChoseongB() {
        return choseongB;
    }

    public void setChoseongB(String choseongB) {
        this.choseongB = choseongB;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

}
