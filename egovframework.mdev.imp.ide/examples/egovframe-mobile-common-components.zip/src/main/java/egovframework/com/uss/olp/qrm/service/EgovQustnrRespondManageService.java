package egovframework.com.uss.olp.qrm.service;

/** 설문응답자관리 Service Class 구현 */
public interface EgovQustnrRespondManageService {

    /** 응답자정보를(을) 등록한다. */
	void  insertQustnrRespondManage(QustnrRespondManageVO qustnrRespondManageVO) throws Exception;

    /** 응답자정보를(을) 수정한다. */
	void  updateQustnrRespondManage(QustnrRespondManageVO qustnrRespondManageVO) throws Exception;

    /** 응답자정보를(을) 삭제한다. */
	void  deleteQustnrRespondManage(QustnrRespondManageVO qustnrRespondManageVO) throws Exception;

}
