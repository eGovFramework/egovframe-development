package egovframework.com.uss.olp.cns.service;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** 상담내용을 처리하는 VO 클래스 */
public class CnsltManageVO extends CnsltManageDefaultVO {

    private static final long serialVersionUID = 1L;

    /** 상담 ID */
    private String cnsltId;

    /** 상담제목 */
    @EgovNullCheck(message = "{valid.CnsltManageVO.cnsltSj.required}")
    @Size(max = 250, message = "{valid.CnsltManageVO.cnsltSj.maxlength}")
    private String cnsltSj;

    /** 상담내용 */
    @EgovNullCheck(message = "{valid.CnsltManageVO.cnsltCn.required}")
    @Size(max = 2500, message = "{valid.CnsltManageVO.cnsltCn.maxlength}")
    private String cnsltCn;

    /** 공개여부 */
    private String othbcAt;

    /** 작성비밀번호 */
    @EgovNullCheck(message = "{valid.CnsltManageVO.writngPassword.required}")
    @Size(max = 20, message = "{valid.CnsltManageVO.writngPassword.maxlength}")
    private String writngPassword;

    /** 지역번호 */
    @EgovNullCheck(message = "{valid.CnsltManageVO.areaNo.required}")
    @Size(max = 4, message = "{valid.CnsltManageVO.areaNo.maxlength}")
    @Pattern(regexp = "\\d*", message = "{valid.CnsltManageVO.areaNo.integer}")
    private String areaNo;

    /** 중간전화번호 */
    @EgovNullCheck(message = "{valid.CnsltManageVO.middleTelno.required}")
    @Size(max = 4, message = "{valid.CnsltManageVO.middleTelno.maxlength}")
    @Pattern(regexp = "\\d*", message = "{valid.CnsltManageVO.middleTelno.integer}")
    private String middleTelno;

    /** 끝전화번호 */
    @EgovNullCheck(message = "{valid.CnsltManageVO.endTelno.required}")
    @Size(max = 4, message = "{valid.CnsltManageVO.endTelno.maxlength}")
    @Pattern(regexp = "\\d*", message = "{valid.CnsltManageVO.endTelno.integer}")
    private String endTelno;

    /** 처음휴대폰번호 */
    @Size(max = 4, message = "{valid.CnsltManageVO.firstMoblphonNo.maxlength}")
    @Pattern(regexp = "\\d*", message = "{valid.CnsltManageVO.firstMoblphonNo.integer}")
    private String firstMoblphonNo;

    /** 중간휴대폰번호 */
    @Size(max = 4, message = "{valid.CnsltManageVO.middleMbtlnum.maxlength}")
    @Pattern(regexp = "\\d*", message = "{valid.CnsltManageVO.middleMbtlnum.integer}")
    private String middleMbtlnum;

    /** 끝휴대폰번호 */
    @Size(max = 4, message = "{valid.CnsltManageVO.endMbtlnum.maxlength}")
    @Pattern(regexp = "\\d*", message = "{valid.CnsltManageVO.endMbtlnum.integer}")
    private String endMbtlnum;

    /** 이메일 주소 */
    @Size(max = 50, message = "{valid.CnsltManageVO.emailAdres.maxlength}")
    @Email(message = "{valid.CnsltManageVO.emailAdres.email}")
    private String emailAdres;

    /** 이메일 답변여부 */
    private String emailAnswerAt;

    /** 첨부파일 ID */
    private String atchFileId;

    /** 작성자 명 */
    @EgovNullCheck(message = "{valid.CnsltManageVO.wrterNm.required}")
    @Size(max = 20, message = "{valid.CnsltManageVO.wrterNm.maxlength}")
    private String wrterNm;

    /** 작성일자 */
    private String writngDe;

    /** 조회횟수 */
    private String inqireCo;

    /** 질의응답처리상태코드 */
    private String qnaProcessSttusCode;

    /** 질의응답처리상태코드명 */
    private String qnaProcessSttusCodeNm;

    /** 조치내용 */
    @EgovNullCheck(message = "{valid.CnsltManageVO.managtCn.required}")
    @Size(max = 2500, message = "{valid.CnsltManageVO.managtCn.maxlength}")
    private String managtCn;

    /** 조치일자 */
    private String managtDe;

    /** 작성비밀번호 확인여부 */
    private String passwordConfirmAt;

    /** 답변자명 */
    private String emplyrNm;

    /** 사무실전화번호 */
    private String offmTelno;

    /** 답변자 EMAIL 주소 */
    private String aemailAdres;

    /** 부서명 */
    private String orgnztNm;

    /** 최초등록시점 */
    private String frstRegisterPnttm;

    /** 최초등록자ID */
    private String frstRegisterId;

    /** 최종수정시점 */
    private String lastUpdusrPnttm;

    /** 최종수정자ID */
    private String lastUpdusrId;

	public String getCnsltId() {
		return cnsltId;
	}

	public void setCnsltId(String cnsltId) {
		this.cnsltId = cnsltId;
	}

	public String getCnsltSj() {
		return cnsltSj;
	}

	public void setCnsltSj(String cnsltSj) {
		this.cnsltSj = cnsltSj;
	}

	public String getCnsltCn() {
		return cnsltCn;
	}

	public void setCnsltCn(String cnsltCn) {
		this.cnsltCn = cnsltCn;
	}

	public String getOthbcAt() {
		return othbcAt;
	}

	public void setOthbcAt(String othbcAt) {
		this.othbcAt = othbcAt;
	}

	public String getWritngPassword() {
		return writngPassword;
	}

	public void setWritngPassword(String writngPassword) {
		this.writngPassword = writngPassword;
	}

	public String getAreaNo() {
		return areaNo;
	}

	public void setAreaNo(String areaNo) {
		this.areaNo = areaNo;
	}

	public String getMiddleTelno() {
		return middleTelno;
	}

	public void setMiddleTelno(String middleTelno) {
		this.middleTelno = middleTelno;
	}

	public String getEndTelno() {
		return endTelno;
	}

	public void setEndTelno(String endTelno) {
		this.endTelno = endTelno;
	}

	public String getFirstMoblphonNo() {
		return firstMoblphonNo;
	}

	public void setFirstMoblphonNo(String firstMoblphonNo) {
		this.firstMoblphonNo = firstMoblphonNo;
	}

	public String getMiddleMbtlnum() {
		return middleMbtlnum;
	}

	public void setMiddleMbtlnum(String middleMbtlnum) {
		this.middleMbtlnum = middleMbtlnum;
	}

	public String getEndMbtlnum() {
		return endMbtlnum;
	}

	public void setEndMbtlnum(String endMbtlnum) {
		this.endMbtlnum = endMbtlnum;
	}

	public String getEmailAdres() {
		return emailAdres;
	}

	public void setEmailAdres(String emailAdres) {
		this.emailAdres = emailAdres;
	}

	public String getEmailAnswerAt() {
		return emailAnswerAt;
	}

	public void setEmailAnswerAt(String emailAnswerAt) {
		this.emailAnswerAt = emailAnswerAt;
	}

	public String getAtchFileId() {
		return atchFileId;
	}

	public void setAtchFileId(String atchFileId) {
		this.atchFileId = atchFileId;
	}

	public String getWrterNm() {
		return wrterNm;
	}

	public void setWrterNm(String wrterNm) {
		this.wrterNm = wrterNm;
	}

	public String getWritngDe() {
		return writngDe;
	}

	public void setWritngDe(String writngDe) {
		this.writngDe = writngDe;
	}

	public String getInqireCo() {
		return inqireCo;
	}

	public void setInqireCo(String inqireCo) {
		this.inqireCo = inqireCo;
	}

	public String getQnaProcessSttusCode() {
		return qnaProcessSttusCode;
	}

	public void setQnaProcessSttusCode(String qnaProcessSttusCode) {
		this.qnaProcessSttusCode = qnaProcessSttusCode;
	}

	public String getQnaProcessSttusCodeNm() {
		return qnaProcessSttusCodeNm;
	}

	public void setQnaProcessSttusCodeNm(String qnaProcessSttusCodeNm) {
		this.qnaProcessSttusCodeNm = qnaProcessSttusCodeNm;
	}

	public String getManagtCn() {
		return managtCn;
	}

	public void setManagtCn(String managtCn) {
		this.managtCn = managtCn;
	}

	public String getManagtDe() {
		return managtDe;
	}

	public void setManagtDe(String managtDe) {
		this.managtDe = managtDe;
	}

	public String getPasswordConfirmAt() {
		return passwordConfirmAt;
	}

	public void setPasswordConfirmAt(String passwordConfirmAt) {
		this.passwordConfirmAt = passwordConfirmAt;
	}

	public String getEmplyrNm() {
		return emplyrNm;
	}

	public void setEmplyrNm(String emplyrNm) {
		this.emplyrNm = emplyrNm;
	}

	public String getOffmTelno() {
		return offmTelno;
	}

	public void setOffmTelno(String offmTelno) {
		this.offmTelno = offmTelno;
	}

	public String getAemailAdres() {
		return aemailAdres;
	}

	public void setAemailAdres(String aemailAdres) {
		this.aemailAdres = aemailAdres;
	}

	public String getOrgnztNm() {
		return orgnztNm;
	}

	public void setOrgnztNm(String orgnztNm) {
		this.orgnztNm = orgnztNm;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

}
