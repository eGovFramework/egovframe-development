package egovframework.com.uss.olp.opp.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.olp.opp.service.OnlinePollPartcptn;

/** 온라인POLL참여를 처리하는 Dao Class 구현 */
@Repository("onlinePollPartcptnDao")
public class OnlinePollPartcptnDao extends EgovComAbstractDAO {

    /** 온라인POLL관리를(을) 목록을 한다. */
    public List<?> selectOnlinePollManageList(ComDefaultVO searchVO) throws Exception {
        return list("OnlinePollPartcptn.selectOnlinePollManageList", searchVO);
    }

    /** 온라인POLL관리를(을) 목록 전체 건수를(을) 조회한다. */
    public int selectOnlinePollManageListCnt(ComDefaultVO searchVO) throws Exception {
        return (Integer)selectOne("OnlinePollPartcptn.selectOnlinePollManageListCnt", searchVO);
    }

    /** 온라인POLL관리를(을) 상세조회 한다. */
    public List<?> selectOnlinePollManageDetail(OnlinePollPartcptn onlinePollPartcptn) throws Exception {
        return list("OnlinePollPartcptn.selectOnlinePollManageDetail", onlinePollPartcptn);
    }

    /** 온라인POLL항목를(을) 상세조회 한다. */
    public List<?> selectOnlinePollItemDetail(OnlinePollPartcptn onlinePollPartcptn) throws Exception {
        return list("OnlinePollPartcptn.selectOnlinePollItem", onlinePollPartcptn);
    }

    /** 온라인POLL참여를(을) 등록한다. */
    public void insertOnlinePollResult(OnlinePollPartcptn onlinePollPartcptn) throws Exception {
        insert("OnlinePollPartcptn.insertOnlinePollResult", onlinePollPartcptn);
    }

    /** 온라인POLL통계를(을) 등록한다. */
    public List<?> selectOnlinePollManageStatistics(OnlinePollPartcptn onlinePollPartcptn) throws Exception {
        return list("OnlinePollPartcptn.selectOnlinePollPartcptnStatistics", onlinePollPartcptn);
    }

    /** 온라인POLL참여 여부를 조회한다. */
    public int selectOnlinePollResult( OnlinePollPartcptn onlinePollPartcptn) throws Exception{
    	return (Integer)selectOne("OnlinePollPartcptn.selectOnlinePollResult", onlinePollPartcptn);
    }

}
