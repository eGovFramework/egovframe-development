package egovframework.com.cop.bbs.service;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/** 만족도조사 서비스 데이터 처리 모델 */
@SuppressWarnings("serial")
public class Satisfaction implements Serializable {
    /** 만족도 번호 */
    private String stsfdgNo = "";

    /** 게시판 ID */
    private String bbsId = "";

    /** 게시물 번호 */
    private long nttId = 0L;

    /** 작성자 ID */
    private String wrterId = "";

    /** 작성자명 */
    private String wrterNm = "";

    /** 패스워드 */
    private String stsfdgPassword = "";

    /** 만족도 내용 */
    private String stsfdgCn = "";

    /** 만족도 */
    private int stsfdg = 0;

    /** 사용 여부 */
    private String useAt = "";

    /** 최초등록자 아이디 */
    private String frstRegisterId = "";

    /** 최초 등록자명 */
    private String frstRegisterNm = "";

    /** 최초등록시점 */
    private String frstRegisterPnttm = "";

    /** 최종수정자 아이디 */
    private String lastUpdusrId = "";

    /** 최종수정시점 */
    private String lastUpdusrPnttm = "";

    /** 확인 패스워드 */
    private String confirmPassword = "";

    public String getStsfdgNo() {
        return stsfdgNo;
    }

    public void setStsfdgNo(String stsfdgNo) {
        this.stsfdgNo = stsfdgNo;
    }

    public String getBbsId() {
        return bbsId;
    }

    public void setBbsId(String bbsId) {
        this.bbsId = bbsId;
    }

    public long getNttId() {
        return nttId;
    }

    public void setNttId(long nttId) {
        this.nttId = nttId;
    }

    public String getWrterId() {
        return wrterId;
    }

    public void setWrterId(String wrterId) {
        this.wrterId = wrterId;
    }

    public String getWrterNm() {
        return wrterNm;
    }

    public void setWrterNm(String wrterNm) {
        this.wrterNm = wrterNm;
    }

    public String getStsfdgPassword() {
        return stsfdgPassword;
    }

    public void setStsfdgPassword(String stsfdgPassword) {
        this.stsfdgPassword = stsfdgPassword;
    }

    public String getStsfdgCn() {
        return stsfdgCn;
    }

    public void setStsfdgCn(String stsfdgCn) {
        this.stsfdgCn = stsfdgCn;
    }

    public int getStsfdg() {
        return stsfdg;
    }

    public void setStsfdg(int stsfdg) {
        this.stsfdg = stsfdg;
    }

    public String getUseAt() {
        return useAt;
    }

    public void setUseAt(String useAt) {
        this.useAt = useAt;
    }

    public String getFrstRegisterId() {
        return frstRegisterId;
    }

    public void setFrstRegisterId(String frstRegisterId) {
        this.frstRegisterId = frstRegisterId;
    }

    public String getFrstRegisterNm() {
        return frstRegisterNm;
    }

    public void setFrstRegisterNm(String frstRegisterNm) {
        this.frstRegisterNm = frstRegisterNm;
    }

    public String getFrstRegisterPnttm() {
        return frstRegisterPnttm;
    }

    public void setFrstRegisterPnttm(String frstRegisterPnttm) {
        this.frstRegisterPnttm = frstRegisterPnttm;
    }

    public String getLastUpdusrId() {
        return lastUpdusrId;
    }

    public void setLastUpdusrId(String lastUpdusrId) {
        this.lastUpdusrId = lastUpdusrId;
    }

    public String getLastUpdusrPnttm() {
        return lastUpdusrPnttm;
    }

    public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
        this.lastUpdusrPnttm = lastUpdusrPnttm;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    /** toString 메소드를 대치한다. */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}
