package egovframework.com.cop.cmy.service.impl;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.cmy.service.ConfirmHistory;

/** 승인정보 관리를 위한 데이터 접근 클래스 */
@Repository("ConfirmManageDAO")
public class ConfirmManageDAO extends EgovComAbstractDAO {

    /** 승인(탈퇴)요청에 대한 등록을 처리한다. */
    public void insertConfirmRequest(ConfirmHistory history) throws Exception {
	insert("ConfirmManageDAO.insertConfirmRequest", history);
    }

    /** 승인(탈퇴)요청에 대한 상세내용을 조회한다. */
    public int countConfirmRequest(ConfirmHistory history) throws Exception {
	return (Integer)selectOne("ConfirmManageDAO.countConfirmRequest", history);
    }
}
