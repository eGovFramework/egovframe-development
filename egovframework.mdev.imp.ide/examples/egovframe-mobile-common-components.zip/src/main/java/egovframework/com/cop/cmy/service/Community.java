package egovframework.com.cop.cmy.service;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/** 커뮤니티 관리를 위한 모델 클래스 */
@SuppressWarnings("serial")
public class Community implements Serializable {

    /** 커뮤니티 아이디 */
    private String cmmntyId = "";

    /** 커뮤니티 소개 */
    private String cmmntyIntrcn = "";

    /** 커뮤니티 명 */
    private String cmmntyNm = "";

    /** 최초등록자 아이디 */
    private String frstRegisterId = "";

    /** 최초등록시점 */
    private String frstRegisterPnttm = "";

    /** 최종수정자 아이디 */
    private String lastUpdusrId = "";

    /** 최종수정시점 */
    private String lastUpdusrPnttm = "";

    /** 등록구분코드 */
    private String registSeCode = "";

    /** 템플릿 아이디 */
    private String tmplatId = "";

    /** 템플릿 아이디 */
    private String useAt = "";

    /** 사용자 아이디 */
    private String emplyrId = "";

    /** 사용자명 */
    private String userNm = "";

    /** 템플릿 명 */
    private String tmplatNm = "";

    public String getCmmntyId() {
	return cmmntyId;
    }

    public void setCmmntyId(String cmmntyId) {
	this.cmmntyId = cmmntyId;
    }

    public String getCmmntyIntrcn() {
	return cmmntyIntrcn;
    }

    public void setCmmntyIntrcn(String cmmntyIntrcn) {
	this.cmmntyIntrcn = cmmntyIntrcn;
    }

    public String getCmmntyNm() {
	return cmmntyNm;
    }

    public void setCmmntyNm(String cmmntyNm) {
	this.cmmntyNm = cmmntyNm;
    }

    public String getFrstRegisterId() {
	return frstRegisterId;
    }

    public void setFrstRegisterId(String frstRegisterId) {
	this.frstRegisterId = frstRegisterId;
    }

    public String getFrstRegisterPnttm() {
	return frstRegisterPnttm;
    }

    public void setFrstRegisterPnttm(String frstRegisterPnttm) {
	this.frstRegisterPnttm = frstRegisterPnttm;
    }

    public String getLastUpdusrId() {
	return lastUpdusrId;
    }

    public void setLastUpdusrId(String lastUpdusrId) {
	this.lastUpdusrId = lastUpdusrId;
    }

    public String getLastUpdusrPnttm() {
	return lastUpdusrPnttm;
    }

    public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
	this.lastUpdusrPnttm = lastUpdusrPnttm;
    }

    public String getRegistSeCode() {
	return registSeCode;
    }

    public void setRegistSeCode(String registSeCode) {
	this.registSeCode = registSeCode;
    }

    public String getTmplatId() {
	return tmplatId;
    }

    public void setTmplatId(String tmplatId) {
	this.tmplatId = tmplatId;
    }

    public String getUseAt() {
	return useAt;
    }

    public void setUseAt(String useAt) {
	this.useAt = useAt;
    }

    public String getEmplyrId() {
	return emplyrId;
    }

    public void setEmplyrId(String emplyrId) {
	this.emplyrId = emplyrId;
    }

    public String getUserNm() {
	return userNm;
    }

    public void setUserNm(String userNm) {
	this.userNm = userNm;
    }

    public String getTmplatNm() {
	return tmplatNm;
    }

    public void setTmplatNm(String tmplatNm) {
	this.tmplatNm = tmplatNm;
    }

    /** toString 메소드를 대치한다. */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }

}
