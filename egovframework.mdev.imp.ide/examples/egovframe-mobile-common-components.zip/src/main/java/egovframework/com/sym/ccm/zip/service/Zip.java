package egovframework.com.sym.ccm.zip.service;

import java.io.Serializable;

/** 우편번호 모델 클래스 */
public class Zip implements Serializable {

	private static final long serialVersionUID = -8767083970521429218L;

	/*
	 * 우편번호
	 */
    private String zip            = "";

    /*
     * 일련번호
     */
    private int    sn             = 0;

    /*
     * 시도명
     */
	private String ctprvnNm       = "";

	/*
	 * 시군구명
	 */
    private String signguNm       = "";

    /*
     * 읍면동명
     */
    private String emdNm          = "";

    /*
     * 리건물명
     */
    private String liBuldNm      = "";

    /*
     * 도로명코드
     */
    private String rdmnCode       = "";

	/*
     * 도로명
     */
    private String rdmn       = "";

    /*
     * 건물번호본번
     */
    private String bdnbrMnnm          = "";

    /*
     * 건물번호부번
     */
    private String bdnbrSlno      = "";

    /*
     * 건물명
     */
    private String buldNm      = "";

    /*
     * 상세건물명
     */
    private String detailBuldNm      = "";

    /*
     * 번지동호
     */
    private String lnbrDongHo     = "";

	/*
     * 최초등록자ID
     */
    private String frstRegisterId = "";

    /*
     * 최종수정자ID
     */
    private String lastUpdusrId   = "";

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public int getSn() {
		return sn;
	}

	public void setSn(int sn) {
		this.sn = sn;
	}

	public String getCtprvnNm() {
		return ctprvnNm;
	}

	public void setCtprvnNm(String ctprvnNm) {
		this.ctprvnNm = ctprvnNm;
	}

	public String getSignguNm() {
		return signguNm;
	}

	public void setSignguNm(String signguNm) {
		this.signguNm = signguNm;
	}

	public String getEmdNm() {
		return emdNm;
	}

	public void setEmdNm(String emdNm) {
		this.emdNm = emdNm;
	}

	public String getLiBuldNm() {
		return liBuldNm;
	}

	public void setLiBuldNm(String liBuldNm) {
		this.liBuldNm = liBuldNm;
	}

	public String getLnbrDongHo() {
		return lnbrDongHo;
	}

	public void setLnbrDongHo(String lnbrDongHo) {
		this.lnbrDongHo = lnbrDongHo;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

	public String getRdmn() {
		return rdmn;
	}

	public void setRdmn(String rdmn) {
		this.rdmn = rdmn;
	}

	public String getBdnbrMnnm() {
		return bdnbrMnnm;
	}

	public void setBdnbrMnnm(String bdnbrMnnm) {
		this.bdnbrMnnm = bdnbrMnnm;
	}

	public String getBdnbrSlno() {
		return bdnbrSlno;
	}

	public void setBdnbrSlno(String bdnbrSlno) {
		this.bdnbrSlno = bdnbrSlno;
	}

	public String getBuldNm() {
		return buldNm;
	}

	public void setBuldNm(String buldNm) {
		this.buldNm = buldNm;
	}

	public String getDetailBuldNm() {
		return detailBuldNm;
	}

	public void setDetailBuldNm(String detailBuldNm) {
		this.detailBuldNm = detailBuldNm;
	}

    public String getRdmnCode() {
		return rdmnCode;
	}

	public void setRdmnCode(String rdmnCode) {
		this.rdmnCode = rdmnCode;
	}
}
