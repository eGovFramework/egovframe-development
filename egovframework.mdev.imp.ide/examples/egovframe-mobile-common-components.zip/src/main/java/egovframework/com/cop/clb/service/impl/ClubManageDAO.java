package egovframework.com.cop.clb.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

//import com.sun.star.uno.Exception;	불필요한 파일 주석처리

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.clb.service.Club;
import egovframework.com.cop.clb.service.ClubUser;
import egovframework.com.cop.clb.service.ClubVO;

/** 동호회 정보를 관리하기 위한 데이터 접근 클래스 */
@Repository("ClubManageDAO")
public class ClubManageDAO extends EgovComAbstractDAO {

    /** 동호회 사용자 존재 여부를 확인한다. */
    public int checkExistUser(ClubUser clubUser) throws Exception {
	return (Integer)selectOne("ClubManageDAO.checkExistUser", clubUser);
    }

    /** 특정 커뮤니티에 사용되는 동호회 목록을 조회 한다(포틀릿 형식용). */
    @SuppressWarnings("unchecked")
    public List<ClubVO> selectClubListPortletByTrget(Club club) throws Exception {
	return (List<ClubVO>) list("ClubManageDAO.selectClubListPortletByTrget", club);
    }
}
