package egovframework.com.uss.olh.hpc.service;

import java.util.List;

/** 도움말을 처리하기 위한 서비스 클래스 */
public interface EgovHpcmManageService {

    /**
     * 도움말 글을 조회한다.
     * @return 조회한 글
     */
	HpcmManageVO selectHpcmDetail(HpcmManageVO vo) throws Exception;

    /**
     * 도움말 글 목록을 조회한다.
     * @return 글 목록
     */
    List<?> selectHpcmList(HpcmManageDefaultVO searchVO) throws Exception;

    /**
     * 도움말 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    int selectHpcmListTotCnt(HpcmManageDefaultVO searchVO);

	/** 도움말 글을 등록한다. */
    void insertHpcmCn(HpcmManageVO vo) throws Exception;

	/** 도움말 글을 수정한다. */
    void updateHpcmCn(HpcmManageVO vo) throws Exception;

	/** 도움말 글을 삭제한다. */
    void deleteHpcmCn(HpcmManageVO vo) throws Exception;

}
