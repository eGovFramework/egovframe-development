package egovframework.com.cop.adb.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.adb.service.AdressBook;
import egovframework.com.cop.adb.service.AdressBookUser;
import egovframework.com.cop.adb.service.AdressBookUserVO;
import egovframework.com.cop.adb.service.AdressBookVO;

/** 주소록을 관리하는 서비스를 정의하기위한 데이터 접근 클래스 */
@SuppressWarnings("unchecked")
@Repository("AdressBookDAO")
public class AdressBookDAO extends EgovComAbstractDAO{

    /** 주어진 조건에 따른 주소록목록을 불러온다. */
	public List<AdressBookVO> selectAdressBookList(AdressBookVO adbkVO) throws Exception {
        return (List<AdressBookVO>) list("AdressBookDAO.selectAdressBookList", adbkVO);
    }

    /** 주어진 조건에 따라 주소록에 추가할 사용자목록을 불러온다. */
	public List<AdressBookUserVO> selectManList(AdressBookUserVO adbkUserVO) throws Exception {
        return (List<AdressBookUserVO>) list("AdressBookDAO.selectManList", adbkUserVO);
    }

    /** 주어진 조건에 따라 주소록에 추가할 명함목록을 불러온다. */
    public List<AdressBookUserVO> selectCardList(AdressBookUserVO adbkUserVO) throws Exception {
        return (List<AdressBookUserVO>) list("AdressBookDAO.selectCardList", adbkUserVO);
    }

    /** 주어진 조건에 따라 주소록에 기등록된 구성원의 목록을 불러온다. */
    public List<AdressBookUser> selectUserList(AdressBookVO adbkVO) throws Exception {
        return (List<AdressBookUser>) list("AdressBookDAO.selectUserList", adbkVO);
    }

    /** 주어진 조건에 맞는 주소록을 불러온다. */
    public AdressBookVO selectAdressBook(AdressBookVO adbkVO) throws Exception {
        return (AdressBookVO)selectOne("AdressBookDAO.selectAdressBook", adbkVO);
    }

    /** 주소록 정보를 등록한다. */
    public void insertAdressBook(AdressBook adressBook) throws Exception {
        insert("AdressBookDAO.insertAdressBook", adressBook);
    }

    /** 주소록을 구성하는 구성원을 등록한다. */
    public void insertAdressBookUser(AdressBookUser adressBookUser) throws Exception {
        insert("AdressBookDAO.insertAdressBookUser", adressBookUser);
    }

    /** 주소록 정보를 수정한다. */
    public void updateAdressBook(AdressBook adressBook) throws Exception {
        update("AdressBookDAO.updateAdressBook", adressBook);
    }

    /** 주소록 구성원을 삭제한다. */
    public void deleteAdressBookUser(AdressBookUser adbkUser) throws Exception {
        delete("AdressBookDAO.deleteAdressBookUser", adbkUser);
    }

    /** 주소록 목록에 대한 전체 건수를 조회한다. */
    public int selectAdressBookListCnt(AdressBookVO adbkVO) throws Exception {
        return (Integer)selectOne("AdressBookDAO.selectAdressBookListCnt", adbkVO);
    }

    /** 사용자 목록에 대한 전체 건수를 조회한다. */
    public int selectManListCnt(AdressBookUserVO adbkUserVO) throws Exception {
        return (Integer)selectOne("AdressBookDAO.selectManListCnt", adbkUserVO);
    }

    /** 명함 목록에 대한 전체 건수를 조회한다. */
    public int selectCardListCnt(AdressBookUserVO adbkUserVO) throws Exception {
        return (Integer)selectOne("AdressBookDAO.selectCardListCnt", adbkUserVO);
    }

    /** 주소록을 구성할 사용자의 정보를 조회한다. */
    public AdressBookUser selectManUser(String id) throws Exception {
        return (AdressBookUser)selectOne("AdressBookDAO.selectManUser", id);
    }

    /** 주소록을 구성할 명함의 정보를 조회한다. */
    public AdressBookUser selectCardUser(String id) throws Exception {
        return (AdressBookUser)selectOne("AdressBookDAO.selectCardUser", id);
    }

}
