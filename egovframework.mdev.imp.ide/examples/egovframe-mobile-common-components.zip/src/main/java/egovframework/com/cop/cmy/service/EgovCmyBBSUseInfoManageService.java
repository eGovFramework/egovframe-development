package egovframework.com.cop.cmy.service;

/** 게시판 이용정보를 관리하기 위한 서비스 인터페이스 클래스 */
public interface EgovCmyBBSUseInfoManageService {
}
