package egovframework.com.uss.olh.qna.service;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Q&A를 처리하는 VO 클래스 */
public class QnaManageVO extends QnaManageDefaultVO {

    private static final long serialVersionUID = 1L;

    /** QA ID */
    private String qaId;

    /** 질문제목 */
    @EgovNullCheck(message = "{valid.QnaManageVO.qestnSj.required}")
    @Size(max = 250, message = "{valid.QnaManageVO.qestnSj.maxlength}")
    private String qestnSj;

    /** 질문내용 */
    @EgovNullCheck(message = "{valid.QnaManageVO.qestnCn.required}")
    @Size(max = 2500, message = "{valid.QnaManageVO.qestnCn.maxlength}")
    private String qestnCn;

    /** 작성비밀번호 */
    @EgovNullCheck(message = "{valid.QnaManageVO.writngPassword.required}")
    @Size(max = 20, message = "{valid.QnaManageVO.writngPassword.maxlength}")
    private String writngPassword;

    /** 지역번호 */
    @EgovNullCheck(message = "{valid.QnaManageVO.areaNo.required}")
    @Size(max = 4, message = "{valid.QnaManageVO.areaNo.maxlength}")
    @Pattern(regexp = "\\d*", message = "{valid.QnaManageVO.areaNo.integer}")
    private String areaNo;

    /** 중간전화번호 */
    @EgovNullCheck(message = "{valid.QnaManageVO.middleTelno.required}")
    @Size(max = 4, message = "{valid.QnaManageVO.middleTelno.maxlength}")
    @Pattern(regexp = "\\d*", message = "{valid.QnaManageVO.middleTelno.integer}")
    private String middleTelno;

    /** 끝전화번호 */
    @EgovNullCheck(message = "{valid.QnaManageVO.endTelno.required}")
    @Size(max = 4, message = "{valid.QnaManageVO.endTelno.maxlength}")
    @Pattern(regexp = "\\d*", message = "{valid.QnaManageVO.endTelno.integer}")
    private String endTelno;

    /** 이메일 주소 */
    @Size(max = 50, message = "{valid.QnaManageVO.emailAdres.maxlength}")
    @Email(message = "{valid.QnaManageVO.emailAdres.email}")
    private String emailAdres;

    /** 이메일 답변여부 */
    private String emailAnswerAt;

    /** 작성자 명 */
    @EgovNullCheck(message = "{valid.QnaManageVO.wrterNm.required}")
    @Size(max = 20, message = "{valid.QnaManageVO.wrterNm.maxlength}")
    private String wrterNm;

    /** 작성일자 */
    private String writngDe;

    /** 조회횟수 */
    private String inqireCo;

    /** 질의응답처리상태코드 */
    private String qnaProcessSttusCode;

    /** 질의응답처리상태코드명 */
    private String qnaProcessSttusCodeNm;

    /** 답변내용 */
    @EgovNullCheck(message = "{valid.QnaManageVO.answerCn.required}")
    @Size(max = 2500, message = "{valid.QnaManageVO.answerCn.maxlength}")
    private String answerCn;

    /** 답변일자 */
    private String answerDe;

    /** 작성비밀번호 확인여부 */
    private String passwordConfirmAt;

    /** 답변자명 */
    private String emplyrNm;

    /** 사무실전화번호 */
    private String offmTelno;

    /** 답변자 EMAIL 주소 */
    private String aemailAdres;

    /** 부서명 */
    private String orgnztNm;

    /** 최초등록시점 */
    private String frstRegisterPnttm;

    /** 최초등록자ID */
    private String frstRegisterId;

    /** 최종수정시점 */
    private String lastUpdusrPnttm;

    /** 최종수정자ID */
    private String lastUpdusrId;

	public String getQaId() {
		return qaId;
	}

	public void setQaId(String qaId) {
		this.qaId = qaId;
	}

	public String getQestnSj() {
		return qestnSj;
	}

	public void setQestnSj(String qestnSj) {
		this.qestnSj = qestnSj;
	}

	public String getQestnCn() {
		return qestnCn;
	}

	public void setQestnCn(String qestnCn) {
		this.qestnCn = qestnCn;
	}

	public String getWritngPassword() {
		return writngPassword;
	}

	public void setWritngPassword(String writngPassword) {
		this.writngPassword = writngPassword;
	}

	public String getAreaNo() {
		return areaNo;
	}

	public void setAreaNo(String areaNo) {
		this.areaNo = areaNo;
	}

	public String getMiddleTelno() {
		return middleTelno;
	}

	public void setMiddleTelno(String middleTelno) {
		this.middleTelno = middleTelno;
	}

	public String getEndTelno() {
		return endTelno;
	}

	public void setEndTelno(String endTelno) {
		this.endTelno = endTelno;
	}

	public String getEmailAdres() {
		return emailAdres;
	}

	public void setEmailAdres(String emailAdres) {
		this.emailAdres = emailAdres;
	}

	public String getEmailAnswerAt() {
		return emailAnswerAt;
	}

	public void setEmailAnswerAt(String emailAnswerAt) {
		this.emailAnswerAt = emailAnswerAt;
	}

	public String getWrterNm() {
		return wrterNm;
	}

	public void setWrterNm(String wrterNm) {
		this.wrterNm = wrterNm;
	}

	public String getWritngDe() {
		return writngDe;
	}

	public void setWritngDe(String writngDe) {
		this.writngDe = writngDe;
	}

	public String getInqireCo() {
		return inqireCo;
	}

	public void setInqireCo(String inqireCo) {
		this.inqireCo = inqireCo;
	}

	public String getQnaProcessSttusCode() {
		return qnaProcessSttusCode;
	}

	public void setQnaProcessSttusCode(String qnaProcessSttusCode) {
		this.qnaProcessSttusCode = qnaProcessSttusCode;
	}

	public String getQnaProcessSttusCodeNm() {
		return qnaProcessSttusCodeNm;
	}

	public void setQnaProcessSttusCodeNm(String qnaProcessSttusCodeNm) {
		this.qnaProcessSttusCodeNm = qnaProcessSttusCodeNm;
	}

	public String getAnswerCn() {
		return answerCn;
	}

	public void setAnswerCn(String answerCn) {
		this.answerCn = answerCn;
	}

	public String getAnswerDe() {
		return answerDe;
	}

	public void setAnswerDe(String answerDe) {
		this.answerDe = answerDe;
	}

	public String getPasswordConfirmAt() {
		return passwordConfirmAt;
	}

	public void setPasswordConfirmAt(String passwordConfirmAt) {
		this.passwordConfirmAt = passwordConfirmAt;
	}

	public String getEmplyrNm() {
		return emplyrNm;
	}

	public void setEmplyrNm(String emplyrNm) {
		this.emplyrNm = emplyrNm;
	}

	public String getOffmTelno() {
		return offmTelno;
	}

	public void setOffmTelno(String offmTelno) {
		this.offmTelno = offmTelno;
	}

	public String getAemailAdres() {
		return aemailAdres;
	}

	public void setAemailAdres(String aemailAdres) {
		this.aemailAdres = aemailAdres;
	}

	public String getOrgnztNm() {
		return orgnztNm;
	}

	public void setOrgnztNm(String orgnztNm) {
		this.orgnztNm = orgnztNm;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

}
