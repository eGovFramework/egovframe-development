package egovframework.com.uss.umt.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.umt.service.UserDefaultVO;

/** 사용자관리에 관한 데이터 접근 클래스를 정의한다. */
@Repository("userManageDAO")
public class UserManageDAO extends EgovComAbstractDAO{

    /** 기 등록된 특정 사용자의 정보를 데이터베이스에서 읽어와 화면에 출력 */
    public List<?> selectUserList(UserDefaultVO userSearchVO){
        return list("userManageDAO.selectUserList_S", userSearchVO);
    }

}
