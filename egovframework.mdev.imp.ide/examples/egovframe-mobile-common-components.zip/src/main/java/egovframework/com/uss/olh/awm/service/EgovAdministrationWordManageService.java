package egovframework.com.uss.olh.awm.service;

import java.util.List;

/** 행정전문용어사전관리를 처리하는 Service Class 구현 */
public interface EgovAdministrationWordManageService {

	/** 행정전문용어사전관리 목록을 조회한다. */
	public List<?> selectAdministrationWordManageList(AdministrationWordManage searchVO) throws Exception;

	/** 행정전문용어사전관리를(을) 목록 전체 건수를(을) 조회한다. */
	public int selectAdministrationWordManageListCnt(AdministrationWordManage searchVO) throws Exception;

	/** 행정전문용어사전관리를(을) 상세조회 한다. */
	public AdministrationWordManage selectAdministrationWordManageDetail(AdministrationWordManage administrationWordManage) throws Exception;

	/** 행정전문용어사전관리를(을) 등록한다. */
	void insertAdministrationWordManage(AdministrationWordManage administrationWordManage) throws Exception;

	/** 행정전문용어사전관리를(을) 수정한다. */
	void updateAdministrationWordManage(AdministrationWordManage administrationWordManage) throws Exception;

	/** 행정전문용어사전관리를(을) 삭제한다. */
	void deleteAdministrationWordManage(AdministrationWordManage administrationWordManage) throws Exception;

}
