package egovframework.com.cmm.exception;

import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;

/** 허용되지 않은 파일 확장자 업로드 예외 */
public class EgovFileExtensionException extends BaseRuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * @param messageKey 메세지 키
	 */
	public EgovFileExtensionException(String message, String messageKey) {
		this.messageKey = messageKey;
		this.messageParameters = null;
		this.message = message;
		this.wrappedException = null;
	}

}
