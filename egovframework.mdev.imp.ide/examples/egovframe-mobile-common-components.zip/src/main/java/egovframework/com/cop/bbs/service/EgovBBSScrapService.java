package egovframework.com.cop.bbs.service;

import java.util.Map;

/** 스크랩관리를 위한 서비스 인터페이스 클래스 */
public interface EgovBBSScrapService {
    /** 스크랩 사용 가능 여부를 확인한다. */
    public boolean canUseScrap() throws Exception;

    /** 스크랩에 대한 목록을 조회 한다. */
    public Map<String, Object> selectScrapList(ScrapVO scrapVO) throws Exception;

    /** 스크랩을 등록한다. */
    public void insertScrap(Scrap scrap) throws Exception;

    /** 스크랩을 삭제한다. */
    public void deleteScrap(ScrapVO scrapVO) throws Exception;

    /** 스크랩에 대한 내용을 조회한다. */
    public Scrap selectScrap(ScrapVO scrapVO) throws Exception;

    /** 스크랩에 대한 내용을 수정한다. */
    public void updateScrap(Scrap scrap) throws Exception;
}
