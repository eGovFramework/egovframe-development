package egovframework.com.uss.sam.stp.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.sam.stp.service.StplatManageDefaultVO;
import egovframework.com.uss.sam.stp.service.StplatManageVO;

/** 약관내용을 처리하는 DAO 클래스 */
@Repository("StplatManageDAO")
public class StplatManageDAO extends EgovComAbstractDAO {

    /**
     * 약관정보 글 목록에 대한 상세내용을 조회한다.
     * @return 조회한 글
     */
    public StplatManageVO selectStplatDetail(StplatManageVO vo) throws Exception {
        return (StplatManageVO) selectOne("StplatManageDAO.selectStplatDetail", vo);
    }

    /**
     * 약관정보 글 목록을 조회한다.
     * @return 글 목록
     */
    public List<?> selectStplatList(StplatManageDefaultVO searchVO) throws Exception {
        return list("StplatManageDAO.selectStplatList", searchVO);
    }

    /**
     * 약관정보 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    public int selectStplatListTotCnt(StplatManageDefaultVO searchVO) {
        return (Integer)selectOne("StplatManageDAO.selectStplatListTotCnt", searchVO);
    }

	/** 약관정보 글을 등록한다. */
    public void insertStplatCn(StplatManageVO vo) throws Exception {
        insert("StplatManageDAO.insertStplatCn", vo);
    }

	/** 약관정보 글을 수정한다. */
    public void updateStplatCn(StplatManageVO vo) throws Exception {
        update("StplatManageDAO.updateStplatCn", vo);
    }

	/** 약관정보 글을 삭제한다. */
    public void deleteStplatCn(StplatManageVO vo) throws Exception {
        delete("StplatManageDAO.deleteStplatCn", vo);
    }

}
