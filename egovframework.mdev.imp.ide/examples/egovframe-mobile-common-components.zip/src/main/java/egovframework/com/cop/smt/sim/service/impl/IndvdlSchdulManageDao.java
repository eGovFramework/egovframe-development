package egovframework.com.cop.smt.sim.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.smt.sim.service.IndvdlSchdulManageVO;

/** 일정관리를 처리하는 Dao Class 구현 */
@Repository("indvdlSchdulManageDao")
public class IndvdlSchdulManageDao extends EgovComAbstractDAO {

	/** 일정 목록을 Map(map)형식으로 조회한다. */
	public List<?> selectIndvdlSchdulManageRetrieve(Map<?, ?> map) throws Exception {
		return list("IndvdlSchdulManage.selectIndvdlSchdulManageRetrieve", map);
	}

	/** 일정를(을) 상세조회 한다. */
	public List<?> selectIndvdlSchdulManageDetail(IndvdlSchdulManageVO indvdlSchdulManageVO) throws Exception {
		return list("IndvdlSchdulManage.selectIndvdlSchdulManageDetail", indvdlSchdulManageVO);
	}

	/** 일정를(을) 등록한다. */
	public void insertIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) throws Exception {
		insert("IndvdlSchdulManage.insertIndvdlSchdulManage", indvdlSchdulManageVO);
	}

	/** 일정를(을) 수정한다. */
	public void updateIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) throws Exception {
		insert("IndvdlSchdulManage.updateIndvdlSchdulManage", indvdlSchdulManageVO);
	}

	/** 일정를(을) 삭제한다. */
	public void deleteIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) throws Exception {
		// 일지 삭제
		delete("IndvdlSchdulManage.deleteDiaryManage", indvdlSchdulManageVO);
		// 일정관리 삭제
		delete("IndvdlSchdulManage.deleteIndvdlSchdulManage", indvdlSchdulManageVO);
	}
}
