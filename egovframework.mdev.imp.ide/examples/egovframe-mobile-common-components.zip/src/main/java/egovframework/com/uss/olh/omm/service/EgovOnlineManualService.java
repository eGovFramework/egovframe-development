package egovframework.com.uss.olh.omm.service;

import java.util.List;

import egovframework.com.cmm.ComDefaultVO;

/** 온라인메뉴얼를 처리하는 Service Class 구현 */
public interface EgovOnlineManualService {

        /** 온라인메뉴얼 목록을 조회한다. */
	public List<?> selectOnlineManualList(ComDefaultVO searchVO) throws Exception;

        /** 온라인메뉴얼를(을) 상세조회 한다. */
	public OnlineManual selectOnlineManualDetail(OnlineManual onlineManual) throws Exception;

        /** 온라인메뉴얼를(을) 목록 전체 건수를(을) 조회한다. */
	public int selectOnlineManualListCnt(ComDefaultVO searchVO) throws Exception;

        /** 온라인메뉴얼를(을) 등록한다. */
	void  insertOnlineManual(OnlineManual onlineManual) throws Exception;

        /** 온라인메뉴얼를(을) 수정한다. */
	void  updateOnlineManual(OnlineManual onlineManual) throws Exception;

	/** 온라인메뉴얼를(을) 삭제한다. */
	void  deleteOnlineManual(OnlineManual onlineManual) throws Exception;

}
