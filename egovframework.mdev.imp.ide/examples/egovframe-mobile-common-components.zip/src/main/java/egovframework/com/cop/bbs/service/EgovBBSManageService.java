package egovframework.com.cop.bbs.service;

import java.util.Map;

/** 게시물 관리를 위한 서비스 인터페이스 클래스 */
public interface EgovBBSManageService {

    /** 게시물 한 건을 삭제 한다. */
    public void deleteBoardArticle(Board Board) throws Exception;

    /** 게시판에 게시물 또는 답변 게시물을 등록 한다. */
    public void insertBoardArticle(Board Board) throws Exception;

    /** 게시물 대하여 상세 내용을 조회 한다. */
    public BoardVO selectBoardArticle(BoardVO boardVO) throws Exception;

    /** 조건에 맞는 게시물 목록을 조회 한다. */
    public Map<String, Object> selectBoardArticles(BoardVO boardVO, String attrbFlag) throws Exception;

    /** 게시물 한 건의 내용을 수정 한다. */
    public void updateBoardArticle(Board Board) throws Exception;

    /** 방명록에 대한 목록을 조회 한다. */
    public Map<String, Object> selectGuestList(BoardVO boardVO) throws Exception;

    /** 방명록 내용을 삭제 한다. */
    public void deleteGuestList(BoardVO boardVO) throws Exception;

    /** 방명록에 대한 패스워드를 조회 한다. */
    public String getPasswordInf(Board Board) throws Exception;

}
