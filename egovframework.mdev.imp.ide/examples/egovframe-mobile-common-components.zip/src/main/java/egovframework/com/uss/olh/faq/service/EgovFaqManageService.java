package egovframework.com.uss.olh.faq.service;

import java.util.List;

/** FAQ를 처리하는 서비스 클래스 */
public interface EgovFaqManageService {

    /**
     * FAQ 글을 조회한다.
     * @return 조회한 글
     */
	FaqManageVO selectFaqListDetail(FaqManageVO vo) throws Exception;

	/** 조회수를 수정한다. */
    void updateFaqInqireCo(FaqManageVO vo) throws Exception;

    /**
     * FAQ 글 목록을 조회한다.
     * @return 글 목록
     */
    List<?> selectFaqList(FaqManageDefaultVO searchVO) throws Exception;

    /**
     * FAQ 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    int selectFaqListTotCnt(FaqManageDefaultVO searchVO);

	/** FAQ글을 등록한다. */
    void insertFaqCn(FaqManageVO vo) throws Exception;

	/** FAQ 글을 수정한다. */
    void updateFaqCn(FaqManageVO vo) throws Exception;

	/** FAQ 글을 삭제한다. */
    void deleteFaqCn(FaqManageVO vo) throws Exception;

}
