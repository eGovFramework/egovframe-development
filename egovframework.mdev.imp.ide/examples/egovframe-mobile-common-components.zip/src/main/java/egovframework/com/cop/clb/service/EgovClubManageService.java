package egovframework.com.cop.clb.service;

import java.util.List;

/** 동호회 정보를 관리하기 위한 서비스 인터페이스 클래스 */
public interface EgovClubManageService {

    /** 특정 커뮤니티에 사용되는 동호회 목록을 조회 한다(포틀릿 형식용). */
    public List<ClubVO> selectClubListPortletByTrget(Club club) throws Exception;
}
