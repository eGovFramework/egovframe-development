package egovframework.com.uss.ion.ecc.service;

import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import egovframework.com.cmm.ComDefaultVO;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** 행사/이벤트/캠페인 VO Class 구현 */
public class EventCmpgnVO extends ComDefaultVO implements Serializable {

	private static final long serialVersionUID = -5817021412630105195L;

	/** 행사/이벤트/캠페인ID */
	private String eventId = "";

	/** 사업년도 */
	private String bsnsYear = "";

	/** 사업코드 */
	private String bsnsCode = "";

	/** 행사시작일자 */
	@EgovNullCheck(message = "{valid.EventCmpgnVO.eventSvcBeginDe.required}")
	@Pattern(regexp = "(\\d{4}-?\\d{2}-?\\d{2})?", message = "{valid.EventCmpgnVO.eventSvcBeginDe.date}")
	private String eventSvcBeginDe = "";

	/** 서비스이용 인원수 */
	private int svcUseNmprCo = 0;

	/** 담당자명 */
	private String chargerNm = "";

	/** 행사내용 */
	@EgovNullCheck(message = "{valid.EventCmpgnVO.eventCn.required}")
	@Size(max = 1000, message = "{valid.EventCmpgnVO.eventCn.maxlength}")
	private String eventCn = "";

	/** 행사종료일자 */
	@EgovNullCheck(message = "{valid.EventCmpgnVO.eventSvcEndDe.required}")
	@Pattern(regexp = "(\\d{4}-?\\d{2}-?\\d{2})?", message = "{valid.EventCmpgnVO.eventSvcEndDe.date}")
	private String eventSvcEndDe = "";

	/** 행사유형코드 */
	@EgovNullCheck(message = "{valid.EventCmpgnVO.eventTyCode.required}")
	private String eventTyCode = "";

	/** 준비물내용 */
	@Size(max = 1000, message = "{valid.EventCmpgnVO.prparetgCn.maxlength}")
	private String prparetgCn = "";

	/** 최초등록시점 */
	private String frstRegisterPnttm = "";
	/** 최초등록ID */
	private String frstRegisterId = "";
	/** 최종수정시점 */
	private String lastUpdusrPnttm = "";
	/** 최종수정ID */
	private String lastUpdusrId = "";
	/** 화면처리 명령어 */
	private String cmd = "";

	/** 행사/이벤트 승인여부 */
	private String eventConfmAt = "";

	/** 행사/이벤트 승인일 */
	@Pattern(regexp = "(\\d{4}-?\\d{2}-?\\d{2})?", message = "{valid.EventCmpgnVO.eventConfmDe.date}")
	private String eventConfmDe = "";

	public String getEventConfmDe() {
		return eventConfmDe;
	}
	public void setEventConfmDe(String eventConfmDe) {
		this.eventConfmDe = eventConfmDe;
	}

	public String getEventConfmAt() {
		return eventConfmAt;
	}
	public void setEventConfmAt(String eventConfmAt) {
		this.eventConfmAt = eventConfmAt;
	}

	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getBsnsYear() {
		return bsnsYear;
	}
	public void setBsnsYear(String bsnsYear) {
		this.bsnsYear = bsnsYear;
	}
	public String getBsnsCode() {
		return bsnsCode;
	}
	public void setBsnsCode(String bsnsCode) {
		this.bsnsCode = bsnsCode;
	}
	public String getEventSvcBeginDe() {
		return eventSvcBeginDe;
	}
	public void setEventSvcBeginDe(String eventSvcBeginDe) {
		this.eventSvcBeginDe = eventSvcBeginDe;
	}
	public int getSvcUseNmprCo() {
		return svcUseNmprCo;
	}
	public void setSvcUseNmprCo(int svcUseNmprCo) {
		this.svcUseNmprCo = svcUseNmprCo;
	}
	public String getChargerNm() {
		return chargerNm;
	}
	public void setChargerNm(String chargerNm) {
		this.chargerNm = chargerNm;
	}
	public String getEventCn() {
		return eventCn;
	}
	public void setEventCn(String eventCn) {
		this.eventCn = eventCn;
	}
	public String getEventSvcEndDe() {
		return eventSvcEndDe;
	}
	public void setEventSvcEndDe(String eventSvcEndDe) {
		this.eventSvcEndDe = eventSvcEndDe;
	}
	public String getEventTyCode() {
		return eventTyCode;
	}
	public void setEventTyCode(String eventTyCode) {
		this.eventTyCode = eventTyCode;
	}
	public String getPrparetgCn() {
		return prparetgCn;
	}
	public void setPrparetgCn(String prparetgCn) {
		this.prparetgCn = prparetgCn;
	}
	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}
	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}
	public String getFrstRegisterId() {
		return frstRegisterId;
	}
	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}
	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}
	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}
	public String getLastUpdusrId() {
		return lastUpdusrId;
	}
	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}
	public String getCmd() {
		return cmd;
	}
	public void setCmd(String cmd) {
		this.cmd = cmd;
	}

}
