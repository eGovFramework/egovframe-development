package egovframework.com.uss.olp.mgt.service;

import java.util.List;

import egovframework.com.cmm.ComDefaultVO;

/** 회의관리를 처리하기 위한 Service 구현 Class */
public interface EgovMeetingManageService {

    /** 부서 목록을 조회한다. */
	public List<?> egovMeetingManageLisAuthorGroupPopup(ComDefaultVO searchVO) throws Exception;
    /** 아이디 목록을 조회한다. */
	public List<?> egovMeetingManageLisEmpLyrPopup(ComDefaultVO searchVO) throws Exception;

    /** 회의정보를 등록한다. */
	void  insertMeetingManage(MeetingManageVO meetingManageVO) throws Exception;

    /** 회의정보를 수정한다. */
	void  updateMeetingManage(MeetingManageVO meetingManageVO) throws Exception;

    /** 회의정보를 삭제한다. */
	void  deleteMeetingManage(MeetingManageVO meetingManageVO) throws Exception;

}
