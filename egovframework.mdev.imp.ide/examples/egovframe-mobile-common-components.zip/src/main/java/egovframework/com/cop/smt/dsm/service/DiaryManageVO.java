package egovframework.com.cop.smt.dsm.service;

import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import egovframework.com.cmm.ComDefaultVO;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** 일지관리 VO Class 구현 */
public class DiaryManageVO extends ComDefaultVO implements Serializable {

	private static final long serialVersionUID = 8243616489957327248L;

	/** 일지ID */
	private String diaryId;

	/** 일정내용 */
	@EgovNullCheck(message = "{valid.DiaryManageVO.schdulCn.required}")
	private String schdulCn;

	/** 일정ID */
	private String schdulId;

	/** 진척율 */
	@EgovNullCheck(message = "{valid.DiaryManageVO.diaryProcsPte.required}")
	@Pattern(regexp = "\\d*", message = "{valid.DiaryManageVO.diaryProcsPte.integer}")
	private String diaryProcsPte;

	/** 일정명 */
	@EgovNullCheck(message = "{valid.DiaryManageVO.diaryNm.required}")
	@Size(max = 255, message = "{valid.DiaryManageVO.diaryNm.maxlength}")
	private String diaryNm;

	/** 지지사항 */
	@EgovNullCheck(message = "{valid.DiaryManageVO.drctMatter.required}")
	@Size(max = 2500, message = "{valid.DiaryManageVO.drctMatter.maxlength}")
	private String drctMatter;

	/** 특이사항 */
	@EgovNullCheck(message = "{valid.DiaryManageVO.partclrMatter.required}")
	@Size(max = 2500, message = "{valid.DiaryManageVO.partclrMatter.maxlength}")
	private String partclrMatter;

	/** 첨부파일 */
	private String atchFileId;

	/** 최초등록시점 */
	private String frstRegisterPnttm = "";

	/** 최초등록자ID */
	private String frstRegisterId = "";

	/** 최종수정시점 */
	private String lastUpdusrPnttm = "";

	/** 최종수정ID */
	private String lastUpdusrId = "";

	public String getDiaryId() {
		return diaryId;
	}

	public void setDiaryId(String diaryId) {
		this.diaryId = diaryId;
	}

	public String getSchdulCn() {
		return schdulCn;
	}

	public void setSchdulCn(String schdulCn) {
		this.schdulCn = schdulCn;
	}

	public String getSchdulId() {
		return schdulId;
	}

	public void setSchdulId(String schdulId) {
		this.schdulId = schdulId;
	}

	public String getDiaryProcsPte() {
		return diaryProcsPte;
	}

	public void setDiaryProcsPte(String diaryProcsPte) {
		this.diaryProcsPte = diaryProcsPte;
	}

	public String getDiaryNm() {
		return diaryNm;
	}

	public void setDiaryNm(String diaryNm) {
		this.diaryNm = diaryNm;
	}

	public String getDrctMatter() {
		return drctMatter;
	}

	public void setDrctMatter(String drctMatter) {
		this.drctMatter = drctMatter;
	}

	public String getPartclrMatter() {
		return partclrMatter;
	}

	public void setPartclrMatter(String partclrMatter) {
		this.partclrMatter = partclrMatter;
	}

	public String getAtchFileId() {
		return atchFileId;
	}

	public void setAtchFileId(String atchFileId) {
		this.atchFileId = atchFileId;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

}
