package egovframework.com.uss.olh.wor.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.uss.olh.wor.service.EgovWordDicaryService;
import egovframework.com.uss.olh.wor.service.WordDicaryDefaultVO;
import egovframework.com.uss.olh.wor.service.WordDicaryVO;

import jakarta.annotation.Resource;

/** 용어사전을 처리하는 비즈니스 구현 클래스 */
@Service("WordDicaryService")
public class EgovWordDicaryServiceImpl extends EgovAbstractServiceImpl implements
        EgovWordDicaryService {

    @Resource(name="WordDicaryDAO")
    private WordDicaryDAO wordDicaryDAO;

    /** ID Generation */
	@Resource(name="egovWordDicaryIdGnrService")
	private EgovIdGnrService idgenService;

    /**
     * 글을 조회한다.
     * @return 조회한 글
     */
    @Override
	public WordDicaryVO selectWordDicaryDetail(WordDicaryVO vo) throws Exception {
        WordDicaryVO resultVO = wordDicaryDAO.selectWordDicaryDetail(vo);
        if (resultVO == null)
            throw processException("info.nodata.msg");
        return resultVO;
    }

    /**
     * 글 목록을 조회한다.
     * @return 글 목록
     */
    @Override
	public List<?> selectWordDicaryList(WordDicaryDefaultVO searchVO) throws Exception {
        return wordDicaryDAO.selectWordDicaryList(searchVO);
    }

    /**
     * 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    @Override
	public int selectWordDicaryListTotCnt(WordDicaryDefaultVO searchVO) {
		return wordDicaryDAO.selectWordDicarListTotCnt(searchVO);
	}

	/** 글을 등록한다. */
    @Override
	public void insertWordDicary(WordDicaryVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

		String	wordId = idgenService.getNextStringId();

		vo.setWordId(wordId);

    	wordDicaryDAO.insertWordDicary(vo);
    }

	/** 글을 수정한다. */
    @Override
	public void updateWordDicary(WordDicaryVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	wordDicaryDAO.updateWordDicary(vo);
    }

	/** 글을 삭제한다. */
    @Override
	public void deleteWordDicary(WordDicaryVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	wordDicaryDAO.deleteWordDicary(vo);
    }

}
