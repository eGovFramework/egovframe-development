package egovframework.com.cop.clb.service;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/** 동호회 속성정보를 관리하기 위한 모델 클래스 */
@SuppressWarnings("serial")
public class Club implements Serializable {

    /** 동호회 아이디 */
    private String clbId = "";

    /** 동호회 소개 */
    private String clbIntrcn = "";

    /** 동호회 명 */
    private String clbNm = "";

    /** 커뮤니티 아이디 */
    private String cmmntyId = "";

    /** 최초등록자 아이디 */
    private String frstRegisterId = "";

    /** 최초등록시점 */
    private String frstRegisterPnttm = "";

    /** 최종수정자 아이디 */
    private String lastUpdusrId = "";

    /** 최종수정시점 */
    private String lastUpdusrPnttm = "";

    /** 등록구분코드 */
    private String registSeCode;

    /** 템플릿 아이디 */
    private String tmplatId = "";

    /** 사용여부 */
    private String useAt = "";

    /** 사용자 아이디 */
    private String emplyrId = "";

    /** 대상 아이디 */
    private String trgetId = "";

    public String getClbId() {
	return clbId;
    }

    public void setClbId(String clbId) {
	this.clbId = clbId;
    }

    public String getClbIntrcn() {
	return clbIntrcn;
    }

    public void setClbIntrcn(String clbIntrcn) {
	this.clbIntrcn = clbIntrcn;
    }

    public String getClbNm() {
	return clbNm;
    }

    public void setClbNm(String clbNm) {
	this.clbNm = clbNm;
    }

    public String getCmmntyId() {
	return cmmntyId;
    }

    public void setCmmntyId(String cmmntyId) {
	this.cmmntyId = cmmntyId;
    }

    public String getFrstRegisterId() {
	return frstRegisterId;
    }

    public void setFrstRegisterId(String frstRegisterId) {
	this.frstRegisterId = frstRegisterId;
    }

    public String getFrstRegisterPnttm() {
	return frstRegisterPnttm;
    }

    public void setFrstRegisterPnttm(String frstRegisterPnttm) {
	this.frstRegisterPnttm = frstRegisterPnttm;
    }

    public String getLastUpdusrId() {
	return lastUpdusrId;
    }

    public void setLastUpdusrId(String lastUpdusrId) {
	this.lastUpdusrId = lastUpdusrId;
    }

    public String getLastUpdusrPnttm() {
	return lastUpdusrPnttm;
    }

    public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
	this.lastUpdusrPnttm = lastUpdusrPnttm;
    }

    public String getRegistSeCode() {
	return registSeCode;
    }

    public void setRegistSeCode(String registSeCode) {
	this.registSeCode = registSeCode;
    }

    public String getTmplatId() {
	return tmplatId;
    }

    public void setTmplatId(String tmplatId) {
	this.tmplatId = tmplatId;
    }

    public String getUseAt() {
	return useAt;
    }

    public void setUseAt(String useAt) {
	this.useAt = useAt;
    }

    public String getEmplyrId() {
	return emplyrId;
    }

    public void setEmplyrId(String emplyrId) {
	this.emplyrId = emplyrId;
    }

    public String getTrgetId() {
	return trgetId;
    }

    public void setTrgetId(String trgetId) {
	this.trgetId = trgetId;
    }

    /** toString 메소드를 대치한다. */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}
