package egovframework.com.uss.olp.mgt.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.uss.olp.mgt.service.EgovMeetingManageService;
import egovframework.com.uss.olp.mgt.service.MeetingManageVO;

import jakarta.annotation.Resource;

/** 회의관리를 처리하기 위한 ServiceImpl 구현 Class */
@Service("egovMeetingManageService")
public class EgovMeetingManageServiceImpl extends EgovAbstractServiceImpl implements EgovMeetingManageService{

	@Resource(name="meetingManageDao")
	private MeetingManageDao dao;

	@Resource(name="egovMgtIdGnrService")
	private EgovIdGnrService idgenService;

    /** 부서 목록을 조회한다. */
	@Override
	public List<?> egovMeetingManageLisAuthorGroupPopup(ComDefaultVO searchVO){
		return dao.egovMeetingManageLisAuthorGroupPopup(searchVO);
	}

    /** 아이디 목록을 조회한다. */
	@Override
	public List<?> egovMeetingManageLisEmpLyrPopup(ComDefaultVO searchVO){
		return dao.egovMeetingManageLisEmpLyrPopup(searchVO);
	}

    /** 회의정보를 등록한다. */
	@Override
	public void insertMeetingManage(MeetingManageVO meetingManageVO) throws Exception {
		String sMakeId = idgenService.getNextStringId();

		meetingManageVO.setMtgId(sMakeId);

		dao.insertMeetingManage(meetingManageVO);
	}

    /** 회의정보를 수정한다. */
	@Override
	public void updateMeetingManage(MeetingManageVO meetingManageVO){
		dao.updateMeetingManage(meetingManageVO);
	}

    /** 회의정보를 삭제한다. */
	@Override
	public void deleteMeetingManage(MeetingManageVO meetingManageVO){
		dao.deleteMeetingManage(meetingManageVO);
	}
}
