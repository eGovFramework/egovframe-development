package egovframework.com.cop.adb.service;

import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Size;

/** 주소록 관리를 위한 모델 클래스 */
@SuppressWarnings("serial")
public class AdressBook implements Serializable{

    /** 주소록 아이디 */
    private String adbkId = "";

    /** 주소록 명 */
    @EgovNullCheck(message = "{valid.AdressBook.adbkNm.required}")
    @Size(max = 50, message = "{valid.AdressBook.adbkNm.maxlength}")
    private String adbkNm = "";

    /** 주소록 공개범위 */
    @EgovNullCheck(message = "{valid.AdressBook.othbcScope.required}")
    private String othbcScope = "";

    /** 최초등록자 부서 */
    private String trgetOrgnztId = "";

    /** 주소록 사용여부 */
    private String useAt = "";

    /** 주소록 등록자 아이디 */
    private String wrterId = "";

    /** 최초등록자 아이디 */
    private String frstRegisterId = "";

    /** 최초등록시점 */
    private String frstRegisterPnttm = "";

    /** 최종수정자 아이디 */
    private String lastUpdusrId = "";

    /** 최종수정시점 */
    private String lastUpdusrPnttm = "";

    public String getAdbkId() {
        return adbkId;
    }

    public void setAdbkId(String adbkId) {
        this.adbkId = adbkId;
    }

    public String getAdbkNm() {
        return adbkNm;
    }

    public void setAdbkNm(String adbkNm) {
        this.adbkNm = adbkNm;
    }

    public String getOthbcScope() {
        return othbcScope;
    }

    public void setOthbcScope(String othbcScope) {
        this.othbcScope = othbcScope;
    }

    public String getTrgetOrgnztId() {
        return trgetOrgnztId;
    }

    public void setTrgetOrgnztId(String trgetOrgnztId) {
        this.trgetOrgnztId = trgetOrgnztId;
    }

    public String getUseAt() {
        return useAt;
    }

    public void setUseAt(String useAt) {
        this.useAt = useAt;
    }

    public String getWrterId() {
        return wrterId;
    }

    public void setWrterId(String wrterId) {
        this.wrterId = wrterId;
    }

    public String getFrstRegisterId() {
        return frstRegisterId;
    }

    public void setFrstRegisterId(String frstRegisterId) {
        this.frstRegisterId = frstRegisterId;
    }

    public String getFrstRegisterPnttm() {
        return frstRegisterPnttm;
    }

    public void setFrstRegisterPnttm(String frstRegisterPnttm) {
        this.frstRegisterPnttm = frstRegisterPnttm;
    }

    public String getLastUpdusrId() {
        return lastUpdusrId;
    }

    public void setLastUpdusrId(String lastUpdusrId) {
        this.lastUpdusrId = lastUpdusrId;
    }

    public String getLastUpdusrPnttm() {
        return lastUpdusrPnttm;
    }

    public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
        this.lastUpdusrPnttm = lastUpdusrPnttm;
    }

}
