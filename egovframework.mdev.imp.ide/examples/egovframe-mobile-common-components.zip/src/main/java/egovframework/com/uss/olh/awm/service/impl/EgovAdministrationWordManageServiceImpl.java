package egovframework.com.uss.olh.awm.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.uss.olh.awm.service.AdministrationWordManage;
import egovframework.com.uss.olh.awm.service.EgovAdministrationWordManageService;

import jakarta.annotation.Resource;

/** 행정전문용어사전관리를 처리하는 ServiceImpl Class 구현 */
@Service("egovAdministrationWordManageService")
public class EgovAdministrationWordManageServiceImpl extends EgovAbstractServiceImpl
        implements EgovAdministrationWordManageService {

    @Resource(name = "onlineAdministrationWordManageDao")
    private AdministrationWordManageDao dao;

    @Resource(name = "egovAdministrationWordIdGnrService")
    private EgovIdGnrService idgenService;

    /** 행정전문용어사전관리를(을) 목록을 조회 한다. */
    @Override
	public List<?> selectAdministrationWordManageList(AdministrationWordManage searchVO) throws Exception {
        return dao.selectAdministrationWordManageList(searchVO);
    }

    /** 행정전문용어사전관리를(을) 목록 전체 건수를(을) 조회한다. */
    @Override
	public int selectAdministrationWordManageListCnt(AdministrationWordManage searchVO) throws Exception {
        return dao.selectAdministrationWordManageListCnt(searchVO);
    }

    /** 행정전문용어사전관리를(을) 상세조회 한다. */
    @Override
	public AdministrationWordManage selectAdministrationWordManageDetail( AdministrationWordManage administrationWordManage) throws Exception {
        return dao.selectAdministrationWordManageDetail(administrationWordManage);
    }

    /** 행정전문용어사전관리를(을) 등록한다. */
    @Override
	public void insertAdministrationWordManage(AdministrationWordManage administrationWordManage)throws Exception {
       String sMakeId = idgenService.getNextStringId();
       administrationWordManage.setAdministWordId(sMakeId);
       dao.insertAdministrationWordManage(administrationWordManage);
    }

    /** 행정전문용어사전관리를(을) 수정한다. */
    @Override
	public void updateAdministrationWordManage(AdministrationWordManage administrationWordManage) throws Exception {
        dao.updateAdministrationWordManage(administrationWordManage);
    }

    /** 행정전문용어사전관리를(을) 삭제한다. */
    @Override
	public void deleteAdministrationWordManage(AdministrationWordManage administrationWordManage) throws Exception {
        dao.deleteAdministrationWordManage(administrationWordManage);
    }

}
