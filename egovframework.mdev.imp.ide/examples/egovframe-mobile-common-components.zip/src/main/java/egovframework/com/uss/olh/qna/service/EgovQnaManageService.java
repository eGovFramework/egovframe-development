package egovframework.com.uss.olh.qna.service;

import java.util.List;

/** Q&A를 처리하는 서비스 클래스 */
public interface EgovQnaManageService {

    /**
     * Q&A 글을 조회한다.
     * @return 조회한 글
     */
	QnaManageVO selectQnaListDetail(QnaManageVO vo) throws Exception;

	/** Q&A 조회수를 수정한다. */
    void updateQnaInqireCo(QnaManageVO vo) throws Exception;

    /**
     * Q&A 글 목록을 조회한다.
     * @return 글 목록
     */
    List<?> selectQnaList(QnaManageDefaultVO searchVO) throws Exception;

    /**
     * Q&A 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    int selectQnaListTotCnt(QnaManageDefaultVO searchVO);

	/** Q&A 글을 등록한다. */
    void insertQnaCn(QnaManageVO vo) throws Exception;

    /** Q&A 작성비밀번호를 확인한다. */
    int selectQnaPasswordConfirmCnt(QnaManageVO vo);

	/** Q&A 글을 수정한다. */
    void updateQnaCn(QnaManageVO vo) throws Exception;

	/** Q&A 글을 삭제한다. */
    void deleteQnaCn(QnaManageVO vo) throws Exception;

    /**
     * Q&A 답변 글을 조회한다.
     * @return 조회한 글
     */
	QnaManageVO selectQnaAnswerListDetail(QnaManageVO vo) throws Exception;

    /**
     * Q&A 답변 글 목록을 조회한다.
     * @return 글 목록
     */
    List<?> selectQnaAnswerList(QnaManageDefaultVO searchVO) throws Exception;

    /**
     * Q&A 답변 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    int selectQnaAnswerListTotCnt(QnaManageDefaultVO searchVO);

	/** Q&A 답변 글을 수정한다. */
    void updateQnaCnAnswer(QnaManageVO vo) throws Exception;

}
