package egovframework.com.uss.olh.awm.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.olh.awm.service.AdministrationWordManage;

/** 행정전문용어사전관리를 처리하는 Dao Class 구현 */
@Repository("onlineAdministrationWordManageDao")
public class AdministrationWordManageDao extends EgovComAbstractDAO {

    /** 행정전문용어사전관리를(을) 목록을 한다. */
    public List<?> selectAdministrationWordManageList(AdministrationWordManage searchVO) throws Exception {
        return list("AdministrationWord.selectAdministrationWord", searchVO);
    }

    /** 행정전문용어사전관리를(을) 목록 전체 건수를(을) 조회한다. */
    public int selectAdministrationWordManageListCnt(AdministrationWordManage searchVO) throws Exception {
        return (Integer)selectOne("AdministrationWord.selectAdministrationWordCnt", searchVO);
    }

    /** 행정전문용어사전관리를(을) 상세조회 한다. */
    public AdministrationWordManage selectAdministrationWordManageDetail(AdministrationWordManage administrationWordManage) throws Exception {
        return (AdministrationWordManage)selectOne("AdministrationWord.selectAdministrationWordDetail", administrationWordManage);
    }

    /** 행정전문용어사전관리를(을) 등록한다. */
    public void insertAdministrationWordManage(AdministrationWordManage administrationWordManage) throws Exception {
        insert("AdministrationWord.insertAdministrationWord", administrationWordManage);
    }

    /** 행정전문용어사전관리를(을) 수정한다. */
    public void updateAdministrationWordManage(AdministrationWordManage administrationWordManage) throws Exception {
        update("AdministrationWord.updateAdministrationWord", administrationWordManage);
    }

    /** 행정전문용어사전관리를(을) 삭제한다. */
    public void deleteAdministrationWordManage(AdministrationWordManage administrationWordManage) throws Exception {
        delete("AdministrationWord.deleteAdministrationWord", administrationWordManage);

    }

}
