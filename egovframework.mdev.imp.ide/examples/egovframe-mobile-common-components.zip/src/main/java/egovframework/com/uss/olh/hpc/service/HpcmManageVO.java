package egovframework.com.uss.olh.hpc.service;

/** 도움말 처리를 위한 VO 클래스 */
public class HpcmManageVO extends HpcmManageDefaultVO {

    private static final long serialVersionUID = 1L;

    /** 도움말 ID */
    private String	hpcmId;

    /** 도움말구분코드 */
    private String hpcmSeCode;

    /** 도움말구분코드명 */
    private String hpcmSeCodeNm;

    /** 도움말정의 */
    private String hpcmDf;

    /** 도움말 설명 */
    private String hpcmDc;

    /** 최초등록시점 */
    private String frstRegisterPnttm;

    /** 최초등록자ID */
    private String frstRegisterId;

    /** 최종수정시점 */
    private String lastUpdusrPnttm;

    /** 최종수정자ID */
    private String lastUpdusrId;

	public String getHpcmId() {
		return hpcmId;
	}

	public void setHpcmId(String hpcmId) {
		this.hpcmId = hpcmId;
	}

	public String getHpcmSeCode() {
		return hpcmSeCode;
	}

	public void setHpcmSeCode(String hpcmSeCode) {
		this.hpcmSeCode = hpcmSeCode;
	}

	public String getHpcmSeCodeNm() {
		return hpcmSeCodeNm;
	}

	public void setHpcmSeCodeNm(String hpcmSeCodeNm) {
		this.hpcmSeCodeNm = hpcmSeCodeNm;
	}

	public String getHpcmDf() {
		return hpcmDf;
	}

	public void setHpcmDf(String hpcmDf) {
		this.hpcmDf = hpcmDf;
	}

	public String getHpcmDc() {
		return hpcmDc;
	}

	public void setHpcmDc(String hpcmDc) {
		this.hpcmDc = hpcmDc;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

}
