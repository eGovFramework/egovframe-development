package egovframework.com.cop.smt.sam.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cop.smt.sam.service.EgovAllSchdulManageService;

import jakarta.annotation.Resource;

/** 전체일정을 처리하는 ServiceImpl Class 구현 */
@Service("egovAllSchdulManageService")
public class EgovAllSchdulManageServiceImpl extends EgovAbstractServiceImpl implements EgovAllSchdulManageService {

	@Resource(name = "allSchdulManageDao")
	private AllSchdulManageDao dao;

	/** 전체일정 목록을 조회한다. */
	@Override
	public List<?> selectAllSchdulManageeList(ComDefaultVO searchVO) throws Exception {
		return dao.selectAllSchdulManageeList(searchVO);
	}

	/** 전체일정를(을) 목록 전체 건수를(을) 조회한다. */
	@Override
	public int selectAllSchdulManageListCnt(ComDefaultVO searchVO) throws Exception {
		return dao.selectAllSchdulManageListCnt(searchVO);
	}

}
