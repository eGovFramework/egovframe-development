package egovframework.com.cop.smt.sim.service;

import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Size;

/** 일정관리 VO Class 구현 */
public class IndvdlSchdulManageVO implements Serializable {

	private static final long serialVersionUID = 6643386546296100019L;

	/** 일정ID */
	private String schdulId;

	/** 일정구분(회의/교육/세미나/강의 기타) */
	@EgovNullCheck(message = "{valid.IndvdlSchdulManageVO.schdulSe.required}")
	private String schdulSe;

	/** 일정부서ID */
	private String schdulDeptId;

	/** 일정종류(부서일정/개인일정) */
	private String schdulKindCode;

	/** 일정시작일자 */
	private String schdulBgnde;

	/** 일정종료일자 */
	private String schdulEndde;

	/** 일정명 */
	@EgovNullCheck(message = "{valid.IndvdlSchdulManageVO.schdulNm.required}")
	@Size(max = 255, message = "{valid.IndvdlSchdulManageVO.schdulNm.maxlength}")
	private String schdulNm;

	/** 일정내용 */
	@EgovNullCheck(message = "{valid.IndvdlSchdulManageVO.schdulCn.required}")
	@Size(max = 2500, message = "{valid.IndvdlSchdulManageVO.schdulCn.maxlength}")
	private String schdulCn;

	/** 일정장소 */
	private String schdulPlace;

	/** 일정중요도코드 */
	@EgovNullCheck(message = "{valid.IndvdlSchdulManageVO.schdulIpcrCode.required}")
	private String schdulIpcrCode;

	/** 일정담담자ID */
	private String schdulChargerId;

	/** 첨부파일ID */
	private String atchFileId;

	/** 반복구분(반복, 연속, 요일반복) */
	private String reptitSeCode;

	/** 최초등록시점 */
	private String frstRegisterPnttm = "";

	/** 최초등록자ID */
	private String frstRegisterId = "";

	/** 최종수정시점 */
	private String lastUpdusrPnttm = "";

	/** 최종수정ID */
	private String lastUpdusrId = "";

	/** 일정시작일자(시간) */
	@EgovNullCheck(message = "{valid.IndvdlSchdulManageVO.schdulBgndeHH.required}")
	private String schdulBgndeHH = "";

	/** 일정시작일자(분) */
	private String schdulBgndeMM = "";

	/** 일정종료일자(시간) */
	@EgovNullCheck(message = "{valid.IndvdlSchdulManageVO.schdulEnddeHH.required}")
	private String schdulEnddeHH = "";

	/** 일정종료일자(분) */
	private String schdulEnddeMM = "";

	/** 일정시작일자(Year/Month/Day) */
	@EgovNullCheck(message = "{valid.IndvdlSchdulManageVO.schdulBgndeYYYMMDD.required}")
	private String schdulBgndeYYYMMDD = "";

	/** 일정종료일자(Year/Month/Day) */
	@EgovNullCheck(message = "{valid.IndvdlSchdulManageVO.schdulEnddeYYYMMDD.required}")
	private String schdulEnddeYYYMMDD = "";

	/** 담당부서 */
	@EgovNullCheck(message = "{valid.IndvdlSchdulManageVO.schdulDeptName.required}")
	private String schdulDeptName = "";

	/** 담당자명 */
	@EgovNullCheck(message = "{valid.IndvdlSchdulManageVO.schdulChargerName.required}")
	private String schdulChargerName = "";

	public String getSchdulId() {
		return schdulId;
	}

	public void setSchdulId(String schdulId) {
		this.schdulId = schdulId;
	}

	public String getSchdulSe() {
		return schdulSe;
	}

	public void setSchdulSe(String schdulSe) {
		this.schdulSe = schdulSe;
	}

	public String getSchdulDeptId() {
		return schdulDeptId;
	}

	public void setSchdulDeptId(String schdulDeptId) {
		this.schdulDeptId = schdulDeptId;
	}

	public String getSchdulKindCode() {
		return schdulKindCode;
	}

	public void setSchdulKindCode(String schdulKindCode) {
		this.schdulKindCode = schdulKindCode;
	}

	public String getSchdulBgnde() {
		return schdulBgnde;
	}

	public void setSchdulBgnde(String schdulBgnde) {
		this.schdulBgnde = schdulBgnde;
	}

	public String getSchdulEndde() {
		return schdulEndde;
	}

	public void setSchdulEndde(String schdulEndde) {
		this.schdulEndde = schdulEndde;
	}

	public String getSchdulNm() {
		return schdulNm;
	}

	public void setSchdulNm(String schdulNm) {
		this.schdulNm = schdulNm;
	}

	public String getSchdulCn() {
		return schdulCn;
	}

	public void setSchdulCn(String schdulCn) {
		this.schdulCn = schdulCn;
	}

	public String getSchdulPlace() {
		return schdulPlace;
	}

	public void setSchdulPlace(String schdulPlace) {
		this.schdulPlace = schdulPlace;
	}

	public String getSchdulIpcrCode() {
		return schdulIpcrCode;
	}

	public void setSchdulIpcrCode(String schdulIpcrCode) {
		this.schdulIpcrCode = schdulIpcrCode;
	}

	public String getSchdulChargerId() {
		return schdulChargerId;
	}

	public void setSchdulChargerId(String schdulChargerId) {
		this.schdulChargerId = schdulChargerId;
	}

	public String getAtchFileId() {
		return atchFileId;
	}

	public void setAtchFileId(String atchFileId) {
		this.atchFileId = atchFileId;
	}

	public String getReptitSeCode() {
		return reptitSeCode;
	}

	public void setReptitSeCode(String reptitSeCode) {
		this.reptitSeCode = reptitSeCode;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

	public String getSchdulBgndeHH() {
		return schdulBgndeHH;
	}

	public void setSchdulBgndeHH(String schdulBgndeHH) {
		this.schdulBgndeHH = schdulBgndeHH;
	}

	public String getSchdulBgndeMM() {
		return schdulBgndeMM;
	}

	public void setSchdulBgndeMM(String schdulBgndeMM) {
		this.schdulBgndeMM = schdulBgndeMM;
	}

	public String getSchdulEnddeHH() {
		return schdulEnddeHH;
	}

	public void setSchdulEnddeHH(String schdulEnddeHH) {
		this.schdulEnddeHH = schdulEnddeHH;
	}

	public String getSchdulEnddeMM() {
		return schdulEnddeMM;
	}

	public void setSchdulEnddeMM(String schdulEnddeMM) {
		this.schdulEnddeMM = schdulEnddeMM;
	}

	public String getSchdulBgndeYYYMMDD() {
		return schdulBgndeYYYMMDD;
	}

	public void setSchdulBgndeYYYMMDD(String schdulBgndeYYYMMDD) {
		this.schdulBgndeYYYMMDD = schdulBgndeYYYMMDD;
	}

	public String getSchdulEnddeYYYMMDD() {
		return schdulEnddeYYYMMDD;
	}

	public void setSchdulEnddeYYYMMDD(String schdulEnddeYYYMMDD) {
		this.schdulEnddeYYYMMDD = schdulEnddeYYYMMDD;
	}

	public String getSchdulDeptName() {
		return schdulDeptName;
	}

	public void setSchdulDeptName(String schdulDeptName) {
		this.schdulDeptName = schdulDeptName;
	}

	public String getSchdulChargerName() {
		return schdulChargerName;
	}

	public void setSchdulChargerName(String schdulChargerName) {
		this.schdulChargerName = schdulChargerName;
	}

}
