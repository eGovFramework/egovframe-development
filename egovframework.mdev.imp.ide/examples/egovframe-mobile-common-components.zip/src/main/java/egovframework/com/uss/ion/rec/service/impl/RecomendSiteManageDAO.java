package egovframework.com.uss.ion.rec.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.ion.rec.service.RecomendSiteManageDefaultVO;
import egovframework.com.uss.ion.rec.service.RecomendSiteManageVO;

/** 추천사이트정보를 처리하는 DAO 클래스 */
@Repository("RecomendSiteManageDAO")
public class RecomendSiteManageDAO extends EgovComAbstractDAO {

    /**
     * 추천사이트 목록에 대한 상세내용을 조회한다.
     * @return 조회한 글
     */
    public RecomendSiteManageVO selectRecomendSiteDetail(RecomendSiteManageVO vo) throws Exception {

        return (RecomendSiteManageVO) selectOne("RecomendSiteManageDAO.selectRecomendSiteDetail", vo);

    }

    /**
     * 추천사이트 목록을 조회한다.
     * @return	글 목록
     */
    public List<?> selectRecomendSiteList(RecomendSiteManageDefaultVO searchVO) throws Exception {

        return list("RecomendSiteManageDAO.selectRecomendSiteList", searchVO);

    }

    /**
     * 추천사이트 총 갯수를 조회한다.
     * @return	총 갯수
     */
    public int selectRecomendSiteListTotCnt(RecomendSiteManageDefaultVO searchVO) {

        return (Integer)selectOne("RecomendSiteManageDAO.selectRecomendSiteListTotCnt", searchVO);

    }

	/** 추천사이트를 등록한다. */
    public void insertRecomendSiteInfo(RecomendSiteManageVO vo) throws Exception {

        insert("RecomendSiteManageDAO.insertRecomendSiteInfo", vo);

    }

	/** 추천사이트를 수정한다. */
    public void updateRecomendSiteInfo(RecomendSiteManageVO vo) throws Exception {

        update("RecomendSiteManageDAO.updateRecomendSiteInfo", vo);

    }

	/** 추천사이트를 삭제한다. */
    public void deleteRecomendSiteInfo(RecomendSiteManageVO vo) throws Exception {

        delete("RecomendSiteManageDAO.deleteRecomendSiteInfo", vo);

    }

}
