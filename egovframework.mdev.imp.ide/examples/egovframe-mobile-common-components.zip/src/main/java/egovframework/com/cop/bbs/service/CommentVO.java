package egovframework.com.cop.bbs.service;

import org.apache.commons.lang3.builder.ToStringBuilder;

/** 댓글관리 서비스를 위한 VO 클래스 */
@SuppressWarnings("serial")
public class CommentVO extends Comment {
    /** 정렬순서(DESC,ASC) */
    private long sortOrdr = 0L;

    /** 현재페이지 */
    private int subPageIndex = 1;

    /** 페이지갯수 */
    private int subPageUnit = 10;

    /** 페이지사이즈 */
    private int subPageSize = 10;

    /** 첫페이지 인덱스 */
    private int subFirstIndex = 1;

    /** 마지막페이지 인덱스 */
    private int subLastIndex = 1;

    /** 페이지당 레코드 개수 */
    private int subRecordCountPerPage = 10;

    /** 레코드 번호 */
    private int subRowNo = 0;

    /** 호출 TYPE (head or body) */
    private String type = "";

    /** 수정 처리 여부 */
    private boolean isModified = false;

    public long getSortOrdr() {
        return sortOrdr;
    }

    public void setSortOrdr(long sortOrdr) {
        this.sortOrdr = sortOrdr;
    }

    public int getSubPageIndex() {
        return subPageIndex;
    }

    public void setSubPageIndex(int subPageIndex) {
        this.subPageIndex = subPageIndex;
    }

    public int getSubPageUnit() {
        return subPageUnit;
    }

    public void setSubPageUnit(int subPageUnit) {
        this.subPageUnit = subPageUnit;
    }

    public int getSubPageSize() {
        return subPageSize;
    }

    public void setSubPageSize(int subPageSize) {
        this.subPageSize = subPageSize;
    }

    public int getSubFirstIndex() {
        return subFirstIndex;
    }

    public void setSubFirstIndex(int subFirstIndex) {
        this.subFirstIndex = subFirstIndex;
    }

    public int getSubLastIndex() {
        return subLastIndex;
    }

    public void setSubLastIndex(int subLastIndex) {
        this.subLastIndex = subLastIndex;
    }

    public int getSubRecordCountPerPage() {
        return subRecordCountPerPage;
    }

    public void setSubRecordCountPerPage(int subRecordCountPerPage) {
        this.subRecordCountPerPage = subRecordCountPerPage;
    }

    public int getSubRowNo() {
        return subRowNo;
    }

    public void setSubRowNo(int subRowNo) {
        this.subRowNo = subRowNo;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isModified() {
        return isModified;
    }

    public void setModified(boolean isModified) {
        this.isModified = isModified;
    }

    /** toString 메소드를 대치한다. */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}
