package egovframework.com.cop.smt.sam.service;

import java.util.List;

import egovframework.com.cmm.ComDefaultVO;

/** 전체일정을 처리하는 Service Class 구현 */
public interface EgovAllSchdulManageService {

    /** 전체일정 목록을 조회한다. */
	public List<?> selectAllSchdulManageeList(ComDefaultVO searchVO) throws Exception;

    /** 전체일정를(을) 목록 전체 건수를(을) 조회한다. */
	public int selectAllSchdulManageListCnt(ComDefaultVO searchVO) throws Exception;

}
