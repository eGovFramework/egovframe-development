package egovframework.com.uss.olp.qrm.service.impl;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.uss.olp.qrm.service.EgovQustnrRespondManageService;
import egovframework.com.uss.olp.qrm.service.QustnrRespondManageVO;

import jakarta.annotation.Resource;

/** 설문응답자관리 ServiceImpl Class 구현 */
@Service("egovQustnrRespondManageService")
public class EgovQustnrRespondManageServiceImpl extends EgovAbstractServiceImpl implements EgovQustnrRespondManageService{

	@Resource(name="qustnrRespondManageDao")
	private QustnrRespondManageDao dao;

	@Resource(name="qustnrRespondManageIdGnrService")
	private EgovIdGnrService idgenService;

    /** 응답자정보를(을) 등록한다. */
	@Override
	public void insertQustnrRespondManage(QustnrRespondManageVO qustnrRespondManageVO) throws Exception {
		String sMakeId = idgenService.getNextStringId();

		qustnrRespondManageVO.setQestnrRespondId(sMakeId);

		dao.insertQustnrRespondManage(qustnrRespondManageVO);
	}

    /** 응답자정보를(을) 수정한다. */
	@Override
	public void updateQustnrRespondManage(QustnrRespondManageVO qustnrRespondManageVO) throws Exception{
		dao.updateQustnrRespondManage(qustnrRespondManageVO);
	}

    /** 응답자정보를(을) 삭제한다. */
	@Override
	public void deleteQustnrRespondManage(QustnrRespondManageVO qustnrRespondManageVO) throws Exception{
		dao.deleteQustnrRespondManage(qustnrRespondManageVO);
	}
}
