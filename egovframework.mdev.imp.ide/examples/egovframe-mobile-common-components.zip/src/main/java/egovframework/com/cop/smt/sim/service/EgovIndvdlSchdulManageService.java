package egovframework.com.cop.smt.sim.service;

import java.util.List;
import java.util.Map;

/** 일정관리를 처리하는 Service Class 구현 */
public interface EgovIndvdlSchdulManageService {

	/** 일정 목록을 Map(map)형식으로 조회한다. */
	public List<?> selectIndvdlSchdulManageRetrieve(Map<?, ?> map) throws Exception;

	/** 일정를(을) 상세조회 한다. */
	public List<?> selectIndvdlSchdulManageDetail(IndvdlSchdulManageVO indvdlSchdulManageVO) throws Exception;

	/** 일정를(을) 등록한다. */
	void insertIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) throws Exception;

	/** 일정를(을) 수정한다. */
	void updateIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) throws Exception;

	/** 일정를(을) 삭제한다. */
	void deleteIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) throws Exception;

}
