package egovframework.com.uss.olh.qna.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.olh.qna.service.QnaManageDefaultVO;
import egovframework.com.uss.olh.qna.service.QnaManageVO;

/** Q&A정보를 처리하는 DAO 클래스 */
@Repository("QnaManageDAO")
public class QnaManageDAO extends EgovComAbstractDAO {

    /**
     * Q&A 글 목록에 대한 상세내용을 조회한다.
     * @return 조회한 글
     */
    public QnaManageVO selectQnaListDetail(QnaManageVO vo) throws Exception {

        return (QnaManageVO) selectOne("QnaManageDAO.selectQnaListDetail", vo);

    }

	/** Q&A 글을 수정한다.(조회수를 수정) */
    public void updateQnaInqireCo(QnaManageVO vo) throws Exception {

        update("QnaManageDAO.updateQnaInqireCo", vo);

    }

    /**
     * Q&A 글 목록을 조회한다.
     * @return 글 목록
     */
    public List<?> selectQnaList(QnaManageDefaultVO searchVO) throws Exception {

        return list("QnaManageDAO.selectQnaList", searchVO);

    }

    /**
     * Q&A 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    public int selectQnaListTotCnt(QnaManageDefaultVO searchVO) {

        return (Integer)selectOne("QnaManageDAO.selectQnaListTotCnt", searchVO);

    }

	/** Q&A 글을 등록한다. */
    public void insertQnaCn(QnaManageVO vo) throws Exception {

        insert("QnaManageDAO.insertQnaCn", vo);

    }

    /**
     * 작성비밀번호를 확인한다.
     * @return 글 총 갯수
     */
    public int selectQnaPasswordConfirmCnt(QnaManageVO vo) {

        return (Integer)selectOne("QnaManageDAO.selectQnaPasswordConfirmCnt", vo);

    }

	/** Q&A 글을 수정한다. */
    public void updateQnaCn(QnaManageVO vo) throws Exception {

        update("QnaManageDAO.updateQnaCn", vo);

    }

	/** Q&A 글을 삭제한다. */
    public void deleteQnaCn(QnaManageVO vo) throws Exception {

        delete("QnaManageDAO.deleteQnaCn", vo);

    }

    /**
     * Q&A 답변 글 목록에 대한 상세내용을 조회한다.
     * @return 조회한 글
     */
    public QnaManageVO selectQnaAnswerListDetail(QnaManageVO vo) throws Exception {

        return (QnaManageVO) selectOne("QnaManageDAO.selectQnaAnswerListDetail", vo);

    }

    /**
     * Q&A 답변 글 목록을 조회한다.
     * @return 글 목록
     */
    public List<?> selectQnaAnswerList(QnaManageDefaultVO searchVO) throws Exception {

        return list("QnaManageDAO.selectQnaAnswerList", searchVO);

    }

	/** Q&A 답변 글을 수정한다. */
    public void updateQnaCnAnswer(QnaManageVO vo) throws Exception {

        update("QnaManageDAO.updateQnaCnAnswer", vo);

    }

}
