package egovframework.com.uss.olh.wor.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.olh.wor.service.WordDicaryDefaultVO;
import egovframework.com.uss.olh.wor.service.WordDicaryVO;

/** 용어사전을 처리하는 DAO 클래스 */
@Repository("WordDicaryDAO")
public class WordDicaryDAO extends EgovComAbstractDAO {

    /** 용어사전을 상세조회한다. */
    public WordDicaryVO selectWordDicaryDetail(WordDicaryVO vo) throws Exception {

        return (WordDicaryVO) selectOne("WordDicaryDAO.selectWordDicaryDetail_S", vo);

    }

    /**
     * 용어사전 목록을 조회한다.
     * @return	내용 목록
     */
    public List<?> selectWordDicaryList(WordDicaryDefaultVO searchVO) throws Exception {

        return list("WordDicaryDAO.selectWordDicaryList_D", searchVO);

    }

    /**
     * 용어사전 총 갯수를 조회한다.
     * @return	총 갯수
     */
    public int selectWordDicarListTotCnt(WordDicaryDefaultVO searchVO) {

        return (Integer)selectOne("WordDicaryDAO.selectWordDicaryListTotCnt_S", searchVO);

    }

	/** 용어사전을 등록한다. */
    public void insertWordDicary(WordDicaryVO vo) throws Exception {

        insert("wordDicaryDAO.insertWordDicary_S", vo);

    }

	/** 용어사전을 수정한다. */
    public void updateWordDicary(WordDicaryVO vo) throws Exception {

        update("wordDicaryDAO.updateWordDicary_S", vo);

    }

	/** 용어사전을 삭제한다. */
    public void deleteWordDicary(WordDicaryVO vo) throws Exception {

        delete("wordDicaryDAO.deleteWordDicary_S", vo);

    }

}
