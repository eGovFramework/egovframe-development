package egovframework.com.uss.ion.nws.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.ion.nws.service.NewsManageDefaultVO;
import egovframework.com.uss.ion.nws.service.NewsManageVO;

/** 뉴스정보를 처리하는 DAO 클래스 */
@Repository("NewsManageDAO")
public class NewsManageDAO extends EgovComAbstractDAO {

    /** 뉴스정보를 상세 조회한다. */
    public NewsManageVO selectNewsDetail(NewsManageVO vo) throws Exception {
        return (NewsManageVO) selectOne("NewsManageDAO.selectNewsDetail", vo);
    }

    /** 뉴스목록을 조회한다. */
    public List<?> selectNewsList(NewsManageDefaultVO searchVO) throws Exception {
        return list("NewsManageDAO.selectNewsList", searchVO);
    }

    /** 뉴스정보 총 갯수를 조회한다. */
    public int selectNewsListTotCnt(NewsManageDefaultVO searchVO) {
        return (Integer)selectOne("NewsManageDAO.selectNewsListTotCnt", searchVO);
    }

	/** 뉴스정보를 등록한다. */
    public void insertNewsInfo(NewsManageVO vo) throws Exception {
        insert("NewsManageDAO.insertNewsInfo", vo);
    }

	/** 뉴스정보를 수정한다. */
    public void updateNewsInfo(NewsManageVO vo) throws Exception {
        update("NewsManageDAO.updateNewsInfo", vo);
    }

	/** 뉴스정보를 삭제한다. */
    public void deleteNewsInfo(NewsManageVO vo) throws Exception {
        delete("NewsManageDAO.deleteNewsInfo", vo);
    }

}
