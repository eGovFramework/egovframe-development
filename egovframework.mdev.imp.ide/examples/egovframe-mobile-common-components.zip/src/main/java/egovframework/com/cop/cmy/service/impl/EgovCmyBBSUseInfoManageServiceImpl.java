package egovframework.com.cop.cmy.service.impl;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import egovframework.com.cop.cmy.service.EgovCmyBBSUseInfoManageService;

import jakarta.annotation.Resource;

/** 게시판 이용정보를 관리하기 위한 서비스 구현 클래스 */
@Service("EgovCmyBBSUseInfoManageService")
public class EgovCmyBBSUseInfoManageServiceImpl extends EgovAbstractServiceImpl implements EgovCmyBBSUseInfoManageService {

    @Resource(name = "CmyBBSUseInfoManageDAO")
    private CmyBBSUseInfoManageDAO bbsUseDAO;
}
