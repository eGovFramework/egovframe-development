package egovframework.com.uss.ion.nws.service;

import java.util.List;

/** 뉴스정보를 처리하는 서비스 클래스 */
public interface EgovNewsManageService {

    /**
     * 뉴스 상세조회를 한다.
     * @return 글 내용
     */
	NewsManageVO selectNewsDetail(NewsManageVO vo) throws Exception;

    /**
     * 뉴스목록을 조회한다.
     * @return	글 목록
     */
    List<?> selectNewsList(NewsManageDefaultVO searchVO) throws Exception;

    /**
     * 뉴스정보 총 갯수를 조회한다.
     * @return	총 갯수
     */
    int selectNewsListTotCnt(NewsManageDefaultVO searchVO);

	/** 뉴스정보를 등록한다. */
    void insertNewsInfo(NewsManageVO vo) throws Exception;

	/** 뉴스정보를 수정한다. */
    void updateNewsInfo(NewsManageVO vo) throws Exception;

	/** 뉴스정보를 삭제한다. */
    void deleteNewsInfo(NewsManageVO vo) throws Exception;

}
