package egovframework.com.cop.scp.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cop.bbs.service.EgovBBSScrapService;
import egovframework.com.cop.bbs.service.Scrap;
import egovframework.com.cop.bbs.service.ScrapVO;

import jakarta.annotation.Resource;

/** 스크랩관리를 위한 서비스 구현 클래스 */
@Service("EgovBBSScrapService")
public class EgovBBSScrapServiceImpl extends EgovAbstractServiceImpl implements EgovBBSScrapService {

    @Resource(name = "BBSScrapDAO")
    private BBSScrapDAO bbsScrapDAO;

    @Resource(name="egovScrapIdGnrService")
    private EgovIdGnrService idgenService;

    /** 스크랩 사용 가능 여부를 확인한다. */
    public boolean canUseScrap() throws Exception {
	    return true;
    }

    /** 스크랩에 대한 목록을 조회 한다. */
    public Map<String, Object> selectScrapList(ScrapVO scrapVO) throws Exception {
	List<ScrapVO> result = bbsScrapDAO.selectScrapList(scrapVO);
	int cnt = bbsScrapDAO.selectScrapListCnt(scrapVO);

	Map<String, Object> map = new HashMap<String, Object>();

	map.put("resultList", result);
	map.put("resultCnt", Integer.toString(cnt));

	return map;
    }

    /** 스크랩을 등록한다. */
    public void insertScrap(Scrap scrap) throws Exception {
	String scrapId = idgenService.getNextStringId();

	scrap.setScrapId(scrapId);

	bbsScrapDAO.insertScrap(scrap);
    }

    /** 스크랩을 삭제한다. */
    public void deleteScrap(ScrapVO scrapVO) throws Exception {
	bbsScrapDAO.deleteScrap(scrapVO);
    }

    /** 스크랩에 대한 내용을 조회한다. */
    public Scrap selectScrap(ScrapVO scrapVO) throws Exception {
	return bbsScrapDAO.selectScrap(scrapVO);
    }

    /** 스크랩에 대한 내용을 수정한다. */
    public void updateScrap(Scrap scrap) throws Exception {
	bbsScrapDAO.updateScrap(scrap);
    }
}
