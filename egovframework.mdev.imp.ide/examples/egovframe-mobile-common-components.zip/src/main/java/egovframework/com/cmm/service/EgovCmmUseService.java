package egovframework.com.cmm.service;

import java.util.List;

import egovframework.com.cmm.ComDefaultCodeVO;

/** 공통코드등 전체 업무에서 공용해서 사용해야 하는 서비스를 정의하기 위한 서비스 인터페이스 */
public interface EgovCmmUseService {

    /** 공통코드를 조회한다. */
    public List<CmmnDetailCode> selectCmmCodeDetail(ComDefaultCodeVO vo) throws Exception;
}
