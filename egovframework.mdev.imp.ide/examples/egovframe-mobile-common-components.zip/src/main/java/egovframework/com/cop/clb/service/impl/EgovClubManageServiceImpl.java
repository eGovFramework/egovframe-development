package egovframework.com.cop.clb.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import egovframework.com.cop.bbs.service.BoardMaster;
import egovframework.com.cop.bbs.service.EgovBBSAttributeManageService;
import egovframework.com.cop.clb.service.Club;
import egovframework.com.cop.clb.service.ClubVO;
import egovframework.com.cop.clb.service.EgovClubManageService;
import egovframework.com.cop.cmy.service.EgovCmyBBSUseInfoManageService;

import jakarta.annotation.Resource;

/** 동호회 정보를 관리하기 위한 서비스 구현 클래스 */
@Service("EgovClubManageService")
public class EgovClubManageServiceImpl extends EgovAbstractServiceImpl implements EgovClubManageService {

    @Resource(name = "EgovBBSAttributeManageService")
    private EgovBBSAttributeManageService bbsAttrbService;

    @Resource(name = "EgovCmyBBSUseInfoManageService")
    private EgovCmyBBSUseInfoManageService bbsUseService;

    @Resource(name = "ClubManageDAO")
    private ClubManageDAO clubDAO;

    @Resource(name = "egovClbIdGnrService")
    private EgovIdGnrService idgenService;

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovClubManageServiceImpl.class);

    /** 커뮤니티 사용을 위한 게시판 정보를 생성한다. */
    private List<BoardMaster> makeBdMstrListforCmmnty(Club club) {
	BoardMaster bdMstr;
	ArrayList<BoardMaster> result = new ArrayList<BoardMaster>();

	for (int i = 0; i < 5; i++) {
	    bdMstr = new BoardMaster();

	    bdMstr.setFrstRegisterId(club.getFrstRegisterId());
	    bdMstr.setUseAt("Y");
	    bdMstr.setBbsUseFlag("Y");
	    bdMstr.setTrgetId(club.getClbId());
	    bdMstr.setRegistSeCode("REGC05");

	    if (i == 0) {
		bdMstr.setBbsTyCode("BBST04");
		bdMstr.setReplyPosblAt("N");
		bdMstr.setFileAtchPosblAt("N");
		bdMstr.setBbsAttrbCode("BBSA03");
		bdMstr.setBbsNm("방명록");
	    } else if (i == 1) {
		bdMstr.setBbsTyCode("BBST03");
		bdMstr.setReplyPosblAt("N");
		bdMstr.setFileAtchPosblAt("Y");
		bdMstr.setPosblAtchFileNumber(3);
		bdMstr.setBbsAttrbCode("BBSA01");
		bdMstr.setBbsNm("공지게시판");
	    } else if (i == 3) {
		bdMstr.setBbsTyCode("BBST01");
		bdMstr.setReplyPosblAt("Y");
		bdMstr.setFileAtchPosblAt("N");
		bdMstr.setBbsAttrbCode("BBSA03");
		bdMstr.setBbsNm("자유게시판");
	    } else if (i == 4) {
		bdMstr.setBbsTyCode("BBST01");
		bdMstr.setReplyPosblAt("N");
		bdMstr.setFileAtchPosblAt("Y");
		bdMstr.setPosblAtchFileNumber(5);
		bdMstr.setBbsAttrbCode("BBSA03");
		bdMstr.setBbsNm("자료실");
	    } else {
		bdMstr.setBbsTyCode("BBST01");
		bdMstr.setReplyPosblAt("N");
		bdMstr.setFileAtchPosblAt("Y");
		bdMstr.setPosblAtchFileNumber(5);
		bdMstr.setBbsAttrbCode("BBSA02");
		bdMstr.setBbsNm("갤러리");
	    }

	    bdMstr.setBbsIntrcn(club.getClbNm() + " - " + bdMstr.getBbsNm());

	    result.add(bdMstr);
	}

	return result;
    }

    /** 특정 커뮤니티에 사용되는 동호회 목록을 조회 한다(포틀릿 형식용). */
    public List<ClubVO> selectClubListPortletByTrget(Club club) throws Exception {
	return clubDAO.selectClubListPortletByTrget(club);
    }
}
