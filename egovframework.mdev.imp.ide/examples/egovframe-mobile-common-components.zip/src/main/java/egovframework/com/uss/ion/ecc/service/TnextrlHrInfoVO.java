package egovframework.com.uss.ion.ecc.service;

import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** 외부인사관리 VO Class 구현 */
public class TnextrlHrInfoVO implements Serializable {

	private static final long serialVersionUID = 1739374172177710041L;

	/** 성별코드 */
	@EgovNullCheck(message = "{valid.TnextrlHrInfoVO.sexdstnCode.required}")
	private String sexdstnCode = "";

	/** 외부인사명 */
	@EgovNullCheck(message = "{valid.TnextrlHrInfoVO.extrlHrNm.required}")
	private String extrlHrNm = "";

	/** 이메일주소 */
	@EgovNullCheck(message = "{valid.TnextrlHrInfoVO.emailAdres.required}")
	@Email(message = "{valid.TnextrlHrInfoVO.emailAdres.email}")
	private String emailAdres = "";

	/** 직업유형코드 */
	@EgovNullCheck(message = "{valid.TnextrlHrInfoVO.occpTyCode.required}")
	private String occpTyCode = "";

	/** 소속기관명 */
	private String psitnInsttNm = "";

	/** 외부인사ID */
	private String extrlHrId = "";

	/** 행사/이벤트/캠페인 아이디 */
	private String eventId = "";

	/** 생년월일 */
	private String brth = "";

	/** 지역번호 */
	@EgovNullCheck(message = "{valid.TnextrlHrInfoVO.areaNo.required}")
	@Size(max = 4, message = "{valid.TnextrlHrInfoVO.areaNo.maxlength}")
	@Pattern(regexp = "\\d*", message = "{valid.TnextrlHrInfoVO.areaNo.integer}")
	private String areaNo = "";

	/** 중간전화번호 */
	@EgovNullCheck(message = "{valid.TnextrlHrInfoVO.middleTelno.required}")
	@Size(max = 4, message = "{valid.TnextrlHrInfoVO.middleTelno.maxlength}")
	@Pattern(regexp = "\\d*", message = "{valid.TnextrlHrInfoVO.middleTelno.integer}")
	private String middleTelno = "";

	/** 끝전화번호 */
	@EgovNullCheck(message = "{valid.TnextrlHrInfoVO.endTelno.required}")
	@Size(max = 4, message = "{valid.TnextrlHrInfoVO.endTelno.maxlength}")
	@Pattern(regexp = "\\d*", message = "{valid.TnextrlHrInfoVO.endTelno.integer}")
	private String endTelno = "";

	/** 생년월일(년) */
	@EgovNullCheck(message = "{valid.TnextrlHrInfoVO.brthYYYY.required}")
	private String brthYYYY = "";

	/** 생년월일(월) */
	@EgovNullCheck(message = "{valid.TnextrlHrInfoVO.brthMM.required}")
	private String brthMM = "";

	/** 생년월일(일) */
	@EgovNullCheck(message = "{valid.TnextrlHrInfoVO.brthDD.required}")
	private String brthDD = "";

	/** 최초등록시점 */
	private String frstRegisterPnttm = "";

	/** 최초등록ID */
	private String frstRegisterId = "";

	/** 최종수정시점 */
	private String lastUpdusrPnttm = "";

	/** 최종수정ID */
	private String lastUpdusrId = "";

	public String getSexdstnCode() {
		return sexdstnCode;
	}

	public void setSexdstnCode(String sexdstnCode) {
		this.sexdstnCode = sexdstnCode;
	}

	public String getExtrlHrNm() {
		return extrlHrNm;
	}

	public void setExtrlHrNm(String extrlHrNm) {
		this.extrlHrNm = extrlHrNm;
	}

	public String getEmailAdres() {
		return emailAdres;
	}

	public void setEmailAdres(String emailAdres) {
		this.emailAdres = emailAdres;
	}

	public String getOccpTyCode() {
		return occpTyCode;
	}

	public void setOccpTyCode(String occpTyCode) {
		this.occpTyCode = occpTyCode;
	}

	public String getPsitnInsttNm() {
		return psitnInsttNm;
	}

	public void setPsitnInsttNm(String psitnInsttNm) {
		this.psitnInsttNm = psitnInsttNm;
	}

	public String getExtrlHrId() {
		return extrlHrId;
	}

	public void setExtrlHrId(String extrlHrId) {
		this.extrlHrId = extrlHrId;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getBrth() {
		return brth;
	}

	public void setBrth(String brth) {
		this.brth = brth;
	}

	public String getAreaNo() {
		return areaNo;
	}

	public void setAreaNo(String areaNo) {
		this.areaNo = areaNo;
	}

	public String getMiddleTelno() {
		return middleTelno;
	}

	public void setMiddleTelno(String middleTelno) {
		this.middleTelno = middleTelno;
	}

	public String getEndTelno() {
		return endTelno;
	}

	public void setEndTelno(String endTelno) {
		this.endTelno = endTelno;
	}

	public String getBrthYYYY() {
		return brthYYYY;
	}

	public void setBrthYYYY(String brthYYYY) {
		this.brthYYYY = brthYYYY;
	}

	public String getBrthMM() {
		return brthMM;
	}

	public void setBrthMM(String brthMM) {
		this.brthMM = brthMM;
	}

	public String getBrthDD() {
		return brthDD;
	}

	public void setBrthDD(String brthDD) {
		this.brthDD = brthDD;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

}
