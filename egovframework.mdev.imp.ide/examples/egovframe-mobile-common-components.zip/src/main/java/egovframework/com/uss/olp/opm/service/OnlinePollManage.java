package egovframework.com.uss.olp.opm.service;

import java.io.Serializable;

/** 온라인POLL관리 VO Class 구현 */
public class OnlinePollManage implements Serializable {

	private static final long serialVersionUID = -2949206969185434664L;

	/** 온라인POLL 아이디 */
    private String pollId;

    /** 온라인POLL 이름 */
    private String pollNm;

    /** 온라인POLL 시작일자 */
    private String pollBeginDe;

    /** 온라인POLL 종료일자 */
    private String pollEndDe;

    /** 온라인POLL 종류 */
    private String pollKindCode;

    /** 온라인POLL 페기유무 */
    private String pollDsuseYn;

    /** 온라인POLL 자동페기 */
    private String pollAutoDsuseYn;

    /** 최초등록시점 */
    private String frstRegisterPnttm;

    /** 최초등록아이디 */
    private String frstRegisterId;

    private String lastUpdusrPnttm;

    /** 최종수정자 아이디 */
    private String lastUpdusrId;

    /** 컨트롤 명령어 */
    private String cmd;

    public String getPollId() {
        return pollId;
    }

    public void setPollId(String pollId) {
        this.pollId = pollId;
    }

    public String getPollNm() {
        return pollNm;
    }

    public void setPollNm(String pollNm) {
        this.pollNm = pollNm;
    }

    public String getPollBeginDe() {
        return pollBeginDe;
    }

    public void setPollBeginDe(String pollBeginDe) {
        this.pollBeginDe = pollBeginDe;
    }

    public String getPollEndDe() {
        return pollEndDe;
    }

    public void setPollEndDe(String pollEndDe) {
        this.pollEndDe = pollEndDe;
    }

    public String getPollKindCode() {
        return pollKindCode;
    }

    public void setPollKindCode(String pollKindCode) {
        this.pollKindCode = pollKindCode;
    }

    public String getPollDsuseYn() {
        return pollDsuseYn;
    }

    public void setPollDsuseYn(String pollDsuseYn) {
        this.pollDsuseYn = pollDsuseYn;
    }

    public String getPollAutoDsuseYn() {
        return pollAutoDsuseYn;
    }

    public void setPollAutoDsuseYn(String pollAutoDsuseYn) {
        this.pollAutoDsuseYn = pollAutoDsuseYn;
    }

    public String getFrstRegisterPnttm() {
        return frstRegisterPnttm;
    }

    public void setFrstRegisterPnttm(String frstRegisterPnttm) {
        this.frstRegisterPnttm = frstRegisterPnttm;
    }

    public String getFrstRegisterId() {
        return frstRegisterId;
    }

    public void setFrstRegisterId(String frstRegisterId) {
        this.frstRegisterId = frstRegisterId;
    }

    public String getLastUpdusrPnttm() {
        return lastUpdusrPnttm;
    }

    public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
        this.lastUpdusrPnttm = lastUpdusrPnttm;
    }

    public String getLastUpdusrId() {
        return lastUpdusrId;
    }

    public void setLastUpdusrId(String lastUpdusrId) {
        this.lastUpdusrId = lastUpdusrId;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

}
