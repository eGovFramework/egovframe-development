package egovframework.com.cmm.util;

import java.util.function.Function;

import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;

import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.exception.EgovAccessDeniedException;

/**
 * 소유권 확인 : 수정/삭제는 등록자 본인만 가능하다.
 * 등록자 정보는 컴포넌트에 따라 사용자 고유ID(ESNTL_ID, LoginVO.uniqId) 또는 아이디(LoginVO.id)로 저장되므로 둘 중 하나와 일치하면 등록자로 본다.
 */
public final class EgovOwnerCheck {

	private EgovOwnerCheck() {
	}

	/**
	 * 로그인 사용자가 등록자인지 확인한다.
	 * @param registerId 등록자 고유ID 또는 아이디
	 * @return 등록자 여부 (미로그인, 등록자 정보 없음은 false)
	 */
	public static boolean isOwner(String registerId) {
		if (registerId == null || registerId.isEmpty()
				|| !(EgovUserDetailsHelper.getAuthenticatedUser() instanceof LoginVO loginVO)) {
			return false;
		}
		return registerId.equals(loginVO.getUniqId()) || registerId.equals(loginVO.getId());
	}

	/**
	 * 로그인 사용자가 등록자가 아니면 접근 거부 예외를 발생시킨다.
	 * @param registerId 등록자 고유ID 또는 아이디
	 * @throws EgovAccessDeniedException 등록자가 아닌 경우
	 */
	public static void checkOwner(String registerId) {
		if (!isOwner(registerId)) {
			throw new EgovAccessDeniedException("본인이 등록한 정보만 수정/삭제할 수 있습니다.");
		}
	}

	/**
	 * 등록된 정보의 등록자가 로그인 사용자가 아니면(정보가 없는 경우 포함) 접근 거부 예외를 발생시킨다.
	 * @param registered 수정/삭제 대상의 등록 정보 (DB 조회 결과)
	 * @param registerId 등록 정보에서 등록자 고유ID 또는 아이디를 꺼내는 함수
	 * @throws EgovAccessDeniedException 등록자가 아닌 경우
	 */
	public static <T> void checkOwner(T registered, Function<T, String> registerId) {
		checkOwner(registered == null ? null : registerId.apply(registered));
	}
}
