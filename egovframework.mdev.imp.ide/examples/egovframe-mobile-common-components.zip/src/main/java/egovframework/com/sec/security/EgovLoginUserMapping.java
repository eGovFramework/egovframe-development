package egovframework.com.sec.security;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;

import org.egovframe.rte.fdl.security.userdetails.EgovUserDetails;
import org.egovframe.rte.fdl.security.userdetails.jdbc.EgovUsersByUsernameMapping;

import egovframework.com.cmm.LoginVO;

/**
 * 실행환경 보안(fdl-security) 사용자 조회 결과 매핑 (egov-security-config.properties 의 jdbcMapClass)
 * jdbcUsersByUsernameQuery 결과를 LoginVO 로 매핑하며, EgovUserDetailsHelper.getAuthenticatedUser() 가 이 LoginVO 를 반환한다.
 */
public class EgovLoginUserMapping extends EgovUsersByUsernameMapping {

	public EgovLoginUserMapping(DataSource ds, String usersByUsernameQuery) {
		super(ds, usersByUsernameQuery);
	}

	@Override
	protected EgovUserDetails mapRow(ResultSet rs, int rownum) throws SQLException {
		String userId = rs.getString("USER_ID");

		LoginVO loginVO = new LoginVO();
		loginVO.setId(userId);
		loginVO.setName(rs.getString("USER_NM"));
		loginVO.setEmail(rs.getString("EMAIL_ADRES"));
		loginVO.setUserSe(rs.getString("USER_SE"));
		loginVO.setOrgnztId(rs.getString("ORGNZT_ID"));
		loginVO.setUniqId(rs.getString("ESNTL_ID"));

		// 비밀번호(해시)는 인증 비교에만 사용하고 세션의 LoginVO 에는 보관하지 않는다.
		return new EgovUserDetails(userId, rs.getString("PASSWORD"), rs.getBoolean("ENABLED"), loginVO);
	}
}
