package egovframework.com.uss.olh.qna.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.uss.olh.qna.service.EgovQnaManageService;
import egovframework.com.uss.olh.qna.service.QnaManageDefaultVO;
import egovframework.com.uss.olh.qna.service.QnaManageVO;

import jakarta.annotation.Resource;

/** Q&A정보를 처리하는 비즈니스 구현 클래스 */
@Service("QnaManageService")
public class EgovQnaManageServiceImpl extends EgovAbstractServiceImpl implements
        EgovQnaManageService {

    @Resource(name="QnaManageDAO")
    private QnaManageDAO qnaManageDAO;

    /** ID Generation */
	@Resource(name="egovQnaManageIdGnrService")
	private EgovIdGnrService idgenService;

    /**
     * Q&A 글을 조회한다.
     * @return 조회한 글
     */
    @Override
	public QnaManageVO selectQnaListDetail(QnaManageVO vo) throws Exception {
        QnaManageVO resultVO = qnaManageDAO.selectQnaListDetail(vo);
        if (resultVO == null)
            throw processException("info.nodata.msg");
        return resultVO;
    }

	/** Q&A 글을 수정한다.(조회수를 수정) */
    @Override
	public void updateQnaInqireCo(QnaManageVO vo) throws Exception {
    	qnaManageDAO.updateQnaInqireCo(vo);
    }

    /**
     * Q&A 글 목록을 조회한다.
     * @return 글 목록
     */
    @Override
	public List<?> selectQnaList(QnaManageDefaultVO searchVO) throws Exception {
        return qnaManageDAO.selectQnaList(searchVO);
    }

    /**
     * Q&A 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    @Override
	public int selectQnaListTotCnt(QnaManageDefaultVO searchVO) {
		return qnaManageDAO.selectQnaListTotCnt(searchVO);
	}

	/** Q&A 글을 등록한다. */
    @Override
	public void insertQnaCn(QnaManageVO vo) throws Exception {
		String	qaId = idgenService.getNextStringId();

		vo.setQaId(qaId);

    	qnaManageDAO.insertQnaCn(vo);
    }

    /**
     * 작성비밀번호를 확인한다.
     * @return 글 총 갯수
     */
    @Override
	public int selectQnaPasswordConfirmCnt(QnaManageVO vo) {
		return qnaManageDAO.selectQnaPasswordConfirmCnt(vo);
	}

	/** Q&A 글을 수정한다. */
    @Override
	public void updateQnaCn(QnaManageVO vo) throws Exception {
    	qnaManageDAO.updateQnaCn(vo);
    }

	/** Q&A 글을 삭제한다. */
    @Override
	public void deleteQnaCn(QnaManageVO vo) throws Exception {
    	qnaManageDAO.deleteQnaCn(vo);
    }

    /**
     * Q&A 답변 글을 조회한다.
     * @return 조회한 글
     */
    @Override
	public QnaManageVO selectQnaAnswerListDetail(QnaManageVO vo) throws Exception {
        QnaManageVO resultVO = qnaManageDAO.selectQnaAnswerListDetail(vo);
        if (resultVO == null)
            throw processException("info.nodata.msg");
        return resultVO;
    }

    /**
     * Q&A 답변 글 목록을 조회한다.
     * @return 글 목록
     */
    @Override
	public List<?> selectQnaAnswerList(QnaManageDefaultVO searchVO) throws Exception {
        return qnaManageDAO.selectQnaAnswerList(searchVO);
    }

    /**
     * Q&A 답변 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    @Override
	public int selectQnaAnswerListTotCnt(QnaManageDefaultVO searchVO) {
		return qnaManageDAO.selectQnaListTotCnt(searchVO);
	}

	/** Q&A 답변 글을 수정한다. */
    @Override
	public void updateQnaCnAnswer(QnaManageVO vo) throws Exception {
    	qnaManageDAO.updateQnaCnAnswer(vo);
    }

}
