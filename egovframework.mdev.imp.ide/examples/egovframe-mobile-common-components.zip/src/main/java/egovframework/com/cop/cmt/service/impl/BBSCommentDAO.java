package egovframework.com.cop.cmt.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.bbs.service.Comment;
import egovframework.com.cop.bbs.service.CommentVO;

/** 댓글관리를 위한 데이터 접근 클래스 */
@Repository("BBSCommentDAO")
public class BBSCommentDAO extends EgovComAbstractDAO {

    /** 댓글에 대한 목록을 조회 한다. */
    @SuppressWarnings("unchecked")
    public List<CommentVO> selectCommentList(CommentVO commentVO) throws Exception {
	return (List<CommentVO>) list("BBSCommentDAO.selectCommentList", commentVO);
    }

    /** 댓글에 대한 목록 건수를 조회 한다. */
    public int selectCommentListCnt(CommentVO commentVO) throws Exception {
	return (Integer)selectOne("BBSCommentDAO.selectCommentListCnt", commentVO);
    }

    /** 댓글을 등록한다. */
    public void insertComment(Comment comment) throws Exception {
	insert("BBSCommentDAO.insertComment", comment);
    }

    /** 댓글을 삭제한다. */
    public void deleteComment(CommentVO commentVO) throws Exception {
	update("BBSCommentDAO.deleteComment", commentVO);
    }

    /** 댓글에 대한 내용을 조회한다. */
    public Comment selectComment(CommentVO commentVO) throws Exception {
	return (Comment)selectOne("BBSCommentDAO.selectComment", commentVO);
    }

    /** 댓글에 대한 내용을 수정한다. */
    public void updateComment(Comment comment) throws Exception {
	insert("BBSCommentDAO.updateComment", comment);
    }

    /** 댓글에 대한 패스워드를 조회 한다. */
    public String getCommentPassword(Comment comment) throws Exception {
	return (String)selectOne("BBSCommentDAO.getCommentPassword", comment);
    }
}
