package egovframework.com.uss.sam.stp.service;

import java.util.List;

/** 약관내용을 처리하는 서비스 클래스 */
public interface EgovStplatManageService {

    /**
     * 약관정보 글을 조회한다.
     * @return 조회한 글
     */
	StplatManageVO selectStplatDetail(StplatManageVO vo) throws Exception;

    /**
     * 약관정보 글 목록을 조회한다.
     * @return 글 목록
     */
    List<?> selectStplatList(StplatManageDefaultVO searchVO) throws Exception;

    /**
     * 약관정보 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    int selectStplatListTotCnt(StplatManageDefaultVO searchVO);

	/** 약관정보 글을 등록한다. */
    void insertStplatCn(StplatManageVO vo) throws Exception;

	/** 약관정보 글을 수정한다. */
    void updateStplatCn(StplatManageVO vo) throws Exception;

	/** 약관정보 글을 삭제한다. */
    void deleteStplatCn(StplatManageVO vo) throws Exception;

}
