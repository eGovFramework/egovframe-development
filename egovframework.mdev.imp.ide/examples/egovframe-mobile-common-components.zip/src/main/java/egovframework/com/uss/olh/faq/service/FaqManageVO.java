package egovframework.com.uss.olh.faq.service;

/** FAQ를 처리하는 VO 클래스 */
public class FaqManageVO extends FaqManageDefaultVO {

    private static final long serialVersionUID = 1L;

    /** FAQ ID */
    private String faqId;

    /** 질문제목 */
    private String qestnSj;

    /** 질문내용 */
    private String qestnCn;

    /** 답변내용 */
    private String answerCn;

    /** 조회횟수 */
    private String inqireCo;

    /** 첨부파일ID */
    private String atchFileId;

    /** 최초등록시점 */
    private String frstRegisterPnttm;

    /** 최초등록자ID */
    private String frstRegisterId;

    /** 최종수정시점 */
    private String lastUpdusrPnttm;

    /** 최종수정자ID */
    private String lastUpdusrId;

	public String getFaqId() {
		return faqId;
	}

	public void setFaqId(String faqId) {
		this.faqId = faqId;
	}

	public String getQestnSj() {
		return qestnSj;
	}

	public void setQestnSj(String qestnSj) {
		this.qestnSj = qestnSj;
	}

	public String getQestnCn() {
		return qestnCn;
	}

	public void setQestnCn(String qestnCn) {
		this.qestnCn = qestnCn;
	}

	public String getAnswerCn() {
		return answerCn;
	}

	public void setAnswerCn(String answerCn) {
		this.answerCn = answerCn;
	}

	public String getInqireCo() {
		return inqireCo;
	}

	public void setInqireCo(String inqireCo) {
		this.inqireCo = inqireCo;
	}

	public String getAtchFileId() {
		return atchFileId;
	}

	public void setAtchFileId(String atchFileId) {
		this.atchFileId = atchFileId;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

}
