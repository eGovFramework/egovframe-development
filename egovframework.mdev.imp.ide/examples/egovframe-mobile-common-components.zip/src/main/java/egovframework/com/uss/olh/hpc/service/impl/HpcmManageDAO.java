package egovframework.com.uss.olh.hpc.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.olh.hpc.service.HpcmManageDefaultVO;
import egovframework.com.uss.olh.hpc.service.HpcmManageVO;

/** 도움말을 처리하는 DAO 클래스 */
@Repository("HpcmManageDAO")
public class HpcmManageDAO extends EgovComAbstractDAO {

    /**
     * 도움말 글 목록에 대한 상세내용을 조회한다.
     * @return 조회한 글
     */
    public HpcmManageVO selectHpcmDetail(HpcmManageVO vo) throws Exception {

        return (HpcmManageVO) selectOne("HpcmManageDAO.selectHpcmDetail", vo);

    }

    /**
     * 도움말 글 목록을 조회한다.
     * @return 글 목록
     */
    public List<?> selectHpcmList(HpcmManageDefaultVO searchVO) throws Exception {

        return list("HpcmManageDAO.selectHpcmList", searchVO);

    }

    /**
     * 도움말 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    public int selectHpcmListTotCnt(HpcmManageDefaultVO searchVO) {

        return (Integer)selectOne("HpcmManageDAO.selectHpcmListTotCnt", searchVO);

    }

	/** 도움말 글을 등록한다. */
    public void insertHpcmCn(HpcmManageVO vo) throws Exception {

        insert("HpcmManageDAO.insertHpcmCn", vo);

    }

	/** 도움말 글을 수정한다. */
    public void updateHpcmCn(HpcmManageVO vo) throws Exception {

        update("HpcmManageDAO.updateHpcmCn", vo);

    }

	/** 도움말 글을 삭제한다. */
    public void deleteHpcmCn(HpcmManageVO vo) throws Exception {

        delete("HpcmManageDAO.deleteHpcmCn", vo);

    }

}
