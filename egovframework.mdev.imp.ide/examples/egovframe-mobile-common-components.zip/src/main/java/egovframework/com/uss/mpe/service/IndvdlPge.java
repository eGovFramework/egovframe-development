package egovframework.com.uss.mpe.service;

import egovframework.com.cmm.ComDefaultVO;

/** 마이페이지에 대한 model 클래스를 정의한다. / 마이페이지의 컨텐츠아이디, 컨텐츠 명, 컨텐츠 URL, 컨텐츠 사용 여부 항목을 관리한다. */
public class IndvdlPge extends ComDefaultVO{
	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** 순번 */
	private int rownum;
	/** 사용자 아이디 */
	private String userId;
	/** 컨텐츠 아이디 */
	private String cntntsId;
	/** 컨텐츠 명 */
	private String cntntsNm;
	/** 컨텐츠 URL */
	private String cntntsLinkUrl;
	/** 컨텐츠 상세보기 URL */
	private String cntcUrl;
	/** 컨텐츠 설명 */
	private String cntntsDc;
	/** 컨텐츠 사용 여부 */
	private String cntntsUseAt;
	public int getRownum() {
		return rownum;
	}
	public void setRownum(int rownum) {
		this.rownum = rownum;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCntntsId() {
		return cntntsId;
	}
	public void setCntntsId(String cntntsId) {
		this.cntntsId = cntntsId;
	}
	public String getCntntsNm() {
		return cntntsNm;
	}
	public void setCntntsNm(String cntntsNm) {
		this.cntntsNm = cntntsNm;
	}
	public String getCntntsLinkUrl() {
		return cntntsLinkUrl;
	}
	public void setCntntsLinkUrl(String cntntsLinkUrl) {
		this.cntntsLinkUrl = cntntsLinkUrl;
	}
	public String getCntcUrl() {
		return cntcUrl;
	}
	public void setCntcUrl(String cntcUrl) {
		this.cntcUrl = cntcUrl;
	}
	public String getCntntsDc() {
		return cntntsDc;
	}
	public void setCntntsDc(String cntntsDc) {
		this.cntntsDc = cntntsDc;
	}
	public String getCntntsUseAt() {
		return cntntsUseAt;
	}
	public void setCntntsUseAt(String cntntsUseAt) {
		this.cntntsUseAt = cntntsUseAt;
	}
}
