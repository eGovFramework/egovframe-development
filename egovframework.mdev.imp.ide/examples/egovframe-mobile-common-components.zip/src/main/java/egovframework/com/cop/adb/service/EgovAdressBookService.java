package egovframework.com.cop.adb.service;

import java.util.Map;

/** 주소록정보를 관리하기 위한 서비스 인터페이스 클래스 */
public interface EgovAdressBookService {

    /**
     * 주소록 목록을 조회한다.
     * @return  Map<String, Object>
     */
    public Map<String, Object> selectAdressBookList(AdressBookVO adressBookVO) throws Exception;

    /** 주소록 정보를 조회한다. */
    public AdressBookVO selectAdressBook(AdressBookVO adressBookVO) throws Exception;

    /** 주소록 정보를 삭제한다. */
    public void deleteAdressBook(AdressBook adressBook) throws Exception;

    /**
     * 사용자 목록을 조회한다.
     * @return Map<String, Object>
     */
    public Map<String, Object> selectManList(AdressBookUserVO adressBookUserVO) throws Exception;

    /**
     * 명함 목록을 조회한다.
     * @return Map<String, Object>
     */
    public Map<String, Object> selectCardList(AdressBookUserVO adressBookUserVO) throws Exception;

    /** 주소록 정보를 등록한다. */
    public void insertAdressBook(AdressBookVO adbkVO) throws Exception;

    /** 주소록 정보를 수정한다. */
    public void updateAdressBook(AdressBookVO adressBookVO) throws Exception;

    /** 주소록 구성원 정보를 불러온다. */
    public AdressBookUser selectAdbkUser(String id) throws Exception;

}
