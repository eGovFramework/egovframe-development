package egovframework.com.cop.smt.dsm.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cop.smt.dsm.service.DiaryManageVO;
import egovframework.com.cop.smt.dsm.service.EgovDiaryManageService;

import jakarta.annotation.Resource;

/** 일지관리를 처리하는 ServiceImpl Class 구현 */
@Service("egovDiaryManageService")
public class EgovDiaryManageServiceImpl extends EgovAbstractServiceImpl implements EgovDiaryManageService{

	@Resource(name="diaryManageDao")
	private DiaryManageDao dao;

	@Resource(name="diaryManageIdGnrService")
	private EgovIdGnrService idgenService;

    /** 일지관리 목록를(을) 조회한다. */
	@Override
	public List<?> selectDiaryManageList(ComDefaultVO searchVO) throws Exception{
		return dao.selectDiaryManageList(searchVO);
	}

    /** 일지관리를(을) 상세조회 한다. */
	@Override
	public DiaryManageVO selectDiaryManageDetail(DiaryManageVO diaryManageVO) throws Exception{
		return dao.selectDiaryManageDetail(diaryManageVO);
	}

    /** 일지관리를(을) 목록 전체 건수를(을) 조회한다. */
	@Override
	public int selectDiaryManageListCnt(ComDefaultVO searchVO) throws Exception{
		return dao.selectDiaryManageListCnt(searchVO);
	}

    /** 일지관리를(을) 등록한다. */
	@Override
	public void insertDiaryManage(DiaryManageVO diaryManageVO) throws Exception {
		String sMakeId = idgenService.getNextStringId();

		diaryManageVO.setDiaryId(sMakeId);

		dao.insertDiaryManage(diaryManageVO);
	}

    /** 일지관리를(을) 수정한다. */
	@Override
	public void updateDiaryManage(DiaryManageVO diaryManageVO) throws Exception{
		dao.updateDiaryManage(diaryManageVO);
	}

    /** 일지관리를(을) 삭제한다. */
	@Override
	public void deleteDiaryManage(DiaryManageVO diaryManageVO) throws Exception{
		dao.deleteDiaryManage(diaryManageVO);
	}
}
