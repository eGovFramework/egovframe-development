package egovframework.com.cop.cmy.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

//import com.sun.star.uno.Exception;	불필요한 파일 주석처리

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.cmy.service.CommunityUser;
import egovframework.com.cop.cmy.service.CommunityVO;

/** 커뮤니티 정보를 관리하기 위한 데이터 접근 클래스 */
@Repository("CommunityManageDAO")
public class CommunityManageDAO extends EgovComAbstractDAO {

    /** 커뮤니티 게사판 사용정보 목록을 조회한다. */
    @SuppressWarnings("unchecked")
    public List<CommunityVO> selectCommunityBBSUseInf(CommunityVO cmmntyVO) throws Exception {
	return (List<CommunityVO>) list("CommunityManageDAO.selectCommunityBBSUseInf", cmmntyVO);
    }

    /** 커뮤니티에 대한 상세정보를 조회한다. */
    public CommunityVO selectCommunityInf(CommunityVO cmmntyVO) throws Exception {
	return (CommunityVO)selectOne("CommunityManageDAO.selectCommunityInf", cmmntyVO);
    }

    /** 포트릿을 위한 커뮤니티 정보 목록 정보를 조회한다. */
    @SuppressWarnings("unchecked")
    public List<CommunityVO> selectCmmntyListPortlet(CommunityVO cmmntyVO) throws Exception {
	return (List<CommunityVO>) list("CommunityManageDAO.selectCmmntyListPortlet", cmmntyVO);
    }

    /** 커뮤니티용 템플릿 경로명을 조회한다. */
    public String selectCmmntyTemplat(CommunityVO cmmntyVO) throws Exception {
	return (String)selectOne("CommunityManageDAO.selectCmmntyTmplat", cmmntyVO);
    }

    /** 커뮤니티 사용여부를 조회한다. */
    public int checkExistUser(CommunityUser cmmntyUser) throws Exception {
	return (Integer)selectOne("CommunityManageDAO.checkExistUser", cmmntyUser);
    }

    /** 커뮤니티에 대한 특정 사용자 정보를 조회한다. */
    public CommunityUser selectSingleCommunityUserInf(CommunityUser cmmntyUser) throws Exception {
	return (CommunityUser)selectOne("CommunityManageDAO.selectSingleCommunityUserInf", cmmntyUser);
    }

    /** 커뮤니티에 대한 관리자 정보를 조회한다. */
    @SuppressWarnings("unchecked")
    public List<CommunityUser> selectCommunityManagerInfs(CommunityVO cmmnty) throws Exception {
	return (List<CommunityUser>) list("CommunityManageDAO.selectCommunityManagerInf", cmmnty);
    }
}
