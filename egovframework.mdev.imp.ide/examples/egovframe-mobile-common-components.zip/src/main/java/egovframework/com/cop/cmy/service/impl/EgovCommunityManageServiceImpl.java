package egovframework.com.cop.cmy.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import egovframework.com.cop.bbs.service.BoardMaster;
import egovframework.com.cop.bbs.service.EgovBBSAttributeManageService;
import egovframework.com.cop.cmy.service.Community;
import egovframework.com.cop.cmy.service.CommunityUser;
import egovframework.com.cop.cmy.service.CommunityVO;
import egovframework.com.cop.cmy.service.EgovCmyBBSUseInfoManageService;
import egovframework.com.cop.cmy.service.EgovCommunityManageService;

import jakarta.annotation.Resource;

/** 커뮤니티 정보를 관리하기 위한 서비스 구현 클래스 */
@Service("EgovCommunityManageService")
public class EgovCommunityManageServiceImpl extends EgovAbstractServiceImpl implements EgovCommunityManageService {

    @Resource(name = "EgovBBSAttributeManageService")
    private EgovBBSAttributeManageService bbsAttrbService;

    @Resource(name = "EgovCmyBBSUseInfoManageService")
    private EgovCmyBBSUseInfoManageService bbsUseService;

    @Resource(name = "CommunityManageDAO")
    private CommunityManageDAO cmmntyDAO;

    @Resource(name = "egovCmmntyIdGnrService")
    private EgovIdGnrService idgenService;

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovCommunityManageServiceImpl.class);

    /** 커뮤니티용 게사판 정보를 생성한다. */
    private List<BoardMaster> makeBdMstrListforCmmnty(Community cmmnty) {
	BoardMaster bdMstr;
	ArrayList<BoardMaster> result = new ArrayList<BoardMaster>();

	for (int i = 0; i < 5; i++) {
	    bdMstr = new BoardMaster();

	    bdMstr.setFrstRegisterId(cmmnty.getFrstRegisterId());
	    bdMstr.setUseAt("Y");
	    bdMstr.setBbsUseFlag("Y");
	    bdMstr.setTrgetId(cmmnty.getCmmntyId());
	    bdMstr.setRegistSeCode("REGC06");

	    if (i == 0) {
		bdMstr.setBbsTyCode("BBST04");
		bdMstr.setReplyPosblAt("N");
		bdMstr.setFileAtchPosblAt("N");
		bdMstr.setBbsAttrbCode("BBSA03");
		bdMstr.setBbsNm("방명록");
	    } else if (i == 1) {
		bdMstr.setBbsTyCode("BBST03");
		bdMstr.setReplyPosblAt("N");
		bdMstr.setFileAtchPosblAt("Y");
		bdMstr.setPosblAtchFileNumber(3);
		bdMstr.setBbsAttrbCode("BBSA01");
		bdMstr.setBbsNm("공지게시판");
	    } else if (i == 3) {
		bdMstr.setBbsTyCode("BBST01");
		bdMstr.setReplyPosblAt("Y");
		bdMstr.setFileAtchPosblAt("N");
		bdMstr.setBbsAttrbCode("BBSA03");
		bdMstr.setBbsNm("자유게시판");
	    } else if (i == 4) {
		bdMstr.setBbsTyCode("BBST01");
		bdMstr.setReplyPosblAt("N");
		bdMstr.setFileAtchPosblAt("Y");
		bdMstr.setPosblAtchFileNumber(5);
		bdMstr.setBbsAttrbCode("BBSA03");
		bdMstr.setBbsNm("자료실");
	    } else {
		bdMstr.setBbsTyCode("BBST01");
		bdMstr.setReplyPosblAt("N");
		bdMstr.setFileAtchPosblAt("Y");
		bdMstr.setPosblAtchFileNumber(5);
		bdMstr.setBbsAttrbCode("BBSA02");
		bdMstr.setBbsNm("갤러리");
	    }

	    bdMstr.setBbsIntrcn(cmmnty.getCmmntyNm() + " - " + bdMstr.getBbsNm());

	    result.add(bdMstr);
	}

	return result;
    }

	/** 커뮤니티 사용자 정보를 확인한다. */
    public String checkCommunityUserInf(CommunityUser cmmntyUser) throws Exception {
	// 회원가입 승인처리 적용시 기존 insertCommunityUserInf 대신 사용자 확인만 확인

	//cmmntyId
	CommunityVO vo = new CommunityVO();
	vo.setCmmntyId(cmmntyUser.getCmmntyId());

	if (cmmntyDAO.checkExistUser(cmmntyUser) == 0) {
	    return "";
	} else {
	    return "EXIST";
	}
    }

	/** 커뮤니티에 대한 특정 사용자 정보를 조회한다. */
    public Map<String, Object> selectCommunityInf(CommunityVO cmmntyVO) throws Exception {

	CommunityVO vo = cmmntyDAO.selectCommunityInf(cmmntyVO);

	List<CommunityVO> result = cmmntyDAO.selectCommunityBBSUseInf(cmmntyVO);

	CommunityUser cmmntyUser = new CommunityUser();

	cmmntyUser.setCmmntyId(cmmntyVO.getCmmntyId());
	cmmntyUser.setEmplyrId(cmmntyVO.getEmplyrId());

	cmmntyUser = cmmntyDAO.selectSingleCommunityUserInf(cmmntyUser);

	// 관리자 정보를 처리한다. (여러 명이 있을 수 있음 - DB 설계 문제상 문제)
	// 위의 처리는 cmmntyVO.getEmplyrId()가 ""이기 때문에 의미 없음..
	List<CommunityUser> managers = cmmntyDAO.selectCommunityManagerInfs(cmmntyVO);

	if (cmmntyUser == null) {
	    cmmntyUser = new CommunityUser();
	}
	if (managers.size() == 1) {
	    cmmntyUser.setEmplyrId(managers.get(0).getEmplyrId());
	    cmmntyUser.setEmplyrNm(managers.get(0).getEmplyrNm());
	} else if (managers.size() > 1) {
	    cmmntyUser.setEmplyrId(managers.get(0).getEmplyrId());
	    cmmntyUser.setEmplyrNm(managers.get(0).getEmplyrNm() + "외 " + (managers.size() - 1) + "명");
	} else {
		LOGGER.debug("No managers...");
	}

	Map<String, Object> map = new HashMap<String, Object>();

	map.put("resultList", result);
	map.put("cmmntyVO", vo);
	map.put("cmmntyUser", cmmntyUser);

	return map;
    }

    /** 커뮤니티 관리자 정보를 조회한다. */
    public CommunityUser selectManager(CommunityVO cmmntyVO) throws Exception {
	CommunityUser cmmntyUser = new CommunityUser();

	List<CommunityUser> managers = cmmntyDAO.selectCommunityManagerInfs(cmmntyVO);

	if (managers.size() == 1) {
	    cmmntyUser.setEmplyrId(managers.get(0).getEmplyrId());
	    cmmntyUser.setEmplyrNm(managers.get(0).getEmplyrNm());
	} else if (managers.size() > 1) {
	    cmmntyUser.setEmplyrId(managers.get(0).getEmplyrId());
	    cmmntyUser.setEmplyrNm(managers.get(0).getEmplyrNm() + "외 " + (managers.size() - 1) + "명");
	} else {
		LOGGER.debug("No managers...");
	}

	return cmmntyUser;
    }

    /** 포트릿을 위한 커뮤니티 정보 목록 정보를 조회한다. */
    public List<CommunityVO> selectCmmntyListPortlet(CommunityVO cmmntyVO) throws Exception {
	return cmmntyDAO.selectCmmntyListPortlet(cmmntyVO);
    }

    /** 커뮤니티용 템플릿 경로명을 조회한다. */
    public String selectCmmntyTemplat(CommunityVO cmmntyVO) throws Exception {
	return cmmntyDAO.selectCmmntyTemplat(cmmntyVO);
    }
}
