package egovframework.com.uss.umt.service;

import java.io.Serializable;

/** 가입약관VO클래스로서가입약관확인시 비지니스로직 처리용 항목을 구성한다. */
public class StplatVO implements Serializable {

	private static final long serialVersionUID = 3744005602026645L;

	/** 약관아이디 */
    private String useStplatId;

    /** 사용약관안내 */
    private String useStplatCn;

    /** 정보동의안내 */
    private String infoProvdAgeCn;

	public String getUseStplatId() {
		return useStplatId;
	}

	public void setUseStplatId(String useStplatId) {
		this.useStplatId = useStplatId;
	}

	public String getUseStplatCn() {
		return useStplatCn;
	}

	public void setUseStplatCn(String useStplatCn) {
		this.useStplatCn = useStplatCn;
	}

	public String getInfoProvdAgeCn() {
		return infoProvdAgeCn;
	}

	public void setInfoProvdAgeCn(String infoProvdAgeCn) {
		this.infoProvdAgeCn = infoProvdAgeCn;
	}

}
