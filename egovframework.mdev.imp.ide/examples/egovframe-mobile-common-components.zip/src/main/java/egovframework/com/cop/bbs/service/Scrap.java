package egovframework.com.cop.bbs.service;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

/** 스크랩 서비스 데이터 처리 모델 */
@SuppressWarnings("serial")
public class Scrap implements Serializable {
    /** 스크랩 ID */
    private String scrapId = "";

    /** 게시판 ID */
    private String bbsId = "";

    /** 게시물 번호 */
    private long nttId = 0L;

    /** 스크랩명 */
    @EgovNullCheck(message = "{valid.Scrap.scrapNm.required}")
    private String scrapNm = "";

    /** 사용 여부 */
    private String useAt = "";

    /** 유일 아이디 */
    private String uniqId = "";

    /** 최초등록자 아이디 */
    private String frstRegisterId = "";

    /** 최초 등록자명 */
    private String frstRegisterNm = "";

    /** 최초등록시점 */
    private String frstRegisterPnttm = "";

    /** 최종수정자 아이디 */
    private String lastUpdusrId = "";

    /** 최종수정시점 */
    private String lastUpdusrPnttm = "";

    public String getScrapId() {
        return scrapId;
    }

    public void setScrapId(String scrapId) {
        this.scrapId = scrapId;
    }

    public String getBbsId() {
        return bbsId;
    }

    public void setBbsId(String bbsId) {
        this.bbsId = bbsId;
    }

    public long getNttId() {
        return nttId;
    }

    public void setNttId(long nttId) {
        this.nttId = nttId;
    }

    public String getScrapNm() {
        return scrapNm;
    }

    public void setScrapNm(String scrapNm) {
        this.scrapNm = scrapNm;
    }

    public String getUseAt() {
        return useAt;
    }

    public void setUseAt(String useAt) {
        this.useAt = useAt;
    }

    public String getFrstRegisterId() {
        return frstRegisterId;
    }

    public void setFrstRegisterId(String frstRegisterId) {
        this.frstRegisterId = frstRegisterId;
    }

    public String getFrstRegisterNm() {
        return frstRegisterNm;
    }

    public void setFrstRegisterNm(String frstRegisterNm) {
        this.frstRegisterNm = frstRegisterNm;
    }

    public String getFrstRegisterPnttm() {
        return frstRegisterPnttm;
    }

    public void setFrstRegisterPnttm(String frstRegisterPnttm) {
        this.frstRegisterPnttm = frstRegisterPnttm;
    }

    public String getLastUpdusrId() {
        return lastUpdusrId;
    }

    public void setLastUpdusrId(String lastUpdusrId) {
        this.lastUpdusrId = lastUpdusrId;
    }

    public String getLastUpdusrPnttm() {
        return lastUpdusrPnttm;
    }

    public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
        this.lastUpdusrPnttm = lastUpdusrPnttm;
    }

    public String getUniqId() {
        return uniqId;
    }

    public void setUniqId(String uniqId) {
        this.uniqId = uniqId;
    }

    /** toString 메소드를 대치한다. */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}
