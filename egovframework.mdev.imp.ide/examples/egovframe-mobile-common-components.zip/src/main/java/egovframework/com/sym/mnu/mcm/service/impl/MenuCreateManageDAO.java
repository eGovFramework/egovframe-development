package egovframework.com.sym.mnu.mcm.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.sym.mnu.mcm.service.MenuCreatVO;
import egovframework.com.sym.mnu.mcm.service.MenuSiteMapVO;

/** 메뉴생성, 사이트맵 생성에 대한 DAO 클래스를 정의한다. * */
@Repository("menuCreateManageDAO")
public class MenuCreateManageDAO extends EgovComAbstractDAO{

	/** ID 존재여부를 조회 */
	public int selectUsrByPk(ComDefaultVO vo) throws Exception{
		return (Integer)selectOne("menuManageDAO.selectUsrByPk", vo);
	}

	/** ID에 대한 권한코드를 조회 */
	public MenuCreatVO selectAuthorByUsr(ComDefaultVO vo) throws Exception{
		return (MenuCreatVO)selectOne("menuManageDAO.selectAuthorByUsr", vo);
	}

	/** 메뉴생성관리 내역을 조회 */
	public List<?> selectMenuCreatManagList(ComDefaultVO vo) throws Exception{
		return list("menuManageDAO.selectMenuCreatManageList_D", vo);
	}

	/** 메뉴생성관리 총건수를 조회한다. */
    public int selectMenuCreatManagTotCnt(ComDefaultVO vo) {
        return (Integer)selectOne("menuManageDAO.selectMenuCreatManageTotCnt_S", vo);
    }

    /** ******* 메뉴 생성 관리 ************** */
	/** 메뉴생성 내역을 조회 */
	public List<?> selectMenuCreatList(MenuCreatVO vo) throws Exception{
		return list("menuManageDAO.selectMenuCreatList_D", vo);
	}

	/** 메뉴생성내역 등록 */
	public void insertMenuCreat(MenuCreatVO vo){
		insert("menuManageDAO.insertMenuCreat_S", vo);
	}

	/** 메뉴생성 사이트맵 내용 조회 */
	public List<?> selectMenuCreatSiteMapList(MenuSiteMapVO vo) throws Exception{
		return list("menuManageDAO.selectMenuCreatSiteMapList_D", vo);
	}

	/** 사이트맵 등록 */
	public void creatSiteMap(MenuSiteMapVO vo){
		insert("menuManageDAO.insertSiteMap_S", vo);
	}

	/** 사용자 권한별 사이트맵 내용 조회 */
	public List<?> selectSiteMapByUser(MenuSiteMapVO vo) throws Exception{
		return list("menuManageDAO.selectSiteMapByUser", vo);
	}

	/** 메뉴생성내역 존재여부 조회한다. */
    public int selectMenuCreatCnt(MenuCreatVO vo) {
        return (Integer)selectOne("menuManageDAO.selectMenuCreatCnt_S", vo);
    }

	/** 메뉴생성내역 수정 */
	public void updateMenuCreat(MenuCreatVO vo){
		update("menuManageDAO.updateMenuCreat_S", vo);
	}

	/** 메뉴생성내역 삭제 */
	public void deleteMenuCreat(MenuCreatVO vo){
		delete("menuManageDAO.deleteMenuCreat_S", vo);
	}

	/** 사이트맵 존재여부 조회한다. */
    public int selectSiteMapCnt(MenuSiteMapVO vo) {
        return (Integer)selectOne("menuManageDAO.selectSiteMapCnt_S", vo);
    }

}
