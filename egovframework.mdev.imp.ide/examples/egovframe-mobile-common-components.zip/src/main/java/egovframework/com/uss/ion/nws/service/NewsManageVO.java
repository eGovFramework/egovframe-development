package egovframework.com.uss.ion.nws.service;

/** 뉴스정보를 처리하는 VO 클래스 */
public class NewsManageVO extends NewsManageDefaultVO {

    private static final long serialVersionUID = 1L;

    /** 뉴스 ID */
    private String newsId;

    /** 뉴스제목 */
    private String newsSj;

    /** 뉴스내용 */
    private String newsCn;

    /** 뉴스출처 */
    private String newsOrigin;

    /** 게시일자 */
    private String ntceDe;

    /** 첨부파일ID */
    private String atchFileId;

    /** 최초등록시점 */
    private String frstRegisterPnttm;

    /** 최초등록자ID */
    private String frstRegisterId;

    /** 최종수정시점 */
    private String lastUpdusrPnttm;

    /** 최종수정자ID */
    private String lastUpdusrId;

	public String getNewsId() {
		return newsId;
	}

	public void setNewsId(String newsId) {
		this.newsId = newsId;
	}

	public String getNewsSj() {
		return newsSj;
	}

	public void setNewsSj(String newsSj) {
		this.newsSj = newsSj;
	}

	public String getNewsCn() {
		return newsCn;
	}

	public void setNewsCn(String newsCn) {
		this.newsCn = newsCn;
	}

	public String getNewsOrigin() {
		return newsOrigin;
	}

	public void setNewsOrigin(String newsOrigin) {
		this.newsOrigin = newsOrigin;
	}

	public String getNtceDe() {
		return ntceDe;
	}

	public void setNtceDe(String ntceDe) {
		this.ntceDe = ntceDe;
	}

	public String getAtchFileId() {
		return atchFileId;
	}

	public void setAtchFileId(String atchFileId) {
		this.atchFileId = atchFileId;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

}
