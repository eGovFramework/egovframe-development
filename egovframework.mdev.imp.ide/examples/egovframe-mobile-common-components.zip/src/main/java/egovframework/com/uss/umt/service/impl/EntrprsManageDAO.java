package egovframework.com.uss.umt.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/** 기업회원관리에 관한 데이터 접근 클래스를 정의한다. */
@Repository("entrprsManageDAO")
public class EntrprsManageDAO extends EgovComAbstractDAO{

    /**
     * 약관정보를 조회
     * @param stplatId 기업회원 약관아이디
     */
    public List<?> selectStplat(String stplatId) {
    	return list("entrprsManageDAO.selectStplat_S", stplatId);
    }
}
