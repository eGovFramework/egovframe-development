package egovframework.com.cop.scp.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.bbs.service.Scrap;
import egovframework.com.cop.bbs.service.ScrapVO;

/** 스크랩관리를 위한 데이터 접근 클래스 */
@Repository("BBSScrapDAO")
public class BBSScrapDAO extends EgovComAbstractDAO {

    /** 스크랩에 대한 목록을 조회 한다. */
    @SuppressWarnings("unchecked")
    public List<ScrapVO> selectScrapList(ScrapVO scrapVO) throws Exception {
	return (List<ScrapVO>) list("BBSScrapDAO.selectScrapList", scrapVO);
    }

    /** 스크랩에 대한 목록 건수를 조회 한다. */
    public int selectScrapListCnt(ScrapVO scrapVO) throws Exception {
	return (Integer)selectOne("BBSScrapDAO.selectScrapListCnt", scrapVO);
    }

    /** 스크랩을 등록한다. */
    public void insertScrap(Scrap scrap) throws Exception {
	insert("BBSScrapDAO.insertScrap", scrap);
    }

    /** 스크랩을 삭제한다. */
    public void deleteScrap(ScrapVO scrapVO) throws Exception {
	update("BBSScrapDAO.deleteScrap", scrapVO);
    }

    /** 스크랩에 대한 내용을 조회한다. */
    public Scrap selectScrap(ScrapVO scrapVO) throws Exception {
	return (Scrap)selectOne("BBSScrapDAO.selectScrap", scrapVO);
    }

    /** 스크랩에 대한 내용을 수정한다. */
    public void updateScrap(Scrap scrap) throws Exception {
	insert("BBSScrapDAO.updateScrap", scrap);
    }
}
