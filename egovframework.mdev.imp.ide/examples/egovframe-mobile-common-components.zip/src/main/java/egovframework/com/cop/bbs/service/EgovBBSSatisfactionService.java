package egovframework.com.cop.bbs.service;

/** 만족도조사를 위한 서비스 인터페이스 클래스 */
public interface EgovBBSSatisfactionService {
    /** 만족도조사 사용 가능 여부를 확인한다. */
    public boolean canUseSatisfaction(String bbsId) throws Exception;
}
