package egovframework.com.uss.olh.omm.service;

import java.io.Serializable;

/** 온라인메뉴얼 VO Class 구현 */
public class OnlineManual implements Serializable {

	private static final long serialVersionUID = -7024282928339275971L;

	/** 온라인메뉴얼 아이디 */
    private String onlineMnlId;

    /** 온라인메뉴얼 명 */
    private String onlineMnlNm;

    /** 온라인메뉴얼 구분코드 */
    private String onlineMnlSeCode;

    /** 온라인메뉴얼 정의 */
    private String onlineMnlDf;

    /** 온라인메뉴얼 설명 */
    private String onlineMnlDc;

    /** 최초등록시점 */
    private String frstRegisterPnttm;

    /** 최초등록아이디 */
    private String frstRegisterId;

    private String lastUpdusrPnttm;

    /** 최종수정자 아이디 */
    private String lastUpdusrId;

    /** 컨트롤 명령어 */
    private String cmd;

    public String getOnlineMnlId() {
        return onlineMnlId;
    }

    public void setOnlineMnlId(String onlineMnlId) {
        this.onlineMnlId = onlineMnlId;
    }

    public String getOnlineMnlNm() {
        return onlineMnlNm;
    }

    public void setOnlineMnlNm(String onlineMnlNm) {
        this.onlineMnlNm = onlineMnlNm;
    }

    public String getOnlineMnlSeCode() {
        return onlineMnlSeCode;
    }

    public void setOnlineMnlSeCode(String onlineMnlSeCode) {
        this.onlineMnlSeCode = onlineMnlSeCode;
    }

    public String getOnlineMnlDf() {
        return onlineMnlDf;
    }

    public void setOnlineMnlDf(String onlineMnlDf) {
        this.onlineMnlDf = onlineMnlDf;
    }

    public String getOnlineMnlDc() {
        return onlineMnlDc;
    }

    public void setOnlineMnlDc(String onlineMnlDc) {
        this.onlineMnlDc = onlineMnlDc;
    }

    public String getFrstRegisterPnttm() {
        return frstRegisterPnttm;
    }

    public void setFrstRegisterPnttm(String frstRegisterPnttm) {
        this.frstRegisterPnttm = frstRegisterPnttm;
    }

    public String getFrstRegisterId() {
        return frstRegisterId;
    }

    public void setFrstRegisterId(String frstRegisterId) {
        this.frstRegisterId = frstRegisterId;
    }

    public String getLastUpdusrPnttm() {
        return lastUpdusrPnttm;
    }

    public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
        this.lastUpdusrPnttm = lastUpdusrPnttm;
    }

    public String getLastUpdusrId() {
        return lastUpdusrId;
    }

    public void setLastUpdusrId(String lastUpdusrId) {
        this.lastUpdusrId = lastUpdusrId;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

}
