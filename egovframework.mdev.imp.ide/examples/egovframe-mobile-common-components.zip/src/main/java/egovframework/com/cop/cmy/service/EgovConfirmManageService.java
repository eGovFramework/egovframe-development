package egovframework.com.cop.cmy.service;

/** 승인정보를 관리하기 위한 서비스 인테페이스 클래스 */
public interface EgovConfirmManageService {

    /** 승인(탈퇴)요청에 대한 등록을 처리한다. */
    public void insertConfirmRequest(ConfirmHistory history) throws Exception;

    /** 현재 승인 요청된 건수를 조회한다. */
    public int countConfirmRequest(ConfirmHistory history) throws Exception;
}
