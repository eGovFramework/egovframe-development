package egovframework.com.uss.olp.opp.service;

import java.util.List;

import egovframework.com.cmm.ComDefaultVO;

/** 온라인POLL참여를 처리하는 Service Class 구현 */
public interface EgovOnlinePollPartcptnService {

    /** 온라인POLL관리를(을) 목록을 한다. */
    public List<?> selectOnlinePollManageList(ComDefaultVO searchVO) throws Exception;

    /** 온라인POLL관리를(을) 목록 전체 건수를(을) 조회한다. */
    public int selectOnlinePollManageListCnt(ComDefaultVO searchVO) throws Exception;

    /** 온라인POLL관리를(을) 상세조회 한다. */
    public List<?> selectOnlinePollManageDetail(OnlinePollPartcptn onlinePollPartcptn) throws Exception;

    /** 온라인POLL항목를(을) 상세조회 한다. */
    public List<?> selectOnlinePollItemDetail( OnlinePollPartcptn onlinePollPartcptn) throws Exception;

    /** 온라인POLL참여를(을) 등록한다. */
    public void insertOnlinePollResult(OnlinePollPartcptn onlinePollPartcptn)throws Exception;

    /** 온라인POLL참여 통계를 조회한다. */
    public List<?> selectOnlinePollManageStatistics( OnlinePollPartcptn onlinePollPartcptn) throws Exception;

    /** 온라인POLL참여 여부를 조회한다. */
    public int selectOnlinePollResult( OnlinePollPartcptn onlinePollPartcptn) throws Exception;
}
