package egovframework.com.uss.olh.faq.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.uss.olh.faq.service.EgovFaqManageService;
import egovframework.com.uss.olh.faq.service.FaqManageDefaultVO;
import egovframework.com.uss.olh.faq.service.FaqManageVO;

import jakarta.annotation.Resource;

/** FAQ를 처리하는 비즈니스 구현 클래스 */
@Service("FaqManageService")
public class EgovFaqManageServiceImpl extends EgovAbstractServiceImpl implements
        EgovFaqManageService {

    @Resource(name="FaqManageDAO")
    private FaqManageDAO faqManageDAO;

    /** ID Generation */
	@Resource(name="egovFaqManageIdGnrService")
	private EgovIdGnrService idgenService;

    /**
     * FAQ 글을 조회한다.
     * @return 조회한 글
     */
    @Override
	public FaqManageVO selectFaqListDetail(FaqManageVO vo) throws Exception {
        FaqManageVO resultVO = faqManageDAO.selectFaqListDetail(vo);
        if (resultVO == null)
            throw processException("info.nodata.msg");
        return resultVO;
    }

	/** FAQ 조회수를 수정한다. */
    @Override
	public void updateFaqInqireCo(FaqManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	faqManageDAO.updateFaqInqireCo(vo);
    }

    /**
     * FAQ 글 목록을 조회한다.
     * @return 글 목록
     */
    @Override
	public List<?> selectFaqList(FaqManageDefaultVO searchVO) throws Exception {
        return faqManageDAO.selectFaqList(searchVO);
    }

    /**
     * FAQ 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    @Override
	public int selectFaqListTotCnt(FaqManageDefaultVO searchVO) {
		return faqManageDAO.selectFaqListTotCnt(searchVO);
	}

	/** FAQ 글을 등록한다. */
    @Override
	public void insertFaqCn(FaqManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

		String	newsId = idgenService.getNextStringId();

		vo.setFaqId(newsId);

    	faqManageDAO.insertFaqCn(vo);
    }

	/** FAQ 글을 수정한다. */
    @Override
	public void updateFaqCn(FaqManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	faqManageDAO.updateFaqCn(vo);
    }

	/** FAQ 글을 삭제한다. */
    @Override
	public void deleteFaqCn(FaqManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	faqManageDAO.deleteFaqCn(vo);
    }

}
