package egovframework.com.uss.mpe.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.mpe.service.IndvdlPge;
import egovframework.com.uss.mpe.service.IndvdlPgeCntntsVO;
import egovframework.com.uss.mpe.service.IndvdlPgeVO;

/** 마이페이지에 대한 DAO를 정의한다. / 마이페이지 콘텐츠의 등록, 수정, 삭제, 조회, 반영확인 기능을 제공한다. */
@Repository("IndvdlPgeDAO")
public class IndvdlPgeDAO extends EgovComAbstractDAO {

	public IndvdlPgeDAO(){
	}
	private static final Logger LOGGER = LoggerFactory.getLogger(IndvdlPgeDAO.class);
	/**
	 * 기 등록된 마이페이지 정보를 조회한다.
	 * @return indvdlPgeVO - 마이페이지 VO
	 * @param indvdlPgeVO public IndvdlPgeVO selectIndvdlpgeResult(IndvdlPgeVO indvdlPgeVO){ return (IndvdlPgeVO)selectOne("IndvdlPgeDAO.selectIndvdlpgeResult", indvdlPgeVO); }
	 */

	/**
	 * 등록된 마이페이지 컨텐츠의 상세정보를 조회한다.
	 * @return indvdlPgeCntntsVO - 마이페이지 콘텐츠 Vo
	 */
	public IndvdlPge selectIndvdlpgeCntnts(IndvdlPge indvdlPge){
		return (IndvdlPge)selectOne("IndvdlPgeDAO.selectIndvdlpgeCntnts", indvdlPge);
	}

	/** 마이페이지에 컨텐츠를 추가하기 위해 등록된 마이페이지 컨텐츠 목록을 조회한다. */
	@SuppressWarnings("unchecked")
	public List<IndvdlPgeCntntsVO> addIndvdlpgeCntntsList(IndvdlPgeCntntsVO indvdlPgeCntntsVO){
		return (List<IndvdlPgeCntntsVO>) list("IndvdlPgeDAO.addIndvdlpgeCntntsList", indvdlPgeCntntsVO);
	}

	/** 마이페이지에 컨텐츠를 바로 추가한다. */
	public boolean addIndvdlpgeCntnts(IndvdlPgeCntntsVO indvdlPgeCntntsVO){
		try{
			insert("IndvdlPgeDAO.addIndvdlpgeCntnts", indvdlPgeCntntsVO);
			} catch(IllegalArgumentException e) {
				LOGGER.error("[IllegalArgumentException] Try/Catch...usingParameters Runing : "+ e.getMessage());
				return false;
			}catch(Exception e){
				LOGGER.error("["+e.getClass()+"] Try/Catch...Runing : " + e.getMessage());
				return false;
			}
			return true;
	}

	/** 마이페이지에서 컨텐츠를 바로 삭제한다. */
	public boolean delIndvdlpgeCntnts(IndvdlPgeCntntsVO indvdlPgeCntntsVO){
		try{
			delete("IndvdlPgeDAO.delIndvdlpgeCntnts", indvdlPgeCntntsVO);
			} catch(IllegalArgumentException e) {
				LOGGER.error("[IllegalArgumentException] Try/Catch...usingParameters Runing : "+ e.getMessage());
				return false;
			}catch(Exception e){
				LOGGER.error("["+e.getClass()+"] Try/Catch...Runing : " + e.getMessage());
				return false;
			}
			return true;
	}

	/**
	 * 마이페이지 컨텐츠가 등록된 개수를 조회한다.
	 * @return int - 마이페이지 컨텐츠 개수
	 */
	public int selectIndvdlpgeAddCntntsListTotCnt(IndvdlPgeCntntsVO indvdlPgeCntntsVO){
		return (Integer)selectOne("IndvdlPgeDAO.selectIndvdlpgeAddListTotCnt", indvdlPgeCntntsVO);
	}

	/**
	 * 기 등록된 마이페이지 정보를 조회한다.
	 * @return indvdlPgeVO - 마이페이지 VO
	 */
	@SuppressWarnings("unchecked")
	public List<IndvdlPgeVO> selectIndvdlpgeResultDetail(IndvdlPgeVO indvdlPgeVO) throws Exception {
		return (List<IndvdlPgeVO>) list("IndvdlPgeDAO.selectIndvdlpgeResultDetail", indvdlPgeVO);
	}

	/** 기 등록된 마이페이지 정보의 카운트를 조회한다. */
	public int selectIndvdlpgeResultDetailTotCnt(IndvdlPgeVO indvdlPgeVO) throws Exception {
		return (Integer)selectOne("IndvdlPgeDAO.selectIndvdlpgeResultDetailTotCnt", indvdlPgeVO);
	}

}
