package egovframework.com.cmm;

import org.egovframe.rte.fdl.cmmn.exception.handler.ExceptionHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** 공통서비스의 exception 처리 클래스 */
public class EgovComExcepHndlr implements ExceptionHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovComExcepHndlr.class);

    /** 발생된 Exception을 처리한다. */
    public void occur(Exception ex, String packageName) {
	try {
		LOGGER.error(packageName, ex);
	} catch(IllegalArgumentException e) {
	    LOGGER.error("[IllegalArgumentException] Try/Catch...usingParameters Runing : "+ e.getMessage());
	} catch (Exception e) {
		LOGGER.error("["+e.getClass()+"] Try/Catch...Runing : " + e.getMessage());
	}
    }
}
