package egovframework.com.uss.ion.rec.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.uss.ion.rec.service.EgovRecomendSiteManageService;
import egovframework.com.uss.ion.rec.service.RecomendSiteManageDefaultVO;
import egovframework.com.uss.ion.rec.service.RecomendSiteManageVO;

import jakarta.annotation.Resource;

/** 추천사이트정보를 처리하는 구현 클래스 */
@Service("RecomendSiteManageService")
public class EgovRecomendSiteManageServiceImpl extends EgovAbstractServiceImpl implements
        EgovRecomendSiteManageService {

    @Resource(name="RecomendSiteManageDAO")
    private RecomendSiteManageDAO recomendSiteManageDAO;

    /** ID Generation */
	@Resource(name="egovRecomendSiteManageIdGnrService")
	private EgovIdGnrService idgenService;

    /**
     * 추천사이트 상세조회를 한다.
     * @return 조회한 글
     */
    @Override
	public RecomendSiteManageVO selectRecomendSiteDetail(RecomendSiteManageVO vo) throws Exception {
        RecomendSiteManageVO resultVO = recomendSiteManageDAO.selectRecomendSiteDetail(vo);
        if (resultVO == null)
            throw processException("info.nodata.msg");
        return resultVO;
    }

    /**
     * 추천사이트 목록을 조회한다.
     * @return 글 목록
     */
    @Override
	public List<?> selectRecomendSiteList(RecomendSiteManageDefaultVO searchVO) throws Exception {
        return recomendSiteManageDAO.selectRecomendSiteList(searchVO);
    }

    /**
     * 추천사이트 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    @Override
	public int selectRecomendSiteListTotCnt(RecomendSiteManageDefaultVO searchVO) {
		return recomendSiteManageDAO.selectRecomendSiteListTotCnt(searchVO);
	}

	/** 추천사이트를 등록한다. */
    @Override
	public void insertRecomendSiteInfo(RecomendSiteManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

		String	recomendSiteId = idgenService.getNextStringId();

		vo.setRecomendSiteId(recomendSiteId);

    	recomendSiteManageDAO.insertRecomendSiteInfo(vo);
    }

	/** 추천사이트를 수정한다. */
    @Override
	public void updateRecomendSiteInfo(RecomendSiteManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	recomendSiteManageDAO.updateRecomendSiteInfo(vo);
    }

	/** 추천사이트를 삭제한다. */
    @Override
	public void deleteRecomendSiteInfo(RecomendSiteManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	recomendSiteManageDAO.deleteRecomendSiteInfo(vo);
    }

}
