package egovframework.com.uss.ion.nws.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.uss.ion.nws.service.EgovNewsManageService;
import egovframework.com.uss.ion.nws.service.NewsManageDefaultVO;
import egovframework.com.uss.ion.nws.service.NewsManageVO;

import jakarta.annotation.Resource;

/** 뉴스정보를 처리하는 비즈니스 구현 클래스 */
@Service("NewsManageService")
public class EgovNewsManageServiceImpl extends EgovAbstractServiceImpl implements
        EgovNewsManageService {

    @Resource(name="NewsManageDAO")
    private NewsManageDAO newsManageDAO;

    /** ID Generation */
	@Resource(name="egovNewsManageIdGnrService")
	private EgovIdGnrService idgenService;

    /**
     * 뉴스정보 상세조회한다.
     * @return 조회한 글
     */
    @Override
	public NewsManageVO selectNewsDetail(NewsManageVO vo) throws Exception {
        NewsManageVO resultVO = newsManageDAO.selectNewsDetail(vo);
        if (resultVO == null)
            throw processException("info.nodata.msg");
        return resultVO;
    }

    /**
     * 뉴스정보 목록을 조회한다.
     * @return 글 목록
     */
    @Override
	public List<?> selectNewsList(NewsManageDefaultVO searchVO) throws Exception {
        return newsManageDAO.selectNewsList(searchVO);
    }

    /**
     * 뉴스정보 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    @Override
	public int selectNewsListTotCnt(NewsManageDefaultVO searchVO) {
		return newsManageDAO.selectNewsListTotCnt(searchVO);
	}

	/** 뉴스정보를 등록한다. */
    @Override
	public void insertNewsInfo(NewsManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

		String	newsId = idgenService.getNextStringId();

		vo.setNewsId(newsId);

    	newsManageDAO.insertNewsInfo(vo);
    }

	/** 뉴스정보를 수정한다. */
    @Override
	public void updateNewsInfo(NewsManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	newsManageDAO.updateNewsInfo(vo);
    }

	/** 뉴스정보를 삭제한다. */
    @Override
	public void deleteNewsInfo(NewsManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	newsManageDAO.deleteNewsInfo(vo);
    }

}
