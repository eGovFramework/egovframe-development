package egovframework.com.cop.smt.sdm.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.smt.sdm.service.DeptSchdulManageVO;

/** 부서일정관리를 처리하는 Dao Class 구현 */
@Repository("deptSchdulManageDao")
public class DeptSchdulManageDao extends EgovComAbstractDAO {

    /** 부서일정 목록을 Map(map)형식으로 조회한다. */
	public List<?> selectDeptSchdulManageRetrieve(Map<?, ?> map) throws Exception{
		 return  list("DeptSchdulManage.selectDeptSchdulManageRetrieve", map);
	}

    /** 부서일정 목록을 조회한다. */
	public List<?> selectDeptSchdulManageList(ComDefaultVO searchVO) throws Exception{
		return list("DeptSchdulManage.selectDeptSchdulManage", searchVO);
	}

    /** 부서일정를(을) 상세조회 한다. */
	public List<?> selectDeptSchdulManageDetail(DeptSchdulManageVO deptSchdulManageVO) throws Exception{
		return list("DeptSchdulManage.selectDeptSchdulManageDetail", deptSchdulManageVO);
	}

    /** 부서일정를(을) 목록 전체 건수를(을) 조회한다. */
	public int selectDeptSchdulManageListCnt(ComDefaultVO searchVO) throws Exception{
		return (Integer)selectOne("DeptSchdulManage.selectDeptSchdulManageCnt", searchVO);
	}

    /** 부서일정를(을) 등록한다. */
	public void insertDeptSchdulManage(DeptSchdulManageVO deptSchdulManageVO) throws Exception{
		insert("DeptSchdulManage.insertDeptSchdulManage", deptSchdulManageVO);
	}

    /** 부서일정를(을) 수정한다. */
	public void updateDeptSchdulManage(DeptSchdulManageVO deptSchdulManageVO) throws Exception{
		insert("DeptSchdulManage.updateDeptSchdulManage", deptSchdulManageVO);
	}

    /** 부서일정를(을) 삭제한다. */
	public void deleteDeptSchdulManage(DeptSchdulManageVO deptSchdulManageVO) throws Exception{
		// 일지 삭제
		delete("DeptSchdulManage.deleteDiaryManage", deptSchdulManageVO);
		// 부서일정 삭제
		delete("DeptSchdulManage.deleteDeptSchdulManage", deptSchdulManageVO);
	}
}
