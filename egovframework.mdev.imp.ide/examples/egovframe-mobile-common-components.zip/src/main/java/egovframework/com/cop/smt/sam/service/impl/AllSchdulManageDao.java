package egovframework.com.cop.smt.sam.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/** 전체일정을 처리하는 Dao Class 구현 */
@Repository("allSchdulManageDao")
public class AllSchdulManageDao extends EgovComAbstractDAO {

    /** 전체일정 목록을 조회한다. */
	public List<?> selectAllSchdulManageeList(ComDefaultVO searchVO) throws Exception{
		return list("AllSchdulManage.selectIndvdlSchdulManage", searchVO);
	}

    /** 전체일정를(을) 목록 전체 건수를(을) 조회한다. */
	public int selectAllSchdulManageListCnt(ComDefaultVO searchVO) throws Exception{
		return (Integer)selectOne("AllSchdulManage.selectIndvdlSchdulManageCnt", searchVO);
	}
}
