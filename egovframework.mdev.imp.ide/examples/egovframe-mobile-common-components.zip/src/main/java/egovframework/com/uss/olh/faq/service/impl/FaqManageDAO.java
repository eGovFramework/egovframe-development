package egovframework.com.uss.olh.faq.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.olh.faq.service.FaqManageDefaultVO;
import egovframework.com.uss.olh.faq.service.FaqManageVO;

/** FAQ를 처리하는 DAO 클래스 */
@Repository("FaqManageDAO")
public class FaqManageDAO extends EgovComAbstractDAO {

    /**
     * FAQ 글 목록에 대한 상세내용을 조회한다.
     * @return 조회한 글
     */
    public FaqManageVO selectFaqListDetail(FaqManageVO vo) throws Exception {

        return (FaqManageVO) selectOne("FaqManageDAO.selectFaqListDetail", vo);

    }

	/** FAQ 조회수를 수정한다. */
    public void updateFaqInqireCo(FaqManageVO vo) throws Exception {

        update("FaqManageDAO.updateFaqInqireCo", vo);

    }

    /**
     * FAQ 글 목록을 조회한다.
     * @return 글 목록
     */
    public List<?> selectFaqList(FaqManageDefaultVO searchVO) throws Exception {

        return list("FaqManageDAO.selectFaqList", searchVO);

    }

    /**
     * FAQ 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    public int selectFaqListTotCnt(FaqManageDefaultVO searchVO) {

        return (Integer)selectOne("FaqManageDAO.selectFaqListTotCnt", searchVO);

    }

	/** FAQ 글을 등록한다. */
    public void insertFaqCn(FaqManageVO vo) throws Exception {

        insert("FaqManageDAO.insertFaqCn", vo);

    }

	/** FAQ 글을 수정한다. */
    public void updateFaqCn(FaqManageVO vo) throws Exception {

        update("FaqManageDAO.updateFaqCn", vo);

    }

	/** FAQ 글을 삭제한다. */
    public void deleteFaqCn(FaqManageVO vo) throws Exception {

        delete("FaqManageDAO.deleteFaqCn", vo);

    }

}
