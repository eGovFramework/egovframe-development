package egovframework.com.cop.com.service;

import java.util.Map;

/** 협업 기능에서 사용자 정보를 관리하기 위한 서비스 인터페이스 클래스 */
public interface EgovUserInfManageService {

	/** 사용자 정보에 대한 목록을 조회한다. */
    public Map<String, Object> selectUserList(UserInfVO userVO) throws Exception;
}
