package egovframework.com.uss.olp.qrm.service.impl;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.olp.qrm.service.QustnrRespondManageVO;

/** 설문응답자관리 Dao Class 구현 */
@Repository("qustnrRespondManageDao")
public class QustnrRespondManageDao extends EgovComAbstractDAO {

    /** 응답자정보를(을) 등록한다. */
	public void insertQustnrRespondManage(QustnrRespondManageVO qustnrRespondManageVO) throws Exception{
		insert("QustnrRespondManage.insertQustnrRespondManage", qustnrRespondManageVO);
	}

    /** 응답자정보를(을) 수정한다. */
	public void updateQustnrRespondManage(QustnrRespondManageVO qustnrRespondManageVO) throws Exception{
		insert("QustnrRespondManage.updateQustnrRespondManage", qustnrRespondManageVO);
	}

    /** 응답자정보를(을) 삭제한다. */
	public void deleteQustnrRespondManage(QustnrRespondManageVO qustnrRespondManageVO) throws Exception{
		insert("QustnrRespondManage.deleteQustnrRespondManage", qustnrRespondManageVO);
	}
}
