package egovframework.com.uss.umt.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/** 일반회원관리에 관한 데이터 접근 클래스를 정의한다. */
@Repository("mberManageDAO")
public class MberManageDAO extends EgovComAbstractDAO{

    /** 일반회원 약관확인 */
    public List<?> selectStplat(String stplatId){
    	return list("mberManageDAO.selectStplat_S", stplatId);
    }

}
