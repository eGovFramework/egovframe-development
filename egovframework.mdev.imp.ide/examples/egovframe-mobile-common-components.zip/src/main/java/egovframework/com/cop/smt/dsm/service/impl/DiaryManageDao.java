package egovframework.com.cop.smt.dsm.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.smt.dsm.service.DiaryManageVO;

/** 일지관리를 처리하는 Dao Class 구현 */
@Repository("diaryManageDao")
public class DiaryManageDao extends EgovComAbstractDAO {

    /** 일지관리 목록을 조회한다. */
	public List<?> selectDiaryManageList(ComDefaultVO searchVO) throws Exception{
		return list("DiaryManage.selectDiaryManage", searchVO);
	}

    /** 일지관리를(을) 상세조회 한다. */
	public DiaryManageVO selectDiaryManageDetail(DiaryManageVO diaryManageVO) throws Exception{
		return (DiaryManageVO)selectOne("DiaryManage.selectDiaryManageDetail", diaryManageVO);
	}

    /** 일지관리를(을) 목록 전체 건수를(을) 조회한다. */
	public int selectDiaryManageListCnt(ComDefaultVO searchVO) throws Exception{
		return (Integer)selectOne("DiaryManage.selectDiaryManageCnt", searchVO);
	}

    /** 일지관리를(을) 등록한다. */
	public void insertDiaryManage(DiaryManageVO diaryManageVO) throws Exception{
		insert("DiaryManage.insertDiaryManage", diaryManageVO);
	}

    /** 일지관리를(을) 수정한다. */
	public void updateDiaryManage(DiaryManageVO diaryManageVO) throws Exception{
		insert("DiaryManage.updateDiaryManage", diaryManageVO);
	}

    /** 일지관리를(을) 삭제한다. */
	public void deleteDiaryManage(DiaryManageVO diaryManageVO) throws Exception{
		insert("DiaryManage.deleteDiaryManage", diaryManageVO);
	}
}
