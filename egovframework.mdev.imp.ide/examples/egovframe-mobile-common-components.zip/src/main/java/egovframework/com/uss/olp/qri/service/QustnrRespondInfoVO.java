package egovframework.com.uss.olp.qri.service;

import java.io.Serializable;

/** 설문조사 VO Class 구현 */
public class QustnrRespondInfoVO implements Serializable {

	private static final long serialVersionUID = 129726904408750568L;

	/** 설문응답ID */
	private String qestnrQesrspnsId = "";

	/** 설문문항ID */
	private String qestnrQesitmId = "";

	/** 설문ID */
	private String qestnrId = "";

	/** 설문템플릿ID */
	private String qestnrTmplatId = "";

	/** 설문항목ID */
	private String qustnrIemId = "";

	/** 응답자답변내용 */
	private String respondAnswerCn = "";

	/** 응답자명 */
	private String respondNm = "";

	/** 기타답변내용 */
	private String etcAnswerCn = "";

	/** 최초등록시점 */
	private String frstRegisterPnttm = "";

	/** 최등등록시점ID */
	private String frstRegisterId = "";

	/** 최종수정시점 */
	private String lastUpdusrPnttm = "";

	/** 최종수정시점ID */
	private String lastUpdusrId = "";

	public String getQestnrQesrspnsId() {
		return qestnrQesrspnsId;
	}

	public void setQestnrQesrspnsId(String qestnrQesrspnsId) {
		this.qestnrQesrspnsId = qestnrQesrspnsId;
	}

	public String getQestnrQesitmId() {
		return qestnrQesitmId;
	}

	public void setQestnrQesitmId(String qestnrQesitmId) {
		this.qestnrQesitmId = qestnrQesitmId;
	}

	public String getQestnrId() {
		return qestnrId;
	}

	public void setQestnrId(String qestnrId) {
		this.qestnrId = qestnrId;
	}

	public String getQestnrTmplatId() {
		return qestnrTmplatId;
	}

	public void setQestnrTmplatId(String qestnrTmplatId) {
		this.qestnrTmplatId = qestnrTmplatId;
	}

	public String getQustnrIemId() {
		return qustnrIemId;
	}

	public void setQustnrIemId(String qustnrIemId) {
		this.qustnrIemId = qustnrIemId;
	}

	public String getRespondAnswerCn() {
		return respondAnswerCn;
	}

	public void setRespondAnswerCn(String respondAnswerCn) {
		this.respondAnswerCn = respondAnswerCn;
	}

	public String getRespondNm() {
		return respondNm;
	}

	public void setRespondNm(String respondNm) {
		this.respondNm = respondNm;
	}

	public String getEtcAnswerCn() {
		return etcAnswerCn;
	}

	public void setEtcAnswerCn(String etcAnswerCn) {
		this.etcAnswerCn = etcAnswerCn;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

}
