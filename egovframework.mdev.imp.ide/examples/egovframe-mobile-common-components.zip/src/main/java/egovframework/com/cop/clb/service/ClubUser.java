package egovframework.com.cop.clb.service;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/** 동호회 사용자 정보를 관리하기 위한 모델 클래스 */
@SuppressWarnings("serial")
public class ClubUser implements Serializable {

    /** 동호회 아이디 */
    private String clbId = "";

    /** 커뮤니티 아이디 */
    private String cmmntyId = "";

    /** 최초등록자 아이디 */
    private String frstRegisterId = "";

    /** 최초등록시점 */
    private String frstRegisterPnttm = "";

    /** 최종수정자 아이디 */
    private String lastUpdusrId = "";

    /** 최종수정시점 */
    private String lastUpdusrPnttm = "";

    /** 운영인여부 */
    private String oprtrAt = "";

    /** 탈퇴일 */
    private String secsnDe = "";

    /** 가입일 */
    private String srbDe = "";

    /** 사용여부 */
    private String useAt = "";

    /** 사용자 아이디 */
    private String emplyrId = "";

    /** 사용자명 */
    private String emplyrNm = "";

    public String getClbId() {
	return clbId;
    }

    public void setClbId(String clbId) {
	this.clbId = clbId;
    }

    public String getCmmntyId() {
	return cmmntyId;
    }

    public void setCmmntyId(String cmmntyId) {
	this.cmmntyId = cmmntyId;
    }

    public String getFrstRegisterId() {
	return frstRegisterId;
    }

    public void setFrstRegisterId(String frstRegisterId) {
	this.frstRegisterId = frstRegisterId;
    }

    public String getFrstRegisterPnttm() {
	return frstRegisterPnttm;
    }

    public void setFrstRegisterPnttm(String frstRegisterPnttm) {
	this.frstRegisterPnttm = frstRegisterPnttm;
    }

    public String getLastUpdusrId() {
	return lastUpdusrId;
    }

    public void setLastUpdusrId(String lastUpdusrId) {
	this.lastUpdusrId = lastUpdusrId;
    }

    public String getLastUpdusrPnttm() {
	return lastUpdusrPnttm;
    }

    public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
	this.lastUpdusrPnttm = lastUpdusrPnttm;
    }

    public String getOprtrAt() {
	return oprtrAt;
    }

    public void setOprtrAt(String oprtrAt) {
	this.oprtrAt = oprtrAt;
    }

    public String getSecsnDe() {
	return secsnDe;
    }

    public void setSecsnDe(String secsnDe) {
	this.secsnDe = secsnDe;
    }

    public String getSrbDe() {
	return srbDe;
    }

    public void setSrbDe(String srbDe) {
	this.srbDe = srbDe;
    }

    public String getUseAt() {
	return useAt;
    }

    public void setUseAt(String useAt) {
	this.useAt = useAt;
    }

    public String getEmplyrId() {
	return emplyrId;
    }

    public void setEmplyrId(String emplyrId) {
	this.emplyrId = emplyrId;
    }

    public String getEmplyrNm() {
	return emplyrNm;
    }

    public void setEmplyrNm(String emplyrNm) {
	this.emplyrNm = emplyrNm;
    }

    /** toString 메소드를 대치한다. */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}
