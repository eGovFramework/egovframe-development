package egovframework.com.cop.smt.sdm.service;

import java.util.List;
import java.util.Map;

import egovframework.com.cmm.ComDefaultVO;

/** 부서일정관리를 처리하는 Service Class 구현 */
public interface EgovDeptSchdulManageService {

	/** 부서일정 목록을 조회한다. */
	public List<?> selectDeptSchdulManageRetrieve(Map<?, ?> map) throws Exception;

	/** 부서일정 목록을 조회한다. */
	public List<?> selectDeptSchdulManageList(ComDefaultVO searchVO) throws Exception;

	/** 부서일정를(을) 상세조회 한다. */
	public List<?> selectDeptSchdulManageDetail(DeptSchdulManageVO deptSchdulManageVO) throws Exception;

	/** 부서일정를(을) 목록 전체 건수를(을) 조회한다. */
	public int selectDeptSchdulManageListCnt(ComDefaultVO searchVO) throws Exception;

	/** 부서일정을 등록한다. */
	void  insertDeptSchdulManage(DeptSchdulManageVO deptSchdulManageVO) throws Exception;

	/** 부서일정를(을) 수정한다. */
	void  updateDeptSchdulManage(DeptSchdulManageVO deptSchdulManageVO) throws Exception;

	/** 부서일정를(을) 삭제한다. */
	void  deleteDeptSchdulManage(DeptSchdulManageVO deptSchdulManageVO) throws Exception;

}
