package egovframework.com.uss.ion.rec.service;

/** 추천사이트정보를 처리하는 VO 클래스 */
public class RecomendSiteManageVO extends RecomendSiteManageDefaultVO {

    private static final long serialVersionUID = 1L;

    /** 추천사이트 ID */
    private String recomendSiteId;

    /** 추천사이트 URL */
    private String recomendSiteUrl;

    /** 추천사이트명 */
    private String recomendSiteNm;

    /** 추천사이트설명 */
    private String recomendSiteDc;

    /** 추천사유내용 */
    private String recomendResnCn;

    /** 추천승인여부 */
    private String recomendConfmAt;

    /** 승인일자 */
    private String confmDe;

    /** 최초등록시점 */
    private String frstRegisterPnttm;

    /** 최초등록자ID */
    private String frstRegisterId;

    /** 최종수정시점 */
    private String lastUpdusrPnttm;

    /** 최종수정자ID */
    private String lastUpdusrId;

	public String getRecomendSiteId() {
		return recomendSiteId;
	}

	public void setRecomendSiteId(String recomendSiteId) {
		this.recomendSiteId = recomendSiteId;
	}

	public String getRecomendSiteUrl() {
		return recomendSiteUrl;
	}

	public void setRecomendSiteUrl(String recomendSiteUrl) {
		this.recomendSiteUrl = recomendSiteUrl;
	}

	public String getRecomendSiteNm() {
		return recomendSiteNm;
	}

	public void setRecomendSiteNm(String recomendSiteNm) {
		this.recomendSiteNm = recomendSiteNm;
	}

	public String getRecomendSiteDc() {
		return recomendSiteDc;
	}

	public void setRecomendSiteDc(String recomendSiteDc) {
		this.recomendSiteDc = recomendSiteDc;
	}

	public String getRecomendResnCn() {
		return recomendResnCn;
	}

	public void setRecomendResnCn(String recomendResnCn) {
		this.recomendResnCn = recomendResnCn;
	}

	public String getRecomendConfmAt() {
		return recomendConfmAt;
	}

	public void setRecomendConfmAt(String recomendConfmAt) {
		this.recomendConfmAt = recomendConfmAt;
	}

	public String getConfmDe() {
		return confmDe;
	}

	public void setConfmDe(String confmDe) {
		this.confmDe = confmDe;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

}
