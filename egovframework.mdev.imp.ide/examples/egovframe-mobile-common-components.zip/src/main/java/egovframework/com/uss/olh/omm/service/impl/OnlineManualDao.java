package egovframework.com.uss.olh.omm.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.olh.omm.service.OnlineManual;

/** 온라인메뉴얼를 처리하는 Dao Class 구현 */
@Repository("onlineOnlineManualDao")
public class OnlineManualDao extends EgovComAbstractDAO {

    /** 온라인메뉴얼를(을) 목록을 한다. */
    public List<?> selectOnlineManualList(ComDefaultVO searchVO) throws Exception {
        return list("OnlineManual.selectOnlineManual", searchVO);
    }

    /** 온라인메뉴얼를(을) 목록 전체 건수를(을) 조회한다. */
    public int selectOnlineManualListCnt(ComDefaultVO searchVO) throws Exception {
        return (Integer)selectOne("OnlineManual.selectOnlineManualCnt", searchVO);
    }

    /** 온라인메뉴얼를(을) 상세조회 한다. */
    public OnlineManual selectOnlineManualDetail(OnlineManual onlineManual) throws Exception {
        return (OnlineManual)selectOne("OnlineManual.selectOnlineManualDetail", onlineManual);
    }

    /** 온라인메뉴얼를(을) 등록한다. */
    public void insertOnlineManual(OnlineManual onlineManual) throws Exception {
        insert("OnlineManual.insertOnlineManual", onlineManual);
    }

    /** 온라인메뉴얼를(을) 수정한다. */
    public void updateOnlineManual(OnlineManual onlineManual) throws Exception {
        update("OnlineManual.updateOnlineManual", onlineManual);
    }

    /** 온라인메뉴얼를(을) 삭제한다. */
    public void deleteOnlineManual(OnlineManual onlineManual) throws Exception {
        delete("OnlineManual.deleteOnlineManual", onlineManual);
    }

}
