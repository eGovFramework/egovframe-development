package egovframework.com.cmm.service;

/** globals.properties 공통 설정값 */
public class Globals {

	/** 로그인 후 메인 페이지 */
	public static final String MAIN_PAGE = EgovProperties.getProperty("Globals.MainPage");

	private Globals() {
	}
}
