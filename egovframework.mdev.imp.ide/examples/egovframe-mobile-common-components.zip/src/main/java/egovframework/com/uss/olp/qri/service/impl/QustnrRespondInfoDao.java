package egovframework.com.uss.olp.qri.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.olp.qri.service.QustnrRespondInfoVO;

/** 설문조사 Dao Class 구현 */
@Repository("qustnrRespondInfoDao")
public class QustnrRespondInfoDao extends EgovComAbstractDAO {

    /** 설문템플릿을 조회한다. */
	public List<?> selectQustnrTmplatManage(Map<?, ?> map) throws Exception{
		return list("QustnrRespondInfo.selectQustnrTmplatManages", map);
	}

    /** 객관식 통계를 조회 조회한다. */
	public List<?> selectQustnrRespondInfoManageStatistics1(Map<?, ?> map) throws Exception{
		return list("QustnrRespondInfo.selectQustnrRespondInfoManageStatistics1", map);
	}
    /** 주관식 통계를 조회 조회한다. */
	public List<?> selectQustnrRespondInfoManageStatistics2(Map<?, ?> map) throws Exception{
		return list("QustnrRespondInfo.selectQustnrRespondInfoManageStatistics2", map);
	}

    /** 회원정보를 조회한다. */
	public Map<?, ?> selectQustnrRespondInfoManageEmplyrinfo(Map<?, ?> map) throws Exception{
		return (Map<?, ?>)selectOne("QustnrRespondInfo.selectQustnrRespondInfoManageEmplyrinfo", map);
	}

    /** 설문정보를 조회한다. */
	public List<?> selectQustnrRespondInfoManageComtnqestnrinfo(Map<?, ?> map) throws Exception{
		return list("QustnrRespondInfo.selectQustnrRespondInfoManageComtnqestnrinfo", map);
	}
    /** 문항정보를 조회한다. */
	public List<?> selectQustnrRespondInfoManageComtnqustnrqesitm(Map<?, ?> map) throws Exception{
		return list("QustnrRespondInfo.selectQustnrRespondInfoManageComtnqustnrqesitm", map);
	}
    /** 항목정보를 조회한다. */
	public List<?> selectQustnrRespondInfoManageComtnqustnriem(Map<?, ?> map) throws Exception{
		return list("QustnrRespondInfo.selectQustnrRespondInfoManageComtnqustnriem", map);
	}

    /** 설문조사(설문등록)를(을) 목록을 조회한다. */
	public List<?> selectQustnrRespondInfoManageList(ComDefaultVO searchVO) throws Exception{
		return list("QustnrRespondInfo.selectQustnrRespondInfoManage", searchVO);
	}

    /** 설문조사(설문등록)를(을) 목록 전체 건수를(을) 조회한다. */
	public int selectQustnrRespondInfoManageListCnt(ComDefaultVO searchVO) throws Exception{
		return (Integer)selectOne("QustnrRespondInfo.selectQustnrRespondInfoManageCnt", searchVO);
	}

    /** 응답자결과(설문조사)를(을) 등록한다. */
	public void insertQustnrRespondInfo(QustnrRespondInfoVO qustnrRespondInfoVO) throws Exception{
		insert("QustnrRespondInfo.insertQustnrRespondInfo", qustnrRespondInfoVO);
	}

    /** 응답자결과(설문조사)를(을) 수정한다. */
	public void updateQustnrRespondInfo(QustnrRespondInfoVO qustnrRespondInfoVO) throws Exception{
		insert("QustnrRespondInfo.updateQustnrRespondInfo", qustnrRespondInfoVO);
	}

    /** 응답자결과(설문조사)를(을) 삭제한다. */
	public void deleteQustnrRespondInfo(QustnrRespondInfoVO qustnrRespondInfoVO) throws Exception{
		insert("QustnrRespondInfo.deleteQustnrRespondInfo", qustnrRespondInfoVO);
	}
}
