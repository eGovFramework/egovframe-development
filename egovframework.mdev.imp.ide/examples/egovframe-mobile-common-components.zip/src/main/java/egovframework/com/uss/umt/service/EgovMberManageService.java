package egovframework.com.uss.umt.service;

import java.util.List;

/** 일반회원관리에 관한 인터페이스클래스를 정의한다. */
public interface EgovMberManageService {

	/**
	 * 일반회원 약관확인
	 * @return 일반회원약관정보(List)
	 */
	public List<?> selectStplat(String stplatId)  throws Exception;

}
