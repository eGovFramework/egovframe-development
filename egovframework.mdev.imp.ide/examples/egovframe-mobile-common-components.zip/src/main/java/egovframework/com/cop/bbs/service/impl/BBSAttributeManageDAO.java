package egovframework.com.cop.bbs.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.bbs.service.BoardMaster;
import egovframework.com.cop.bbs.service.BoardMasterVO;

/** 게시판 속성정보 관리를 위한 데이터 접근 클래스 */
@Repository("BBSAttributeManageDAO")
public class BBSAttributeManageDAO extends EgovComAbstractDAO {

    /** 게시판 속성정보 한 건을 상세조회 한다. */
    public BoardMasterVO selectBBSMasterInf(BoardMaster vo) throws Exception {
	return (BoardMasterVO)selectOne("BBSAttributeManageDAO.selectBBSMasterInf", vo);
    }

    /** 커뮤니티, 동호회등 게시판 사용등록이 된 게시판 목록 전체를 불러온다. */
    @SuppressWarnings("unchecked")
    public List<BoardMasterVO> selectAllBdMstrByTrget(BoardMasterVO vo) throws Exception {
	return (List<BoardMasterVO>) list("BBSAttributeManageDAO.selectAllBdMstrByTrget", vo);
    }
}
