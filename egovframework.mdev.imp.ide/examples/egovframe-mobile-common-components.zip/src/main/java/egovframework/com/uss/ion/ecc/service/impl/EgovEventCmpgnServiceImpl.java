package egovframework.com.uss.ion.ecc.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.uss.ion.ecc.service.EgovEventCmpgnService;
import egovframework.com.uss.ion.ecc.service.EventCmpgnVO;
import egovframework.com.uss.ion.ecc.service.TnextrlHrInfoVO;

import jakarta.annotation.Resource;

/** 행사/이벤트/캠페인을 처리하는 ServiceImpl Class 구현 */
@Service("egovEventCmpgnService")
public class EgovEventCmpgnServiceImpl extends EgovAbstractServiceImpl implements EgovEventCmpgnService{

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovEventCmpgnServiceImpl.class);

	@Resource(name="eventCmpgnVODao")
	private EventCmpgnDao dao;

	@Resource(name="egovEventInfoIdGnrService")
	private EgovIdGnrService idgenService1;

	@Resource(name="egovExtrlhrInfoIdGnrService")
	private EgovIdGnrService idgenService2;

	/** 행사/이벤트/캠페인를(을) 목록을 조회한다. */
	@Override
	public List<?> selectEventCmpgnList(ComDefaultVO searchVO) throws Exception{
		return dao.selectEventCmpgnList(searchVO);
	}

	/** 행사/이벤트/캠페인를(을) 상세조회한다. */
	@Override
	public List<?> selectEventCmpgnDetail(EventCmpgnVO eventCmpgnVO) throws Exception{

		return dao.selectEventCmpgnDetail(eventCmpgnVO);
	}

	/** 행사/이벤트/캠페인를(을) 전체 갯수를 조회한다. */
	@Override
	public int selectEventCmpgnListCnt(ComDefaultVO searchVO) throws Exception{

		return dao.selectEventCmpgnListCnt(searchVO);
	}

	/** 행사/이벤트/캠페인를(을) 전체 갯수를 조회한다. */
	public int selectEgovEventCmpgnListCount(ComDefaultVO searchVO) {

		return 1;
	}

	/** 행사/이벤트/캠페인를(을) 입력한다. */
	@Override
	public void insertEventCmpgn(EventCmpgnVO eventCmpgnVO) throws Exception{
		String sMakeId = idgenService1.getNextStringId();
		eventCmpgnVO.setEventId(sMakeId);
		dao.insertEventCmpgn(eventCmpgnVO);
	}

	/** 행사/이벤트/캠페인를(을) 수정한다. */
	@Override
	public void updateEventCmpgn(EventCmpgnVO eventCmpgnVO){
		dao.updateEventCmpgn(eventCmpgnVO);
	}

	/** 행사/이벤트/캠페인를(을) 삭제한다. */
	@Override
	public void deleteEventCmpgn(EventCmpgnVO eventCmpgnVO){
		dao.deleteEventCmpgn(eventCmpgnVO);
	}

	/** 외부인사정보를(을) 등록한다. */
	@Override
	public void insertTnextrlHrInfo(TnextrlHrInfoVO TnextrlHrInfo) throws Exception{
		String sMakeId = idgenService2.getNextStringId();
		TnextrlHrInfo.setExtrlHrId(sMakeId);
		dao.insertTnextrlHrInfo(TnextrlHrInfo);
	}

	/** 외부인사정보를(을) 수정한다. */
	@Override
	public void updateTnextrlHrInfo(TnextrlHrInfoVO TnextrlHrInfo){
		dao.updateTnextrlHrInfo(TnextrlHrInfo);
	}

	/** 외부인사정보를(을) 삭제한다. */
	@Override
	public void deleteTnextrlHrInfo(TnextrlHrInfoVO TnextrlHrInfo){
		dao.deleteTnextrlHrInfo(TnextrlHrInfo);
	}
}
