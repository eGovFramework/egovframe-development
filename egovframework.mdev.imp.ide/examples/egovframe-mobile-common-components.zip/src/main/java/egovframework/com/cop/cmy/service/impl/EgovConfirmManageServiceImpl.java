package egovframework.com.cop.cmy.service.impl;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import egovframework.com.cop.clb.service.EgovClubManageService;
import egovframework.com.cop.cmy.service.ConfirmHistory;
import egovframework.com.cop.cmy.service.EgovCommunityManageService;
import egovframework.com.cop.cmy.service.EgovConfirmManageService;

import jakarta.annotation.Resource;

/** 승인정보를 관리하기 위한 서비스 구현 클래스 */
@Service("EgovConfirmManageService")
public class EgovConfirmManageServiceImpl extends EgovAbstractServiceImpl implements EgovConfirmManageService {

    @Resource(name = "ConfirmManageDAO")
    private ConfirmManageDAO confmDAO;

    @Resource(name = "EgovClubManageService")
    private EgovClubManageService clubService;

    @Resource(name = "EgovCommunityManageService")
    private EgovCommunityManageService cmmntyService;

    /** 승인(탈퇴)요청에 대한 등록을 처리한다. */
    public void insertConfirmRequest(ConfirmHistory history) throws Exception {
	confmDAO.insertConfirmRequest(history);
    }

    /** 현재 승인 요청된 건수를 조회한다. */
    public int countConfirmRequest(ConfirmHistory history) throws Exception {
	return confmDAO.countConfirmRequest(history);
    }
}
