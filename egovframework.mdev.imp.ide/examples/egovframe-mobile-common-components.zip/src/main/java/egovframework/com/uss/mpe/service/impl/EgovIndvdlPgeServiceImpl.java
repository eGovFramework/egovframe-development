package egovframework.com.uss.mpe.service.impl;
import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import egovframework.com.uss.mpe.service.EgovIndvdlPgeService;
import egovframework.com.uss.mpe.service.IndvdlPge;
import egovframework.com.uss.mpe.service.IndvdlPgeCntntsVO;
import egovframework.com.uss.mpe.service.IndvdlPgeVO;

import jakarta.annotation.Resource;

/**
 * 개요
 * - 마이페이지에 대한 ServiceImpl을 정의한다.
 *
 * 상세내용
 * - 마이페이지 콘텐츠의 등록, 수정, 삭제, 조회, 반영확인 기능을 제공한다.
 * - 마이페이지 콘텐츠의 조회기능은 목록조회, 상세조회로 구분된다.
 * - 등록된 콘텐츠를 마이페이지에 추가, 삭제, 조회 기능을 제공한다.
 * @created 05-8-2009 오후 2:19:28
 */

/** EgovIndvdlPgeServiceImpl */
@Service("EgovIndvdlPgeService")
public class EgovIndvdlPgeServiceImpl extends EgovAbstractServiceImpl implements EgovIndvdlPgeService {

	@Resource(name="IndvdlPgeDAO")
    private IndvdlPgeDAO indvdlPgeDAO;

	public EgovIndvdlPgeServiceImpl(){
	}

	/**
	 * 등록된 마이페이지 컨텐츠의 상세정보를 조회한다.
	 * @return indvdlPgeCntntsVO - 마이페이지 콘텐츠 Vo
	 */
	public IndvdlPge selectIndvdlpgeCntnts(IndvdlPge indvdlPge){
		return indvdlPgeDAO.selectIndvdlpgeCntnts(indvdlPge);
	}

	/** 마이페이지에 컨텐츠를 추가하기 위해 등록된 마이페이지 컨텐츠 목록을 조회한다. */
	public List<IndvdlPgeCntntsVO> addIndvdlpgeCntntsList(IndvdlPgeCntntsVO indvdlPgeCntntsVO){
		return indvdlPgeDAO.addIndvdlpgeCntntsList(indvdlPgeCntntsVO);
	}

	/**
	 * 마이페이지에 등록 가능한 컨텐츠 개수를 조회한다.
	 * @return int - 마이페이지 컨텐츠 개수
	 */
	public int selectIndvdlpgeAddCntntsTotCnt(IndvdlPgeCntntsVO indvdlPgeCntntsVO){
		return indvdlPgeDAO.selectIndvdlpgeAddCntntsListTotCnt(indvdlPgeCntntsVO);
	}

	/** 마이페이지에 컨텐츠를 바로추가한다. */
	public boolean addIndvdlpgeCntnts(IndvdlPgeCntntsVO indvdlPgeCntntsVO){
		return indvdlPgeDAO.addIndvdlpgeCntnts(indvdlPgeCntntsVO);
	}

	/** 마이페이지에 컨텐츠를 바로 삭제한다. */
	public boolean delIndvdlpgeCntnts(IndvdlPgeCntntsVO indvdlPgeCntntsVO){
		return indvdlPgeDAO.delIndvdlpgeCntnts(indvdlPgeCntntsVO);
	}

	/**
	 * 기 등록된 마이페이지 정보를 조회한다.
	 * @return indvdlPgeVO - 마이페이지 VO
	 */
	public List<IndvdlPgeVO> selectIndvdlpgeResultDetail(IndvdlPgeVO indvdlPgeVO) throws Exception {
		return indvdlPgeDAO.selectIndvdlpgeResultDetail(indvdlPgeVO);
	}

	/** 기 등록된 마이페이지 정보의 카운트를 조회한다. */
	public int selectIndvdlpgeResultDetailTotCnt(IndvdlPgeVO indvdlPgeVO) throws Exception {
		return indvdlPgeDAO.selectIndvdlpgeResultDetailTotCnt(indvdlPgeVO);
	}

}
