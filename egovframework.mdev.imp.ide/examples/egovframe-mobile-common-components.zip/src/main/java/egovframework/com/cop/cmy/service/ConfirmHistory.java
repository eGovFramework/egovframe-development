package egovframework.com.cop.cmy.service;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/** 승인정보를 관리하기 위한 모델 클래스 */
@SuppressWarnings("serial")
public class ConfirmHistory implements Serializable {

    /** 승인일 */
    private String confmDe = "";

    /** 승인자 아이디 */
    private String confmerId = "";

    /** 확인구분코드 */
    private int confmNumber = 0;

    /** 승인요청자 아이디 */
    private String confmRqesterId = "";

    /** 승인상태코드 */
    private String confmSttusCode = "";

    /** 승인유형코드 */
    private String confmTyCode = "";

    /** 작업 아이디 */
    private String opertId = "";

    /** 작업유형코드 */
    private String opertTyCode = "";

    /** 대상업무 아이디 */
    private String trgetJobId = "";

    /** 대상업무유형코드 */
    private String trgetJobTyCode = "";

    /** 대상 ID */
    private String trgetId = "";

    public String getConfmDe() {
	return confmDe;
    }

    public void setConfmDe(String confmDe) {
	this.confmDe = confmDe;
    }

    public String getConfmerId() {
	return confmerId;
    }

    public void setConfmerId(String confmerId) {
	this.confmerId = confmerId;
    }

    public int getConfmNumber() {
	return confmNumber;
    }

    public void setConfmNumber(int confmNumber) {
	this.confmNumber = confmNumber;
    }

    public String getConfmRqesterId() {
	return confmRqesterId;
    }

    public void setConfmRqesterId(String confmRqesterId) {
	this.confmRqesterId = confmRqesterId;
    }

    public String getConfmSttusCode() {
	return confmSttusCode;
    }

    public void setConfmSttusCode(String confmSttusCode) {
	this.confmSttusCode = confmSttusCode;
    }

    public String getConfmTyCode() {
	return confmTyCode;
    }

    public void setConfmTyCode(String confmTyCode) {
	this.confmTyCode = confmTyCode;
    }

    public String getOpertId() {
	return opertId;
    }

    public void setOpertId(String opertId) {
	this.opertId = opertId;
    }

    public String getOpertTyCode() {
	return opertTyCode;
    }

    public void setOpertTyCode(String opertTyCode) {
	this.opertTyCode = opertTyCode;
    }

    public String getTrgetJobId() {
	return trgetJobId;
    }

    public void setTrgetJobId(String trgetJobId) {
	this.trgetJobId = trgetJobId;
    }

    public String getTrgetJobTyCode() {
	return trgetJobTyCode;
    }

    public void setTrgetJobTyCode(String trgetJobTyCode) {
	this.trgetJobTyCode = trgetJobTyCode;
    }

    public String getTrgetId() {
        return trgetId;
    }

    public void setTrgetId(String trgetId) {
        this.trgetId = trgetId;
    }

    /** toString 메소드를 대치한다. */
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}
