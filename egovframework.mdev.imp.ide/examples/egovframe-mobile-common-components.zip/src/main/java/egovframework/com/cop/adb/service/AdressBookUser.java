package egovframework.com.cop.adb.service;

import java.io.Serializable;

/** 주소록구성원 관리를 위한 모델 클래스 */
@SuppressWarnings("serial")
public class AdressBookUser implements Serializable{

    /** 주소록구성원 아이디 */
    private String adbkUserId = "";

    /** 주소록 아이디 */
    private String adbkId = "";

    /** 사용자 아이디 */
    private String emplyrId = "";

    /** 명함 아이디 */
    private String ncrdId = "";

    /** 주소록구성원 이름 */
    private String nm = "";

    /** 이메일 주소 */
    private String emailAdres = "";

    /** 집 전화번호 */
    private String homeTelno = "";

    /** 폰 번호 */
    private String moblphonNo = "";

    /** 회사 번호 */
    private String offmTelno = "";

    /** 팩스 번호 */
    private String fxnum = "";

    public String getAdbkUserId() {
        return adbkUserId;
    }

    public void setAdbkUserId(String adbkUserId) {
        this.adbkUserId = adbkUserId;
    }

    public String getAdbkId() {
        return adbkId;
    }

    public void setAdbkId(String adbkId) {
        this.adbkId = adbkId;
    }

    public String getEmplyrId() {
        return emplyrId;
    }

    public void setEmplyrId(String emplyrId) {
        this.emplyrId = emplyrId;
    }

    public String getNcrdId() {
        return ncrdId;
    }

    public void setNcrdId(String ncrdId) {
        this.ncrdId = ncrdId;
    }

    public String getNm() {
        return nm;
    }

    public void setNm(String nm) {
        this.nm = nm;
    }

    public String getEmailAdres() {
        return emailAdres;
    }

    public void setEmailAdres(String emailAdres) {
        this.emailAdres = emailAdres;
    }

    public String getHomeTelno() {
        return homeTelno;
    }

    public void setHomeTelno(String homeTelno) {
        this.homeTelno = homeTelno;
    }

    public String getMoblphonNo() {
        return moblphonNo;
    }

    public void setMoblphonNo(String moblphonNo) {
        this.moblphonNo = moblphonNo;
    }

    public String getOffmTelno() {
        return offmTelno;
    }

    public void setOffmTelno(String offmTelno) {
        this.offmTelno = offmTelno;
    }

    public String getFxnum() {
        return fxnum;
    }

    public void setFxnum(String fxnum) {
        this.fxnum = fxnum;
    }
}
