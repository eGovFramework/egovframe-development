package egovframework.com.cop.smt.dsm.service;

import java.util.List;

import egovframework.com.cmm.ComDefaultVO;

/** 일지관리를 처리하는 Service Class 구현 */
public interface EgovDiaryManageService {

    /** 일지관리 목록을 조회한다. */
	public List<?> selectDiaryManageList(ComDefaultVO searchVO) throws Exception;

    /** 일지관리를(을) 상세조회 한다. */
	public DiaryManageVO selectDiaryManageDetail(DiaryManageVO diaryManageVO) throws Exception;

    /** 일지관리를(을) 목록 전체 건수를(을) 조회한다. */
	public int selectDiaryManageListCnt(ComDefaultVO searchVO) throws Exception;

    /** 일지관리를(을) 등록한다. */
	void  insertDiaryManage(DiaryManageVO diaryManageVO) throws Exception;

    /** 일지관리를(을) 수정한다. */
	void  updateDiaryManage(DiaryManageVO diaryManageVO) throws Exception;

    /** 일지관리를(을) 삭제한다. */
	void  deleteDiaryManage(DiaryManageVO diaryManageVO) throws Exception;

}
