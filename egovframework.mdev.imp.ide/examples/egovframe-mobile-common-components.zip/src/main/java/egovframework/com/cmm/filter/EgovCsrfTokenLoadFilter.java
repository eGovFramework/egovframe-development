package egovframework.com.cmm.filter;

import java.io.IOException;

import org.springframework.security.web.csrf.CsrfToken;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

/**
 * 화면 렌더링 전에 CSRF 토큰을 미리 로드한다.
 * 실행환경 보안은 CSRF 토큰을 지연 로드하므로, JSP 하단(csrf.jspf)에서 ${_csrf.token} 을 처음 읽는 시점에 세션이 생성되면
 * 응답이 이미 commit 된 경우 세션 생성에 실패한다. springSecurityFilterChain 다음에 적용한다. (web.xml)
 */
public class EgovCsrfTokenLoadFilter implements Filter {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		if (request.getAttribute(CsrfToken.class.getName()) instanceof CsrfToken csrfToken) {
			csrfToken.getToken();
		}
		chain.doFilter(request, response);
	}
}
