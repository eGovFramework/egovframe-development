package egovframework.com.uss.olp.qri.service;

import java.util.List;
import java.util.Map;

import egovframework.com.cmm.ComDefaultVO;

/** 설문조사 Service Class 구현 */
public interface EgovQustnrRespondInfoService {

    /** 설문템플릿을 조회한다. */
	public List<?> selectQustnrTmplatManage(Map<?, ?> map) throws Exception;

    /** 객관식 통계를 조회 조회한다. */
	public List<?> selectQustnrRespondInfoManageStatistics1(Map<?, ?> map) throws Exception;
    /** 주관식 통계를 조회 조회한다. */
	public List<?> selectQustnrRespondInfoManageStatistics2(Map<?, ?> map) throws Exception;
    /** 회원정보를 조회한다. */
	public Map<?, ?> selectQustnrRespondInfoManageEmplyrinfo(Map<?, ?> map) throws Exception;

    /** 설문정보를 조회한다. */
	public List<?> selectQustnrRespondInfoManageComtnqestnrinfo(Map<?, ?> map) throws Exception;
    /** 문항정보를 조회한다. */
	public List<?> selectQustnrRespondInfoManageComtnqustnrqesitm(Map<?, ?> map) throws Exception;
    /** 항목정보를 조회한다. */
	public List<?> selectQustnrRespondInfoManageComtnqustnriem(Map<?, ?> map) throws Exception;

    /** 설문조사(설문등록)를(을) 목록을 조회한다. */
	public List<?> selectQustnrRespondInfoManageList(ComDefaultVO searchVO) throws Exception;

    /** 설문조사(설문등록)를(을) 목록 전체 건수를(을) 조회한다. */
	public int selectQustnrRespondInfoManageListCnt(ComDefaultVO searchVO) throws Exception;

    /** 응답자결과(설문조사)를(을) 등록한다. */
	void  insertQustnrRespondInfo(QustnrRespondInfoVO qustnrRespondInfoVO) throws Exception;

    /** 응답자결과(설문조사)를(을) 수정한다. */
	void  updateQustnrRespondInfo(QustnrRespondInfoVO qustnrRespondInfoVO) throws Exception;

    /** 응답자결과(설문조사)를(을) 삭제한다. */
	void  deleteQustnrRespondInfo(QustnrRespondInfoVO qustnrRespondInfoVO) throws Exception;

}
