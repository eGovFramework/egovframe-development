package egovframework.com.uss.ion.rec.service;

import java.util.List;

/** 추천사이트정보를 처리하는 서비스 클래스 */
public interface EgovRecomendSiteManageService {

    /** 추천사이트 상세조회를 한다. */
	RecomendSiteManageVO selectRecomendSiteDetail(RecomendSiteManageVO vo) throws Exception;

    /** 추천사이트목록을 조회한다. */
    List<?> selectRecomendSiteList(RecomendSiteManageDefaultVO searchVO) throws Exception;

    /**
     * 추천사이트 총 갯수를 조회한다.
     * @return	총 갯수
     */
    int selectRecomendSiteListTotCnt(RecomendSiteManageDefaultVO searchVO);

	/** 추천사이트를 등록한다. */
    void insertRecomendSiteInfo(RecomendSiteManageVO vo) throws Exception;

	/** 추천사이트를 수정한다. */
    void updateRecomendSiteInfo(RecomendSiteManageVO vo) throws Exception;

	/** 추천사이트를 삭제한다. */
    void deleteRecomendSiteInfo(RecomendSiteManageVO vo) throws Exception;

}
