package egovframework.com.cmm.service;

import java.util.List;

/** 파일정보의 관리를 위한 서비스 인터페이스 */
public interface EgovFileMngService {

    /** 파일에 대한 목록을 조회한다. */
    public List<FileVO> selectFileInfs(FileVO fvo) throws Exception;

    /** 여러 개의 파일에 대한 정보(속성 및 상세)를 등록한다. */
    public String insertFileInfs(List<?> fvoList) throws Exception;

    /** 여러 개의 파일에 대한 정보(속성 및 상세)를 수정한다. */
    public void updateFileInfs(List<?> fvoList) throws Exception;

    /** 하나의 파일을 삭제한다. */
    public void deleteFileInf(FileVO fvo) throws Exception;

    /** 파일에 대한 상세정보를 조회한다. */
    public FileVO selectFileInf(FileVO fvo) throws Exception;

    /** 파일 구분자에 대한 최대값을 구한다. */
    public int getMaxFileSN(FileVO fvo) throws Exception;

    /** 전체 파일을 삭제한다. */
    public void deleteAllFileInf(FileVO fvo) throws Exception;

    /** 이미지 파일에 대한 목록을 조회한다. */
    public List<FileVO> selectImageFileList(FileVO vo) throws Exception;
}
