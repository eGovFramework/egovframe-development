package egovframework.com.utl.fcc.service;

/** 업로드 파일 확장자 유틸 */
public final class EgovFileUploadUtil {

	private EgovFileUploadUtil() {
	}

	/**
	 * 파일 확장자를 추출한다.
	 * @return 확장자(점 제외), 없으면 ""
	 */
	public static String getFileExtension(String fileNamePath) {
		if (fileNamePath == null) {
			return "";
		}
		int dot = fileNamePath.lastIndexOf('.');
		return dot < 0 ? "" : fileNamePath.substring(dot + 1);
	}
}
