package egovframework.com.sym.mnu.mcm.service;

/** 메뉴생성 처리를 위한 VO 클래스르를 정의한다 */
public class MenuCreatVO{

   /** 메뉴번호 */
   private   int      menuNo;
   /** 맵생성ID */
   private   String   mapCreatId;
   /** 권한코드 */
   private   String   authorCode;

   /** 권한정보설정 */
   /** 권한명 */
   private   String   authorNm;
   /** 권한설명 */
   private   String   authorDc;
   /** 권한생성일자 */
   private   String   authorCreatDe;

   /** 기타VO변수 */
   /** 생성자ID * */
   private   String   creatPersonId;

	public int getMenuNo() {
		return menuNo;
	}
	public void setMenuNo(int menuNo) {
		this.menuNo = menuNo;
	}
	public String getMapCreatId() {
		return mapCreatId;
	}
	public void setMapCreatId(String mapCreatId) {
		this.mapCreatId = mapCreatId;
	}
	public String getAuthorCode() {
		return authorCode;
	}
	public void setAuthorCode(String authorCode) {
		this.authorCode = authorCode;
	}
	public String getAuthorNm() {
		return authorNm;
	}
	public void setAuthorNm(String authorNm) {
		this.authorNm = authorNm;
	}
	public String getAuthorDc() {
		return authorDc;
	}
	public void setAuthorDc(String authorDc) {
		this.authorDc = authorDc;
	}
	public String getAuthorCreatDe() {
		return authorCreatDe;
	}
	public void setAuthorCreatDe(String authorCreatDe) {
		this.authorCreatDe = authorCreatDe;
	}
	public String getCreatPersonId() {
		return creatPersonId;
	}
	public void setCreatPersonId(String creatPersonId) {
		this.creatPersonId = creatPersonId;
	}

}
