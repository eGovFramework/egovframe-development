package egovframework.com.sym.mnu.mcm.service;

/** 사이트맵/메인메뉴 처리를 위한 VO 클래스르를 정의한다 */

public class MenuSiteMapVO{

   /** 메뉴번호 */
   private   int      menuNo;

   /* 사이트맵 */
   /** 생성자ID * */
   private   String   creatPersonId;
   /** 맵생성ID */
   private   String   mapCreatId;
   /** 맵파일명 */
   private   String   bndeFileNm;
   /** 맵파일경로 */
   private   String   bndeFilePath;

   /* 권한정보설정 */
   /** 권한코드 */
   private   String   authorCode;
   /** 권한명 */
   private   String   authorNm;
   /** 권한설명 */
   private   String   authorDc;
   /** 권한생성일자 */
   private   String   authorCreatDe;

   /* 기타VO변수 */
   /** rootPath Temp */
   private   String   tmpRootPath;

/* Login 메뉴관련 VO변수 */
   /** tmp_Id */
   private   String   tmpId;
   /** tmp_Password */
   private   String   tmpPassword;
   /** tmp_Name */
   private   String   tmpName;
   /** tmp_UserSe */
   private   String   tmpUserSe;
   /** tmp_Email */
   private   String   tmpEmail;
   /** tmp_OrgnztId */
   private   String   tmpOrgnztId;
   /** tmp_UniqId */
   private   String   tmpUniqId;
   /** tmp_Cmd */
   private   String   tmpCmd;

	public int getMenuNo() {
		return menuNo;
	}
	public void setMenuNo(int menuNo) {
		this.menuNo = menuNo;
	}
	public String getCreatPersonId() {
		return creatPersonId;
	}
	public void setCreatPersonId(String creatPersonId) {
		this.creatPersonId = creatPersonId;
	}
	public String getMapCreatId() {
		return mapCreatId;
	}
	public void setMapCreatId(String mapCreatId) {
		this.mapCreatId = mapCreatId;
	}
	public String getBndeFileNm() {
		return bndeFileNm;
	}
	public void setBndeFileNm(String bndeFileNm) {
		this.bndeFileNm = bndeFileNm;
	}
	public String getBndeFilePath() {
		return bndeFilePath;
	}
	public void setBndeFilePath(String bndeFilePath) {
		this.bndeFilePath = bndeFilePath;
	}
	public String getAuthorCode() {
		return authorCode;
	}
	public void setAuthorCode(String authorCode) {
		this.authorCode = authorCode;
	}
	public String getAuthorNm() {
		return authorNm;
	}
	public void setAuthorNm(String authorNm) {
		this.authorNm = authorNm;
	}
	public String getAuthorDc() {
		return authorDc;
	}
	public void setAuthorDc(String authorDc) {
		this.authorDc = authorDc;
	}
	public String getAuthorCreatDe() {
		return authorCreatDe;
	}
	public void setAuthorCreatDe(String authorCreatDe) {
		this.authorCreatDe = authorCreatDe;
	}

	public String getTmpId() {
		return tmpId;
	}
	public void setTmpId(String tmp_Id) {
		this.tmpId = tmp_Id;
	}
	public String getTmpPassword() {
		return tmpPassword;
	}
	public void setTmpPassword(String tmp_Password) {
		this.tmpPassword = tmp_Password;
	}
	public String getTmpName() {
		return tmpName;
	}
	public void setTmpName(String tmp_Name) {
		this.tmpName = tmp_Name;
	}
	public String getTmpUserSe() {
		return tmpUserSe;
	}
	public void setTmpUserSe(String tmp_UserSe) {
		this.tmpUserSe = tmp_UserSe;
	}
	public String getTmpEmail() {
		return tmpEmail;
	}
	public void setTmpEmail(String tmp_Email) {
		this.tmpEmail = tmp_Email;
	}
	public String getTmpOrgnztId() {
		return tmpOrgnztId;
	}
	public void setTmpOrgnztId(String tmp_OrgnztId) {
		this.tmpOrgnztId = tmp_OrgnztId;
	}
	public String getTmpUniqId() {
		return tmpUniqId;
	}
	public void setTmpUniqId(String tmp_UniqId) {
		this.tmpUniqId = tmp_UniqId;
	}
	public String getTmpCmd() {
		return tmpCmd;
	}
	public void setTmpCmd(String tmp_Cmd) {
		this.tmpCmd = tmp_Cmd;
	}

	public String getTmpRootPath() {
		return tmpRootPath;
	}
	public void setTmpRootPath(String tmp_rootPath) {
		this.tmpRootPath = tmp_rootPath;
	}

}
