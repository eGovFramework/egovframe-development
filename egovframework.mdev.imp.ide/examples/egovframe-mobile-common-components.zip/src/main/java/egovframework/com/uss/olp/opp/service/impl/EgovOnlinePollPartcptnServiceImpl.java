package egovframework.com.uss.olp.opp.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.uss.olp.opp.service.EgovOnlinePollPartcptnService;
import egovframework.com.uss.olp.opp.service.OnlinePollPartcptn;

import jakarta.annotation.Resource;

/** 온라인POLL참여를 처리하는 ServiceImpl Class 구현 */
@Service("egovOnlinePollPartcptnService")
public class EgovOnlinePollPartcptnServiceImpl extends EgovAbstractServiceImpl
        implements EgovOnlinePollPartcptnService {

    @Resource(name = "onlinePollPartcptnDao")
    private OnlinePollPartcptnDao dao;

    @Resource(name = "egovOnlinePollResultIdGnrService")
    private EgovIdGnrService idgenService;

    /** 온라인POLL관리를(을) 목록을 한다. */
    @Override
	public List<?> selectOnlinePollManageList(ComDefaultVO searchVO) throws Exception {
        return dao.selectOnlinePollManageList(searchVO);
    }

    /** 온라인POLL관리를(을) 목록 전체 건수를(을) 조회한다. */
    @Override
	public int selectOnlinePollManageListCnt(ComDefaultVO searchVO) throws Exception {
        return dao.selectOnlinePollManageListCnt(searchVO);
    }

    /** 온라인POLL관리를(을) 상세조회 한다. */
    @Override
	public List<?> selectOnlinePollManageDetail( OnlinePollPartcptn onlinePollPartcptn) throws Exception {
        return dao.selectOnlinePollManageDetail(onlinePollPartcptn);
    }

    /** 온라인POLL항목를(을) 상세조회 한다. */
    @Override
	public List<?> selectOnlinePollItemDetail( OnlinePollPartcptn onlinePollPartcptn) throws Exception {
        return dao.selectOnlinePollItemDetail(onlinePollPartcptn);
    }

    /** 온라인POLL참여를(을) 등록한다. */
    @Override
	public void insertOnlinePollResult(OnlinePollPartcptn onlinePollPartcptn)throws Exception {
        String sMakeId = idgenService.getNextStringId();
        onlinePollPartcptn.setPollResultId(sMakeId);
        dao.insertOnlinePollResult(onlinePollPartcptn);
    }

    /** 온라인POLL통계를(을) 목록을 한다. */
    @Override
	public List<?> selectOnlinePollManageStatistics(OnlinePollPartcptn onlinePollPartcptn) throws Exception {
        return dao.selectOnlinePollManageStatistics(onlinePollPartcptn);
    }

    /** 온라인POLL참여 여부를 조회한다. */
    @Override
	public int selectOnlinePollResult( OnlinePollPartcptn onlinePollPartcptn) throws Exception{
    	return dao.selectOnlinePollResult(onlinePollPartcptn);
    }

}
