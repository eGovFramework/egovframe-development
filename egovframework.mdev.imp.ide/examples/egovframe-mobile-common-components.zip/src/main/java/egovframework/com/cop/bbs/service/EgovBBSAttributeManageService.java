package egovframework.com.cop.bbs.service;

import java.util.List;

/** 게시판 속성관리를 위한 서비스 인터페이스 클래스 */
public interface EgovBBSAttributeManageService {

    /** 게시판 속성정보 한 건을 상세조회한다. */
    public BoardMasterVO selectBBSMasterInf(BoardMaster searchVO) throws Exception;

    /** 커뮤니티, 동호회에서 사용중인 게시판 속성 정보의 목록을 전체조회 한다. */
    public List<BoardMasterVO> selectAllBdMstrByTrget(BoardMasterVO vo) throws Exception;
}
