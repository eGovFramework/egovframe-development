package egovframework.com.cop.bbs.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.bbs.service.Board;
import egovframework.com.cop.bbs.service.BoardVO;

/** 게시물 관리를 위한 데이터 접근 클래스 */
@Repository("BBSManageDAO")
public class BBSManageDAO extends EgovComAbstractDAO {

    /** 게시판에 게시물을 등록 한다. */
    public void insertBoardArticle(Board board) throws Exception {

	insert("BBSManageDAO.insertBoardArticle", board);
    }

    /** 게시판에 답변 게시물을 등록 한다. */
    public long replyBoardArticle(Board board) throws Exception {
	long nttId = (Long)selectOne("BBSManageDAO.selectMaxNttId");
	board.setNttId(nttId);

	insert("BBSManageDAO.replyBoardArticle", board);

	// 현재 글 이후 게시물에 대한 NTT_NO를 증가 (정렬을 추가하기 위해)
	long nttNo = (Long)selectOne("BBSManageDAO.getParentNttNo", board);

	board.setNttNo(nttNo);
	update("BBSManageDAO.updateOtherNttNo", board);

	board.setNttNo(nttNo + 1);
	update("BBSManageDAO.updateNttNo", board);

	return nttId;
    }

    /** 게시물 한 건에 대하여 상세 내용을 조회 한다. */
    public BoardVO selectBoardArticle(BoardVO boardVO) throws Exception {
	return (BoardVO)selectOne("BBSManageDAO.selectBoardArticle", boardVO);
    }

    /** 조건에 맞는 게시물 목록을 조회 한다. */
    @SuppressWarnings("unchecked")
    public List<BoardVO> selectBoardArticleList(BoardVO boardVO) throws Exception {
	return (List<BoardVO>) list("BBSManageDAO.selectBoardArticleList", boardVO);
    }

    /** 조건에 맞는 게시물 목록에 대한 전체 건수를 조회 한다. */
    public int selectBoardArticleListCnt(BoardVO boardVO) throws Exception {
	return (Integer)selectOne("BBSManageDAO.selectBoardArticleListCnt", boardVO);
    }

    /** 게시물 한 건의 내용을 수정 한다. */
    public void updateBoardArticle(Board board) throws Exception {
	update("BBSManageDAO.updateBoardArticle", board);
    }

    /** 게시물 한 건을 삭제 한다. */
    public void deleteBoardArticle(Board board) throws Exception {
	update("BBSManageDAO.deleteBoardArticle", board);
    }

    /** 게시물에 대한 조회 건수를 수정 한다. */
    public void updateInqireCo(BoardVO boardVO) throws Exception {
	update("BBSManageDAO.updateInqireCo", boardVO);
    }

    /** 게시물에 대한 현재 조회 건수를 조회 한다. */
    public int selectMaxInqireCo(BoardVO boardVO) throws Exception {
	return (Integer)selectOne("BBSManageDAO.selectMaxInqireCo", boardVO);
    }

    /** 방명록에 대한 목록을 조회 한다. */
    @SuppressWarnings("unchecked")
    public List<BoardVO> selectGuestList(BoardVO boardVO) throws Exception {
	return (List<BoardVO>) list("BBSManageDAO.selectGuestList", boardVO);
    }

    /** 방명록에 대한 목록 건수를 조회 한다. */
    public int selectGuestListCnt(BoardVO boardVO) throws Exception {
	return (Integer)selectOne("BBSManageDAO.selectGuestListCnt", boardVO);
    }

    /** 방명록 내용을 삭제 한다. */
    public void deleteGuestList(BoardVO boardVO) throws Exception {
	update("BBSManageDAO.deleteGuestList", boardVO);
    }

    /** 방명록에 대한 패스워드를 조회 한다. */
    public String getPasswordInf(Board board) throws Exception {
	return (String)selectOne("BBSManageDAO.getPasswordInf", board);
    }
}
