package egovframework.com.cop.bbs.service;

import java.util.Map;

/** 댓글관리를 위한 서비스 인터페이스 클래스 */
public interface EgovBBSCommentService {
    /** 댓글 사용 가능 여부를 확인한다. */
    public boolean canUseComment(String bbsId) throws Exception;

    /** 댓글에 대한 목록을 조회 한다. */
    public Map<String, Object> selectCommentList(CommentVO commentVO) throws Exception;

    /** 댓글을 등록한다. */
    public void insertComment(Comment comment) throws Exception;

    /** 댓글을 삭제한다. */
    public void deleteComment(CommentVO commentVO) throws Exception;

    /** 댓글에 대한 내용을 조회한다. */
    public Comment selectComment(CommentVO commentVO) throws Exception;

    /** 댓글에 대한 내용을 수정한다. */
    public void updateComment(Comment comment) throws Exception;

    /** 댓글 패스워드를 가져온다. */
    public String getCommentPassword(Comment comment) throws Exception;
}
