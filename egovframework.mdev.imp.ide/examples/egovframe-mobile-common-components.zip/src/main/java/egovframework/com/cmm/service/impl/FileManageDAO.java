package egovframework.com.cmm.service.impl;

import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.FileVO;

/** 파일정보 관리를 위한 데이터 처리 클래스 */
@Repository("FileManageDAO")
public class FileManageDAO extends EgovComAbstractDAO {

	/** 여러 개의 파일에 대한 정보(속성 및 상세)를 등록한다. */
	public String insertFileInfs(List<?> fileList) throws Exception {
		FileVO vo = (FileVO) fileList.get(0);
		String atchFileId = vo.getAtchFileId();

		insert("FileManageDAO.insertFileMaster", vo);

		Iterator<?> iter = fileList.iterator();
		while (iter.hasNext()) {
			vo = (FileVO) iter.next();

			insert("FileManageDAO.insertFileDetail", vo);
		}

		return atchFileId;
	}

	/** 여러 개의 파일에 대한 정보(속성 및 상세)를 수정한다. */
	public void updateFileInfs(List<?> fileList) throws Exception {
		FileVO vo;
		Iterator<?> iter = fileList.iterator();
		while (iter.hasNext()) {
			vo = (FileVO) iter.next();

			insert("FileManageDAO.insertFileDetail", vo);
		}
	}

	/** 하나의 파일을 삭제한다. */
	public void deleteFileInf(FileVO fvo) throws Exception {
		delete("FileManageDAO.deleteFileDetail", fvo);
	}

	/** 파일에 대한 목록을 조회한다. */
	@SuppressWarnings("unchecked")
	public List<FileVO> selectFileInfs(FileVO vo) throws Exception {
		return (List<FileVO>) list("FileManageDAO.selectFileList", vo);
	}

	/** 파일 구분자에 대한 최대값을 구한다. */
	public int getMaxFileSN(FileVO fvo) throws Exception {
		return (Integer) selectOne("FileManageDAO.getMaxFileSN", fvo);
	}

	/** 파일에 대한 상세정보를 조회한다. */
	public FileVO selectFileInf(FileVO fvo) throws Exception {
		return (FileVO) selectOne("FileManageDAO.selectFileInf", fvo);
	}

	/** 전체 파일을 삭제한다. */
	public void deleteAllFileInf(FileVO fvo) throws Exception {
		update("FileManageDAO.deleteCOMTNFILE", fvo);
	}

	/** 이미지 파일에 대한 목록을 조회한다. */
	@SuppressWarnings("unchecked")
	public List<FileVO> selectImageFileList(FileVO vo) throws Exception {
		return (List<FileVO>) list("FileManageDAO.selectImageFileList", vo);
	}
}
