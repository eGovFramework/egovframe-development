package egovframework.com.sym.mnu.mcm.service;

import java.util.List;

import egovframework.com.cmm.ComDefaultVO;

/** 메뉴관리에 관한 서비스 인터페이스 클래스를 정의한다. */
public interface EgovMenuCreateManageService {

	/** ID 존재여부를 조회 */
	int selectUsrByPk(ComDefaultVO vo) throws Exception;

	/** ID에 대한 권한코드를 조회 */
	MenuCreatVO selectAuthorByUsr(ComDefaultVO vo) throws Exception;

	/** 메뉴생성관리 목록을 조회 */
	List<?> selectMenuCreatManagList(ComDefaultVO vo) throws Exception;

	/** 메뉴생성관리 총건수를 조회한다. */
	int selectMenuCreatManagTotCnt(ComDefaultVO vo) throws Exception;

	/** 메뉴생성 내역을 조회 */
	List<?> selectMenuCreatList(MenuCreatVO vo) throws Exception;

	/** 화면에 조회된 메뉴정보로 메뉴생성내역 데이터베이스에서 입력 */
	void insertMenuCreatList(String checkedScrtyForInsert, String checkedMenuNoForInsert) throws Exception;

	/** 메뉴생성 사이트맵 내용 조회 */
	List<?> selectMenuCreatSiteMapList(MenuSiteMapVO vo) throws Exception;

	/** 사용자 권한별 사이트맵 내용 조회 */
	 List<?> selectSiteMapByUser(MenuSiteMapVO vo) throws Exception;

	 /** 사이트맵 등록 */
	 boolean creatSiteMap(MenuSiteMapVO vo, String vHtmlValue) throws Exception;
}
