package egovframework.com.uss.olp.cns.service;

import java.util.List;

/** 상담내용을 처리하는 비즈니스 구현 클래스 */
public interface EgovCnsltManageService {

    /**
     * 상담내용 글을 조회한다.
     * @return 조회한 글
     */
	CnsltManageVO selectCnsltListDetail(CnsltManageVO vo) throws Exception;

	/** 상담내용 글을 수정한다.(조회수를 수정) */
    void updateCnsltInqireCo(CnsltManageVO vo) throws Exception;

    /**
     * 상담내용 글 목록을 조회한다.
     * @return 글 목록
     */
    List<?> selectCnsltList(CnsltManageDefaultVO searchVO) throws Exception;

    /**
     * 상담내용 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    int selectCnsltListTotCnt(CnsltManageDefaultVO searchVO);

	/** 상담내용 글을 등록한다. */
    void insertCnsltDtls(CnsltManageVO vo) throws Exception;

    /**
     * 작성비밀번호를 확인한다.
     * @return 글 총 갯수
     */
    int selectCnsltPasswordConfirmCnt(CnsltManageVO vo);

	/** 상담내용 글을 수정한다. */
    void updateCnsltDtls(CnsltManageVO vo) throws Exception;

	/** 상담내용 글을 삭제한다. */
    void deleteCnsltDtls(CnsltManageVO vo) throws Exception;

    /**
     * 상담답변 글을 조회한다.
     * @return 조회한 글
     */
	CnsltManageVO selectCnsltAnswerListDetail(CnsltManageVO vo) throws Exception;

    /**
     * 상담답변 글 목록을 조회한다.
     * @return 글 목록
     */
    List<?> selectCnsltAnswerList(CnsltManageDefaultVO searchVO) throws Exception;

    /**
     * 상담답변 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    int selectCnsltAnswerListTotCnt(CnsltManageDefaultVO searchVO);

	/** 상담답변 글을 수정한다. */
    void updateCnsltDtlsAnswer(CnsltManageVO vo) throws Exception;

}
