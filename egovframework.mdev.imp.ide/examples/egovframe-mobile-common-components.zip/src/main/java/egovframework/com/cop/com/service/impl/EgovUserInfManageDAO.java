package egovframework.com.cop.com.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.cop.com.service.UserInfVO;

/** 협업 활용 사용자 정보 조회를 위한 데이터 접근 클래스 */
@Repository("EgovUserInfManageDAO")
public class EgovUserInfManageDAO extends EgovComAbstractDAO {

    /** 사용자 정보에 대한 목록을 조회한다. */
    @SuppressWarnings("unchecked")
    public List<UserInfVO> selectUserList(UserInfVO userVO) throws Exception {
	return (List<UserInfVO>) list("EgovUserInfManageDAO.selectUserList", userVO);
    }

    /** 사용자 정보에 대한 목록 전체 건수를 조회한다. */
    public int selectUserListCnt(UserInfVO userVO) throws Exception {
	return (Integer)selectOne("EgovUserInfManageDAO.selectUserListCnt", userVO);
    }
}
