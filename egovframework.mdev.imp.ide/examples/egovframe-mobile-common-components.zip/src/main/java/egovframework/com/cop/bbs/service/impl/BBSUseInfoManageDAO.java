package egovframework.com.cop.bbs.service.impl;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

/** 게시판 이용정보를 관리하기 위한 데이터 접근 클래스 */
@Repository("BBSUseInfoManageDAO")
public class BBSUseInfoManageDAO extends EgovComAbstractDAO {
}
