package egovframework.com.uss.olh.wor.service;

import java.util.List;

/** 용어사전 처리를 위한 서비스 클래스 */
public interface EgovWordDicaryService {

    /** 용어사전 상세 조회를 한다. */
	WordDicaryVO selectWordDicaryDetail(WordDicaryVO vo) throws Exception;

    /**
     * 용어사전 목록을 조회한다.
     * @return	조회 목록
     */
    List<?> selectWordDicaryList(WordDicaryDefaultVO searchVO) throws Exception;

    /**
     * 글 총 갯수를 조회한다
     * @return 총 갯수
     */
    int selectWordDicaryListTotCnt(WordDicaryDefaultVO searchVO);

	/** 용어사전내용을 등록한다. */
    void insertWordDicary(WordDicaryVO vo) throws Exception;

    /** 용어사전내용을 수정한다. */
    void updateWordDicary(WordDicaryVO vo) throws Exception;

	/** 용어사전을 삭제한다. */
    void deleteWordDicary(WordDicaryVO vo) throws Exception;

}
