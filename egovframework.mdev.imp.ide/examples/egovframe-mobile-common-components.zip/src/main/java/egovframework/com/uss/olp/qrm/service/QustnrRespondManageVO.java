package egovframework.com.uss.olp.qrm.service;

import java.io.Serializable;

/** 설문응답자관리 VO Class 구현 */
public class QustnrRespondManageVO implements Serializable {

	private static final long serialVersionUID = -4378392561239344699L;

	/** 설문지ID */
	private String qestnrId = "";

	/** 설문응답자아이디 */
	private String qestnrRespondId = "";

	/** 설별코드 */
	private String sexdstnCode = "";

	/** 직업유형코드 */
	private String occpTyCode = "";

	/** 응답자명 */
	private String respondNm = "";

	/** 생년월일 */
	private String brth = "";

	/** 첫번째전화번호 */
	private String areaNo = "";

	/** 두번째전화번호 */
	private String middleTelno = "";

	/** 마지막전화번호 */
	private String endTelno = "";

	/** 최초등록시점 */
	private String frstRegisterPnttm = "";

	/** 최초등록자ID */
	private String frstRegisterId = "";

	/** 최종수정시점 */
	private String lastUpdusrPnttm = "";

	/** 최종수정ID */
	private String lastUpdusrId = "";

	/** 설문템플릿ID */
	private String qestnrTmplatId = "";

	public String getQestnrId() {
		return qestnrId;
	}

	public void setQestnrId(String qestnrId) {
		this.qestnrId = qestnrId;
	}

	public String getQestnrRespondId() {
		return qestnrRespondId;
	}

	public void setQestnrRespondId(String qestnrRespondId) {
		this.qestnrRespondId = qestnrRespondId;
	}

	public String getSexdstnCode() {
		return sexdstnCode;
	}

	public void setSexdstnCode(String sexdstnCode) {
		this.sexdstnCode = sexdstnCode;
	}

	public String getOccpTyCode() {
		return occpTyCode;
	}

	public void setOccpTyCode(String occpTyCode) {
		this.occpTyCode = occpTyCode;
	}

	public String getRespondNm() {
		return respondNm;
	}

	public void setRespondNm(String respondNm) {
		this.respondNm = respondNm;
	}

	public String getBrth() {
		return brth;
	}

	public void setBrth(String brth) {
		this.brth = brth;
	}

	public String getAreaNo() {
		return areaNo;
	}

	public void setAreaNo(String areaNo) {
		this.areaNo = areaNo;
	}

	public String getMiddleTelno() {
		return middleTelno;
	}

	public void setMiddleTelno(String middleTelno) {
		this.middleTelno = middleTelno;
	}

	public String getEndTelno() {
		return endTelno;
	}

	public void setEndTelno(String endTelno) {
		this.endTelno = endTelno;
	}

	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}

	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}

	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

	public String getQestnrTmplatId() {
		return qestnrTmplatId;
	}

	public void setQestnrTmplatId(String qestnrTmplatId) {
		this.qestnrTmplatId = qestnrTmplatId;
	}

}
