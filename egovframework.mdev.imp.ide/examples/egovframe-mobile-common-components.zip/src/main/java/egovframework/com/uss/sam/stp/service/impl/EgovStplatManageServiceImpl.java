package egovframework.com.uss.sam.stp.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.uss.sam.stp.service.EgovStplatManageService;
import egovframework.com.uss.sam.stp.service.StplatManageDefaultVO;
import egovframework.com.uss.sam.stp.service.StplatManageVO;

import jakarta.annotation.Resource;

/** 약관내용을 처리하는 서비스 구현 클래스 */
@Service("StplatManageService")
public class EgovStplatManageServiceImpl extends EgovAbstractServiceImpl implements
        EgovStplatManageService {

    @Resource(name="StplatManageDAO")
    private StplatManageDAO stplatManageDAO;

    /** ID Generation */
	@Resource(name="egovStplatManageIdGnrService")
	private EgovIdGnrService idgenService;

    /**
     * 글을 조회한다.
     * @return 조회한 글
     */
    @Override
	public StplatManageVO selectStplatDetail(StplatManageVO vo) throws Exception {
        StplatManageVO resultVO = stplatManageDAO.selectStplatDetail(vo);
        if (resultVO == null)
            throw processException("info.nodata.msg");
        return resultVO;
    }

    /**
     * 약관정보 글 목록을 조회한다.
     * @return 글 목록
     */
    @Override
	public List<?> selectStplatList(StplatManageDefaultVO searchVO) throws Exception {
        return stplatManageDAO.selectStplatList(searchVO);
    }

    /**
     * 약관정보 글 총 갯수를 조회한다.
     * @return 글 총 갯수
     */
    @Override
	public int selectStplatListTotCnt(StplatManageDefaultVO searchVO) {
		return stplatManageDAO.selectStplatListTotCnt(searchVO);
	}

	/** 약관정보 글을 등록한다. */
    @Override
	public void insertStplatCn(StplatManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

		String	useStplatId = idgenService.getNextStringId();

		vo.setUseStplatId(useStplatId);

    	stplatManageDAO.insertStplatCn(vo);
    }

	/** 약관정보 글을 수정한다. */
    @Override
	public void updateStplatCn(StplatManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	stplatManageDAO.updateStplatCn(vo);
    }

	/** 약관정보 글을 삭제한다. */
    @Override
	public void deleteStplatCn(StplatManageVO vo) throws Exception {
    	egovLogger.debug(vo.toString());

    	stplatManageDAO.deleteStplatCn(vo);
    }

}
