package egovframework.com.cmm.web;

import java.util.Base64;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.crypto.EgovEnvCryptoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.FileVO;

import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;

/** 파일 조회, 삭제, 다운로드 처리를 위한 컨트롤러 클래스 */
@Controller
public class EgovFileMngController {

	/** 로그설정 */
	private static final Logger LOGGER = LoggerFactory.getLogger(EgovFileMngController.class);

	/** 암호화서비스 */
	private static EgovEnvCryptoService cryptoService;

	@Resource(name = "egovEnvCryptoService")
	public void setEgovEnvCryptoService(EgovEnvCryptoService cryptoService) {
		EgovFileMngController.cryptoService = cryptoService;
	}

	@Resource(name = "EgovFileMngService")
	private EgovFileMngService fileService;

	/** 첨부파일에 대한 목록을 조회한다. */
	@RequestMapping("/cmm/fms/selectFileInfs.mdo")
	public String selectFileInfs(@ModelAttribute("searchVO") FileVO fileVO,
			HttpServletRequest request,
			@RequestParam Map<String, Object> commandMap,
			ModelMap model) throws Exception {

		String param_atchFileId = (String) commandMap.get("param_atchFileId");
		String decodedAtchFileId = "";
		if (param_atchFileId != null && !"".equals(param_atchFileId) ) {
			decodedAtchFileId = cryptoService.decrypt(param_atchFileId);
		}

		fileVO.setAtchFileId(decodedAtchFileId);
		List<FileVO> result = fileService.selectFileInfs(fileVO);

		// FileId를 유추하지 못하도록 세션ID와 함께 암호화하여 표시한다. (2022.12.06 추가) - 파일아이디가 유추 불가능하도록 조치
		for (FileVO file : result) {
			String sessionId = request.getSession().getId();
			String toEncrypt = sessionId + "|" + file.atchFileId;
			file.setAtchFileId(Base64.getEncoder().encodeToString(cryptoService.encrypt(toEncrypt).getBytes()));
		}

		model.addAttribute("fileList", result);
		model.addAttribute("updateFlag", "N");
		model.addAttribute("fileListCnt", result.size());
		model.addAttribute("atchFileId", param_atchFileId);

		return "egovframework/com/cmm/fms/EgovFileList";
	}

	/** 첨부파일 변경을 위한 수정페이지로 이동한다. */
	@RequestMapping("/cmm/fms/selectFileInfsForUpdate.mdo")
	public String selectFileInfsForUpdate(@ModelAttribute("searchVO") FileVO fileVO,
			@RequestParam Map<String, Object> commandMap,
			HttpServletRequest request,
			ModelMap model) throws Exception {

		String param_atchFileId = (String) commandMap.get("param_atchFileId");
		String decodedAtchFileId = "";
		if (param_atchFileId != null && !"".equals(param_atchFileId) ) {
			decodedAtchFileId = cryptoService.decrypt(param_atchFileId);
		}

		fileVO.setAtchFileId(decodedAtchFileId);

		List<FileVO> result = fileService.selectFileInfs(fileVO);

		// FileId를 유추하지 못하도록 세션ID와 함께 암호화하여 표시한다. (2022.12.06 추가) - 파일아이디가 유추 불가능하도록 조치
		for (FileVO file : result) {
			String sessionId = request.getSession().getId();
			String toEncrypt = sessionId + "|" + file.atchFileId;
			file.setAtchFileId(Base64.getEncoder().encodeToString(cryptoService.encrypt(toEncrypt).getBytes()));
		}

		model.addAttribute("fileList", result);
		model.addAttribute("updateFlag", "Y");
		model.addAttribute("fileListCnt", result.size());
		model.addAttribute("atchFileId", param_atchFileId);

		return "egovframework/com/cmm/fms/EgovFileList";
	}

	/** 첨부파일에 대한 삭제를 처리한다. */
	@RequestMapping("/cmm/fms/deleteFileInfs.mdo")
	public String deleteFileInf(@ModelAttribute("searchVO") FileVO fileVO,
			@RequestParam("returnUrl") String returnUrl,
			HttpServletRequest request,
			ModelMap model) throws Exception {

		fileService.deleteFileInf(fileVO);

		// contextRoot가 있는 경우 제외 시켜야 함

		if ("".equals(request.getContextPath()) || "/".equals(request.getContextPath())) {
			return "forward:" + returnUrl;
		}

		if (returnUrl.startsWith(request.getContextPath())) {
			return "forward:" + returnUrl.substring(returnUrl.indexOf("/", 1));
		} else {
			return "forward:" + returnUrl;
		}
		//// ------------------------------------------
	}

	/** 이미지 첨부파일에 대한 목록을 조회한다. */
	@RequestMapping("/cmm/fms/selectImageFileInfs.mdo")
	public String selectImageFileInfs(@ModelAttribute("searchVO") FileVO fileVO,
			@RequestParam Map<String, Object> commandMap,
			HttpServletRequest request,
			ModelMap model) throws Exception {

		String param_atchFileId = (String) commandMap.get("atchFileId");
		String decodedAtchFileId = "";
		if (param_atchFileId != null && !"".equals(param_atchFileId) ) {
			decodedAtchFileId = cryptoService.decrypt(param_atchFileId);
		}

		fileVO.setAtchFileId(decodedAtchFileId);
		List<FileVO> result = fileService.selectImageFileList(fileVO);

		// FileId를 유추하지 못하도록 세션ID와 함께 암호화하여 표시한다. (2022.12.06 추가) - 파일아이디가 유추 불가능하도록 조치
		for (FileVO file : result) {
			String sessionId = request.getSession().getId();
			String toEncrypt = sessionId + "|" + file.atchFileId;
			file.setAtchFileId(Base64.getEncoder().encodeToString(cryptoService.encrypt(toEncrypt).getBytes()));
		}

		model.addAttribute("fileList", result);

		return "egovframework/com/cmm/fms/EgovImgFileList";
	}

	/**
	 * 원본 문자열을 암호화 하는 메서드.
	 * @param source 원본 문자열
	 * @return 암호화 문자열
	 */
	public static String encrypt(String atchFileId) {
		String returnVal = "-";
		returnVal = cryptoService.encrypt(atchFileId);
		return returnVal;
	}

	/**
	 * 원본 문자열을 암호화 하는 메서드.
	 * @param source 원본 문자열
	 * @return 암호화 문자열
	 */
	public static String encryptSession(String atchFileId, String sessionId) {
		String returnVal = "";
		if (atchFileId!=null && !"".equals(atchFileId)) {
			String toEncrypt = sessionId + "|" + atchFileId;
			returnVal = Base64.getEncoder().encodeToString(cryptoService.encrypt(toEncrypt).getBytes());
		}
		return returnVal;
	}

	/**
	 * 암호화 문자열을 복호화 하는 메서드.
	 * @param source 암호화 문자열
	 * @return 원본 문자열
	 */
	public static String decrypt(String base64AtchFileId) {
		String returnVal = "FILE_ID_DECRIPT_EXCEPTION_02";
		if (base64AtchFileId!=null && !"".equals(base64AtchFileId)) {
			try {
				returnVal = cryptoService.decrypt(base64AtchFileId);
			} catch (Exception e) {
				LOGGER.debug(e.getMessage());
			}
		}
		return returnVal;
	}

}
