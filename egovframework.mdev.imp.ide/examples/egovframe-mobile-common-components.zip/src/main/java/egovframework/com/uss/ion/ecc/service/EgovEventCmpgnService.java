package egovframework.com.uss.ion.ecc.service;

import java.util.List;

import egovframework.com.cmm.ComDefaultVO;

/** 행사/이벤트/캠페인을 처리하는 Service Class 구현 */
public interface EgovEventCmpgnService {

	/** 행사/이벤트/캠페인를(을) 목록을 조회한다. */
	public List<?> selectEventCmpgnList(ComDefaultVO searchVO) throws Exception;

	/** 행사/이벤트/캠페인를(을) 상세조회한다. */
	public List<?> selectEventCmpgnDetail(EventCmpgnVO eventCmpgnVO) throws Exception;

	/** 행사/이벤트/캠페인를(을) 전체 갯수를 조회한다. */
	public int selectEventCmpgnListCnt(ComDefaultVO searchVO) throws Exception;

	/** 행사/이벤트/캠페인를(을) 입력한다. */
	void  insertEventCmpgn(EventCmpgnVO eventCmpgnVO) throws Exception;

	/** 행사/이벤트/캠페인를(을) 수정한다. */
	void  updateEventCmpgn(EventCmpgnVO eventCmpgnVO) throws Exception;
	/** 행사/이벤트/캠페인를(을) 삭제한다. */
	void  deleteEventCmpgn(EventCmpgnVO eventCmpgnVO) throws Exception;

	/** 외부인사정보를(을) 등록한다. */
	void  insertTnextrlHrInfo(TnextrlHrInfoVO TnextrlHrInfo) throws Exception;

	/** 외부인사정보를(을) 수정한다. */
	void  updateTnextrlHrInfo(TnextrlHrInfoVO TnextrlHrInfo) throws Exception;

	/** 외부인사정보를(을) 삭제한다. */
	void  deleteTnextrlHrInfo(TnextrlHrInfoVO TnextrlHrInfo) throws Exception;

}
