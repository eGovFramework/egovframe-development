package egovframework.com.uss.ion.ecc.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.ion.ecc.service.EventCmpgnVO;
import egovframework.com.uss.ion.ecc.service.TnextrlHrInfoVO;

/** 행사/이벤트/캠페인을 처리하는 Dao Class 구현 */
@Repository("eventCmpgnVODao")
public class EventCmpgnDao extends EgovComAbstractDAO {

	/** 행사/이벤트/캠페인를(을) 목록을 조회한다. */
	public List<?> selectEventCmpgnList(ComDefaultVO searchVO){
		return list("EventCmpgn.selectEventCmpgn", searchVO);
	}

	/** 행사/이벤트/캠페인를(을) 상세조회한다. */
	public List<?> selectEventCmpgnDetail(EventCmpgnVO eventCmpgnVO){
		return list("EventCmpgn.selectEventCmpgnDetail", eventCmpgnVO);
	}

	/** 행사/이벤트/캠페인를(을) 전체 갯수를 조회한다. */
	public int selectEventCmpgnListCnt(ComDefaultVO searchVO){
		return (Integer)selectOne("EventCmpgn.selectEventCmpgnCnt", searchVO);
	}

	/** 행사/이벤트/캠페인를(을) 입력한다. */
	public void insertEventCmpgn(EventCmpgnVO eventCmpgnVO){
		insert("EventCmpgn.insertEventCmpgn", eventCmpgnVO);
	}

	/** 행사/이벤트/캠페인를(을) 수정한다. */
	public void updateEventCmpgn(EventCmpgnVO eventCmpgnVO){
		update("EventCmpgn.updateEventCmpgn", eventCmpgnVO);
	}

	/** 행사/이벤트/캠페인를(을) 삭제한다. */
	public void deleteEventCmpgn(EventCmpgnVO eventCmpgnVO){

		delete("EventCmpgn.deleteEventCmpgnTnextrlHrInfo", eventCmpgnVO);

		delete("EventCmpgn.deleteEventCmpgn", eventCmpgnVO);
	}

	/** 외부인사정보를(을) 등록한다. */
	public void insertTnextrlHrInfo(TnextrlHrInfoVO TnextrlHrInfo){
		insert("EventCmpgn.insertTnextrlHrInfo", TnextrlHrInfo);
	}

	/** 외부인사정보를(을) 수정한다. */
	public void updateTnextrlHrInfo(TnextrlHrInfoVO TnextrlHrInfo){
		update("EventCmpgn.updateTnextrlHrInfo", TnextrlHrInfo);
	}

	/** 외부인사정보를(을) 삭제한다. */
	public void deleteTnextrlHrInfo(TnextrlHrInfoVO TnextrlHrInfo){
		delete("EventCmpgn.deleteTnextrlHrInfo", TnextrlHrInfo);
	}
}
