package egovframework.mbl.com.sym.mnu.mcm.web;

import java.util.List;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.LoginVO;
import egovframework.com.sym.mnu.mcm.service.EgovMenuCreateManageService;
import egovframework.com.sym.mnu.mcm.service.MenuCreatVO;
import egovframework.com.sym.mnu.mcm.service.MenuSiteMapVO;
import egovframework.mbl.com.cmm.annotation.IncludedMblInfo;

import jakarta.annotation.Resource;

/** 모바일 사이트맵 조회 처리를 하는 비즈니스 구현 클래스 */
@Controller
public class EgovMblSiteMapngController {

	// 페이지 설정
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /** EgovMenuManageService */
	@Resource(name = "meunCreateManageService")
    private EgovMenuCreateManageService menuCreateManageService;

    /**
     * 사이트맵 화면을 출력한다.
     * @return 출력페이지정보 "sym/mnu/mcm/EgovSiteMap"
     */
	@IncludedMblInfo(name="사이트맵 Type B",order = 212 ,gid = 20)
    @RequestMapping(value="/sym/mnu/mcm/EgovSiteMapng.mdo")
    public String siteMapView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		ModelMap model)
            throws Exception {

        return "egovframework/mbl/com/sym/mnu/mcm/EgovSiteMap";
    }

    /** 사이트맵을 조회한다. */
    @RequestMapping(value="/sym/mnu/mcm/EgovSiteMapngActor.mdo")
    public ModelAndView selectSiteMapng(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		ModelMap model)
            throws Exception {

    	ModelAndView modelAndView = new ModelAndView("jsonView");

    	LoginVO user = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();
    	searchVO.setSearchKeyword(user.getId());

    	MenuCreatVO menuCreteVO = menuCreateManageService.selectAuthorByUsr(searchVO);

    	MenuSiteMapVO menuSiteMapVO = new MenuSiteMapVO();
    	menuSiteMapVO.setAuthorCode(menuCreteVO.getAuthorCode());
    	List<?> menulist = menuCreateManageService.selectMenuCreatSiteMapList(menuSiteMapVO);

    	modelAndView.addObject("menulist", menulist);

        return modelAndView;
    }

    /** 사이트맵을 출력한다. (Web Style) */
    @IncludedMblInfo(name="사이트맵 Type A",order = 211 ,gid = 20)
    @RequestMapping(value="/sym/mnu/mcm/EgovWebSiteMapView.mdo")
    public String webSiteMapView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		ModelMap model)
            throws Exception {

        return "egovframework/mbl/com/sym/mnu/mcm/EgovWebSiteMap";
    }
}
