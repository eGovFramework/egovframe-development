package egovframework.mbl.com.geo.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.mbl.com.geo.service.GeoLocation;
import egovframework.mbl.com.geo.service.GeoLocationVO;

/** 건물 위치정보에 대한 DB상의 접근, 변경을 처리한다. / 건물 위치정보에 대한 등록, 수정, 삭제 기능을 제공한다. */
@Repository("geoLocationDAO")
public class GeoLocationDAO extends EgovComAbstractDAO {

    /** 건물 위치정보 목록을 조회한다. */
    @SuppressWarnings("unchecked")
	public List<GeoLocationVO> selectBuildingLocationInfoList(GeoLocationVO geoLocationVO) throws Exception {
        return (List<GeoLocationVO>) list("GeoLocationDAO.selectBuildingLocationInfoList", geoLocationVO);
    }

    /**
     * 건물 위치정보에 대한 목록 건수를 조회 한다.
     * @return int 건물 위치정보 목록 건수
     */
    public int selectBuildingLocationInfoListCnt(GeoLocationVO geoLocationVO) throws Exception {
        return (Integer)selectOne("GeoLocationDAO.selectBuildingLocationInfoListCnt", geoLocationVO);
    }

    /**
     * 건물 위치정보를 조회한다.
     * @return GeoLocation 주변건물 위치정보
     */
    public GeoLocation selectBuildingLocationInfo(GeoLocationVO geoLocationVO) throws Exception {
        return (GeoLocation)selectOne("GeoLocationDAO.selectBuildingLocationInfo", geoLocationVO);
    }

    /** 건물 위치정보를 DB에 등록한다. */
    public void insertBuildingLocationInfo(GeoLocation geoLocation) throws Exception {
        insert("GeoLocationDAO.insertBuildingLocationInfo", geoLocation);
    }

    /** 건물 위치정보를 DB에서 수정한다. */
    public void updateBuildingLocationInfo(GeoLocation geoLocation) throws Exception {
            update("GeoLocationDAO.updateBuildingLocationInfo", geoLocation);
    }

    /** 주변건물 위치정보를 DB에서 삭제한다. */
    public void deleteBuildingLocationInfo(GeoLocation geoLocation) throws Exception {
            delete("GeoLocationDAO.deleteBuildingLocationInfo", geoLocation);
    }
}
