package egovframework.mbl.com.rns.service;

import java.io.Serializable;

/** 실시간 공지 서비스에 대한 VO 클래스를 정의한다. / 실시간 공지 서비스 정보를 조회하기 위해 필요한 정보를 관리한다. */
@SuppressWarnings("serial")
public class RealtimeNoticeVO extends RealtimeNotice implements Serializable {
	/** 회원ID */
	private String mberId = "";

	/** 일련번호 */
	private String searchSn = "";

	/** 목록 조회 갯수 */
	private int fetchRow = 0;

	public int getFetchRow() {
		return fetchRow;
	}

	public void setFetchRow(int fetchRow) {
		this.fetchRow = fetchRow;
	}

	public String getMberId() {
		return mberId;
	}

	public void setMberId(String mberId) {
		this.mberId = mberId;
	}

	public String getSearchSn() {
		return searchSn;
	}

	public void setSsearchSn(String searchSn) {
		this.searchSn = searchSn;
	}

}
