package egovframework.mbl.com.mms.service;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Size;

/** MMS 첨부파일에 대한 model을 정의한다. / MMS 첨부파일 정보를 관리한다. */
public class AttachFile {
    /** 순번 */
    private int sn ;

    /** 회원ID */
    private String mberId ;

    /** 첨부파일 제목 */
    @EgovNullCheck(message = "{valid.AttachFile.mmsAtchFileSj.required}")
    @Size(max = 256, message = "{valid.AttachFile.mmsAtchFileSj.maxlength}")
    private String mmsAtchFileSj ;

    /** MMS 첨부파일ID */
    private String atchFileId ;

    /** MMS 첨부파일명 */
    private String atchFileNm ;

    /** 첨부파일타입 */
    private String atchFileType;

    /** 첨부파일 경로 */
    private String atchFilePath;

    /** 첨부파일 저장 파일명 */
    private String streFileNm;

    /** 생성일시 */
    private String creatDt ;

    private String updtDt ;

    public int getSn() {
        return sn;
    }

    public void setSn(int sn) {
        this.sn = sn;
    }

    public String getMberId() {
        return mberId;
    }

    public void setMberId(String mberId) {
        this.mberId = mberId;
    }

    public String getMmsAtchFileSj() {
        return mmsAtchFileSj;
    }

    public void setMmsAtchFileSj(String mmsAtchFileSj) {
        this.mmsAtchFileSj = mmsAtchFileSj;
    }

    public String getAtchFileId() {
        return atchFileId;
    }

    public void setAtchFileId(String atchFileId) {
        this.atchFileId = atchFileId;
    }

    public String getAtchFileNm() {
        return atchFileNm;
    }

    public void setAtchFileNm(String atchFileNm) {
        this.atchFileNm = atchFileNm;
    }

    public String getAtchFileType() {
        return atchFileType;
    }

    public void setAtchFileType(String atchFileType) {
        this.atchFileType = atchFileType;
    }

    public String getAtchFilePath() {
        return atchFilePath;
    }

    public void setAtchFilePath(String atchFilePath) {
        this.atchFilePath = atchFilePath;
    }

    public String getStreFileNm() {
        return streFileNm;
    }

    public void setStreFileNm(String streFileNm) {
        this.streFileNm = streFileNm;
    }

    public String getCreatDt() {
        return creatDt;
    }

    public void setCreatDt(String creatDt) {
        this.creatDt = creatDt;
    }

    public String getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(String updtDt) {
        this.updtDt = updtDt;
    }

}
