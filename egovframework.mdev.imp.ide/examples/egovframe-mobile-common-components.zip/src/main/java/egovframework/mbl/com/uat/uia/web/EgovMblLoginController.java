package egovframework.mbl.com.uat.uia.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.Globals;
import egovframework.mbl.com.cmm.annotation.IncludedMblInfo;

import jakarta.annotation.Resource;

/** 모바일 로그인 화면 / 로그인(/uat/uia/actionLogin.mdo), 로그아웃(/uat/uia/actionLogout.mdo) 처리는 Spring Security(context-security.xml) */
@Controller
public class EgovMblLoginController {

	@Resource(name = "egovMessageSource")
	private EgovMessageSource egovMessageSource;

	/**
	 * 로그인 화면
	 * @param error 로그인 실패 시 전달
	 */
	@IncludedMblInfo(name = "모바일 Login", order = 300, gid = 30)
	@RequestMapping("/uat/uia/egovLoginUsr.mdo")
	public String loginUsrView(@ModelAttribute("loginVO") LoginVO loginVO,
			@RequestParam(value = "error", required = false) String error, ModelMap model) {
		if (error != null) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
		}
		return "egovframework/mbl/com/uat/uia/EgovLoginUsr";
	}

	/** 로그인 후 메인화면 (Globals.MainPage) */
	@RequestMapping("/uat/uia/actionMain.mdo")
	public String actionMain() {
		String mainPage = Globals.MAIN_PAGE;
		return mainPage.startsWith("/") ? "forward:" + mainPage : mainPage;
	}
}
