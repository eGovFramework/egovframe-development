package egovframework.mbl.com.mcg.service;

import java.util.List;

/** 모바일 차트/그래프에 대한 Service Interface를 정의한다. / 차트/그래프 데이터에 대한 등록, 수정, 삭제, 조회 기능을 제공한다. */

public interface EgovChartGraphService {

	/** 차트/그래프 데이터를 삭제하는 Service interface 메서드 */
	public void deleteChartGraph(ChartGraph chartGraph) throws Exception;

	/** 차트/그래프 데이터를 등록하는 Service interface 메서드 */
	public void insertChartGraph(ChartGraph chartGraph) throws Exception;

	/**
	 * 차트/그래프 데이터를 상세 조회하는 Service interface 메서드
	 * @return ChartGraphVO 차트/그래프 데이터
	 */
	public ChartGraph selectChartGraph(ChartGraph chartGraph) throws Exception;

	/** 차트/그래프 데이터 목록을 조회하는 Service interface 메서드 */
	public List<?> selectChartGraphList(ChartGraphVO chartGraphVO) throws Exception;

	/** 차트/그래프 데이터를 수정하는 Service interface 메서드 */
	public void updateChartGraph(ChartGraph chartGraph) throws Exception;

	/** 차트/그래프 데이터의 총 갯수를 조회한다. */
	public int selectChartGraphListTotCnt(ChartGraphVO searchVO) throws Exception;
}
