package egovframework.mbl.com.mdi.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.mbl.com.mdi.service.DeviceIdent;
import egovframework.mbl.com.mdi.service.DeviceIdentVO;

/** 모바일기기식별에 대한 DB상의 접근, 변경을 처리한다. / 모바일기기 식별정보에 대한 등록, 수정, 삭제, 조회 기능과 User-Agent값 조회, 모바일기기 정보 추출 기능을 제공한다. */
@Repository("DeviceIdentDAO")
public class DeviceIdentDAO extends EgovComAbstractDAO {

	/** 모바일 기기 정보 DB 삭제 메서드 */
	public void deleteDeviceIdent(DeviceIdent deviceIdent) throws Exception {
		delete("DeviceIdentDAO.deleteDeviceIdent", deviceIdent);
	}

	/** 모바일 기기 정보 DB 등록 메서드 */
	public void insertDeviceIdent(DeviceIdent deviceIdent) throws Exception {
		insert("DeviceIdentDAO.insertDeviceIdent", deviceIdent);
	}

	/**
	 * 모바일 기기 정보 상세 DB 조회 메서드
	 * @return DeviceIdent 모바일 기기 정보
	 */
	public DeviceIdent selectDeviceIdent(DeviceIdent deviceIdent) throws Exception {
		return (DeviceIdent) selectOne("DeviceIdentDAO.selectDeviceIdent", deviceIdent);
	}

	/** 모바일 기기 목록 DB 조회 메서드 */
	public List<?> selectDeviceIdentList(DeviceIdentVO searchVO) throws Exception {
		return list("DeviceIdentDAO.selectDeviceIdentList", searchVO);
	}

	/** 모바일 기기 정보 DB 수정 메서드 */
	public void updateDeviceIdent(DeviceIdent deviceIdent) throws Exception {
		update("DeviceIdentDAO.updateDeviceIdent", deviceIdent);
	}

	/** 모바일 기기 정보의 총 갯수를 조회한다. */
	public int selectDeviceIdentListTotCnt(DeviceIdentVO searchVO) throws Exception {
		return (Integer) selectOne("DeviceIdentDAO.selectDeviceIdentListTotCnt", searchVO);
	}
}
