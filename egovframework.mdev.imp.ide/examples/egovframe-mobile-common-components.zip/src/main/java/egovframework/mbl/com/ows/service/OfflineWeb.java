package egovframework.mbl.com.ows.service;
import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Size;

/** 오프라인웹 서비스에 대한 Model 클래스를 정의한다. / 오프라인웹 서비스 정보를 관리한다. */
@SuppressWarnings("serial")
public class OfflineWeb implements Serializable {

	/** 오프라인웹 서비스 일련번호 */
	private int sn = 0;

	/** 오프라인웹 서비스 회원ID */
	private String mberId = "";

	/** 오프라인웹 서비스 제목 */
	@EgovNullCheck(message = "{valid.OfflineWeb.offlineWebSj.required}")
	@Size(max = 100, message = "{valid.OfflineWeb.offlineWebSj.maxlength}")
	private String offlineWebSj = "";

	/** 오프라인웹 서비스 내용 */
	@EgovNullCheck(message = "{valid.OfflineWeb.offlineWebCn.required}")
	@Size(max = 512, message = "{valid.OfflineWeb.offlineWebCn.maxlength}")
	private String offlineWebCn = "";

	/** 오프라인웹 서비스 생성일시 */
	private String creatDt = "";

	private String updtDt = "";

	public int getSn() {
		return sn;
	}

	public void setSn(int sn) {
		this.sn = sn;
	}

	public String getMberId() {
		return mberId;
	}

	public void setMberId(String mberId) {
		this.mberId = mberId;
	}

	public String getOfflineWebSj() {
		return offlineWebSj;
	}

	public void setOfflineWebSj(String offlineWebSj) {
		this.offlineWebSj = offlineWebSj;
	}

	public String getOfflineWebCn() {
		return offlineWebCn;
	}

	public void setOfflineWebCn(String offlineWebCn) {
		this.offlineWebCn = offlineWebCn;
	}

	public String getCreatDt() {
		return creatDt;
	}

	public void setCreatDt(String creatDt) {
		this.creatDt = creatDt;
	}

	public String getUpdtDt() {
		return updtDt;
	}

	public void setUpdtDt(String updtDt) {
		this.updtDt = updtDt;
	}
}
