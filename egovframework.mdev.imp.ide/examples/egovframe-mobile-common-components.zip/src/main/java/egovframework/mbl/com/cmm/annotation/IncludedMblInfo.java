package egovframework.mbl.com.cmm.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** 컴포넌트의 포함 정보 표현을 위한 annotation 클래스 / 기본적으로 Controller 클래스에 annotation을 부여하되, */
@Retention(RetentionPolicy.RUNTIME)
public @interface IncludedMblInfo {
	String name() default "";		// 컴포넌트의 한글 이름
	String listUrl() default "";	// 컴포넌트의 목록정보조회를 위한 URL
	int order() default 0;			// 자동 생성되는 메뉴 목록에 표시되는 순서
	int gid() default 0;			// 컴포넌트의 Group ID(대분류 구분)
}
