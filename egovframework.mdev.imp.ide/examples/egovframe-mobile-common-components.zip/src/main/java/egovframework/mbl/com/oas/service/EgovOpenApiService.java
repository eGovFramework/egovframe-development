package egovframework.mbl.com.oas.service;

import java.util.Map;

import org.apache.xmlbeans.XmlObject;

/** OpenAPI연계에 대한 Service Interface를 정의한다. / OpenAPI연계 정보에 대한 등록, 조회, OpenAPI 서비스 내용 조회 기능을 제공한다. */
public interface EgovOpenApiService {

    /**
     * OpenAPI 연계정보 목록을 조회하는 Service interface 메서드
     * @return Map<String, Object> OpenAPI 연계정보 조회결과 리스트, 조회건수
     */
    public Map<String, Object> selectOpenApiInquiryHistoryList(OpenApiVO openApiVO) throws Exception;

    /**
     * OpenAPI 연계정보를 상세조회하는 Service interface 메서드
     * @return OpenApi OpenAPI 연계정보
     */
    public OpenApi selectOpenApiInquiryHistory(OpenApiVO openApiVO) throws Exception;

    /** OpenAPI 연계정보를 등록하는 Service interface 메서드 */
    public void insertOpenApiInquiryHistory(OpenApi openApi) throws Exception;

    /**
     * 기관별 OpenAPI 서비스를 이용하여 필요한 정보를 가져오는 Service interface 메서드
     * @return XmlObject OpenAPI 서비스 반환값이 매핑된 객체
     */
    public XmlObject getOpenApiSvcInfo(String requestUrl) throws Exception;
}
