package egovframework.mbl.com.mdi.service;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Size;

/** 모바일기기식별에 대한 model을 정의한다. / 모바일기기 정보를 관리한다. */

public class DeviceIdent {

    /** 순번 */
    private int sn;
    /** 회원ID */
    private String mberId;
    /** User-Agent 정보 */
    @EgovNullCheck(message = "{valid.DeviceIdent.uagentInfo.required}")
    @Size(max = 1000, message = "{valid.DeviceIdent.uagentInfo.maxlength}")
    private String uagentInfo;
    /** 브라우저코드 */
    @EgovNullCheck(message = "{valid.DeviceIdent.browserCode.required}")
    private String browserCode;
    /** 브라우저명 */
    private String browserNm;
    /** 운영체제코드 */
    @EgovNullCheck(message = "{valid.DeviceIdent.osCode.required}")
    private String osCode;
    /** 운영체제명 */
    private String osNm;
    /** 최신구분코드 */
    private String recentCode;
    /** 최신구분명 */
    private String recentNm;
    /** 생성 일시 */
    private String creatDt;
    private String updtDt;

    public int getSn() {
        return sn;
    }

    public void setSn(int sn) {
        this.sn = sn;
    }

    public String getMberId() {
        return mberId;
    }

    public void setMberId(String mberId) {
        this.mberId = mberId;
    }

    public String getUagentInfo() {
        return uagentInfo;
    }

    public void setUagentInfo(String uagentInfo) {
        this.uagentInfo = uagentInfo;
    }

    public String getBrowserCode() {
        return browserCode;
    }

    public void setBrowserCode(String browserCode) {
        this.browserCode = browserCode;
    }

    public String getBrowserNm() {
        return browserNm;
    }

    public void setBrowserNm(String browserNm) {
        this.browserNm = browserNm;
    }

    public String getOsCode() {
        return osCode;
    }

    public void setOsCode(String osCode) {
        this.osCode = osCode;
    }

    public String getOsNm() {
        return osNm;
    }

    public void setOsNm(String osNm) {
        this.osNm = osNm;
    }

    public String getRecentCode() {
        return recentCode;
    }

    public void setRecentCode(String recentCode) {
        this.recentCode = recentCode;
    }

    public String getRecentNm() {
        return recentNm;
    }

    public void setRecentNm(String recentNm) {
        this.recentNm = recentNm;
    }

    public String getCreatDt() {
        return creatDt;
    }

    public void setCreatDt(String creatDt) {
        this.creatDt = creatDt;
    }

    public String getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(String updtDt) {
        this.updtDt = updtDt;
    }
}
