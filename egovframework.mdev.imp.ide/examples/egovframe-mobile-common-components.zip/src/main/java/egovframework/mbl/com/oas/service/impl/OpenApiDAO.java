package egovframework.mbl.com.oas.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.mbl.com.oas.service.OpenApi;
import egovframework.mbl.com.oas.service.OpenApiVO;

/** OpenAPI연계에 대한 DB상의 접근, 변경을 처리한다. / OpenAPI연계 정보에 대한 등록, 조회, OpenAPI 서비스 내용 조회 기능을 제공한다. */
@Repository("openApiDAO")
public class OpenApiDAO extends EgovComAbstractDAO {

    /** OpenAPI 연계정보 목록을 조회한다. */
    @SuppressWarnings("unchecked")
	public List<OpenApiVO> selectOpenApiInquiryHistoryList(OpenApiVO openApiVO) throws Exception {
        return (List<OpenApiVO>) list("OpenApiDAO.selectOpenApiInquiryHistoryList", openApiVO);
    }

    /**
     * OpenAPI 연계정보에 대한 목록 건수를 조회 한다.
     * @return int OpenAPI 연계정보 목록 건수
     */
    public int selectOpenApiInquiryHistoryListCnt(OpenApiVO openApiVO) throws Exception {
        return (Integer)selectOne("OpenApiDAO.selectOpenApiInquiryHistoryListCnt", openApiVO);
    }

    /**
     * OpenAPI 연계정보를 조회한다.
     * @return OpenApi OpenAPI 연계정보
     */
    public OpenApi selectOpenApiInquiryHistory(OpenApiVO openApiVO) throws Exception {
        return (OpenApi)selectOne("OpenApiDAO.selectOpenApiInquiryHistory", openApiVO);
    }

    /** OpenAPI 연계정보를 DB에 등록한다. */
    public void insertOpenApiInquiryHistory(OpenApi openApi) throws Exception {
        insert("OpenApiDAO.insertOpenApiInquiryHistory", openApi);
    }
}
