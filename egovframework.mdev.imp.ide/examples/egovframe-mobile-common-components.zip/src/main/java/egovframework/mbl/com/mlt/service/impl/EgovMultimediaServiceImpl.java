package egovframework.mbl.com.mlt.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import egovframework.com.cmm.service.FileVO;
import egovframework.com.cmm.util.EgovXmlUtil;
import egovframework.mbl.com.mlt.service.EgovMultimediaService;
import egovframework.mbl.com.mlt.service.Multimedia;
import egovframework.mbl.com.mlt.service.MultimediaFileInfo;
import egovframework.mbl.com.mlt.service.MultimediaVO;

import jakarta.annotation.Resource;

/** 개요 - 멀티미디어 제어에 대한 Service Interface를 구현한다. / 상세내용 - 멀티미디어에 대한 등록, 수정, 삭제, 조회 기능을 제공한다. - 멀티미디어에 대한 조회기능은 목록, 상세조회로 구분된다. */
@Service("MultimediaService")
public class EgovMultimediaServiceImpl extends EgovAbstractServiceImpl implements EgovMultimediaService {

	/** MultimediaDAO */
	@Resource(name = "MultimediaDAO")
	private MultimediaDAO multimediaDAO;

	/** ID Generation */
	@Resource(name = "egovMultimediaIdGnrService")
	private EgovIdGnrService idgenService;
	private static final Logger LOGGER = LoggerFactory.getLogger(EgovMultimediaServiceImpl.class);

	/** 멀티미디어 정보 삭제 관련 비즈니스 구현 메서드 */
	@Override
	public void deleteMultimedia(Multimedia multimedia) throws Exception {
		multimediaDAO.deleteMultimedia(multimedia);
	}

	/** 멀티미디어 정보 등록 관련 비즈니스 구현 메서드 */
	@Override
	public void insertMultimedia(Multimedia multimedia) throws Exception {

		egovLogger.debug(multimedia.toString());

		int sn = idgenService.getNextIntegerId();

		multimedia.setSn(sn);

		multimediaDAO.insertMultimedia(multimedia);
	}

	/**
	 * 멀티미디어 정보 상세 조회 관련 비즈니스 구현 메서드
	 * @return Multimedia 멀티미디어 정보
	 */
	@Override
	public Multimedia selectMultimedia(Multimedia multimedia) throws Exception {
		Multimedia ret = multimediaDAO.selectMultimedia(multimedia);
		return ret;
	}

	/** 멀티미디어 목록을 조회 관련 비즈니스 구현 메서드 */
	@Override
	public List<?> selectMultimediaList(MultimediaVO searchVO) throws Exception {
		return multimediaDAO.selectMultimediaList(searchVO);
	}

	/** 멀티미디어 정보 수정 관련 비즈니스 구현 메서드 */
	@Override
	public void updateMultimedia(Multimedia multimedia) throws Exception {
		multimediaDAO.updateMultimedia(multimedia);
	}

	/** 멀티미디어 정보의 총 갯수를 조회한다. */
	@Override
	public int selectMultimediaListTotCnt(MultimediaVO searchVO) throws Exception {
		return multimediaDAO.selectMultimediaListTotCnt(searchVO);
	}

	/** 멀티미디어 파일을 상대 경로에 저장한다. */
	@Override
	public void copyFileToRelativePath(List<FileVO> fileList) throws Exception {

		String currPath = this.getClass().getResource("").getPath();
		String absolutePath = "";

		absolutePath = currPath.substring(0, currPath.lastIndexOf("WEB-INF")) + "multimedia";

		// 디렉토리 생성
		if (!(new File(absolutePath)).isDirectory()) {
			if ((new File(absolutePath)).mkdirs()) {
				LOGGER.debug("[file.mkdirs] absolutePath : Creation Success ");
			} else {
				LOGGER.error("[file.mkdirs] absolutePath : Creation Fail ");
			}
		}

		for (int i = 0; i < fileList.size(); i++) {
			File sFile = new File(fileList.get(i).getFileStreCours(), fileList.get(i).getStreFileNm());
			File dFile = new File(absolutePath, fileList.get(i).getStreFileNm() + "." + fileList.get(i).getFileExtsn());

			int fSize = (int) sFile.length();

			// 파일 복사
			if (fSize > 0) {

				FileInputStream fis = null;
				FileOutputStream fos = null;

				try {
					fis = new FileInputStream(sFile);
					fos = new FileOutputStream(dFile);

					FileCopyUtils.copy(fis, fos);
				} catch (MalformedURLException e) {
					LOGGER.error("[" + e.getClass() + "] Try/Catch...MalformedURLException : " + e.getMessage());
				} catch (IOException e) {
					LOGGER.error("[" + e.getClass() + "] Try/Catch...IOException : " + e.getMessage());
				} catch (Exception e) {
					LOGGER.error("[" + e.getClass() + "] Try/Catch...Exception : " + e.getMessage());
				} finally {
					if (fis != null) {
						try {
							fis.close();
						} catch (IOException e) {
							LOGGER.error("[" + e.getClass() + "] Try/Catch...IOException : " + e.getMessage());
						} catch (Exception e) {
							LOGGER.error("[" + e.getClass() + "] Try/Catch...Exception : " + e.getMessage());
						}
					}
					if (fos != null) {
						try {
							fos.close();
						} catch (IOException e) {
							LOGGER.error("[" + e.getClass() + "] Try/Catch...IOException : " + e.getMessage());
						} catch (Exception e) {
							LOGGER.error("[" + e.getClass() + "] Try/Catch...Exception : " + e.getMessage());
						}
					}
				}
			}
		}
	}

	/** 파일별 지원 브라우저 정보를 조회한다. */
	@Override
	public List<MultimediaFileInfo> getMultimediaFileInfoFromXML() throws Exception {
		String XMLPath = this.getClass().getResource("").getPath() + "MultimediaFileInfo.xml";
		List<MultimediaFileInfo> multimediaFileInfoList = new ArrayList<MultimediaFileInfo>();

		DocumentBuilderFactory factory = EgovXmlUtil.newDocumentBuilderFactory();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new File(XMLPath));

		Element rootElement = document.getDocumentElement();

		NodeList multimediaFileInfoElements = rootElement.getChildNodes();

		for (int i = 0; i < multimediaFileInfoElements.getLength(); i++) {
			Node node = multimediaFileInfoElements.item(i);

			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element multimediaFileInfoElement = (Element) node;

				MultimediaFileInfo multimediaFileInfo = new MultimediaFileInfo();

				// 파일 구분
				multimediaFileInfo.setClassification(multimediaFileInfoElement.getNodeName());

				// 파일 확장자
				multimediaFileInfo.setExtension(multimediaFileInfoElement.getAttribute("extension"));

				// 파일 타입
				multimediaFileInfo.setType(multimediaFileInfoElement.getAttribute("type"));

				// 지원 브라우저
				NodeList elements = multimediaFileInfoElement.getChildNodes();
				List<String> browserList = new ArrayList<String>();

				for (int j = 0; j < elements.getLength(); j++) {
					Node childNode = elements.item(j);
					if (childNode.getNodeType() == Node.ELEMENT_NODE) {
						Element childElement = (Element) childNode;
						if (childElement.getNodeName().equalsIgnoreCase("browser")) {
							browserList.add(childElement.getTextContent());
						}
					}
				}
				multimediaFileInfo.setBrowserList(browserList);

				multimediaFileInfoList.add(multimediaFileInfo);
			}
		}

		return multimediaFileInfoList;
	}

	/**
	 * 지원 브라우저 정보를 조회한다.
	 * @param List   <String> 확장자
	 */
	@Override
	@SuppressWarnings("unused")
	public String getBrowserInfoFromXML(String mltmdNm, List<String> extList) throws Exception {
		String browserInfo = "";
		String mltmdNmType = "";

		// 멀티미디어 파일 구분 명 변경 (XML 태그명과 일치)
		if (mltmdNm.equalsIgnoreCase("동영상")) {
			mltmdNmType = "Video";
		} else if (mltmdNm.equalsIgnoreCase("음악")) {
			mltmdNmType = "Audio";
		}

		String XMLPath = this.getClass().getResource("").getPath() + "MultimediaFileInfo.xml";
		List<MultimediaFileInfo> multimediaFileInfoList = new ArrayList<MultimediaFileInfo>();

		DocumentBuilderFactory factory = EgovXmlUtil.newDocumentBuilderFactory();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new File(XMLPath));

		Element rootElement = document.getDocumentElement();

		NodeList multimediaFileInfoElements = rootElement.getChildNodes();

		for (int i = 0; i < multimediaFileInfoElements.getLength(); i++) {
			Node node = multimediaFileInfoElements.item(i);

			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element multimediaFileInfoElement = (Element) node;

				for (int k = 0; k < extList.size(); k++) {

					// 파일 구분 비교
					if (multimediaFileInfoElement.getNodeName().equalsIgnoreCase(mltmdNmType)) {
						// 파일 확장자 비교
						if (multimediaFileInfoElement.getAttribute("extension").equalsIgnoreCase(extList.get(k))) {
							// 지원 브라우저 입력
							NodeList elements = multimediaFileInfoElement.getChildNodes();

							for (int j = 0; j < elements.getLength(); j++) {
								Node childNode = elements.item(j);
								if (childNode.getNodeType() == Node.ELEMENT_NODE) {
									Element childElement = (Element) childNode;
									if (childElement.getNodeName().equalsIgnoreCase("browser")) {
										String elementsText = childElement.getTextContent();
										if (browserInfo.indexOf(elementsText) < 0) {
											browserInfo += elementsText + " ";
										}
									}
								}
							}
						}
					}
				}
			}
		}

		return browserInfo;
	}

	/** 멀티미디어 파일의 확장자를 검사한다. */
	@Override
	public boolean checkMultimediaFileExtension(List<FileVO> fileList) throws Exception {

		List<String> whiteListExtensions = new ArrayList<>();
		String XMLPath = this.getClass().getResource("").getPath() + "MultimediaFileInfo.xml";
		DocumentBuilderFactory factory = EgovXmlUtil.newDocumentBuilderFactory();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new File(XMLPath));
		Element rootElement = document.getDocumentElement();
		NodeList multimediaFileInfoElements = rootElement.getChildNodes();

		for (int i = 0; i < multimediaFileInfoElements.getLength(); i++) {
			Node node = multimediaFileInfoElements.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element multimediaFileInfoElement = (Element) node;
				whiteListExtensions.add(multimediaFileInfoElement.getAttribute("extension"));
			}
		}

		for (int i = 0; i < fileList.size(); i++) {
			String fileExt = fileList.get(i).getFileExtsn();
			if (!whiteListExtensions.contains(fileExt)) {
				return false;
			}
		}
		return true;
	}

}
