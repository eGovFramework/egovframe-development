package egovframework.mbl.com.syn.service;

import java.util.List;

/** 동기화 서비스에 대한 Service Interface를 정의한다. / 동기화 서비스에 대한 등록, 삭제, 조회 기능을 제공한다. */

public interface EgovSyncService {

	/** 동기화 서비스 글 목록 조회 */

	public List<?> selectSyncList(SyncVO searchVO) throws Exception;

	/** 동기화 서비스글 상세 조회 */
	public Sync selectSync(SyncVO searchVO) throws Exception;

	/** 동기화 서비스 글 등록 */
	public int insertSync(Sync sync) throws Exception;

	/** 동기화 서비스 글 삭제 */
	public int deleteSync(Sync sync) throws Exception;

	/** 동기화 서비스 글 수정 */
	public int updateSync(Sync sync) throws Exception;

	/** 동기화 서비스 글 '동기화'를 실행한다. */
	public int executeSync(Sync sync, String localData) throws Exception;

	/** 동기화 서비스 글 목록 총갯수 */
	public int selectSyncListTotCnt(SyncVO searchVO) throws Exception;
}
