package egovframework.mbl.com.ows.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.mbl.com.ows.service.OfflineWeb;
import egovframework.mbl.com.ows.service.OfflineWebVO;

/** 오프라인웹 서비스에 대한 DB상의 접근, 변경을 처리한다. / 오프라인웹 서비스에 대한 등록, 수정, 삭제, 조회 기능을 제공한다. */
@Repository("OfflineWebDAO")
public class OfflineWebDAO extends EgovComAbstractDAO {

	/** 오프라인웹 서비스 신규 일련번호 조회 */
	public int selectOfflineWebNewSn() throws Exception {
		return (Integer)selectOne("OfflineWebDAO.selectOfflineWebNewSn", "");
	}

	/** 오프라인웹 서비스 글 총 갯수 조회 */
	public int selectOfflineWebListTotCnt(OfflineWebVO searchVO) throws Exception {
		return (Integer)selectOne("OfflineWebDAO.selectOfflineWebTotCnt", searchVO);
	}

	/** 오프라인웹 서비스 목록 조회 */
	public List<?> selectOfflineWebList(OfflineWebVO searchVO) throws Exception {
		return list("OfflineWebDAO.selectOfflineWebList", searchVO);
	}

	/** 오프라인웹 서비스 상세 조회 */
	public OfflineWeb selectOfflineWeb(OfflineWebVO searchVO) throws Exception {
		return (OfflineWeb) selectOne("OfflineWebDAO.selectOfflineWeb", searchVO);
	}

	/** 오프라인웹 서비스 등록 */
	public int insertOfflineWeb(OfflineWeb OfflineWeb) throws Exception {
		return update("OfflineWebDAO.insertOfflineWeb", OfflineWeb);
	}

	/** 오프라인웹 서비스 수정 */
	public int updateOfflineWeb(OfflineWeb OfflineWeb) throws Exception {
		return update("OfflineWebDAO.updateOfflineWeb", OfflineWeb);
	}

	/** 오프라인웹 서비스 수정 */
	public int deleteOfflineWeb(OfflineWeb searchVO) throws Exception {
		return delete("OfflineWebDAO.deleteOfflineWeb", searchVO);
	}
}
