package egovframework.mbl.com.mlt.service;

import java.io.Serializable;
import java.util.List;

/** 지원브라우저 정보를 담는 XML을 정의한다. / 지원브라우저 정보를 관리한다. */

public class MultimediaFileInfo implements Serializable {

	private static final long serialVersionUID = 6516852118866931277L;

	/** 파일 구분 */
    private String classification;

    /** 파일 확장자 */
    private String extension;

    /** 파일 타입 */
    private String type;

    /** 지원 브라우저 */
    private List<String> browserList;

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getBrowserList() {
        return browserList;
    }

    public void setBrowserList(List<String> browserList) {
        this.browserList = browserList;
    }
}
