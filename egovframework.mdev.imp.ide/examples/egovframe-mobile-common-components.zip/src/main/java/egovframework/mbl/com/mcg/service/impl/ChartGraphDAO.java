package egovframework.mbl.com.mcg.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.mbl.com.mcg.service.ChartGraph;
import egovframework.mbl.com.mcg.service.ChartGraphVO;

/** 차트/그래프 데이터에 대한 DB상의 접근, 변경을 처리한다. / 차트/그래프 데이터에 대한 등록, 수정, 삭제, 조회 기능을 제공한다. */
@Repository("ChartGraphDAO")
public class ChartGraphDAO extends EgovComAbstractDAO {

    /** 차트/그래프 데이터 DB 삭제 메서드 */
    public void deleteChartGraph(ChartGraph chartGraph) throws Exception {
        delete("ChartGraphDAO.deleteChartGraph", chartGraph);
    }

    /** 차트/그래프 데이터 DB 등록 메서드 */
    public void insertChartGraph(ChartGraph chartGraph) throws Exception {
        insert("ChartGraphDAO.insertChartGraph", chartGraph);
    }

    /**
     * 차트/그래프 데이터 상세 DB 조회 메서드
     * @return ChartGraphVO 차트/그래프 데이터
     */
    public ChartGraph selectChartGraph(ChartGraph chartGraph) throws Exception {
        return (ChartGraph) selectOne("ChartGraphDAO.selectChartGraph",
            chartGraph);
    }

    /** 차트/그래프 데이터 목록 DB 조회 메서드 */
    public List<?> selectChartGraphList(ChartGraphVO searchVO) throws Exception {
        return list("ChartGraphDAO.selectChartGraphList", searchVO);
    }

    /** 차트/그래프 데이터 DB 수정 메서드 */
    public void updateChartGraph(ChartGraph chartGraph) throws Exception {
        update("ChartGraphDAO.updateChartGraph", chartGraph);
    }

    /** 차트/그래프 데이터의 총 갯수를 조회한다. */
    public int selectChartGraphListTotCnt(ChartGraphVO searchVO)
            throws Exception {
        return (Integer) selectOne(
            "ChartGraphDAO.selectChartGraphListTotCnt", searchVO);
    }
}
