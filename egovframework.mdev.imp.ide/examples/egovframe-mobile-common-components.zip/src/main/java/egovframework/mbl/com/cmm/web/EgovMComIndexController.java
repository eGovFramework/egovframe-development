package egovframework.mbl.com.cmm.web;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.aop.support.AopUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.com.cmm.IncludedCompInfoVO;
import egovframework.mbl.com.cmm.annotation.IncludedMblInfo;

import jakarta.annotation.Resource;

/** 설치된 컴포넌트 메뉴 : @IncludedMblInfo 가 선언된 컨트롤러 메소드를 메뉴(order 순)로 표시한다. */
@Controller
public class EgovMComIndexController {

	@Resource
	private ApplicationContext applicationContext;

	/** 메뉴 목록 (최초 요청 시 1회 수집) */
	private volatile Map<Integer, IncludedCompInfoVO> menus;

	@RequestMapping("/EgovMobileMenu.mdo")
	public String mobileMenu(ModelMap model) {
		if (menus == null) {
			menus = collectMenus();
		}
		model.addAttribute("resultList", menus.values());
		return "egovframework/mbl/com/cmm/EgovMobileMain";
	}

	/** 컨트롤러의 @IncludedMblInfo 메소드를 메뉴 정보로 수집한다. 목록 URL 은 listUrl, 없으면 @RequestMapping 값 */
	private Map<Integer, IncludedCompInfoVO> collectMenus() {
		Map<Integer, IncludedCompInfoVO> result = new TreeMap<>();
		for (Object controller : applicationContext.getBeansWithAnnotation(Controller.class).values()) {
			for (Method method : AopUtils.getTargetClass(controller).getMethods()) {
				IncludedMblInfo info = method.getAnnotation(IncludedMblInfo.class);
				if (info == null) {
					continue;
				}
				RequestMapping mapping = method.getAnnotation(RequestMapping.class);
				IncludedCompInfoVO menu = new IncludedCompInfoVO();
				menu.setName(info.name());
				menu.setOrder(info.order());
				menu.setGid(info.gid());
				menu.setListUrl(info.listUrl().isEmpty() && mapping != null ? mapping.value()[0] : info.listUrl());
				result.put(menu.getOrder(), menu);
			}
		}
		return result;
	}
}
