package egovframework.mbl.com.uss.umt.web;

import java.util.List;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.com.cmm.LoginVO;
import egovframework.com.uss.umt.service.EgovMberManageService;

import jakarta.annotation.Resource;

/** 일반회원관련 요청을 비지니스 클래스로 전달하고 처리된결과를 해당 웹 화면으로 전달하는 Controller를 정의한다 */
@Controller
public class EgovMblMberManageController {

	/** mberManageService */
	@Resource(name = "mberManageService")
	private EgovMberManageService mberManageService;

	// 페이지 설정
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/**
	 * 일반회원 약관확인
	 * @return uss/umt/EgovStplatCnfirm
	 */
	@RequestMapping("/uss/umt/EgovStplatCnfirmMber.mdo")
	public String sbscrbEntrprsMber(Model model) throws Exception {

		// 미인증 사용자에 대한 보안처리

		//일반회원용 약관 아이디 설정
		String stplatId = "";
		//회원가입유형 설정-일반회원
		String sbscrbTy = "";

		// 로그인VO에서  사용자 정보 가져오기
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		sbscrbTy = loginVO.getUserSe();

		if ("USR01".equals(sbscrbTy)) {
			stplatId = "STPLAT_0000000000001"; // 개인회원 약관
		} else {
			stplatId = "STPLAT_0000000000002"; // 기업회원 약관
		}

		//약관정보 조회
		List<?> stplatList = mberManageService.selectStplat(stplatId);
		model.addAttribute("stplatList", stplatList); //약관정보 포함
		model.addAttribute("sbscrbTy", sbscrbTy); //회원가입유형 포함

		return "egovframework/mbl/com/uss/umt/EgovStplatCnfirm";
	}

}
