package egovframework.mbl.com.geo.service;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** 위치정보연계에 대한 model을 정의한다. / 위치정보연계 정보를 관리한다. */
public class GeoLocation {
    /** 순번 */
    private int sn ;

    /** 회원ID */
    private String mberId ;

    /** 위도 */
    @EgovNullCheck(message = "{valid.GeoLocation.la.required}")
    @Size(max = 48, message = "{valid.GeoLocation.la.maxlength}")
    @Pattern(regexp = "([-+]?\\d+(\\.\\d+)?)?", message = "{valid.GeoLocation.la.float}")
    private String la ;

    /** 경도 */
    @EgovNullCheck(message = "{valid.GeoLocation.lo.required}")
    @Size(max = 48, message = "{valid.GeoLocation.lo.maxlength}")
    @Pattern(regexp = "([-+]?\\d+(\\.\\d+)?)?", message = "{valid.GeoLocation.lo.float}")
    private String lo ;

    /** 건물명 */
    @EgovNullCheck(message = "{valid.GeoLocation.buldNm.required}")
    @Size(max = 60, message = "{valid.GeoLocation.buldNm.maxlength}")
    private String buldNm ;

    /** 전화번호 */
    private String telno ;

    /** 주소 */
    private String adres ;

    public int getSn() {
        return sn;
    }

    public void setSn(int sn) {
        this.sn = sn;
    }

    public String getMberId() {
        return mberId;
    }

    public void setMberId(String mberId) {
        this.mberId = mberId;
    }

    public String getLa() {
        return la;
    }

    public void setLa(String la) {
        this.la = la;
    }

    public String getLo() {
        return lo;
    }

    public void setLo(String lo) {
        this.lo = lo;
    }

    public String getBuldNm() {
        return buldNm;
    }

    public void setBuldNm(String buldNm) {
        this.buldNm = buldNm;
    }

    public String getTelno() {
        return telno;
    }

    public void setTelno(String telno) {
        this.telno = telno;
    }

    public String getAdres() {
        return adres;
    }

    public void setAdres(String adres) {
        this.adres = adres;
    }
}
