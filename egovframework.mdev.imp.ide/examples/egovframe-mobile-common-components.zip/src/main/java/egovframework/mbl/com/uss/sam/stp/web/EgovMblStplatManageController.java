package egovframework.mbl.com.uss.sam.stp.web;

import java.net.URLDecoder;
import java.util.List;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.uss.sam.stp.service.EgovStplatManageService;
import egovframework.com.uss.sam.stp.service.StplatManageDefaultVO;
import egovframework.com.uss.sam.stp.service.StplatManageVO;
import egovframework.mbl.com.cmm.annotation.IncludedMblInfo;

import jakarta.annotation.Resource;

/** 약관내용을 처리하는 비즈니스 구현 클래스 */
@Controller
public class EgovMblStplatManageController {

    @Resource(name = "StplatManageService")
    private EgovStplatManageService stplatManageService;

    // 페이지 설정
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

	/** EgovMessageSource */
    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;

    /** 개별 배포시 메인메뉴를 조회한다. */
    @RequestMapping(value="/uss/sam/stp/EgovMain.mdo")
    public String EgovMain(ModelMap model) throws Exception {
    	return "egovframework/mbl/com/uss/sam/stp/EgovMain";
    }

    /** 메뉴를 조회한다. */
    @RequestMapping(value="/uss/sam/stp/EgovLeft.mdo")
    public String EgovLeft(ModelMap model) throws Exception {
    	return "egovframework/mbl/com/uss/sam/stp/EgovLeft";
    }

    /** json데이터를 호출하기 위한 페이지를 호출한다. */
    @IncludedMblInfo(name="약관",order = 200 ,gid = 20)
    @RequestMapping(value="/uss/sam/stp/StplatListInqire.mdo")
    public String mainBoard(@ModelAttribute("searchVO") StplatManageDefaultVO searchVO, ModelMap model)
    throws Exception {

    	return "egovframework/mbl/com/uss/sam/stp/EgovStplatListInqire";

    }

    /** 약관정보 목록을 조회한다. */
    @RequestMapping(value="/uss/sam/stp/StplatList.mdo")
    public ModelAndView selectStplatList(@ModelAttribute("searchVO") StplatManageDefaultVO searchVO, ModelMap model) throws Exception {

    	ModelAndView modelAndView = new ModelAndView("jsonView");

    	searchVO.setSearchKeyword(URLDecoder.decode(searchVO.getSearchKeyword(), "UTF-8"));

    	// 페이지 설정
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));

    	// 페이징
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        List<?> StplatList = stplatManageService.selectStplatList(searchVO);

        modelAndView.addObject("reusltList", StplatList);
        modelAndView.addObject("listSize", StplatList.size());

        int totCnt = stplatManageService.selectStplatListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		modelAndView.addObject("paginationInfo", paginationInfo);

		return modelAndView;
    }

    /** 약관정보상세내용을 조회한다. */
    @RequestMapping("/uss/sam/stp/StplatDetailInqire.mdo")
    public String	selectStplatDetail(StplatManageVO stplatManageVO,
            @ModelAttribute("searchVO") StplatManageDefaultVO searchVO,
            ModelMap model) throws Exception {

		StplatManageVO vo = stplatManageService.selectStplatDetail(stplatManageVO);

		model.addAttribute("result", vo);

        return	"egovframework/mbl/com/uss/sam/stp/EgovStplatDetailInqire";
    }

}
