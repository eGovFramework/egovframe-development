package egovframework.mbl.com.cop.smt.dsm.web;

import java.net.URLDecoder;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.CmmnDetailCode;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovOwnerCheck;
import egovframework.com.cop.smt.dsm.service.DiaryManageVO;
import egovframework.com.cop.smt.dsm.service.EgovDiaryManageService;
import egovframework.com.cop.smt.sdm.service.DeptSchdulManageVO;
import egovframework.com.cop.smt.sdm.service.EgovDeptSchdulManageService;
import egovframework.mbl.com.cmm.annotation.IncludedMblInfo;

import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/** 일지관리를 처리하는 Controller Class 구현 */
@Controller
public class EgovMblDiaryManageController {

	/** EgovMessageSource */
    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;

	@Resource(name = "egovDiaryManageService")
	private EgovDiaryManageService egovDiaryManageService;

    // 페이지 설정
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

	@Resource(name = "egovDeptSchdulManageService")
	private EgovDeptSchdulManageService egovDeptSchdulManageService;

	@Resource(name="EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	/** 일지관리 목록을 조회한다. */
	@SuppressWarnings("unused")
	@IncludedMblInfo(name="일지관리",order = 108 ,gid = 10)
	@RequestMapping(value="/cop/smt/dsm/EgovDiaryManageList.mdo")
	public String EgovDiaryManageList(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<?, ?> commandMap,
			DiaryManageVO diaryManageVO,
    		ModelMap model)
    throws Exception {

		String sSearchMode = commandMap.get("searchMode") == null ? "" : (String)commandMap.get("searchMode");

    	// 페이지 설정
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));

    	int pageIndex = commandMap.get("searchKeyword") == null ? searchVO.getPageIndex() : Integer.parseInt((String)commandMap.get("pageIndex"));

    	// 페이징
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(pageIndex);
		paginationInfo.setRecordCountPerPage(10);
		paginationInfo.setPageSize(1);

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        if(commandMap.get("schdulId") != null && "save".equals((commandMap.get("schdulId")))){
        	searchVO.setSearchCondition("SCHDUL_ID");
        	searchVO.setSearchKeyword((String)commandMap.get("schdulId"));
        }

        String searchKeyword = commandMap.get("searchKeyword") == null ? searchVO.getSearchKeyword() : (String)commandMap.get("searchKeyword");
        searchVO.setSearchKeyword(searchKeyword);

        String searchCondition = commandMap.get("searchCondition") == null ? searchVO.getSearchCondition() : (String)commandMap.get("searchCondition");
        searchVO.setSearchCondition(searchCondition);

        List<?> sampleList = egovDiaryManageService.selectDiaryManageList(searchVO);
        model.addAttribute("resultList", sampleList);

        model.addAttribute("searchKeyword", searchKeyword);
        model.addAttribute("searchCondition", searchCondition);

        int totCnt = egovDiaryManageService.selectDiaryManageListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/mbl/com/cop/smt/dsm/EgovDiaryManageList";
	}

	/** 일지관리 목록을 상세조회 조회한다. */
	@RequestMapping(value="/cop/smt/dsm/EgovDiaryManageDetail.mdo")
	public String EgovDiaryManageDetail(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			DiaryManageVO diaryManageVO,
			@RequestParam Map<?, ?> commandMap,
    		ModelMap model)
    throws Exception {
		String sLocationUrl = "egovframework/mbl/com/cop/smt/dsm/EgovDiaryManageDetail";

		String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");

		if(sCmd.equals("del")){
			// 소유권 확인 : 등록자 본인만 삭제 가능
			EgovOwnerCheck.checkOwner(egovDiaryManageService.selectDiaryManageDetail(diaryManageVO), DiaryManageVO::getFrstRegisterId);
			egovDiaryManageService.deleteDiaryManage(diaryManageVO);
			sLocationUrl = "redirect:/cop/smt/dsm/EgovDiaryManageList.mdo";
		}else{
	        model.addAttribute("diaryManageVO",  egovDiaryManageService.selectDiaryManageDetail(diaryManageVO));
			model.addAttribute("searchVO", searchVO);

		}

		return sLocationUrl;
	}

	/** 일지관리를 수정한다. / 초기페이지 */
	@SuppressWarnings("unused")
	@RequestMapping(value="/cop/smt/dsm/EgovDiaryManageModify.mdo")
	public String DiaryManageModify(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<?, ?> commandMap,
			DiaryManageVO diaryManageVO,
			BindingResult bindingResult,
    		ModelMap model)
    throws Exception {

		//로그인 객체 선언
		LoginVO loginVO = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();

		String sLocationUrl = "egovframework/mbl/com/cop/smt/dsm/EgovDiaryManageModify";

		String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");

		model.addAttribute("diaryManageVO",  egovDiaryManageService.selectDiaryManageDetail(diaryManageVO));

		return sLocationUrl;
	}

	/** 일지관리를 수정한다. / 수정처리작업 */
	@RequestMapping(value="/cop/smt/dsm/EgovDiaryManageModifyActor.mdo")
	public String DiaryManageModifyActor(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<?, ?> commandMap,
			@Valid @ModelAttribute("diaryManageVO") DiaryManageVO diaryManageVO,
			BindingResult bindingResult,
    		ModelMap model)
    throws Exception {

    	// 소유권 확인 : 등록자 본인만 수정 가능
    	EgovOwnerCheck.checkOwner(egovDiaryManageService.selectDiaryManageDetail(diaryManageVO), DiaryManageVO::getFrstRegisterId);

		//로그인 객체 선언
		LoginVO loginVO = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();

		String sLocationUrl = "egovframework/mbl/com/cop/smt/dsm/EgovDiaryManageModify";

		String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");

        if(sCmd.equals("save")){

    		if(bindingResult.hasErrors()){

    			return sLocationUrl;
    		}

    		// 일지정보 업데이트
        	egovDiaryManageService.updateDiaryManage(diaryManageVO);
        	sLocationUrl = "redirect:/cop/smt/dsm/EgovDiaryManageList.mdo";
		}

		return sLocationUrl;
	}

	/** 일지관리를 등록한다. / 등록 초기페이지 */
	@SuppressWarnings("unused")
	@RequestMapping(value="/cop/smt/dsm/EgovDiaryManageRegist.mdo")
	public String DiaryManageRegist(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<?, ?> commandMap,
			@ModelAttribute("diaryManageVO") DiaryManageVO diaryManageVO,
			BindingResult bindingResult,
    		ModelMap model)
    throws Exception {

		String schdulId = commandMap.get("schdulId") == null ? "" : (String)commandMap.get("schdulId");
		String schdulCn = commandMap.get("schdulCn") == null ? "" : (String)commandMap.get("schdulCn");

		diaryManageVO.setSchdulId(schdulId);
		diaryManageVO.setSchdulCn(schdulCn);
		model.addAttribute("diaryManageVO", diaryManageVO);

		//로그인 객체 선언
		LoginVO loginVO = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();

		String sLocationUrl = "egovframework/mbl/com/cop/smt/dsm/EgovDiaryManageRegist";

		return sLocationUrl;
	}

	/** 일지관리를 등록한다. / 등록처리작업 */
	@RequestMapping(value="/cop/smt/dsm/EgovDiaryManageRegistActor.mdo")
	public String DiaryManageRegistActor(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<?, ?> commandMap,
			@Valid @ModelAttribute("diaryManageVO") DiaryManageVO diaryManageVO,
			BindingResult bindingResult,
    		ModelMap model)
    throws Exception {

		//로그인 객체 선언
		LoginVO loginVO = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();

		String sLocationUrl = "egovframework/mbl/com/cop/smt/dsm/EgovDiaryManageRegist";

		String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");

        if(sCmd.equals("save")){

    		if(bindingResult.hasErrors()){

    			return sLocationUrl;
    		}

    		//아이디 설정
    		diaryManageVO.setFrstRegisterId(loginVO.getUniqId());
    		diaryManageVO.setLastUpdusrId(loginVO.getUniqId());

        	egovDiaryManageService.insertDiaryManage(diaryManageVO);
        	sLocationUrl = "redirect:/cop/smt/dsm/EgovDiaryManageList.mdo";
        }

		return sLocationUrl;
	}

	/** 일지관리 목록 화면을 출력한다. */
	@RequestMapping(value="/cop/smt/sdm/EgovDeptSchdulManageListPopupView.mdo")
	public String EgovDeptSchdulManageListPopupView(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<?, ?> commandMap,
			DeptSchdulManageVO deptSchdulManageVO,
    		ModelMap model)
    throws Exception {

		return "egovframework/mbl/com/cop/smt/dsm/EgovDeptSchdulManageListPopup";
	}

	/** 일지관리 목록을 조회한다. */
	@RequestMapping(value="/cop/smt/sdm/EgovDeptSchdulManageListPopup.mdo")
	public ModelAndView EgovDeptSchdulManageListPopup(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<?, ?> commandMap,
			DeptSchdulManageVO deptSchdulManageVO,
    		ModelMap model1)
    throws Exception {

		ModelAndView modelAndView = new ModelAndView("jsonView");

		searchVO.setSearchKeyword(URLDecoder.decode(searchVO.getSearchKeyword(), "UTF-8"));

    	// 페이지 설정
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));

    	// 페이징
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		//공통코드  일정구분 조회
		ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
		voComCode = new ComDefaultCodeVO();
    	voComCode.setCodeId("COM030");
    	List<?> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);

    	String searchKeyword = (String)commandMap.get("searchKeyword");
    	if("SCHDUL_SE".equals((commandMap.get("searchCondition")))) {
	    	for (Object code : listComCode) {
				if(searchKeyword.equals(((CmmnDetailCode)code).getCodeNm())){
					searchVO.setSearchKeyword(((CmmnDetailCode)code).getCode());
				}
	    	}
		}
    	modelAndView.addObject("schdulSe", listComCode);

        List<?> sampleList = egovDeptSchdulManageService.selectDeptSchdulManageList(searchVO);

        modelAndView.addObject("resultList", sampleList);
        modelAndView.addObject("searchKeyword", commandMap.get("searchKeyword") == null ? "" : (String)commandMap.get("searchKeyword"));
        modelAndView.addObject("searchCondition", commandMap.get("searchCondition") == null ? "" : (String)commandMap.get("searchCondition"));

        int totCnt = egovDeptSchdulManageService.selectDeptSchdulManageListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		modelAndView.addObject("paginationInfo", paginationInfo);

        return modelAndView;
	}
}
