package egovframework.mbl.com.mcg.service;

import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Size;

/** 차트/그래프 데이터에 대한 Model 클래스를 정의한다. / 차트/그래프 데이터를 관리한다. */

public class ChartGraph implements Serializable {

	private static final long serialVersionUID = -3882546722495194867L;
	/** 순번 */
    int sn;
    /** 회원 ID */
    String mberId;
    /** x축 값 */
    @EgovNullCheck(message = "{valid.ChartGraph.xaxis.required}")
    @Size(max = 20, message = "{valid.ChartGraph.xaxis.maxlength}")
    String xaxis;
    /** y축 값 */
    int yaxis;
    /** 범례명 */
    @EgovNullCheck(message = "{valid.ChartGraph.lgdNm.required}")
    @Size(max = 60, message = "{valid.ChartGraph.lgdNm.maxlength}")
    String lgdNm;
    /** 생성 일시 */
    String creatDt;
    /** 수정 일시 */
    String updtDt;

    public int getSn() {
        return sn;
    }

    public void setSn(int sn) {
        this.sn = sn;
    }

    public String getMberId() {
        return mberId;
    }

    public void setMberId(String mberId) {
        this.mberId = mberId;
    }

    public String getXaxis() {
        return xaxis;
    }

    public void setXaxis(String xaxis) {
        this.xaxis = xaxis;
    }

    public int getYaxis() {
        return yaxis;
    }

    public void setYaxis(int yaxis) {
        this.yaxis = yaxis;
    }

    public String getLgdNm() {
        return lgdNm;
    }

    public void setLgdNm(String lgdNm) {
        this.lgdNm = lgdNm;
    }

    public String getCreatDt() {
        return creatDt;
    }

    public void setCreatDt(String creatDt) {
        this.creatDt = creatDt;
    }

    public String getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(String updtDt) {
        this.updtDt = updtDt;
    }
}
