package egovframework.mbl.com.rns.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import egovframework.mbl.com.rns.service.EgovRealtimeNoticeService;
import egovframework.mbl.com.rns.service.RealtimeNotice;
import egovframework.mbl.com.rns.service.RealtimeNoticeVO;

import jakarta.annotation.Resource;

/** 실시간 공지 서비스에 대한 Service Interface를 구현한다. / 실시간 공지 서비스에 대한 등록, 삭제, 조회 기능을 제공한다. */
@Service("RealtimeNoticeService")
public class EgovRealtimeNoticeServiceImpl extends EgovAbstractServiceImpl implements EgovRealtimeNoticeService{

	/** ID Generation */

	@Resource(name="RealtimeNoticeDAO")
    private RealtimeNoticeDAO realtimeNoticeDAO;

	/** [관리자] 실시간공지서비스 목록 조회 */
	@Override
	public List<?> selectRealtimeNoticeList(RealtimeNoticeVO searchVO) throws Exception {
		List<?> rtnList = null;

		searchVO.setFetchRow(searchVO.getFetchRow() * 5);
		rtnList = realtimeNoticeDAO.selectRealtimeNoticeList(searchVO);

		return rtnList;
	}

	/** [관리자/사용자] 실시간공지서비스 상세조회 / 실시간공지 서비스 내용 */
	@Override
	public RealtimeNotice selectRealtimeNotice(RealtimeNoticeVO searchVO) throws Exception {
		RealtimeNotice rtnRealtimceNotice = null;

		rtnRealtimceNotice = realtimeNoticeDAO.selectRealtimeNotice(searchVO);

		return rtnRealtimceNotice;
	}

	/** [관리자] 실시간공지서비스 등록 */
	@Override
	public int insertRealtimeNotice(RealtimeNotice realtimeNotice) throws Exception {
		int rtn = 0;

		int newSn = realtimeNoticeDAO.selectRealtimeNoticeNewSn();

		// 1. SN 을 생성한다.
		realtimeNotice.setSn(newSn);

		// 2. 등록을 한다.
		rtn = realtimeNoticeDAO.insertRealtimeNotice(realtimeNotice);

		// 3. 정상등록 후 등록 행이 첫번째 행이 아니라면 기존의 행의 최신구분을 변경한다.
		return rtn;
	}

	/** [관리자] 실시간공지서비스 삭제 */
	@Override
	public int deleteRealtimeNotice(RealtimeNoticeVO realtimeNoticeVO) throws Exception {
		int rtn = 0;

		// 실시간 공지 서비스를 삭제 한다.
		rtn = realtimeNoticeDAO.deleteRealtimeNotice(realtimeNoticeVO);

		return rtn;
	}

	/**
	 * 실시간 공지서비스 메시지 조회
	 * @param RealtimeNotice;
	 */
	@Override
	public RealtimeNotice selectRealtimeNoticeMsg() throws Exception {
		RealtimeNotice rtnRealtimceNotice = null;

		rtnRealtimceNotice = realtimeNoticeDAO.selectRealtimeNoticeMsg();

		return rtnRealtimceNotice;
	}
}
