package egovframework.mbl.com.mlt.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.mbl.com.mlt.service.Multimedia;
import egovframework.mbl.com.mlt.service.MultimediaVO;

/** 멀티미디어에 대한 DB상의 접근, 변경을 처리한다. / 멀티미디어에 대한 등록, 수정, 삭제, 조회 기능을 제공한다. */
@Repository("MultimediaDAO")
public class MultimediaDAO extends EgovComAbstractDAO {

	/** 멀티미디어 정보 DB 삭제 메서드 */
	public void deleteMultimedia(Multimedia multimedia) throws Exception {
		delete("MultimediaDAO.deleteMultimedia", multimedia);
	}

	/** 멀티미디어 정보 DB 등록 메서드 */
	public void insertMultimedia(Multimedia multimedia) throws Exception {
		insert("MultimediaDAO.insertMultimedia", multimedia);
	}

	/**
	 * 멀티미디어 정보 상세 DB 조회 메서드
	 * @return Multimedia 멀티미디어 정보
	 */
	public Multimedia selectMultimedia(Multimedia multimedia) throws Exception {
		return (Multimedia) selectOne("MultimediaDAO.selectMultimedia", multimedia);
	}

	/** 멀티미디어 목록 DB 조회 메서드 */
	public List<?> selectMultimediaList(MultimediaVO searchVO) throws Exception {
		return list("MultimediaDAO.selectMultimediaList", searchVO);
	}

	/** 멀티미디어 정보 DB 수정 메서드 */
	public void updateMultimedia(Multimedia multimedia) throws Exception {
		update("MultimediaDAO.updateMultimedia", multimedia);
	}

	/** 멀티미디어 정보의 총 갯수를 조회한다. */
	public int selectMultimediaListTotCnt(MultimediaVO searchVO) throws Exception {
		return (Integer) selectOne("MultimediaDAO.selectMultimediaListTotCnt", searchVO);
	}
}
