package egovframework.mbl.com.mms.service;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** MMS 전송정보에 대한 model을 정의한다. / MMS 전송 정보를 관리한다. */
public class MmsTransInfo {
    /** 순번 */
    private int sn;

    /** 회원ID */
    private String mberId;

    /** 송신번호 */
    @EgovNullCheck(message = "{valid.MmsTransInfo.trnsmisNo.required}")
    @Pattern(regexp = "0[0-9]{9,10}", message = "{valid.MmsTransInfo.trnsmisNo.mask}")
    private String trnsmisNo;

    /** 수신번호 */
    @EgovNullCheck(message = "{valid.MmsTransInfo.recptnNo.required}")
    @Pattern(regexp = "0[0-9]{9,10}", message = "{valid.MmsTransInfo.recptnNo.mask}")
    private String recptnNo;

    /** 전송일시 */
    private String trnsmisDt;

    /** 메시지 제목 */
    @EgovNullCheck(message = "{valid.MmsTransInfo.mssageSj.required}")
    @Size(max = 30, message = "{valid.MmsTransInfo.mssageSj.maxlength}")
    private String mssageSj;

    /** 메시지 내용 */
    @EgovNullCheck(message = "{valid.MmsTransInfo.mssageCn.required}")
    private String mssageCn;

    /** 메시지 ID */
    private String mssageId;

    /** 요청결과명 */
    private String rqesterResultNm;

    /** 전송결과명 */
    private String trnsmisResultNm;

    /** 전송확인일시 */
    private String trnsmisConfirmDt;

    /** 첨부파일 */
    private AttachFile attachFile = new AttachFile();

    public int getSn() {
        return sn;
    }

    public void setSn(int sn) {
        this.sn = sn;
    }

    public String getMberId() {
        return mberId;
    }

    public void setMberId(String mberId) {
        this.mberId = mberId;
    }

    public String getTrnsmisNo() {
        return trnsmisNo;
    }

    public void setTrnsmisNo(String trnsmisNo) {
        this.trnsmisNo = trnsmisNo;
    }

    public String getRecptnNo() {
        return recptnNo;
    }

    public void setRecptnNo(String recptnNo) {
        this.recptnNo = recptnNo;
    }

    public String getTrnsmisDt() {
        return trnsmisDt;
    }

    public void setTrnsmisDt(String trnsmisDt) {
        this.trnsmisDt = trnsmisDt;
    }

    public String getMssageSj() {
        return mssageSj;
    }

    public void setMssageSj(String mssageSj) {
        this.mssageSj = mssageSj;
    }

    public String getMssageCn() {
        return mssageCn;
    }

    public void setMssageCn(String mssageCn) {
        this.mssageCn = mssageCn;
    }

    public String getMssageId() {
        return mssageId;
    }

    public void setMssageId(String mssageId) {
        this.mssageId = mssageId;
    }

    public String getRqesterResultNm() {
        return rqesterResultNm;
    }

    public void setRqesterResultNm(String rqesterResultNm) {
        this.rqesterResultNm = rqesterResultNm;
    }

    public String getTrnsmisResultNm() {
        return trnsmisResultNm;
    }

    public void setTrnsmisResultNm(String trnsmisResultNm) {
        this.trnsmisResultNm = trnsmisResultNm;
    }

    public String getTrnsmisConfirmDt() {
        return trnsmisConfirmDt;
    }

    public void setTrnsmisConfirmDt(String trnsmisConfirmDt) {
        this.trnsmisConfirmDt = trnsmisConfirmDt;
    }

    public AttachFile getAttachFile() {
        return attachFile;
    }

    public void setAttachFile(AttachFile attachFile) {
        this.attachFile = attachFile;
    }
}
