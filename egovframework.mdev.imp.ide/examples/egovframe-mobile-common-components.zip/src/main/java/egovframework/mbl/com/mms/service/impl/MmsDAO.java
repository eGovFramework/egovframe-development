package egovframework.mbl.com.mms.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.mbl.com.mms.service.AttachFile;
import egovframework.mbl.com.mms.service.AttachFileVO;
import egovframework.mbl.com.mms.service.MmsTransInfo;
import egovframework.mbl.com.mms.service.MmsTransInfoVO;

/** MMS서비스연계에 대한 DB상의 접근, 변경을 처리한다. / MMS 전송, MMS 전송 결과 등록, 수정, 조회 기능과 MMS 첨부파일에 대한 등록, 수정, 삭제, 조회 기능을 제공한다. */
@Repository("mmsDAO")
public class MmsDAO extends EgovComAbstractDAO {

    /** MMS 전송 정보를 DB에 등록한다. */
    public void insertMmsTransmissionResult(MmsTransInfo mmsTransInfo) throws Exception {
        insert("MmsDAO.insertMmsTransmissionResult", mmsTransInfo);
    }

    /** MMS 전송 결과를 수정한다. */
    public void updateMmsTransmissionResult(MmsTransInfo mmsTransInfo) throws Exception {
        update("MmsDAO.updateMmsTransmissionResult", mmsTransInfo);
    }

    /** MMS 전송 결과 목록을 조회한다. */
    @SuppressWarnings("unchecked")
	public List<AttachFileVO> selectMmsTransmissionResultList(MmsTransInfoVO mmsTransInfoVO) throws Exception {
        return (List<AttachFileVO>) list("MmsDAO.selectMmsTransmissionResultList", mmsTransInfoVO);
    }

    /**
     * MMS 전송 결과에 대한 목록 건수를 조회 한다.
     * @return int 첨부파일 목록 건수
     */
    public int selectMmsTransmissionResultListCnt(MmsTransInfoVO mmsTransInfoVO) throws Exception {
        return (Integer)selectOne("MmsDAO.selectMmsTransmissionResultListCnt", mmsTransInfoVO);
    }

    /** 첨부파일 목록을 조회한다. */
    @SuppressWarnings("unchecked")
	public List<AttachFileVO> selectAttachFileList(AttachFileVO attachFileVO) throws Exception {
        return (List<AttachFileVO>) list("MmsDAO.selectAttachFileList", attachFileVO);
    }

    /**
     * 첨부파일에 대한 목록 건수를 조회 한다.
     * @return int 첨부파일 목록 건수
     */
    public int selectAttachFileInfoListCnt(AttachFileVO attachFileVO) throws Exception {
        return (Integer)selectOne("MmsDAO.selectAttachFileListCnt", attachFileVO);
    }

    /**
     * 첨부파일의 정보를 상세조회한다.
     * @return AttachFile 첨부파일 정보
     */
    public AttachFile selectAttachFile(AttachFileVO attachFileVO) throws Exception {
        return (AttachFile)selectOne("MmsDAO.selectAttachFile", attachFileVO);
    }

    /** 첨부파일의 정보를 DB에 등록한다. */
    public void insertAttachFile(AttachFile attachFile) throws Exception {
        insert("MmsDAO.insertAttachFile", attachFile);
    }

    /** 조회된 첨부파일의 정보를 DB에서 수정한다. */
    public void updateAttachFile(AttachFile attachFile) throws Exception {
        update("MmsDAO.updateAttachFile", attachFile);
    }

    /** 조회된 첨부파일의 정보를 DB에서 삭제한다. */
    public void deleteAttachFile(AttachFile attachFile) throws Exception {
            delete("MmsDAO.deleteAttachFile", attachFile);
    }
}
