package egovframework.mbl.com.mpa.web;

import java.util.Base64;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.crypto.EgovCryptoService;
import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.psl.dataaccess.util.EgovMap;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.EgovFileMngUtil;
import egovframework.com.cmm.service.EgovProperties;
import egovframework.com.cmm.service.FileVO;
import egovframework.com.cmm.util.EgovOwnerCheck;
import egovframework.mbl.com.cmm.annotation.IncludedMblInfo;
import egovframework.mbl.com.mpa.service.EgovPhotoService;
import egovframework.mbl.com.mpa.service.Photo;
import egovframework.mbl.com.mpa.service.PhotoVO;

import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

/** 사진 앨범에 대한 Controller를 정의한다. / 사진에 대한 등록, 수정, 삭제, 조회 요청 사항을 Service와 매핑 처리한다. */
@Controller
public class EgovPhotoController {

	/** 암호화서비스 */
	@Resource(name = "egovARIACryptoService")
	EgovCryptoService cryptoService;

	// 주의 : 반드시 기본값 "egovframe"을 다른것으로 변경하여 사용하시기 바랍니다.
	public static final String ALGORITHM_KEY = EgovProperties.getProperty("Globals.File.algorithmKey");

    /** EgovPhotoService */
    @Resource(name = "PhotoService")
    private EgovPhotoService photoService;

    // 페이지 설정
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    // 첨부파일 관련
    @Resource(name = "EgovFileMngService")
    private EgovFileMngService fileMngService;

    @Resource(name = "EgovFileMngUtil")
    private EgovFileMngUtil fileUtil;

    /** 모바일 사진 목록 화면으로 이동한다. */
    @IncludedMblInfo(name="모바일 사진 앨범",order = 402 ,gid = 40)
    @RequestMapping(value = "/mbl/com/mpa/goMobilePhotoList.mdo")
    public String goMobilePhotoList(ModelMap model) throws Exception {
        return "egovframework/mbl/com/mpa/EgovMobilePhotoList";
    }

    /** 모바일 사진 목록 조회 Service interface 호출 및 결과를 반환한다.(JSON 통신) */
    @RequestMapping(value = "/mbl/com/mpa/selectMobilePhotoList.mdo")
    public ModelAndView selectMobilePhotoList(ModelMap model,
    		HttpServletRequest request) throws Exception {

        ModelAndView modelAndView = new ModelAndView("jsonView");

        PhotoVO searchVO = new PhotoVO();

        searchVO.setFirstIndex(0);
        searchVO.setRecordCountPerPage(1000);

        List<EgovMap> PhotoList = (List<EgovMap>)photoService.selectPhotoList(searchVO);

        for (EgovMap photo : PhotoList) {
			String sessionId = request.getSession().getId();
			String toEncrypt = sessionId + "|" + photo.get("atchFileId");
			photo.setValue(3, Base64.getEncoder().encodeToString(
					cryptoService.encrypt(toEncrypt.getBytes(), ALGORITHM_KEY)));
		}

        modelAndView.addObject("resultList", PhotoList);

        return modelAndView;
    }

    /** 사진 정보 등록 화면으로 이동한다. */
    @RequestMapping(value = "/mbl/com/mpa/goPhotoRegist.mdo")
    public String goPhotoRegist(@ModelAttribute("searchVO") PhotoVO searchVO,
            ModelMap model) throws Exception {
        model.addAttribute("photo", new Photo());

        return "egovframework/mbl/com/mpa/EgovPhotoRegist";
    }

    /** 사진 정보 등록 Service interface 호출 및 결과를 반환한다. */
    @RequestMapping(value = "/mbl/com/mpa/insertPhoto.mdo")
    public String insertPhoto(final MultipartHttpServletRequest multiRequest,
            @ModelAttribute("searchVO") PhotoVO searchVO,
            @Valid @ModelAttribute("photo") Photo photo, BindingResult bindingResult,
            ModelMap model) throws Exception {

        if (bindingResult.hasErrors()) {
            return "egovframework/mbl/com/mpa/EgovPhotoRegist";
        }

        // 첨부파일 관련 첨부파일ID 생성
        List<FileVO> _result = null;
        String _atchFileId = "";

        final Map<String, MultipartFile> files = multiRequest.getFileMap();

        if (!files.isEmpty()) {
            _result = fileUtil.parseFileInf(files, "MPA_", 0, "", "");
            _atchFileId = fileMngService.insertFileInfs(_result); // 파일이 생성되고나면 생성된 첨부파일 ID를 리턴한다.
        }

        // 리턴받은 첨부파일ID를 셋팅한다..
        photo.setAtchFileId(_atchFileId); // 첨부파일 ID

        // 로그인VO에서 사용자 정보 가져오기
        LoginVO loginVO =
            (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        String mberId = loginVO.getId();

        photo.setMberId(mberId);

        photoService.insertPhoto(photo);
        return "forward:/mbl/com/mpa/selectPhotoList.mdo";
    }

    /** 사진 목록 조회 Service interface 호출 및 결과를 반환한다. */
    @IncludedMblInfo(name="모바일 사진 앨범",order = 501 ,gid = 50)
    @RequestMapping(value = "/mbl/com/mpa/selectPhotoList.mdo")
    public String selectPhotoList(@ModelAttribute("searchVO") PhotoVO searchVO,
            ModelMap model) throws Exception {

        // 페이지 설정
        searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
        searchVO.setPageSize(propertiesService.getInt("pageSize"));

        // 페이징
        PaginationInfo paginationInfo = new PaginationInfo();
        paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
        paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
        paginationInfo.setPageSize(searchVO.getPageSize());

        searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
        searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
        searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        List<?> PhotoList = photoService.selectPhotoList(searchVO);
        model.addAttribute("resultList", PhotoList);

        int totCnt = photoService.selectPhotoListTotCnt(searchVO);
        paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        model.addAttribute("searchVO", searchVO);

        return "egovframework/mbl/com/mpa/EgovPhotoList";
    }

    /** 사진 상세정보 조회 Service interface 호출 및 결과를 반환한다. */
    @RequestMapping(value = "/mbl/com/mpa/selectPhoto.mdo")
    public String selectPhoto(@ModelAttribute("searchVO") PhotoVO searchVO,
            Photo photo, ModelMap model) throws Exception {

        Photo vo = photoService.selectPhoto(photo);
        model.addAttribute("result", vo);
        model.addAttribute("searchVO", searchVO);

        return "egovframework/mbl/com/mpa/EgovPhotoDetail";
    }

    /** 사진 정보 수정 화면으로 이동한다. */
    @RequestMapping(value = "/mbl/com/mpa/goPhotoUpdt.mdo")
    public String goPhotoUpdt(@ModelAttribute("searchVO") PhotoVO searchVO,
            Photo photo, ModelMap model) throws Exception {

        Photo vo = photoService.selectPhoto(photo);
        model.addAttribute("photo", vo);

        return "egovframework/mbl/com/mpa/EgovPhotoUpdt";
    }

    /** 사진 정보 수정 Service interface 호출 및 결과를 반환한다. */
    @RequestMapping(value = "/mbl/com/mpa/updatePhoto.mdo")
    public String updatePhoto(final MultipartHttpServletRequest multiRequest,
            @ModelAttribute("searchVO") PhotoVO searchVO,
            @Valid @ModelAttribute("photo") Photo photo, BindingResult bindingResult,
            ModelMap model) throws Exception {

    	// 소유권 확인 : 등록자 본인만 수정 가능
    	EgovOwnerCheck.checkOwner(photoService.selectPhoto(photo), Photo::getMberId);

        if (bindingResult.hasErrors()) {
            return "egovframework/mbl/com/mpa/EgovPhotoUpdt";
        }

        // 첨부파일 관련 첨부파일ID 생성
        List<FileVO> _result = null;
        String _atchFileId = "";

        final Map<String, MultipartFile> files = multiRequest.getFileMap();

        if (!files.isEmpty()) {
            _result = fileUtil.parseFileInf(files, "MPA_", 0, "", "");
            _atchFileId = fileMngService.insertFileInfs(_result); // 파일이 생성되고나면 생성된 첨부파일 ID를 리턴한다.
        }

        // 리턴받은 첨부파일ID를 셋팅한다..
        if (_atchFileId != null) {
            photo.setAtchFileId(_atchFileId); // 첨부파일 ID
        }

        // 로그인VO에서 사용자 정보 가져오기
        LoginVO loginVO =
            (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        String mberId = loginVO.getId();

        photo.setMberId(mberId);

        photoService.updatePhoto(photo);
        return "forward:/mbl/com/mpa/selectPhotoList.mdo";
    }

    /** 사진 정보 삭제 Service interface 호출 및 결과를 반환한다. */
    @RequestMapping(value = "/mbl/com/mpa/deletePhoto.mdo")
    public String deletePhoto(@ModelAttribute("searchVO") PhotoVO photoVO,
            Photo photo) throws Exception {

    	// 소유권 확인 : 등록자 본인만 삭제 가능
    	EgovOwnerCheck.checkOwner(photoService.selectPhoto(photo), Photo::getMberId);

    	// 로그인VO에서 사용자 정보 가져오기
        LoginVO loginVO =
            (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        String mberId = loginVO.getId();

        photo.setMberId(mberId);

        photoService.deletePhoto(photo);
        return "forward:/mbl/com/mpa/selectPhotoList.mdo";
    }
}
