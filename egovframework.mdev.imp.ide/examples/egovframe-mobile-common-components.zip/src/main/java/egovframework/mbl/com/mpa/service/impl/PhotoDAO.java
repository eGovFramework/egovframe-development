package egovframework.mbl.com.mpa.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.mbl.com.mpa.service.Photo;
import egovframework.mbl.com.mpa.service.PhotoVO;

/** 사진에 대한 DB상의 접근, 변경을 처리한다. / 사진에 대한 등록, 수정, 삭제, 조회 기능을 제공한다. */
@Repository("PhotoDAO")
public class PhotoDAO extends EgovComAbstractDAO {

    /** 사진 정보 DB 삭제 메서드 */
    public void deletePhoto(Photo photo) throws Exception {
        delete("PhotoDAO.deletePhoto", photo);
    }

    /** 사진 정보 DB 등록 메서드 */
    public void insertPhoto(Photo photo) throws Exception {
        insert("PhotoDAO.insertPhoto", photo);
    }

    /**
     * 사진 정보 상세 DB 조회 메서드
     * @return Photo 사진 정보
     */
    public Photo selectPhoto(Photo photo) throws Exception {
        return (Photo) selectOne("PhotoDAO.selectPhoto", photo);
    }

    /** 사진 목록 DB 조회 메서드 */
    public List<?> selectPhotoList(PhotoVO searchVO) throws Exception {
        return list("PhotoDAO.selectPhotoList", searchVO);
    }

    /** 사진 정보 DB 수정 메서드 */
    public void updatePhoto(Photo photo) throws Exception {
        update("PhotoDAO.updatePhoto", photo);
    }

    /** 사진 정보의 총 갯수를 조회한다. */
    public int selectPhotoListTotCnt(PhotoVO searchVO) throws Exception {
        return (Integer) selectOne(
            "PhotoDAO.selectPhotoListTotCnt", searchVO);
    }
}
