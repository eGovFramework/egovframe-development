package egovframework.mbl.com.mdi.service.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.egovframe.rte.psl.dataaccess.util.EgovMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import egovframework.com.cmm.service.EgovProperties;
import egovframework.com.cmm.util.EgovXmlUtil;
import egovframework.mbl.com.mdi.service.DeviceIdent;
import egovframework.mbl.com.mdi.service.DeviceIdentVO;
import egovframework.mbl.com.mdi.service.EgovDeviceIdentService;

import jakarta.annotation.Resource;

/** 모바일기기식별에 대한 Service Interface를 구현한다. / 모바일기기 식별정보에 대한 등록, 수정, 삭제, 조회 기능과 User-Agent값 조회, 모바일기기 정보 추출 기능을 제공한다. */
@Service("DeviceIdentService")
public class EgovDeviceIdentServiceImpl extends EgovAbstractServiceImpl implements EgovDeviceIdentService {
	/** Logger */
	private static final Logger LOGGER = LoggerFactory.getLogger(EgovDeviceIdentServiceImpl.class);

	/** DeviceIdentDAO */
	@Resource(name = "DeviceIdentDAO")
	private DeviceIdentDAO deviceIdentDAO;

	/** ID Generation */
	@Resource(name = "egovDeviceIdentIdGnrService")
	private EgovIdGnrService idgenService;

	/** 조회된 모바일 기기 정보를 삭제한다. */
	@Override
	public void deleteDeviceIdent(DeviceIdent deviceIdent) throws Exception {
		deviceIdentDAO.deleteDeviceIdent(deviceIdent);
	}

	/** 모바일 기기 정보를 등록한다. */
	@Override
	public void insertDeviceIdent(DeviceIdent deviceIdent) throws Exception {

		LOGGER.debug(deviceIdent.toString());

		int sn = idgenService.getNextIntegerId();

		deviceIdent.setSn(sn);
		deviceIdentDAO.insertDeviceIdent(deviceIdent);
	}

	/**
	 * 모바일 기기의 상세정보를 조회한다.
	 * @return deviceIdent 모바일 기기 정보
	 */
	@Override
	public DeviceIdent selectDeviceIdent(DeviceIdent deviceIdent) throws Exception {
		DeviceIdent ret = deviceIdentDAO.selectDeviceIdent(deviceIdent);
		return ret;
	}

	/** 모바일 기기 정보 목록을 조회한다. */
	@Override
	public List<?> selectDeviceIdentList(DeviceIdentVO searchVO) throws Exception {
		return deviceIdentDAO.selectDeviceIdentList(searchVO);
	}

	/** 조회된 모바일 기기 정보를 수정한다. */
	@Override
	public void updateDeviceIdent(DeviceIdent deviceIdent) throws Exception {
		deviceIdentDAO.updateDeviceIdent(deviceIdent);
	}

	/** 모바일 기기 정보의 총 갯수를 조회한다. */
	@Override
	public int selectDeviceIdentListTotCnt(DeviceIdentVO searchVO) throws Exception {
		return deviceIdentDAO.selectDeviceIdentListTotCnt(searchVO);
	}

	/** 모바일 기기 정보를 XML 파일로 생성한다. */
	@Override
	public void createDeviceIndentListToXML() throws Exception {

		// DOM 파서 생성
		DocumentBuilderFactory factory = EgovXmlUtil.newDocumentBuilderFactory();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.newDocument();

		Element rootElement = document.createElement("DeviceIdents");
		document.appendChild(rootElement);

		// 모바일 기기 정보 목록 읽기
		DeviceIdentVO searchVO = new DeviceIdentVO();
		searchVO.setFirstIndex(0);
		searchVO.setRecordCountPerPage(1000);
		List<?> deviceIdentList = selectDeviceIdentList(searchVO);

		// 모바일 기기 정보를 Document 변환
		for (int i = 0; i < deviceIdentList.size(); i++) {
			Element deviceIdentElement = document.createElement("DeviceIdent");

			EgovMap egovMap = (EgovMap) deviceIdentList.get(i);

			Element uagentInfoElement = document.createElement("UserAgent");
			uagentInfoElement.setTextContent((String) egovMap.get("uagentInfo"));
			deviceIdentElement.appendChild(uagentInfoElement);

			Element browserElement = document.createElement("Browser");
			browserElement.setTextContent((String) egovMap.get("browserNm"));
			deviceIdentElement.appendChild(browserElement);

			Element osElement = document.createElement("OS");
			osElement.setTextContent((String) egovMap.get("osNm"));
			deviceIdentElement.appendChild(osElement);

			rootElement.appendChild(deviceIdentElement);
		}

		// 파일로 저장하기
		TransformerFactory transformerFactory = EgovXmlUtil.newTransformerFactory();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

		String xmlPath = EgovProperties.getProperty(EgovProperties.getPathProperty("Globals.MDIConfPath"), "deviceIdentXMLPath");

		//KISA 보안 점검 결과 반영
		FileOutputStream out = null;
		OutputStreamWriter writer = null;

		try {
			out = new FileOutputStream(xmlPath);
			writer = new OutputStreamWriter(out, "utf-8");

			DOMSource source = new DOMSource(document);
			StreamResult result = new StreamResult(writer);
			transformer.transform(source, result);

		} catch (FileNotFoundException e) {
			LOGGER.debug("Fail to createDeviceIndentListToXML : FileNotFoundException");
		} catch (UnsupportedEncodingException e) {

			LOGGER.debug("Fail to createDeviceIndentListToXML : UnsupportedEncodingException");
		} catch (TransformerException e) {

			LOGGER.debug("Fail to createDeviceIndentListToXML : TransformerException");
		} catch (IOException e) {

			LOGGER.debug("Fail to createDeviceIndentListToXML : IOException");
		} finally {//2011.11.23  보안점검 결과 반영
			if (writer != null) {
				writer.close();
			}
			if (out != null) {
				out.close();
			}

		}

	}

	/**
	 * user-Agent 값에서 모바일기기 정보를 추출한다.
	 * @return DeviceIdent 모바일기기 정보
	 */
	@Override
	public DeviceIdent getDeviceIdentFromXML(String userAgent) throws Exception {

		DeviceIdent deviceIdent = null;

		DocumentBuilderFactory factory = EgovXmlUtil.newDocumentBuilderFactory();
		DocumentBuilder builder = factory.newDocumentBuilder();

		String xmlPath = EgovProperties.getProperty(EgovProperties.getPathProperty("Globals.MDIConfPath"), "deviceIdentXMLPath");

		if (!((new File(xmlPath)).isFile())) {
			return null;
		}

		Document document = builder.parse(new File(xmlPath));
		Element rootElement = document.getDocumentElement();
		NodeList deviceIdentElements = rootElement.getChildNodes();

		for (int i = 0; i < deviceIdentElements.getLength(); i++) {
			Node node = deviceIdentElements.item(i);

			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element deviceIdentElement = (Element) node;
				NodeList elements = deviceIdentElement.getChildNodes();

				Element uagentInfoElement = null;
				Element browserElement = null;
				Element osElement = null;

				for (int j = 0; j < elements.getLength(); j++) {
					Node childNode = elements.item(j);
					if (childNode.getNodeType() == Node.ELEMENT_NODE) {
						Element childElement = (Element) childNode;
						if (childElement.getNodeName().equalsIgnoreCase("UserAgent")) {
							uagentInfoElement = childElement;
						} else if (childElement.getNodeName().equalsIgnoreCase("Browser")) {
							browserElement = childElement;
						} else if (childElement.getNodeName().equalsIgnoreCase("OS")) {
							osElement = childElement;
						}
					}
				}

				if (uagentInfoElement != null && browserElement != null && osElement != null
						&& uagentInfoElement.getTextContent().equalsIgnoreCase(userAgent)) {
					deviceIdent = new DeviceIdent();
					deviceIdent.setUagentInfo(uagentInfoElement.getTextContent());
					deviceIdent.setBrowserNm(browserElement.getTextContent());
					deviceIdent.setOsNm(osElement.getTextContent());

					break;
				}
			}
		}

		return deviceIdent;
	}
}
