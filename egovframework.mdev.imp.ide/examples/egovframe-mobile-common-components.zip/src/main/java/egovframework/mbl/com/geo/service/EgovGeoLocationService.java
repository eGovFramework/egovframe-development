package egovframework.mbl.com.geo.service;

import java.util.Map;

/** 위치정보연계에 대한 Service Interface를 정의한다. / 건물의 위치정보에 대한 등록, 수정, 삭제, 상세조회 기능을 제공한다. */
public interface EgovGeoLocationService {

    /**
     * 건물의 위치정보 목록을 조회하는 Service interface 메서드
     * @return Map<String, Object> 주변건물 위치정보 리스트
     */
    public Map<String, Object> selectBuildingLocationInfoList(GeoLocationVO geoLocationVO) throws Exception;

    /**
     * 건물의 위치정보를 상세조회하는 Service interface 메서드
     * @return GeoLocation 주변건물 위치정보
     */
    public GeoLocation selectBuildingLocationInfo(GeoLocationVO geoLocationVO) throws Exception;

    /** 건물의 위치정보를 등록하는 Service interface 메서드 */
    public void insertBuildingLocationInfo(GeoLocation geoLocation) throws Exception;

    /** 건물의 위치정보를 수정하는 Service interface 메서드 */
    public void updateBuildingLocationInfo(GeoLocation geoLocation) throws Exception;

    /** 건물의 위치정보를 삭제하는 Service interface 메서드 */
    public void deleteBuildingLocationInfo(GeoLocation geoLocation) throws Exception;

}
