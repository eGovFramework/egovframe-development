package egovframework.mbl.com.uss.ion.ecc.web;

import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovOwnerCheck;
import egovframework.com.uss.ion.ecc.service.EgovEventCmpgnService;
import egovframework.com.uss.ion.ecc.service.EventCmpgnVO;
import egovframework.mbl.com.cmm.annotation.IncludedMblInfo;

import jakarta.annotation.Resource;

/** 행사/이벤트/캠페인을 처리하는 Controller Class 구현 */
@Controller
public class EgovMblEventCmpgnController {

	/** EgovMessageSource */
    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;

	@Resource(name = "egovEventCmpgnService")
	private EgovEventCmpgnService egovEventCmpgnService;

    // 페이지 설정
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

	@Resource(name="EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	/** 입력값 검증(Bean Validation) : 등록/수정 화면 조회와 저장(cmd=save)을 같이 처리하므로 저장 시에만 검증 */
	@Resource(name = "validator")
	private Validator validator;

    /** 개별 배포시 메인메뉴를 조회한다. */
    @RequestMapping(value="/uss/ion/ecc/EgovMain.mdo")
    public String EgovMain(ModelMap model) throws Exception {
    	return "egovframework/uss/ion/ecc/EgovMain";
    }

    /** 메뉴를 조회한다. */
    @RequestMapping(value="/uss/ion/ecc/EgovLeft.mdo")
    public String EgovLeft(ModelMap model) throws Exception {
    	return "egovframework/uss/ion/ecc/EgovLeft";
    }

	/** 행사/이벤트/캠페인 목록 팝업을 조회한다. */
	@RequestMapping(value="/uss/ion/ecc/EgovEventCmpgnListPopup.mdo")
	public String EgovEventCmpgnListPopup(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			EventCmpgnVO eventCmpgnVO,
			@RequestParam Map<?, ?> commandMap,
    		ModelMap model)
    throws Exception {

    	// 페이지 설정
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));

    	// 페이징
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        List<?> sampleList = egovEventCmpgnService.selectEventCmpgnList(searchVO);
        model.addAttribute("resultList", sampleList);

        model.addAttribute("searchKeyword", commandMap.get("searchKeyword") == null ? "" : (String)commandMap.get("searchKeyword"));
        model.addAttribute("searchCondition", commandMap.get("searchCondition") == null ? "" : (String)commandMap.get("searchCondition"));

        int totCnt = egovEventCmpgnService.selectEventCmpgnListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);

     	//공통코드  행사유형 조회
    	ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
    	voComCode.setCodeId("COM035");
    	List<?> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
    	model.addAttribute("comCode035", listComCode);

		return "egovframework/mbl/com/uss/ion/ecc/EgovEventCmpgnListPopup";

	}

	/** 행사/이벤트/캠페인 목록을 조회한다. */
	@IncludedMblInfo(name="행사/이벤트/캠페인",order = 214 ,gid = 20)
	@RequestMapping(value="/uss/ion/ecc/EgovEventCmpgnList.mdo")
	public String EgovEventCmpgnList(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			EventCmpgnVO eventCmpgnVO,
			@RequestParam Map<?, ?> commandMap,
    		ModelMap model)
    throws Exception {

    	// 페이지 설정
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));

    	// 페이징
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(10);
		paginationInfo.setPageSize(1);

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        List<?> sampleList = egovEventCmpgnService.selectEventCmpgnList(searchVO);
        model.addAttribute("resultList", sampleList);

        model.addAttribute("searchKeyword", commandMap.get("searchKeyword") == null ? "" : (String)commandMap.get("searchKeyword"));
        model.addAttribute("searchCondition", commandMap.get("searchCondition") == null ? "" : (String)commandMap.get("searchCondition"));

        int totCnt = egovEventCmpgnService.selectEventCmpgnListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);

     	//공통코드  행사유형 조회
    	ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
    	voComCode.setCodeId("COM035");
    	List<?> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
    	model.addAttribute("comCode035", listComCode);

		return "egovframework/mbl/com/uss/ion/ecc/EgovEventCmpgnList";

	}

	/** 행사/이벤트/캠페인 상세조회 한다. */
	@RequestMapping(value="/uss/ion/ecc/EgovEventCmpgnDetail.mdo")
	public String EgovEventCmpgnDetail(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			EventCmpgnVO eventCmpgnVO,
			@RequestParam Map<?, ?> commandMap,
    		ModelMap model)
    throws Exception {

		//로그인 객체 선언
		LoginVO loginVO = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();
		model.addAttribute("SUserSe", loginVO.getUserSe());

		String sLocationUrl = "egovframework/mbl/com/uss/ion/ecc/EgovEventCmpgnDetail";

		String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");

		if(sCmd.equals("del")){
			// 소유권 확인 : 등록자 본인만 삭제 가능
			checkEventOwner(eventCmpgnVO);
			egovEventCmpgnService.deleteEventCmpgn(eventCmpgnVO);
			sLocationUrl = "redirect:/uss/ion/ecc/EgovEventCmpgnList.mdo";
		}else{
	     	//공통코드  행사유형 조회
	    	ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
	    	voComCode.setCodeId("COM035");
	    	List<?> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
	    	model.addAttribute("comCode035", listComCode);

	        model.addAttribute("resultList", egovEventCmpgnService.selectEventCmpgnDetail(eventCmpgnVO));

		}

		return sLocationUrl;
	}

	/** 행사/이벤트/캠페인을 수정 한다. */
	@RequestMapping(value="/uss/ion/ecc/EgovEventCmpgnModify.mdo")
	public String EventCmpgnModify(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@ModelAttribute("eventCmpgnVO") EventCmpgnVO eventCmpgnVO,
			BindingResult bindingResult,
			@RequestParam Map<?, ?> commandMap,
    		ModelMap model)
    throws Exception {

		//로그인 객체 선언
		LoginVO loginVO = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();
		model.addAttribute("SUserSe", loginVO.getUserSe());

		String sLocationUrl = "egovframework/mbl/com/uss/ion/ecc/EgovEventCmpgnModify";

		String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");

     	//공통코드  행사유형 조회
    	ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
    	voComCode.setCodeId("COM035");
    	List<?> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
    	model.addAttribute("comCode035", listComCode);

        if(sCmd.equals("save")){
    		// 소유권 확인 : 등록자 본인만 수정 가능
    		checkEventOwner(eventCmpgnVO);

    		validator.validate(eventCmpgnVO, bindingResult);

    		if (bindingResult.hasErrors()){
                List<?> resultList = egovEventCmpgnService.selectEventCmpgnDetail(eventCmpgnVO);
                model.addAttribute("resultList", resultList);
    	        return sLocationUrl;
    		}
    		//아이디 설정
    		eventCmpgnVO.setFrstRegisterId(loginVO.getUniqId());
    		eventCmpgnVO.setLastUpdusrId(loginVO.getUniqId());

        	egovEventCmpgnService.updateEventCmpgn(eventCmpgnVO);
        	sLocationUrl = "redirect:/uss/ion/ecc/EgovEventCmpgnList.mdo";
        }else{

            List<?> resultList = egovEventCmpgnService.selectEventCmpgnDetail(eventCmpgnVO);

            Map<?, ?> cmpgnMap = (Map<?, ?>)resultList.get(0);

	        BeanUtils.populate(eventCmpgnVO, (Map<String, ? extends Object>) cmpgnMap);

            model.addAttribute("eventCmpgnVO", eventCmpgnVO);
        }

		return sLocationUrl;
	}

	/** 행사/이벤트/캠페인을 등록 한다. */
	@RequestMapping(value="/uss/ion/ecc/EgovEventCmpgnRegist.mdo")
	public String EventCmpgnRegist(
			@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@ModelAttribute("eventCmpgnVO") EventCmpgnVO eventCmpgnVO,
			BindingResult bindingResult,
			@RequestParam Map<?, ?> commandMap,
    		ModelMap model)
    throws Exception {

		//로그인 객체 선언
		LoginVO loginVO = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();
		model.addAttribute("SUserSe", loginVO.getUserSe());

		String sLocationUrl = "egovframework/mbl/com/uss/ion/ecc/EgovEventCmpgnRegist";

		String sCmd = commandMap.get("cmd") == null ? "" : (String)commandMap.get("cmd");

     	//공통코드  행사유형 조회
    	ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
    	voComCode.setCodeId("COM035");
    	List<?> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
    	model.addAttribute("comCode035", listComCode);

        if(sCmd.equals("save")){
    		validator.validate(eventCmpgnVO, bindingResult);

    		if(bindingResult.hasErrors()){
    	        return sLocationUrl;
    		}
    		//아이디 설정
    		eventCmpgnVO.setFrstRegisterId(loginVO.getUniqId());
    		eventCmpgnVO.setLastUpdusrId(loginVO.getUniqId());

        	egovEventCmpgnService.insertEventCmpgn(eventCmpgnVO);
        	sLocationUrl = "redirect:/uss/ion/ecc/EgovEventCmpgnList.mdo";
        }

		return sLocationUrl;
	}

	/**
	 * 소유권 확인 : 행사/이벤트/캠페인 등록자 본인만 수정/삭제할 수 있다.
	 * @param eventCmpgnVO 행사ID(eventId)
	 */
	private void checkEventOwner(EventCmpgnVO eventCmpgnVO) throws Exception {
		List<?> registered = egovEventCmpgnService.selectEventCmpgnDetail(eventCmpgnVO);
		EgovOwnerCheck.checkOwner(registered.isEmpty() ? null : (String) ((Map<?, ?>) registered.get(0)).get("frstRegisterId"));
	}
}
