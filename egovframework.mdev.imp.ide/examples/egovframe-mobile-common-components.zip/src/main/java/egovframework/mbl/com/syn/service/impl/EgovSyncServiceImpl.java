package egovframework.mbl.com.syn.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import egovframework.mbl.com.syn.service.EgovSyncService;
import egovframework.mbl.com.syn.service.Sync;
import egovframework.mbl.com.syn.service.SyncVO;

import jakarta.annotation.Resource;

/** 동기화 서비스에 대한 Service Interface를 구현한다. / 동기화 서비스에 대한 등록, 삭제, 조회 기능을 제공한다. */
@Service("SyncService")
public class EgovSyncServiceImpl extends EgovAbstractServiceImpl implements EgovSyncService {

	/** ID Generation */

	@Resource(name = "SyncDAO")
	private SyncDAO syncDAO;

	/** 동기화 서비스 글 총 갯수 */
	@Override
	public int selectSyncListTotCnt(SyncVO searchVO) throws Exception {
		int rtn = 0;

		rtn = syncDAO.selectSyncListTotCnt(searchVO);

		return rtn;
	}

	/** 동기화 서비스 글 목록 조회 */
	@Override
	public List<?> selectSyncList(SyncVO searchVO) throws Exception {
		List<?> rtnList = null;

		searchVO.setFetchRow(searchVO.getFetchRow() * 5);
		rtnList = syncDAO.selectSyncList(searchVO);

		return rtnList;
	}

	/** 동기화 서비스글 상세 조회 */
	@Override
	public Sync selectSync(SyncVO searchVO) throws Exception {
		Sync sync = null;

		sync = syncDAO.selectSync(searchVO);

		return sync;
	}

	/** 동기호 서비스 글 등록 */
	@Override
	public int insertSync(Sync sync) throws Exception {
		int rtn = 0;

		int newSn = syncDAO.selectSyncNewSn();
		sync.setSn(newSn);

		rtn = syncDAO.insertSync(sync);

		return rtn;
	}

	/** 동기화 서비스 글 삭제 */
	@Override
	public int deleteSync(Sync sync) throws Exception {
		int rtn = 0;

		rtn = syncDAO.deleteSync(sync);

		return rtn;

	}

	/** 동기화 서비스 글 수정 */
	@Override
	public int updateSync(Sync sync) throws Exception {
		int rtn = 0;

		rtn = syncDAO.updateSync(sync);

		return rtn;

	}

	/** 동기화 서비스 글 '동기화'를 실행 */
	@Override
	public int executeSync(Sync sync, String localData) throws Exception {
		int rtn = 0;

		String[] localDataArr = localData.split("∀");
		for (int i = 0; i < localDataArr.length; i++) {
			String[] syncDataArr = localDataArr[i].split("\\|");

			if ("I".equals(syncDataArr[0].toString())) {
				sync.setSyncSj(syncDataArr[2]);
				sync.setSyncCn(syncDataArr[3]);
				rtn = insertSync(sync);

			} else if ("U".equals(syncDataArr[0].toString())) {
				int updateSn = Integer.parseInt(syncDataArr[1]);

				sync.setSn(updateSn);
				sync.setSyncSj(syncDataArr[2]);
				sync.setSyncCn(syncDataArr[3]);
				rtn = updateSync(sync);

			} else if ("D".equals(syncDataArr[0].toString())) {
				int deleteSn = Integer.parseInt(syncDataArr[1]);

				sync.setSn(deleteSn);
				rtn = deleteSync(sync);

			}
		}

		return rtn;
	}
}
