package egovframework.mbl.com.syn.service;

import java.io.Serializable;

/** 동기화 서비스에 대한 VO 클래스를 정의한다. / 동기화 서비스 정보를 조회하기 위해 필요한 정보를 관리한다. */
@SuppressWarnings("serial")
public class SyncVO extends Sync implements Serializable {
	/** 첫페이지 인덱스 */
	private int firstIndex = 1;
	/** 마지막페이지 인덱스 */
	private int lastIndex = 1;
	/** 현재페이지 */
	private int pageIndex = 1;
	/** 페이지 사이즈 */
	private int pageSize = 10;
	/** 페이지 개수 */
	private int pageUnit = 10;
	/** 페이지당 레코드 개수 */
	private int recordCountPerPage = 10;
	/** 검색조건 */
	private String searchCondition = "";
	/** 검색단어 */
	private String searchKeyword = "";
	/** 검색사용여부 */
	private String searchUseYn = "";

	private int fetchRow = 0;

	private String deviceType = "";

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public int getFetchRow() {
		return fetchRow;
	}

	public void setFetchRow(int fetchRow) {
		this.fetchRow = fetchRow;
	}

	public int getFirstIndex() {
		return firstIndex;
	}

	public void setFirstIndex(int firstIndex) {
		this.firstIndex = firstIndex;
	}

	public int getLastIndex() {
		return lastIndex;
	}

	public void setLastIndex(int lastIndex) {
		this.lastIndex = lastIndex;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPageUnit() {
		return pageUnit;
	}

	public void setPageUnit(int pageUnit) {
		this.pageUnit = pageUnit;
	}

	public int getRecordCountPerPage() {
		return recordCountPerPage;
	}

	public void setRecordCountPerPage(int recordCountPerPage) {
		this.recordCountPerPage = recordCountPerPage;
	}

	public String getSearchCondition() {
		return searchCondition;
	}

	public void setSearchCondition(String searchCondition) {
		this.searchCondition = searchCondition;
	}

	public String getSearchKeyword() {
		return searchKeyword;
	}

	public void setSearchKeyword(String searchKeyword) {
		this.searchKeyword = searchKeyword;
	}

	public String getSearchUseYn() {
		return searchUseYn;
	}

	public void setSearchUseYn(String searchUseYn) {
		this.searchUseYn = searchUseYn;
	}

}
