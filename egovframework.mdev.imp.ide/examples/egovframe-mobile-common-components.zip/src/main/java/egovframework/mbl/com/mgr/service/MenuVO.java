package egovframework.mbl.com.mgr.service;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Size;

/** Menu VO class */

public class MenuVO {

	/** 메뉴코드 */
	private String menuCode;
	/** 메뉴명 */
	@EgovNullCheck(message = "{valid.MenuVO.menuNm.required}")
	@Size(max = 60, message = "{valid.MenuVO.menuNm.maxlength}")
	private String menuNm;
	/** 메뉴레벨 */
	private int menuLvl;
	/** 연결 URL */
	@Size(max = 255, message = "{valid.MenuVO.cnncUrl.maxlength}")
	private String cnncUrl;
	/** 설명 */
	@Size(max = 250, message = "{valid.MenuVO.menuDc.maxlength}")
	private String menuDc;
	/** 사용여부 */
	private Boolean actvtyAt;
	/** 상위 메뉴 */
	private String upperMenuId;
	/** 상위 메뉴 이름 */
	private String upperMenuNm;
	/** 최초등록일 */
	private String frstRegistPnttm;

	/** 최초등록자아이디 */
	private String frstRegisterId;

	private String lastUpdtPnttm;

	/** 최종수정자아이디 */
	private String lastUpdusrId;

	public String getMenuCode() {
		return menuCode;
	}

	public void setMenuCode(String menuCode) {
		this.menuCode = menuCode;
	}

	public String getMenuNm() {
		return menuNm;
	}

	public void setMenuNm(String menuNm) {
		this.menuNm = menuNm;
	}

	public int getMenuLvl() {
		return menuLvl;
	}

	public void setMenuLvl(int menuLvl) {
		this.menuLvl = menuLvl;
	}

	public String getCnncUrl() {
		return cnncUrl;
	}

	public void setCnncUrl(String cnncUrl) {
		this.cnncUrl = cnncUrl;
	}

	public String getMenuDc() {
		return menuDc;
	}

	public void setMenuDc(String menuDc) {
		this.menuDc = menuDc;
	}

	public Boolean getActvtyAt() {
		return actvtyAt;
	}

	public void setActvtyAt(Boolean actvtyAt) {
		this.actvtyAt = actvtyAt;
	}

	public String getUpperMenuId() {
		return upperMenuId;
	}

	public void setUpperMenuId(String upperMenuId) {
		this.upperMenuId = upperMenuId;
	}

	public String getUpperMenuNm() {
		return upperMenuNm;
	}

	public void setUpperMenuNm(String upperMenuNm) {
		this.upperMenuNm = upperMenuNm;
	}

	public void setFrstRegistPnttm(String frstRegistPnttm) {
		this.frstRegistPnttm = frstRegistPnttm;
	}

	public String getFrstRegistPnttm() {
		return frstRegistPnttm;
	}

	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}

	public String getFrstRegisterId() {
		return frstRegisterId;
	}

	public void setLastUpdtPnttm(String lastUpdtPnttm) {
		this.lastUpdtPnttm = lastUpdtPnttm;
	}

	public String getLastUpdtPnttm() {
		return lastUpdtPnttm;
	}

	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}

	public String getLastUpdusrId() {
		return lastUpdusrId;
	}

}
