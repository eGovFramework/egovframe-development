package egovframework.mbl.com.ows.service;

import java.util.List;

/** 오프라인웹 서비스에 대한 Service Interface를 정의한다. / 오프라인웹 서비스에 대한 등록, 삭제, 조회 기능을 제공한다. */

public interface EgovOfflineWebService {

	/** 오프라인웹 서비스 글 목록 조회 */
	public List<?> selectOfflineWebList(OfflineWebVO searchVO) throws Exception;

	/** 오프라인웹 서비스글 상세 조회 */
	public OfflineWeb selectOfflineWeb(OfflineWebVO searchVO) throws Exception;

	/** 동기호 서비스 글 등록 */
	public int insertOfflineWeb(OfflineWeb OfflineWeb) throws Exception;

	/** 오프라인웹 서비스 글 삭제 */
	public int deleteOfflineWeb(OfflineWebVO searchVO) throws Exception;

	/** 오프라인웹 서비스 글 수정 */
	public int updateOfflineWeb(OfflineWeb OfflineWeb) throws Exception;

	/** 오프라인웹 서비스 글 목록 총갯수 */
	public int selectOfflineWebListTotCnt(OfflineWebVO searchVO) throws Exception;

}
