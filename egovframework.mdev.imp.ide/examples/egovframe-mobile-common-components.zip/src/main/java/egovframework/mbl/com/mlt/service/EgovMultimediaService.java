package egovframework.mbl.com.mlt.service;

import java.util.List;

import egovframework.com.cmm.service.FileVO;

/** 멀티미디어 제어에 대한 Service Interface를 정의한다. / 멀티미디어에 대한 등록, 수정, 삭제, 조회 기능을 제공한다. */

public interface EgovMultimediaService {

    /** 멀티미디어 정보를 삭제하는 Service interface 메서드 * */
    public void deleteMultimedia(Multimedia multimedia) throws Exception;

    /** 멀티미디어 정보를 등록하는 Service interface 메서드 */
    public void insertMultimedia(Multimedia multimedia) throws Exception;

    /**
     * 멀티미디어 상세정보를 조회하는 Service interface 메서드
     * @return multimedia 멀티미디어 정보
     */
    public Multimedia selectMultimedia(Multimedia multimedia) throws Exception;

    /** 멀티미디어 목록을 조회하는 Service interface 메서드 */
    public List<?> selectMultimediaList(MultimediaVO searchVO) throws Exception;

    /** 멀티미디어 정보를 수정하는 Service interface 메서드 */
    public void updateMultimedia(Multimedia multimedia) throws Exception;

    /** 멀티미디어 정보의 총 갯수를 조회한다. */
    public int selectMultimediaListTotCnt(MultimediaVO searchVO)
            throws Exception;

    /** 멀티미디어 파일을 상대 경로에 저장한다. */
    public void copyFileToRelativePath(List<FileVO> fileList) throws Exception;

    /** 파일별 지원 브라우저 정보를 조회한다. */
    public List<MultimediaFileInfo> getMultimediaFileInfoFromXML()
            throws Exception;

    /**
     * 지원 브라우저 정보를 조회한다.
     * @param List <String> 확장자
     */
    public String getBrowserInfoFromXML(String mltmdNm, List<String> extList)
            throws Exception;

    /** 멀티미디어 파일의 확장자를 검사한다. */
    public boolean checkMultimediaFileExtension(List<FileVO> fileList) throws Exception;

}
