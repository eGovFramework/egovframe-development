package egovframework.mbl.com.uss.olh.omm.web;

import java.net.URLDecoder;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.uss.olh.omm.service.EgovOnlineManualService;
import egovframework.com.uss.olh.omm.service.OnlineManual;
import egovframework.mbl.com.cmm.annotation.IncludedMblInfo;

import jakarta.annotation.Resource;

/** 온라인메뉴얼를 처리하는 Controller Class 구현 */
@Controller
public class EgovMblOnlineManualController {

    /** EgovMessageSource */
    @Resource(name = "egovMessageSource")
    EgovMessageSource egovMessageSource;

    /** egovOnlinePollService */
    @Resource(name = "egovOnlineManualService")
    private EgovOnlineManualService egovOnlineManualService;

    // 페이지 설정
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /** Egov Common Code Service */
    @Resource(name="EgovCmmUseService")
    private EgovCmmUseService cmmUseService;

    /** json데이터를 호출하기 위한 페이지를 호출한다. */
    @IncludedMblInfo(name="온라인매뉴얼",order = 209 ,gid = 20)
    @RequestMapping(value="/uss/olh/omm/listOnlineManual.mdo")
    public String mainBoard(@ModelAttribute("searchVO") ComDefaultVO searchVO, @RequestParam Map<?, ?> commandMap,
            OnlineManual onlineManual, ModelMap model)
    throws Exception {
		model.addAttribute("searchVO", searchVO);
		model.addAttribute("onlineMnlId", commandMap.get("onlineMnlId") == null ? "" : (String) commandMap.get("onlineMnlId"));

		return "egovframework/mbl/com/uss/olh/omm/EgovOnlineManualList";

    }

    /** 사용자 온라인메뉴얼 조회한다. */
    @RequestMapping(value = "/uss/olh/omm/setOnlineManual.mdo")
    public String EgovOnlineManualUserDetail(
            @RequestParam Map<?, ?> commandMap,
            ModelMap model) throws Exception {

        String sLocationUrl = "egovframework/mbl/com/uss/olh/omm/EgovOnlineManual";

        model.addAttribute("onlineMnlId", commandMap.get("onlineMnlId") == null ? "" : (String) commandMap.get("onlineMnlId"));

        return sLocationUrl;
    }

    /** 사용자 온라인메뉴얼 목록을 조회한다. */
    @SuppressWarnings("unused")
	@RequestMapping(value = "/uss/olh/omm/listOnlineManualView.mdo")
    public ModelAndView EgovOnlineManualUserList(
            @ModelAttribute("searchVO") ComDefaultVO searchVO, @RequestParam Map<?, ?> commandMap,
            OnlineManual onlineManual, ModelMap model)
            throws Exception {
    	ModelAndView modelAndView = new ModelAndView("jsonView");

    	searchVO.setSearchKeyword(URLDecoder.decode(searchVO.getSearchKeyword(), "UTF-8"));

        String sSearchMode = commandMap.get("searchMode") == null ? "" : (String) commandMap.get("searchMode");

        // 페이지 설정
        searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
        searchVO.setPageSize(propertiesService.getInt("pageSize"));

        // 페이징
        PaginationInfo paginationInfo = new PaginationInfo();
        paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
        paginationInfo.setRecordCountPerPage(10);
        paginationInfo.setPageSize(1);

        searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
        searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
        searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        List<?> reusltList = egovOnlineManualService.selectOnlineManualList(searchVO);
        modelAndView.addObject("reusltList", reusltList);
		modelAndView.addObject("listSize", reusltList.size());

        modelAndView.addObject("searchKeyword", commandMap.get("searchKeyword") == null ? "" : (String) commandMap.get("searchKeyword"));
        modelAndView.addObject("searchCondition", commandMap.get("searchCondition") == null ? "" : (String) commandMap.get("searchCondition"));

        int totCnt = egovOnlineManualService.selectOnlineManualListCnt(searchVO);
        paginationInfo.setTotalRecordCount(totCnt);
        modelAndView.addObject("paginationInfo", paginationInfo);
        //온라인메뉴얼 구분 설정
        ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
        voComCode = new ComDefaultCodeVO();

        voComCode.setCodeId("COM041");
        List<?> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);

        modelAndView.addObject("onlineMnlSeCodeList", listComCode );
        return modelAndView;
    }

    /** 사용자 온라인메뉴얼 목록을 상세조회 조회한다. */
    @SuppressWarnings("unused")
	@RequestMapping(value = "/uss/olh/omm/detailOnlineManual.mdo")
    public String EgovOnlineManualUserDetail(
            @ModelAttribute("searchVO") ComDefaultVO searchVO,
            OnlineManual onlineManual, @RequestParam Map<?, ?> commandMap,
            @RequestParam("onlineMnlId") String onlineMnlId ,
            ModelMap model) throws Exception {

    	onlineManual.setOnlineMnlId(onlineMnlId);

        String sCmd = commandMap.get("cmd") == null ? "" : (String) commandMap.get("cmd");

        OnlineManual reusltList = egovOnlineManualService.selectOnlineManualDetail(onlineManual);
        model.addAttribute("onlineManual", reusltList);

        //온라인메뉴얼 구분 설정
        ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
        voComCode = new ComDefaultCodeVO();
        voComCode.setCodeId("COM041");
        voComCode.setCodeNm(reusltList.getOnlineMnlSeCode());
        List<?> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
        model.addAttribute("onlineMnlSeCodeList", listComCode );
        model.addAttribute("searchVO", searchVO );

        return "egovframework/mbl/com/uss/olh/omm/EgovOnlineManualDetail";

    }
}
