package egovframework.mbl.com.rns.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.mbl.com.rns.service.RealtimeNotice;
import egovframework.mbl.com.rns.service.RealtimeNoticeVO;

/** 실시간 공지 서비스에 대한 DB상의 접근, 변경을 처리한다. / 실시간 공지 서비스에 대한 등록, 삭제, 조회 기능을 제공한다. */
@Repository("RealtimeNoticeDAO")
public class RealtimeNoticeDAO extends EgovComAbstractDAO {

	/** [관리자] 실시간공지서비스 NEW 일련번호 조회 */
	public int selectRealtimeNoticeNewSn() throws Exception {
		return (Integer)selectOne("RealtimeNoticeDAO.selectRealtimeNoticeNewSn", "");
	}

	/** [관리자] 실시간공지서비스 목록 조회 */
	public List<?> selectRealtimeNoticeList(RealtimeNoticeVO searchVO) throws Exception {
		return list("RealtimeNoticeDAO.selectRealtimeNoticeList", searchVO);
	}

	/** [관리자/사용자] 실시간공지서비스 상세조회 / 실시간공지 서비스 내용 */
	public RealtimeNotice selectRealtimeNotice(RealtimeNoticeVO searchVO) throws Exception {
		return (RealtimeNotice) selectOne("RealtimeNoticeDAO.selectRealtimeNotice", searchVO);
	}

	/** [관리자] 실시간공지서비스 등록 */
	public int insertRealtimeNotice(RealtimeNotice realtimeNotice) throws Exception {
		return update("RealtimeNoticeDAO.insertRealtimeNotice", realtimeNotice);
	}

	/** 실시간공지서비스 SN 최신구분 변경 */

	/** [관리자] 실시간공지서비스 삭제 */
	public int deleteRealtimeNotice(RealtimeNotice searchVO) throws Exception {
		return delete("RealtimeNoticeDAO.deleteRealtimeNotice", searchVO);
	}

	/** 실시간 공지서비스 메시지 조회 */
	public RealtimeNotice selectRealtimeNoticeMsg() throws Exception {
		return (RealtimeNotice) selectOne("RealtimeNoticeDAO.selectRealtimeNoticeMsg", "");
	}
}
