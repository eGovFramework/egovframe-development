package egovframework.mbl.com.mpa.service;

import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Size;

/** 사진에 대한 Model 클래스를 정의한다. / 사진 정보를 관리한다. */

public class Photo implements Serializable {

	private static final long serialVersionUID = 6877483374404693898L;
	/** 순번 */
    private int sn;
    /** 회원 아이디 */
    private String mberId;
    /** 사진 제목 */
    @EgovNullCheck(message = "{valid.Photo.photoSj.required}")
    @Size(max = 100, message = "{valid.Photo.photoSj.maxlength}")
    private String photoSj;
    /** 사진 파일 아이디 */
    private String atchFileId;
    /** 생성일시 */
    private String creatDt;
    private String updtDt;

    public int getSn() {
        return sn;
    }

    public void setSn(int sn) {
        this.sn = sn;
    }

    public String getMberId() {
        return mberId;
    }

    public void setMberId(String mberId) {
        this.mberId = mberId;
    }

    public String getPhotoSj() {
        return photoSj;
    }

    public void setPhotoSj(String photoSj) {
        this.photoSj = photoSj;
    }

    public String getAtchFileId() {
        return atchFileId;
    }

    public void setAtchFileId(String atchFileId) {
        this.atchFileId = atchFileId;
    }

    public String getCreatDt() {
        return creatDt;
    }

    public void setCreatDt(String creatDt) {
        this.creatDt = creatDt;
    }

    public String getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(String updtDt) {
        this.updtDt = updtDt;
    }
}
