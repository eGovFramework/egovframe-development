package egovframework.mbl.com.mgr.service;

import java.util.Map;

/** 모바일 템플릿을 위한 서비스 인터페이스 */

public interface EgovMobileMenuService {

	public void deleteMenu(MenuVO vo) throws Exception;

	public MenuVO selectMenuDetail(MenuVO vo) throws Exception;

	public Map<String, Object> selectUseList(MenuVO vo) throws Exception;

	public Map<String, Object> selectMenuList(MenuVO vo) throws Exception;

	public void insertMenu(MenuVO vo) throws Exception;

	public void updateMenu(MenuVO vo) throws Exception;

	public Map<String, Object> selectUpperMenuList(MenuVO menuVO) throws Exception;

}
