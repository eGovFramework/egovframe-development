package egovframework.mbl.com.rns.service;

import java.io.Serializable;

/** 실시간 공지 서비스에 대한 Model 클래스를 정의한다. / 실시간 공지 서비스 정보를 관리한다. */
@SuppressWarnings("serial")
public class RealtimeNotice implements Serializable {

	/** 실시간 공지 서비스 일련번호 */
	private int sn = 0;

	/** 회원ID */
	private String mberId = "";

	/** 실시간 공지 제목 */
	private String noticeSj = "";

	/** 실시간 공지 내용 */
	private String noticeCn = "";

	/** 최신구분명 */
	private String recentNm = "";

	/** 실시간 공지 시작일시 */
	private String noticeBgnDt = "";

	/** 실시간 공지 종료일시 */
	private String noticeEndDt = "";

	/** 실시간 공지 생성일시 */
	private String creatDt = "";

	private String updtDt = "";

	/** 최신구분 코드 ID */
	private String recentCodeId = "";

	/** 최신구분 코드 */
	private String recentCode = "";

	public int getSn() {
		return sn;
	}
	public String getMberId() {
		return mberId;
	}
	public String getNoticeSj() {
		return noticeSj;
	}
	public String getNoticeCn() {
		return noticeCn;
	}

	public String getRecentNm() {
		return recentNm;
	}

	public String getNoticeBgnDt() {
		return noticeBgnDt;
	}

	public String getNoticeEndDt() {
		return noticeEndDt;
	}

	public String getCreatDt() {
		return creatDt;
	}

	public String getUpdtDt() {
		return updtDt;
	}

	public String getRecentCodeId() {
		return recentCodeId;
	}

	public String getRecentCode() {
		return recentCode;
	}

	public void setSn(int sn) {
		this.sn = sn;
	}

	public void setMberId(String mberId) {
		this.mberId = mberId;
	}

	public void setNoticeSj(String noticeSj) {
		this.noticeSj = noticeSj;
	}

	public void setNoticeCn(String noticeCn) {
		this.noticeCn = noticeCn;
	}

	public void setRecentNm(String recentNm) {
		this.recentNm = recentNm;
	}

	public void setNoticeBgnDt(String noticeBgnDt) {
		this.noticeBgnDt = noticeBgnDt;
	}

	public void setNoticeEndDt(String noticeEndDt) {
		this.noticeEndDt = noticeEndDt;
	}

	public void setCreatDt(String creatDt) {
		this.creatDt = creatDt;
	}

	public void setUpdtDt(String updtDt) {
		this.updtDt = updtDt;
	}

	public void setRecentCodeId(String recentCodeId) {
		this.recentCodeId = recentCodeId;
	}

	public void setRecentCode(String recentCode) {
		this.recentCode = recentCode;
	}
}
