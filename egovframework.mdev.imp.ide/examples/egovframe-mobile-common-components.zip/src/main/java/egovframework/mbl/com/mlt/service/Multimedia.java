package egovframework.mbl.com.mlt.service;

import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Size;

/** 멀티미디어제어에 대한 model을 정의한다. / 멀티미디어 정보를 관리한다. */

public class Multimedia implements Serializable {

	private static final long serialVersionUID = 8813567125238782151L;
	/** 순번 */
    private int sn;
    /** 회원ID */
    private String mberId;
    /** 멀티미디어파일(첨부파일) 구분 코드 */
    @EgovNullCheck(message = "{valid.Multimedia.mltmdCode.required}")
    private String mltmdCode;
    /** 멀티미디어파일(첨부파일) 구분명 - 동영상파일, 음악파일.. */
    private String mltmdNm;
    /** 멀티미디어 제목 */
    @EgovNullCheck(message = "{valid.Multimedia.mltmdSj.required}")
    @Size(max = 100, message = "{valid.Multimedia.mltmdSj.maxlength}")
    private String mltmdSj;
    /** 멀티미디어파일(첨부파일)ID */
    private String atchFileId;
    /** 멀티미디어 지원 브라우저명 */
    private String browserNm;
    /** 생성일시 */
    private String creatDt;
    private String updtDt;

    public int getSn() {
        return sn;
    }

    public void setSn(int sn) {
        this.sn = sn;
    }

    public String getMberId() {
        return mberId;
    }

    public void setMberId(String mberId) {
        this.mberId = mberId;
    }

    public String getMltmdCode() {
        return mltmdCode;
    }

    public void setMltmdCode(String mltmdCode) {
        this.mltmdCode = mltmdCode;
    }

    public String getMltmdNm() {
        return mltmdNm;
    }

    public void setMltmdNm(String mltmdNm) {
        this.mltmdNm = mltmdNm;
    }

    public String getMltmdSj() {
        return mltmdSj;
    }

    public void setMltmdSj(String mltmdSj) {
        this.mltmdSj = mltmdSj;
    }

    public String getAtchFileId() {
        return atchFileId;
    }

    public void setAtchFileId(String atchFileId) {
        this.atchFileId = atchFileId;
    }

    public String getBrowserNm() {
        return browserNm;
    }

    public void setBrowserNm(String browserNm) {
        this.browserNm = browserNm;
    }

    public String getCreatDt() {
        return creatDt;
    }

    public void setCreatDt(String creatDt) {
        this.creatDt = creatDt;
    }

    public String getUpdtDt() {
        return updtDt;
    }

    public void setUpdtDt(String updtDt) {
        this.updtDt = updtDt;
    }
}
