package egovframework.mbl.com.oas.service;

import java.util.Date;

/** OpenAPI연계에 대한 model을 정의한다. / OpenAPI연계 정보를 관리한다. */
public class OpenApi {

    /** 순번 */
    private int sn;

    /** 회원ID */
    private String mberId;

    /** OpenAPI서비스명 */
    private String openApiSvcNm;

    /** OpenAPI 제공 기관명 */
    private String openApiProvdInsttNm;

    /** 서비스내용 */
    private String openApiSvcCn;

    /** 수집일시 */
    private Date collectDt;

    public int getSn(){
        return sn;
    }

    public String getMberId(){
        return mberId;
    }

    public String getOpenApiSvcNm(){
        return openApiSvcNm;
    }

    public String getOpenApiProvdInsttNm(){
        return openApiProvdInsttNm;
    }

    public String getOpenApiSvcCn(){
        return openApiSvcCn;
    }

    public Date getCollectDt(){
        return collectDt;
    }

    public void setSn(int sn){
        this.sn = sn;
    }

    public void setMberId(String mberId){
        this.mberId = mberId;
    }

    public void setOpenApiSvcNm(String openApiSvcNm){
        this.openApiSvcNm = openApiSvcNm;
    }

    public void setOpenApiProvdInsttNm(String openApiProvdInsttNm){
        this.openApiProvdInsttNm = openApiProvdInsttNm;
    }

    public void setOpenApiSvcCn(String openApiSvcCn){
        this.openApiSvcCn = openApiSvcCn;
    }

    public void setCollectDt(Date collectDt){
        this.collectDt = collectDt;
    }
}
