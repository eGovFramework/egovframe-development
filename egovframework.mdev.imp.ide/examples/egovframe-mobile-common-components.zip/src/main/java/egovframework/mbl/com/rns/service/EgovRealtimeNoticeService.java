package egovframework.mbl.com.rns.service;

import java.util.List;

/** 실시간 공지 서비스에 대한 Service Interface를 정의한다. / 실시간 공지 서비스에 대한 등록, 삭제, 조회 기능을 제공한다. */
public interface EgovRealtimeNoticeService {

	/** [관리자] 실시간공지서비스 목록 조회 */
	public List<?> selectRealtimeNoticeList(RealtimeNoticeVO searchVO) throws Exception;

	/** [관리자/사용자] 실시간공지서비스 상세조회 / 실시간공지 서비스 내용 */
	public RealtimeNotice selectRealtimeNotice(RealtimeNoticeVO searchVO) throws Exception;

	/** [관리자] 실시간공지서비스 등록 */
	public int insertRealtimeNotice(RealtimeNotice realtimeNotice) throws Exception;

	/** [관리자] 실시간공지서비스 삭제 */
	public int deleteRealtimeNotice(RealtimeNoticeVO searchVO) throws Exception;

	/** 실시간공지서비스 메시지 조회 */
	public RealtimeNotice selectRealtimeNoticeMsg() throws Exception;

}
