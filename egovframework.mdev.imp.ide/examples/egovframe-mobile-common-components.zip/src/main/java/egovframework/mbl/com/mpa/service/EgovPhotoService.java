package egovframework.mbl.com.mpa.service;

import java.util.List;

/** 사진 앨범에 대한 Service Interface를 정의한다. / 사진에 대한 등록, 수정, 삭제, 조회 기능을 제공한다. */

public interface EgovPhotoService {

    /** 사진 정보를 삭제하는 Service interface 메서드 * */
    public void deletePhoto(Photo photo) throws Exception;

    /** 사진 정보를 등록하는 Service interface 메서드 */
    public void insertPhoto(Photo photo) throws Exception;

    /**
     * 사진 상세정보를 조회하는 Service interface 메서드
     * @return Photo 사진 정보
     */
    public Photo selectPhoto(Photo photo) throws Exception;

    /** 사진 목록을 조회하는 Service interface 메서드 */
    public List<?> selectPhotoList(PhotoVO searchVO) throws Exception;

    /** 사진 정보를 수정하는 Service interface 메서드 */
    public void updatePhoto(Photo photo) throws Exception;

    /** 사진 정보의 총 갯수를 조회한다. */
    public int selectPhotoListTotCnt(PhotoVO searchVO) throws Exception;
}
