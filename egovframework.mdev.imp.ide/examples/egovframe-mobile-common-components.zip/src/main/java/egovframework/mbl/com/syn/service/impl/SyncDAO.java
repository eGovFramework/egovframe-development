package egovframework.mbl.com.syn.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.mbl.com.syn.service.Sync;
import egovframework.mbl.com.syn.service.SyncVO;

/** 동기화 서비스에 대한 DB상의 접근, 변경을 처리한다. / 동기화 서비스에 대한 등록, 수정, 삭제, 조회 기능을 제공한다. */
@Repository("SyncDAO")
public class SyncDAO extends EgovComAbstractDAO {

	/** 동기화 서비스 신규 일련번호 조회 */
	public int selectSyncNewSn() throws Exception {
		return (Integer)selectOne("SyncDAO.selectSyncNewSn", "");
	}

	/** 동기화 서비스 글 총 갯수 조회 */
	public int selectSyncListTotCnt(SyncVO searchVO) throws Exception {
		return (Integer)selectOne("SyncDAO.selectSyncTotCnt", searchVO);
	}

	/** 동기화 서비스 목록 조회 */
	@SuppressWarnings("rawtypes")
	public List selectSyncList(SyncVO searchVO) throws Exception {
		return list("SyncDAO.selectSyncList", searchVO);
	}

	/** 동기화 서비스 상세 조회 */
	public Sync selectSync(SyncVO searchVO) throws Exception {
		return (Sync) selectOne("SyncDAO.selectSync", searchVO);
	}

	/** 동기화 서비스 등록 */
	public int insertSync(Sync Sync) throws Exception {
		return update("SyncDAO.insertSync", Sync);
	}

	/** 동기화 서비스 수정 */
	public int updateSync(Sync sync) throws Exception {
		return update("SyncDAO.updateSync", sync);
	}

	/** 동기화 서비스 수정 */
	public int deleteSync(Sync searchVO) throws Exception {
		return delete("SyncDAO.deleteSync", searchVO);
	}

}
