package egovframework.mbl.com.syn.service;
import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Size;

/** 동기화 서비스에 대한 Model 클래스를 정의한다. / 동기화 서비스 정보를 관리한다. */
@SuppressWarnings("serial")
public class Sync implements Serializable {

	/** 동기화 서비스 일련번호 */
	private int sn = 0;

	/** 동기화 서비스 회원ID */
	private String mberId = "";

	/** 동기화 서비스 제목 */
	@EgovNullCheck(message = "{valid.Sync.syncSj.required}")
	@Size(max = 100, message = "{valid.Sync.syncSj.maxlength}")
	private String syncSj = "";

	/** 동기화 서비스 내용 */
	@EgovNullCheck(message = "{valid.Sync.syncCn.required}")
	@Size(max = 512, message = "{valid.Sync.syncCn.maxlength}")
	private String syncCn = "";

	/** 동기화 서비스 동기일시 */
	private String syncDt = "";

	/** 동기화 서비스 생성일시 */
	private String creatDt = "";

	private String updtDt = "";

	public int getSn() {
		return sn;
	}

	public String getMberId() {
		return mberId;
	}

	public String getSyncSj() {
		return syncSj;
	}

	public String getSyncCn() {
		return syncCn;
	}

	public String getSyncDt() {
		return syncDt;
	}

	public String getCreatDt() {
		return creatDt;
	}

	public String getUpdtDt() {
		return updtDt;
	}

	public void setSn(int sn) {
		this.sn = sn;
	}

	public void setMberId(String mberId) {
		this.mberId = mberId;
	}

	public void setSyncSj(String syncSj) {
		this.syncSj = syncSj;
	}

	public void setSyncCn(String syncCn) {
		this.syncCn = syncCn;
	}

	public void setSyncDt(String syncDt) {
		this.syncDt = syncDt;
	}

	public void setCreatDt(String creatDt) {
		this.creatDt = creatDt;
	}

	public void setUpdtDt(String updtDt) {
		this.updtDt = updtDt;
	}
}
