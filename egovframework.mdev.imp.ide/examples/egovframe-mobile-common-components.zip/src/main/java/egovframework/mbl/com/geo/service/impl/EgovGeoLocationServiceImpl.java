package egovframework.mbl.com.geo.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.mbl.com.geo.service.EgovGeoLocationService;
import egovframework.mbl.com.geo.service.GeoLocation;
import egovframework.mbl.com.geo.service.GeoLocationVO;

import jakarta.annotation.Resource;

/** 위치정보연계에 대한 Service Interface를 구현한다. / 건물의 위치정보에 대한 등록, 수정, 삭제, 상세조회 기능을 제공한다. */
@Service("EgovGeoLocationService")
public class EgovGeoLocationServiceImpl extends EgovAbstractServiceImpl implements EgovGeoLocationService {

    /** GeoLocationDAO */
    @Resource(name="geoLocationDAO")
    private GeoLocationDAO geoLocationDAO;

    /** ID Generation */
    @Resource(name="egovGeoLocationIdGnrService")
    private EgovIdGnrService idgenService;

    /**
     * 건물의 위치정보 목록을 조회한다.
     * @return Map<String, Object> 건물 위치정보 조회결과 리스트, 조회건수
     */
    public Map<String, Object> selectBuildingLocationInfoList(GeoLocationVO geoLocationVO) throws Exception {
        List<GeoLocationVO> result = geoLocationDAO.selectBuildingLocationInfoList(geoLocationVO);

        int cnt = geoLocationDAO.selectBuildingLocationInfoListCnt(geoLocationVO);

        Map<String, Object> map = new HashMap<String, Object>();

        map.put("resultList", result);
        map.put("resultCnt", Integer.toString(cnt));

        return map;
    }

    /**
     * 건물의 위치정보를 조회한다.
     * @return Geolocation 건물의 위치정보
     */
    public GeoLocation selectBuildingLocationInfo(GeoLocationVO geoLocationVO) throws Exception {
        return geoLocationDAO.selectBuildingLocationInfo(geoLocationVO);
    }

    /** 건물의 위치정보를 DB에 등록한다. */
    public void insertBuildingLocationInfo(GeoLocation geoLocation) throws Exception {
        int sn = idgenService.getNextIntegerId();

        geoLocation.setSn(sn);
        geoLocationDAO.insertBuildingLocationInfo(geoLocation);
    }

    /** 건물의 위치정보를 수정한다. */
    public void updateBuildingLocationInfo(GeoLocation geoLocation) throws Exception {
        geoLocationDAO.updateBuildingLocationInfo(geoLocation);
    }

    /** 건물의 위치정보를 삭제한다. */
    public void deleteBuildingLocationInfo(GeoLocation geoLocation) throws Exception {
        geoLocationDAO.deleteBuildingLocationInfo(geoLocation);
    }
}
