<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%-- WAS 에러 화면 (web.xml 의 error-page : 404, 405, 500 등 컨트롤러 밖에서 발생한 오류). 예외 메시지 · 상태 정보는 노출하지 않는다. --%>
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="data:," />
	<title>Error</title>
	<link rel="stylesheet" type="text/css" href="<c:url value='/css/component/output.css'/>" />
	<link rel="stylesheet" type="text/css" href="<c:url value='/css/egovframe.css'/>" />
</head>

<body>

<header class="sample-header">
	<div class="inner">
		<h1 class="header-title"><a href="<c:url value='/'/>"><spring:message code="title.sample" /></a></h1>
	</div>
</header>

<main id="container" class="inner">
	<div class="error-wrap" role="alert">
		<p class="error-msg"><spring:message code="fail.common.msg" /></p>
		<a href="<c:url value='/'/>" class="krds-btn large"><spring:message code="button.list" /></a>
	</div>
</main>

<footer class="sample-footer">
	<div class="inner">
		<p>eGovFrame Mobile Sample</p>
	</div>
</footer>

</body>
</html>
