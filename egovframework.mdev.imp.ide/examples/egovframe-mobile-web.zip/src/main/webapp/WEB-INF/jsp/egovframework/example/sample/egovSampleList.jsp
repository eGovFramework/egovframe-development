<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%--
  게시판 목록 화면

  @Modification Information
   수정일      수정자    수정내용
   ----------  --------  ----------------------------------------
   2009.02.01            최초 생성
   2026.10.29  유지보수  web-sample 현행화 (목록 조회·검색·페이지 이동 POST 전송, 조회조건 sampleVO 유지)
   2026.10.29  유지보수  jQuery Mobile → KRDS 모바일 (구조화 목록, 페이지당 표시 건수, KRDS 페이지네이션)
   2026.10.29  유지보수  반응형 웹 (브라우저 전체 폭, 화면 폭별 구조화 목록 배치) — web-sample 구조 적용
   2026.10.29  유지보수  상단 헤더 제거, 타이틀 [List Sample 목록] 우측에 [등록] 버튼 배치
   2026.10.29  유지보수  사용여부를 배지 대신 텍스트(항목 : 값)로 표시

  @author 실행환경 개발팀
  @since 2009.02.01

  Copyright (C) 2009 by MOPAS All right reserved.
--%>
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="data:," />
	<title><spring:message code="title.sample" /></title>

	<%-- KRDS 스타일 --%>
	<link rel="stylesheet" type="text/css" href="<c:url value='/css/component/output.css'/>" />
	<link rel="stylesheet" type="text/css" href="<c:url value='/css/egovframe.css'/>" />
	<script type="text/javascript" src="<c:url value='/js/jquery.min.js'/>"></script>
	<script type="text/javascript" src="<c:url value='/js/egovframework/common.js'/>" defer></script>
	<script type="text/javascript" defer>
		/* 목록 조회조건을 POST 로 전송 (GET 은 "/" 만 허용) */
		function sampleSubmit(url) {
			$('#listForm').attr('method', 'post').attr('action', url).submit();
		}

		function sampleSearch() {
			if (notNullCheck($.trim($('#searchKeyword').val()))) {
				$('#pageIndex').val(1);
				sampleSubmit("<c:url value='/egovSampleList.do'/>");
			} else {
				alert("<spring:message code='search.error' javaScriptEscape='true'/>");
				$('#searchKeyword').focus();
			}
		}

		function samplePagination(pageIndex) {
			$('#pageIndex').val(pageIndex);
			sampleSubmit("<c:url value='/egovSampleList.do'/>");
		}

		function sampleCreate() {
			$('#id').val('');
			sampleSubmit("<c:url value='/addSampleView.do'/>");
		}

		function sampleDetail(id) {
			$('#id').val(id);
			sampleSubmit("<c:url value='/updateSampleView.do'/>");
		}

		$(function () {
			/* 검색어 Enter : 폼 기본 전송(현재 URL 로 POST) 대신 검색 실행 */
			$('#searchKeyword').on('keydown', function (event) {
				if (event.key === 'Enter') {
					event.preventDefault();
					sampleSearch();
				}
			});
			$('#pageUnit').on('change', function () {
				samplePagination(1);
			});
		});
	</script>
</head>

<body>
<div id="krds-skip-link">
	<a href="#container"><spring:message code="skip.content" /></a>
</div>

<main id="container" class="inner">

	<%-- 타이틀 : 좌측 화면명 / 우측 [등록] --%>
	<div class="page-title-wrap">
		<h1 class="heading-large"><spring:message code="list.sample" /> <spring:message code="button.list" /></h1>
		<div class="page-title-actions">
			<button type="button" class="krds-btn small" onclick="sampleCreate()"><spring:message code="button.create" /></button>
		</div>
	</div>

	<form:form modelAttribute="sampleVO" id="listForm" name="listForm" method="post">
		<input type="hidden" id="id" name="id" />
		<input type="hidden" id="pageIndex" name="pageIndex" value="${sampleVO.pageIndex}" />
		<form:hidden path="pageSize" />

		<%-- 검색 --%>
		<div class="form-group">
			<div class="search-wrap">
				<div class="search-body">
					<div class="form-conts searchOption">
						<select id="searchCondition" name="searchCondition" class="krds-form-select medium" title="<spring:message code='search.choose'/>">
							<option value="1" <c:if test="${sampleVO.searchCondition ne '0'}">selected="selected"</c:if>>Name</option>
							<option value="0" <c:if test="${sampleVO.searchCondition eq '0'}">selected="selected"</c:if>>ID</option>
						</select>
					</div>
					<div class="form-conts btn-ico-wrap searchKeyword">
						<input type="text" id="searchKeyword" name="searchKeyword" value="<c:out value='${sampleVO.searchKeyword}'/>" maxlength="100"
							class="krds-input medium" title="<spring:message code='search.keyword'/>" placeholder="<spring:message code='search.keyword'/>" autocomplete="off">
						<button type="button" class="krds-btn medium icon" onclick="sampleSearch()">
							<span class="sr-only"><spring:message code="button.search" /></span>
							<i class="svg-icon ico-sch"></i>
						</button>
					</div>
				</div>
				<div class="page-btn-wrap">
					<label for="pageUnit" class="sr-only"><spring:message code="page.unit.label" /></label>
					<form:select path="pageUnit" cssClass="krds-form-select medium page-unit-select">
						<c:set var="pageUnits" value="5,10,20,50,100" />
						<c:set var="currentPageUnit" value=",${sampleVO.pageUnit}," />
						<c:if test="${not fn:contains(',5,10,20,50,100,', currentPageUnit)}">
							<form:option value="${sampleVO.pageUnit}"><spring:message code="page.unit.option" arguments="${sampleVO.pageUnit}" /></form:option>
						</c:if>
						<c:forEach var="unit" items="${pageUnits}">
							<form:option value="${unit}"><spring:message code="page.unit.option" arguments="${unit}" /></form:option>
						</c:forEach>
					</form:select>
				</div>
			</div>
		</div>
	</form:form>

	<%-- 목록 --%>
	<p class="search-result-count" role="status">
		<spring:message code="search.result.count" arguments="${paginationInfo.totalRecordCount}" htmlEscape="false" />
	</p>
	<c:choose>
		<c:when test="${not empty resultList}">
			<%-- KRDS 구조화 목록(type-full) : 전체 화면 폭 공통 (PC·태블릿 가로 배치, 모바일 세로 배치는 KRDS 기본 동작) --%>
			<ul class="krds-structured-list type-full sample-list">
				<c:forEach var="result" items="${resultList}" varStatus="status">
					<li class="structured-item">
						<div class="in">
							<div class="card-top">
								<span class="list-no"><span class="sr-only">No</span><c:out value="${paginationInfo.totalRecordCount+1 - ((sampleVO.pageIndex-1) * paginationInfo.recordCountPerPage + status.count)}"/></span>
							</div>
							<div class="card-body">
								<a href="#" class="c-text" onclick="sampleDetail('<c:out value="${result.id}"/>'); return false;">
									<p class="c-tit"><span class="span"><c:out value="${result.name}"/></span></p>
									<p class="c-txt"><c:out value="${result.description}"/></p>
									<p class="c-date">
										<strong class="key"><spring:message code="title.sample.id" /></strong>
										<span class="value"><c:out value="${result.id}"/></span>
									</p>
									<p class="c-date">
										<strong class="key"><spring:message code="title.sample.useYn" /></strong>
										<span class="value">
											<c:choose>
												<c:when test="${result.useYn == 'Y'}"><spring:message code="input.yes" /></c:when>
												<c:when test="${result.useYn == 'N'}"><spring:message code="input.no" /></c:when>
												<c:otherwise>-</c:otherwise>
											</c:choose>
										</span>
									</p>
									<p class="c-date">
										<strong class="key"><spring:message code="title.sample.regUser" /></strong>
										<span class="value"><c:out value="${result.regUser}"/></span>
									</p>
								</a>
							</div>
						</div>
					</li>
				</c:forEach>
			</ul>

			<%-- 페이지네이션 (0건이면 출력하지 않음 : RTE 렌더러가 0페이지에서 [다음]을 활성으로 그림) --%>
			<div id="paging" class="krds-pagination">
				<ui:pagination paginationInfo="${paginationInfo}" type="krds" jsFunction="samplePagination" />
			</div>
		</c:when>
		<c:otherwise>
			<p class="sample-list-empty"><spring:message code="info.nodata.msg" /></p>
		</c:otherwise>
	</c:choose>

</main>

<footer class="sample-footer">
	<div class="inner">
		<p>eGovFrame Mobile Sample</p>
	</div>
</footer>

</body>
</html>
