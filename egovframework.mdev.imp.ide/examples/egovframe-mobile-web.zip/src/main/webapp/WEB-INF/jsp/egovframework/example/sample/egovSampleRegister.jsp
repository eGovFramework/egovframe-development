<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%--
  게시판 등록 · 수정 화면

  @Modification Information
   수정일      수정자    수정내용
   ----------  --------  ----------------------------------------
   2009.02.01            최초 생성
   2026.10.29  유지보수  web-sample 현행화 ([목록] POST 전송, 조회조건·페이징 단위 유지, 서버 검증 오류 목록,
                         확인 메시지 다국어 처리, 입력 maxlength 를 컬럼폭과 일치)
   2026.10.29  유지보수  jQuery Mobile → KRDS 모바일 (입력 폼, 글자 수, 하단 버튼)
   2026.10.29  유지보수  반응형 웹 (브라우저 전체 폭, PC·태블릿 좌우 버튼 / 모바일 2열 버튼) — web-sample 구조 적용
   2026.10.29  유지보수  상단 헤더 제거, 타이틀 [List Sample 등록/수정] 우측에 [목록] 버튼 배치

  @author 실행환경 개발팀
  @since 2009.02.01

  Copyright (C) 2009 by MOPAS All right reserved.
--%>
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<c:set var="registerFlag" value="${empty sampleVO.id ? 'create' : 'modify'}"/>
	<link rel="icon" href="data:," />
	<title>Sample <c:if test="${registerFlag == 'create'}"><spring:message code="button.create" /></c:if>
	              <c:if test="${registerFlag == 'modify'}"><spring:message code="button.modify" /></c:if>
	</title>

	<%-- KRDS 스타일 --%>
	<link rel="stylesheet" type="text/css" href="<c:url value='/css/component/output.css'/>" />
	<link rel="stylesheet" type="text/css" href="<c:url value='/css/egovframe.css'/>" />
	<script type="text/javascript" src="<c:url value='/js/jquery.min.js'/>"></script>
	<script type="text/javascript" src="<c:url value='/js/component/ui-script.js'/>" defer></script>
	<script type="text/javascript" src="<c:url value='/js/egovframework/common.js'/>" defer></script>

	<%-- 입력값 검증 스크립트 --%>
	<script type="text/javascript" src="<c:url value='/js/egovframework/EgovValidation.js'/>" defer></script>

	<script type="text/javascript" defer>
		$(function () {
			updateTextCount();
			$('#description').on('input', updateTextCount);
		});

		function updateTextCount() {
			$('#textCount').text($('#description').val().length);
		}

		/* 상세 폼을 POST 로 전송 (GET 은 "/" 만 허용) */
		function sampleSubmit(url) {
			$('#detailForm').attr('method', 'post').attr('action', url).submit();
		}

		function sampleList() {
			sampleSubmit("<c:url value='/egovSampleList.do'/>");
		}

		function sampleAdd() {
			if (confirm("<spring:message code='add.confirm' javaScriptEscape='true'/>")) {
				if (!validateSampleVO(document.detailForm)) {
					return;
				}
				sampleSubmit("<c:url value='/addSample.do'/>");
			}
		}

		function sampleUpdate() {
			if (confirm("<spring:message code='modify.confirm' javaScriptEscape='true'/>")) {
				if (!validateSampleVO(document.detailForm)) {
					return;
				}
				sampleSubmit("<c:url value='/updateSample.do'/>");
			}
		}

		function sampleDelete() {
			if (confirm("<spring:message code='delete.confirm' javaScriptEscape='true'/>")) {
				sampleSubmit("<c:url value='/deleteSample.do'/>");
			}
		}

		function sampleReset() {
			document.detailForm.reset();
			updateTextCount();
		}
	</script>
</head>

<body>
<div id="krds-skip-link">
	<a href="#container"><spring:message code="skip.content" /></a>
</div>

	<main id="container" class="inner">

		<%-- 타이틀 : 좌측 화면명 / 우측 [목록] --%>
		<div class="page-title-wrap">
			<h1 class="heading-large"><spring:message code="list.sample" />
				<c:if test="${registerFlag == 'create'}"><spring:message code="button.create" /></c:if>
				<c:if test="${registerFlag == 'modify'}"><spring:message code="button.modify" /></c:if>
			</h1>
			<div class="page-title-actions">
				<button type="button" class="krds-btn small secondary" onclick="sampleList()"><spring:message code="button.list" /></button>
			</div>
		</div>

		<form:form id="detailForm" name="detailForm" modelAttribute="sampleVO">
			<input type="hidden" id="searchCondition" name="searchCondition" value="<c:out value='${sampleVO.searchCondition}'/>" />
			<input type="hidden" id="searchKeyword" name="searchKeyword" value="<c:out value='${sampleVO.searchKeyword}'/>" />
			<input type="hidden" id="pageIndex" name="pageIndex" value="${sampleVO.pageIndex}" />
			<form:hidden path="pageUnit" />
			<form:hidden path="pageSize" />

			<%-- 서버 검증 오류 --%>
			<spring:hasBindErrors name="sampleVO">
			<ul class="form-error-list" role="alert">
				<form:errors path="*" element="li" delimiter="</li><li>" />
			</ul>
			</spring:hasBindErrors>

			<spring:message code="confirm.required.name" var="placeholderName"/>
			<spring:message code="confirm.required.description" var="placeholderDescription"/>
			<spring:message code="confirm.required.user" var="placeholderUser"/>

			<div class="conts-wrap">
				<div class="fieldset input-form">
					<c:if test="${registerFlag == 'modify'}">
					<div class="form-group">
						<div class="form-tit">
							<label for="id"><spring:message code="title.sample.id" /></label>
						</div>
						<div class="form-conts">
							<form:input path="id" maxlength="16" readonly="true" cssClass="krds-input" />
						</div>
					</div>
					</c:if>

					<div class="form-group">
						<div class="form-tit">
							<label for="name"><spring:message code="title.sample.name" /> <span class="required">*</span></label>
						</div>
						<div class="form-conts">
							<form:input path="name" maxlength="50" cssClass="krds-input" placeholder="${placeholderName}" />
						</div>
					</div>

					<div class="form-group">
						<div class="form-tit">
							<label for="useYn"><spring:message code="title.sample.useYn" /></label>
						</div>
						<div class="form-conts">
							<form:select path="useYn" cssClass="krds-form-select">
								<form:option value="Y"><spring:message code="input.yes" /></form:option>
								<form:option value="N"><spring:message code="input.no" /></form:option>
							</form:select>
						</div>
					</div>

					<div class="form-group">
						<div class="form-tit">
							<label for="description"><spring:message code="title.sample.description" /> <span class="required">*</span></label>
						</div>
						<div class="form-conts">
							<div class="textarea-wrap">
								<form:textarea path="description" maxlength="200" cssClass="krds-input" placeholder="${placeholderDescription}" />
								<p class="textarea-count">
									<span id="textCount" class="text-primary">0</span>
									<span class="text-num">/200</span>
								</p>
							</div>
						</div>
					</div>

					<div class="form-group">
						<div class="form-tit">
							<label for="regUser"><spring:message code="title.sample.regUser" /> <span class="required">*</span></label>
						</div>
						<div class="form-conts">
							<c:choose>
								<c:when test="${registerFlag == 'modify'}">
									<form:input path="regUser" maxlength="10" readonly="true" cssClass="krds-input" placeholder="${placeholderUser}" />
								</c:when>
								<c:otherwise>
									<form:input path="regUser" maxlength="10" cssClass="krds-input" placeholder="${placeholderUser}" />
								</c:otherwise>
							</c:choose>
						</div>
					</div>
				</div>

				<%-- 버튼 : PC·태블릿 좌(목록·재설정) / 우(처리), 모바일은 처리 버튼을 위로 --%>
				<div class="page-btn-wrap">
					<div class="btn-wrap">
						<button type="button" class="krds-btn medium tertiary" onclick="sampleList()"><spring:message code="button.list" /></button>
						<button type="button" class="krds-btn medium tertiary" onclick="sampleReset()"><spring:message code="button.reset" /></button>
					</div>
					<div class="btn-wrap btn-action">
						<c:choose>
							<c:when test="${registerFlag == 'modify'}">
								<button type="button" class="krds-btn medium" onclick="sampleUpdate()"><spring:message code="button.modify" /></button>
								<button type="button" class="krds-btn medium secondary" onclick="sampleDelete()"><spring:message code="button.delete" /></button>
							</c:when>
							<c:otherwise>
								<button type="button" class="krds-btn medium" onclick="sampleAdd()"><spring:message code="button.create" /></button>
							</c:otherwise>
						</c:choose>
					</div>
				</div>
			</div>

		</form:form>

	</main>

	<footer class="sample-footer">
		<div class="inner">
			<p>eGovFrame Mobile Sample</p>
		</div>
	</footer>

</body>
</html>
