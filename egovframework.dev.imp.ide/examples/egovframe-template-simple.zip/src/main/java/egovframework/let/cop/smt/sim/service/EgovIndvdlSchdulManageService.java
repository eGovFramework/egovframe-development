package egovframework.let.cop.smt.sim.service;

import java.util.List;
import java.util.Map;

import egovframework.com.cmm.ComDefaultVO;

/**
 * 일정관리를 처리하는 서비스인터페이스 클래스
 *
 * <pre>
 * 2009.04.10 장동한 최초 생성
 * 2026.09.01 이백행 [2026년 컨트리뷰션] 불필요한 예외 제거
 * </pre>
 *
 * @author 조재영
 * @since 2009.04.10
 */
public interface EgovIndvdlSchdulManageService {

	/**
	 * 일정를(을) 삭제한다.
	 *
	 * @param indvdlSchdulManageVO    - 일정 정보 담김 VO
	 */
	public int deleteIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO);

	/**
	 * 일정를(을) 등록한다.
	 *
	 * @param indvdlSchdulManageVO    - 일정 정보 담김 VO
	 */
	public int insertIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO);

	/**
	 * 일정를(을) 상세조회 한다.
	 * @return List
	 *
	 * @param indvdlSchdulManageVO    - 일정 정보 담김 VO
	 */
	public List<?> selectIndvdlSchdulManageDetail(IndvdlSchdulManageVO indvdlSchdulManageVO);

	/**
	 * 일정 목록을 VO(model)형식으로 조회한다.
	 * @return List
	 *
	 * @param indvdlSchdulManageVO    - 조회할 정보가 담긴 VO
	 */
	public IndvdlSchdulManageVO selectIndvdlSchdulManageDetailVO(IndvdlSchdulManageVO indvdlSchdulManageVO);

	/**
	 * 일정 목록을 조회한다.
	 * @return List
	 *
	 * @param searchVO    - 조회할 정보가 담긴 VO
	 */
	public List<?> selectIndvdlSchdulManageList(ComDefaultVO searchVO);

	/**
	 * 일정를(을) 목록 전체 건수를(을) 조회한다.
	 * @return int
	 *
	 * @param searchVO    - 조회할 정보가 담긴 VO
	 */
	public int selectIndvdlSchdulManageListCnt(ComDefaultVO searchVO);

	/**
	 * 메인페이지/일정관리조회
	 * @return List
	 *
	 * @param map    - 조회할 정보가 담긴 map
	 */
	public List<?> selectIndvdlSchdulManageMainList(Map<?, ?> map);

	/**
	 * 일정 목록을 Map(map)형식으로 조회한다.
	 * @param Map(map) - 조회할 정보가 담긴 Map
	 * @return List
	 *
	 * @param map
	 */
	public List<?> selectIndvdlSchdulManageRetrieve(Map<?, ?> map);

	/**
	 * 일정를(을) 수정한다.
	 *
	 * @param indvdlSchdulManageVO    - 일정 정보 담김 VO
	 */
	public int updateIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO);
}