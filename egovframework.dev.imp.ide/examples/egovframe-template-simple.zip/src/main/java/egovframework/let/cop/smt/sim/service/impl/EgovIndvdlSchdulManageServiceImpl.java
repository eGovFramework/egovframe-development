package egovframework.let.cop.smt.sim.service.impl;

import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;
import org.egovframe.rte.fdl.cmmn.exception.FdlException;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.let.cop.smt.sim.service.EgovIndvdlSchdulManageService;
import egovframework.let.cop.smt.sim.service.IndvdlSchdulManageVO;
import jakarta.annotation.Resource;

/**
 * 일정관리를 처리하는 ServiceImpl Class 구현
 *
 * <pre>
 * 2009.04.10 장동한 최초 생성
 * 2026.09.01 이백행 [2026년 컨트리뷰션] 불필요한 예외 제거
 * </pre>
 *
 * @author 조재영
 * @since 2009.04.10
 */
@Service("egovIndvdlSchdulManageService")
public class EgovIndvdlSchdulManageServiceImpl extends EgovAbstractServiceImpl implements EgovIndvdlSchdulManageService{

	@Resource(name="indvdlSchdulManageDao")
	private IndvdlSchdulManageDao dao;


	@Resource(name="deptSchdulManageIdGnrService")
	private EgovIdGnrService idgenService;


    /**
	 * 메인페이지/일정관리조회
	 * @param map - 조회할 정보가 담긴 map
	 * @return List
	 */
	@Override
	public List<?> selectIndvdlSchdulManageMainList(Map<?, ?> map) {
		return dao.selectIndvdlSchdulManageMainList(map);
	}

    /**
	 * 일정 목록을 Map(map)형식으로 조회한다.
	 * @param Map(map) - 조회할 정보가 담긴 VO
	 * @return List
	 */
	@Override
	public List<?> selectIndvdlSchdulManageRetrieve(Map<?, ?> map) {
		return dao.selectIndvdlSchdulManageRetrieve(map);
	}

    /**
	 * 일정 목록을 VO(model)형식으로 조회한다.
	 * @param indvdlSchdulManageVO - 조회할 정보가 담긴 VO
	 * @return List
	 */
	@Override
	public IndvdlSchdulManageVO selectIndvdlSchdulManageDetailVO(IndvdlSchdulManageVO indvdlSchdulManageVO) {
		return dao.selectIndvdlSchdulManageDetailVO(indvdlSchdulManageVO);
	}

    /**
	 * 일정 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return List
	 */
	@Override
	public List<?> selectIndvdlSchdulManageList(ComDefaultVO searchVO) {
		return dao.selectIndvdlSchdulManageList(searchVO);
	}

    /**
	 * 일정를(을) 상세조회 한다.
	 * @param IndvdlSchdulManage - 회정정보가 담김 VO
	 * @return List
	 */
	@Override
	public List<?> selectIndvdlSchdulManageDetail(IndvdlSchdulManageVO indvdlSchdulManageVO) {
		return dao.selectIndvdlSchdulManageDetail(indvdlSchdulManageVO);
	}

    /**
	 * 일정를(을) 목록 전체 건수를(을) 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return int
	 */
	@Override
	public int selectIndvdlSchdulManageListCnt(ComDefaultVO searchVO) {
		return dao.selectIndvdlSchdulManageListCnt(searchVO);
	}

    /**
	 * 일정를(을) 등록한다.
	 * @param indvdlSchdulManageVO - 조회할 정보가 담긴 VO
	 */
	@Override
	public int insertIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) {
		String sMakeId;
		try {
			sMakeId = idgenService.getNextStringId();
		} catch (FdlException e) {
			throw new BaseRuntimeException(e);
		}
		indvdlSchdulManageVO.setSchdulId(sMakeId);

		return dao.insertIndvdlSchdulManage(indvdlSchdulManageVO);
	}

    /**
	 * 일정를(을) 수정한다.
	 * @param indvdlSchdulManageVO - 조회할 정보가 담긴 VO
	 */
	@Override
	public int updateIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) {
		return dao.updateIndvdlSchdulManage(indvdlSchdulManageVO);
	}

    /**
	 * 일정를(을) 삭제한다.
	 * @param indvdlSchdulManageVO - 조회할 정보가 담긴 VO
	 */
	@Override
	public int deleteIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) {
		return dao.deleteIndvdlSchdulManage(indvdlSchdulManageVO);
	}
}
