package egovframework.let.uat.uia.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import jakarta.annotation.Resource;

/**
 * 로그인 화면 컨트롤러.
 * 로그인(/uat/uia/actionLogin.do)·로그아웃(/uat/uia/actionLogout.do) 처리는 Spring Security 가 수행한다.
 *
 * <pre>
 * 2009.03.06 박지욱 최초 생성
 * 2026.10.26 -      Spring Security 인증 전환
 * </pre>
 *
 * @author 공통서비스 개발팀 박지욱
 * @since 2009.03.06
 * @see org.egovframe.rte.fdl.security.config.EgovSecurityConfiguration
 */
@Controller
public class EgovLoginController {

	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	/**
	 * 로그인 화면으로 들어간다. 인증 실패 시 error 파라미터와 함께 호출된다.
	 */
	@RequestMapping(value = "/uat/uia/egovLoginUsr.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String loginUsrView(@RequestParam(value = "error", required = false) String error, ModelMap model) {
		if (error != null) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
		}
		return "cmm/uat/uia/EgovLoginUsr";
	}

	/**
	 * 로그인 후 메인화면으로 들어간다.
	 */
	@RequestMapping(value = "/uat/uia/actionMain.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String actionMain(ModelMap model) {
		if (!EgovUserDetailsHelper.isAuthenticated()) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "cmm/uat/uia/EgovLoginUsr";
		}
		return "forward:/cmm/main/mainPage.do";
	}

}
