package egovframework.let.cop.com.service;

import java.util.List;
import java.util.Map;

/**
 * 템플릿 관리를 위한 서비스 인터페이스 클래스
 *
 * <pre>
 * 2009.03.17 이삼섭 최초 생성
 * 2026.09.01 이백행 [2026년 컨트리뷰션] 불필요한 예외 제거
 * </pre>
 *
 * @author 공통서비스개발팀 이삼섭
 * @since 2009.03.17
 */
public interface EgovTemplateManageService {

	/**
	 * 템플릿 정보를 삭제한다.
	 * 
	 * @param tmplatInf
	 */
	public int deleteTemplateInf(TemplateInf tmplatInf);

	/**
	 * 템플릿 정보를 등록한다.
	 * 
	 * @param tmplatInf
	 */
	public int insertTemplateInf(TemplateInf tmplatInf);

	/**
	 * 템플릿에 대한 상세정보를 조회한다.
	 * @return
	 * 
	 * @param tmplatInfVO
	 */
	public TemplateInfVO selectTemplateInf(TemplateInfVO tmplatInfVO);

	/**
	 * 템플릿에 대한 목록를 조회한다.
	 * @return
	 * 
	 * @param tmplatInfVO
	 */
	public Map<String, Object> selectTemplateInfs(TemplateInfVO tmplatInfVO);

	/**
	 * 템플릿 구분에 따른 목록을 조회한다.
	 * @return
	 * 
	 * @param tmplatInfVO
	 */
	public List<TemplateInfVO> selectTemplateInfsByCode(TemplateInfVO tmplatInfVO);

	/**
	 * 템플릿에 대한 미리보기 정보를 조회한다.
	 * @return
	 * 
	 * @param tmplatInfVO
	 */
	public TemplateInfVO selectTemplatePreview(TemplateInfVO tmplatInfVO);

	/**
	 * 템플릿 정보를 수정한다.
	 * 
	 * @param tmplatInf
	 */
	public int updateTemplateInf(TemplateInf tmplatInf);

}