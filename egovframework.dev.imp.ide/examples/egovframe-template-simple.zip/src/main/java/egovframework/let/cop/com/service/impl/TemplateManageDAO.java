package egovframework.let.cop.com.service.impl;
import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;
import org.springframework.stereotype.Repository;

import egovframework.let.cop.com.service.TemplateInf;
import egovframework.let.cop.com.service.TemplateInfVO;

/**
 * 템플릿 정보관리를 위한 데이터 접근 클래스
 *
 * <pre>
 * 2009.03.17 이삼섭 최초 생성
 * 2026.06.23 이백행 [2026년 컨트리뷰션] 불필요한 예외 제거
 * </pre>
 *
 * @author 공통서비스개발팀 이삼섭
 * @since 2009.03.17
 */
@Repository("TemplateManageDAO")
public class TemplateManageDAO extends EgovAbstractMapper {

    /**
     * 템플릿 정보를 삭제한다.
     *
     * @param tmplatInf
     */
    public int deleteTemplateInf(TemplateInf tmplatInf) {
    	return update("TemplateManageDAO.deleteTemplateInf", tmplatInf);
    }

    /**
     * 템플릿 정보를 등록한다.
     *
     * @param tmplatInf
     */
    public int insertTemplateInf(TemplateInf tmplatInf) {
    	return insert("TemplateManageDAO.insertTemplateInf", tmplatInf);
    }

    /**
     * 템플릿 정보를 수정한다.
     *
     * @param tmplatInf
     */
    public int updateTemplateInf(TemplateInf tmplatInf) {
    	return update("TemplateManageDAO.updateTemplateInf", tmplatInf);
    }

    /**
     * 템플릿에 대한 목록를 조회한다.
     *
     * @param tmplatInfVO
     * @return
     */
    public List<TemplateInfVO> selectTemplateInfs(TemplateInfVO tmplatInfVO) {
    	return selectList("TemplateManageDAO.selectTemplateInfs", tmplatInfVO);
    }

    /**
     * 템플릿에 대한 목록 전체 건수를 조회한다.
     *
     * @param tmplatInfVO
     * @return
     */
    public int selectTemplateInfsCnt(TemplateInfVO tmplatInfVO) {
    	return (Integer)selectOne("TemplateManageDAO.selectTemplateInfsCnt", tmplatInfVO);
    }

    /**
     * 템플릿에 대한 상세정보를 조회한다.
     *
     * @param tmplatInfVO
     * @return
     */
    public TemplateInfVO selectTemplateInf(TemplateInfVO tmplatInfVO) {
    	return (TemplateInfVO)selectOne("TemplateManageDAO.selectTemplateInf", tmplatInfVO);

    }

    /**
     * 템플릿에 대한 미리보기 정보를 조회한다.
     *
     * @param tmplatInfVO
     * @return
     */
    public TemplateInfVO selectTemplatePreview(TemplateInfVO tmplatInfVO) {
    	return null;
    }

    /**
     * 템플릿 구분에 따른 목록을 조회한다.
     *
     * @param tmplatInfVO
     * @return
     */
    public List<TemplateInfVO> selectTemplateInfsByCode(TemplateInfVO tmplatInfVO) {
    	return selectList("TemplateManageDAO.selectTemplateInfsByCode", tmplatInfVO);
    }

}
