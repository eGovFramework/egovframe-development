package egovframework.let.cop.com.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;
import org.egovframe.rte.fdl.cmmn.exception.FdlException;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.let.cop.com.service.EgovTemplateManageService;
import egovframework.let.cop.com.service.TemplateInf;
import egovframework.let.cop.com.service.TemplateInfVO;
import jakarta.annotation.Resource;

/**
 * 템플릿 정보관리를 위한 서비스 구현 클래스
 *
 * <pre>
 * 2009.03.17 이삼섭 최초 생성
 * 2026.09.01 이백행 [2026년 컨트리뷰션] 불필요한 예외 제거
 * </pre>
 *
 * @author 공통서비스개발팀 이삼섭
 * @since 2009.03.17
 */
@Service("EgovTemplateManageService")
public class EgovTemplateManageServiceImpl extends EgovAbstractServiceImpl implements EgovTemplateManageService {

    @Resource(name = "TemplateManageDAO")
    private TemplateManageDAO tmplatDAO;

    @Resource(name = "egovTmplatIdGnrService")
    private EgovIdGnrService idgenService;

    /**
     * 템플릿 정보를 삭제한다.
     * 
     * @see egovframework.let.cop.bbs.com.service.EgovTemplateManageService#deleteTemplateInf(egovframework.let.cop.bbs.com.service.TemplateInf)
     */
    public int deleteTemplateInf(TemplateInf tmplatInf) {
    	return tmplatDAO.deleteTemplateInf(tmplatInf);
    }

    /**
     * 템플릿 정보를 등록한다.
     * 
     * @see egovframework.let.cop.bbs.com.service.EgovTemplateManageService#insertTemplateInf(egovframework.let.cop.bbs.com.service.TemplateInf)
     */
    public int insertTemplateInf(TemplateInf tmplatInf) {

	try {
		tmplatInf.setTmplatId(idgenService.getNextStringId());
	} catch (FdlException e) {
		throw new BaseRuntimeException(e);
	}

	return tmplatDAO.insertTemplateInf(tmplatInf);
    }

    /**
     * 템플릿에 대한 상세정보를 조회한다.
     * 
     * @see egovframework.let.cop.bbs.com.service.EgovTemplateManageService#selectTemplateInf(egovframework.let.cop.bbs.com.service.TemplateInfVO)
     */
    public TemplateInfVO selectTemplateInf(TemplateInfVO tmplatInfVO) {
	TemplateInfVO vo = new TemplateInfVO();
	vo = tmplatDAO.selectTemplateInf(tmplatInfVO);
	return vo;
    }

    /**
     * 템플릿에 대한 목록를 조회한다.
     * 
     * @see egovframework.let.cop.bbs.com.service.EgovTemplateManageService#selectTemplateInfs(egovframework.let.cop.bbs.com.service.TemplateInfVO)
     */
    public Map<String, Object> selectTemplateInfs(TemplateInfVO tmplatInfVO) {
	List<TemplateInfVO> result = tmplatDAO.selectTemplateInfs(tmplatInfVO);
	int cnt = tmplatDAO.selectTemplateInfsCnt(tmplatInfVO);
	
	Map<String, Object> map = new HashMap<String, Object>();
	
	map.put("resultList", result);
	map.put("resultCnt", Integer.toString(cnt));

	return map;
    }

    /**
     * 템플릿에 대한 미리보기 정보를 조회한다.
     * 
     * @see egovframework.let.cop.bbs.com.service.EgovTemplateManageService#selectTemplatePreview(egovframework.let.cop.bbs.com.service.TemplateInfVO)
     */
    public TemplateInfVO selectTemplatePreview(TemplateInfVO tmplatInfVO) {
	TemplateInfVO vo = new TemplateInfVO();
	
	vo = tmplatDAO.selectTemplatePreview(tmplatInfVO);
	
	return vo;
    }

    /**
     * 템플릿 정보를 수정한다.
     * 
     * @see egovframework.let.cop.bbs.com.service.EgovTemplateManageService#updateTemplateInf(egovframework.let.cop.bbs.com.service.TemplateInf)
     */
    public int updateTemplateInf(TemplateInf tmplatInf) {
    	return tmplatDAO.updateTemplateInf(tmplatInf);
    }

    /**
     * 템플릿 구분에 따른 목록을 조회한다.
     * 
     * @see egovframework.let.cop.bbs.com.service.EgovTemplateManageService#selectAllTemplateInfs(egovframework.let.cop.bbs.com.service.TemplateInfVO)
     */
    public List<TemplateInfVO> selectTemplateInfsByCode(TemplateInfVO tmplatInfVO) {
	return tmplatDAO.selectTemplateInfsByCode(tmplatInfVO);
    }
}
