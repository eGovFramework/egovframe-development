package egovframework.let.uat.uia.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.egovframe.rte.fdl.security.userdetails.EgovUserDetails;
import org.egovframe.rte.fdl.security.userdetails.jdbc.EgovUsersByUsernameMapping;

import egovframework.com.cmm.LoginVO;

/**
 * 표준프레임워크 실행환경 보안(fdl-security) 사용자 조회 결과 매핑.
 * egov-security-config.properties 의 jdbcUsersByUsernameQuery 결과를 LoginVO 로 매핑한다. (jdbcMapClass)
 */
public class EgovLoginUserMapping extends EgovUsersByUsernameMapping {

	public EgovLoginUserMapping(DataSource ds, String usersByUsernameQuery) {
		super(ds, usersByUsernameQuery);
	}

	@Override
	protected EgovUserDetails mapRow(ResultSet rs, int rownum) throws SQLException {
		String userId = rs.getString("USER_ID");
		String password = rs.getString("PASSWORD");
		boolean enabled = rs.getBoolean("ENABLED");

		LoginVO loginVO = new LoginVO();
		loginVO.setId(userId);
		loginVO.setName(rs.getString("USER_NM"));
		loginVO.setEmail(rs.getString("EMAIL_ADRES"));
		loginVO.setOrgnztId(rs.getString("ORGNZT_ID"));
		loginVO.setUniqId(rs.getString("ESNTL_ID"));
		loginVO.setUserSe("USR");

		return new EgovUserDetails(userId, password, enabled, loginVO);
	}
}
