package egovframework.let.cop.com.service.impl;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;
import org.springframework.stereotype.Repository;

import egovframework.let.cop.com.service.UserInfVO;

/**
 * 협업 활용 사용자 정보 조회를 위한 데이터 접근 클래스
 *
 * <pre>
 * 2009.04.06 이삼섭 최초 생성
 * 2026.06.23 이백행 [2026년 컨트리뷰션] 불필요한 예외 제거
 * </pre>
 *
 * @author 공통서비스개발팀 이삼섭
 * @since 2009.04.06
 */
@Repository("EgovUserInfManageDAO")
public class EgovUserInfManageDAO extends EgovAbstractMapper {

    /**
     * 사용자 정보에 대한 목록을 조회한다.
     *
     * @param userVO
     * @return
     */
    public List<UserInfVO> selectUserList(UserInfVO userVO) {
    	return selectList("EgovUserInfManageDAO.selectUserList", userVO);
    }

    /**
     * 사용자 정보에 대한 목록 전체 건수를 조회한다.
     *
     * @param userVO
     * @return
     */
    public int selectUserListCnt(UserInfVO userVO) {
    	return (Integer)selectOne("EgovUserInfManageDAO.selectUserListCnt", userVO);
    }

    /**
     * 커뮤니티 사용자 목록을 조회한다.
     *
     * @param userVO
     * @return
     */
    public List<UserInfVO> selectCmmntyUserList(UserInfVO userVO) {
    	return selectList("EgovUserInfManageDAO.selectCmmntyUserList", userVO);
    }

    /**
     * 커뮤니티 사용자 목록에 대한 전체 건수를 조회한다.
     *
     * @param userVO
     * @return
     */
    public int selectCmmntyUserListCnt(UserInfVO userVO) {
    	return (Integer)selectOne("EgovUserInfManageDAO.selectCmmntyUserListCnt", userVO);
    }

    /**
     * 커뮤니티 관리자 목록을 조회한다.
     *
     * @param userVO
     * @return
     */
    public List<UserInfVO> selectCmmntyMngrList(UserInfVO userVO) {
    	return selectList("EgovUserInfManageDAO.selectCmmntyMngrList", userVO);
    }

    /**
     * 커뮤니티 관리자 목록에 대한 전체 건수를 조회한다.
     *
     * @param userVO
     * @return
     */
    public int selectCmmntyMngrListCnt(UserInfVO userVO) {
    	return (Integer)selectOne("EgovUserInfManageDAO.selectCmmntyMngrListCnt", userVO);
    }

    /**
     * 동호회 사용자 목록을 조회한다.
     *
     * @param userVO
     * @return
     */
    public List<UserInfVO> selectClubUserList(UserInfVO userVO) {
    	return selectList("EgovUserInfManageDAO.selectClubUserList", userVO);
    }

    /**
     * 동호회 사용자 목록에 대한 전체 건수를 조회한다.
     *
     * @param userVO
     * @return
     */
    public int selectClubUserListCnt(UserInfVO userVO) {
    	return (Integer)selectOne("EgovUserInfManageDAO.selectClubUserListCnt", userVO);
    }

    /**
     * 동호회 운영자 목록을 조회한다.
     *
     * @param userVO
     * @return
     */
    public List<UserInfVO> selectClubOprtrList(UserInfVO userVO) {
    	return selectList("EgovUserInfManageDAO.selectClubOprtrList", userVO);
    }

    /**
     * 동호회 운영자 목록에 대한 전체 건수를 조회한다.
     *
     * @param userVO
     * @return
     */
    public int selectClubOprtrListCnt(UserInfVO userVO) {
    	return (Integer)selectOne("EgovUserInfManageDAO.selectClubOprtrListCnt", userVO);
    }

    /**
     * 동호회에 대한 모든 사용자 목록을 조회한다.
     *
     * @param userVO
     * @return
     */
    public List<UserInfVO> selectAllClubUser(UserInfVO userVO) {
    	return selectList("EgovUserInfManageDAO.selectAllClubUser", userVO);
    }

    /**
     * 커뮤니티에 대한 모든 사용자 목록을 조회한다.
     *
     * @param userVO
     * @return
     */
    public List<UserInfVO> selectAllCmmntyUser(UserInfVO userVO) {
    	return selectList("EgovUserInfManageDAO.selectAllCmmntyUser", userVO);
    }
}
