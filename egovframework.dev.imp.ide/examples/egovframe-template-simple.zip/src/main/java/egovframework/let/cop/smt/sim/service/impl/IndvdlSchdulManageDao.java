package egovframework.let.cop.smt.sim.service.impl;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;
import org.springframework.stereotype.Repository;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.let.cop.smt.sim.service.IndvdlSchdulManageVO;

/**
 * 일정관리를 처리하는 Dao Class 구현
 *
 * <pre>
 * 2009.04.10 장동한 최초 생성
 * 2026.06.23 이백행 [2026년 컨트리뷰션] 불필요한 예외 제거
 * </pre>
 *
 * @author 조재영
 * @since 2009.04.10
 */
@Repository("indvdlSchdulManageDao")
public class IndvdlSchdulManageDao extends EgovAbstractMapper {


    /**
	 * 메인페이지/일정관리조회 목록을 Map(map)형식으로 조회한다.
	 * @param Map(map) - 조회할 정보가 담긴 VO
	 * @return List
	 */
	public List<?> selectIndvdlSchdulManageMainList(Map<?, ?> map) {
		 return  selectList("IndvdlSchdulManage.selectIndvdlSchdulManageMainList", map);
	}

    /**
	 * 일정 목록을 Map(map)형식으로 조회한다.
	 * @param Map(map) - 조회할 정보가 담긴 VO
	 * @return List
	 */
	public List<?> selectIndvdlSchdulManageRetrieve(Map<?, ?> map) {
		 return  selectList("IndvdlSchdulManage.selectIndvdlSchdulManageRetrieve", map);
	}


    /**
	 * 일정 목록을 VO(model)형식으로 조회한다.
	 * @param indvdlSchdulManageVO - 조회할 정보가 담긴 VO
	 * @return IndvdlSchdulManageVO
	 */
	public IndvdlSchdulManageVO selectIndvdlSchdulManageDetailVO(IndvdlSchdulManageVO indvdlSchdulManageVO) {
		return (IndvdlSchdulManageVO)selectOne("IndvdlSchdulManage.selectIndvdlSchdulManageDetailVO", indvdlSchdulManageVO);
	}

    /**
	 * 일정 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return List
	 */
	public List<?> selectIndvdlSchdulManageList(ComDefaultVO searchVO) {
		return selectList("IndvdlSchdulManage.selectIndvdlSchdulManage", searchVO);
	}

    /**
	 * 일정를(을) 상세조회 한다.
	 * @param indvdlSchdulManageVO - 일정 정보 담김 VO
	 * @return List
	 */
	public List<?> selectIndvdlSchdulManageDetail(IndvdlSchdulManageVO indvdlSchdulManageVO) {
		return selectList("IndvdlSchdulManage.selectIndvdlSchdulManageDetail", indvdlSchdulManageVO);
	}

    /**
	 * 일정를(을) 목록 전체 건수를(을) 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return int
	 */
	public int selectIndvdlSchdulManageListCnt(ComDefaultVO searchVO) {
		return (Integer)selectOne("IndvdlSchdulManage.selectIndvdlSchdulManageCnt", searchVO);
	}

    /**
	 * 일정를(을) 등록한다.
	 * @param qindvdlSchdulManageVO - 일정 정보 담김 VO
	 */
	public int insertIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) {
		return insert("IndvdlSchdulManage.insertIndvdlSchdulManage", indvdlSchdulManageVO);
	}

    /**
	 * 일정를(을) 수정한다.
	 * @param indvdlSchdulManageVO - 일정 정보 담김 VO
	 */
	public int updateIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) {
		return insert("IndvdlSchdulManage.updateIndvdlSchdulManage", indvdlSchdulManageVO);
	}

    /**
	 * 일정를(을) 삭제한다.
	 * @param indvdlSchdulManageVO - 일정 정보 담김 VO
	 */
	public int deleteIndvdlSchdulManage(IndvdlSchdulManageVO indvdlSchdulManageVO) {
		// 일지 삭제
		// 일정관리 삭제
		return delete("IndvdlSchdulManage.deleteIndvdlSchdulManage", indvdlSchdulManageVO);
	}
}
