package egovframework.let.cop.com.service.impl;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;
import org.springframework.stereotype.Repository;

import egovframework.let.cop.com.service.BoardUseInf;
import egovframework.let.cop.com.service.BoardUseInfVO;

/**
 * 게시판 이용정보를 관리하기 위한 데이터 접근 클래스
 *
 * <pre>
 * 2009.04.02 이삼섭 최초 생성
 * 2026.06.23 이백행 [2026년 컨트리뷰션] 불필요한 예외 제거
 * </pre>
 *
 * @author 공통서비스개발팀 이삼섭
 * @since 2009.04.02
 */
@Repository("BBSUseInfoManageDAO")
public class BBSUseInfoManageDAO extends EgovAbstractMapper {

    /**
     * 게시판 사용 정보를 삭제한다.
     *
     * @param bdUseInf
     */
    public int deleteBBSUseInf(BoardUseInf bdUseInf) {
    	return update("BBSUseInfoManageDAO.deleteBBSUseInf", bdUseInf);
    }

    /**
     * 커뮤니티에 사용되는 게시판 사용정보 목록을 조회한다.
     *
     * @param bdUseInf
     */
    public List<BoardUseInf> selectBBSUseInfByCmmnty(BoardUseInfVO bdUseVO) {
    	return selectList("BBSUseInfoManageDAO.selectBBSUseInfByCmmnty", bdUseVO);
    }

    /**
     * 동호회에 사용되는 게시판 사용정보 목록을 조회한다.
     *
     * @param bdUseInf
     */
    public List<BoardUseInf> selectBBSUseInfByClub(BoardUseInfVO bdUseVO) {
    	return selectList("BBSUseInfoManageDAO.selectBBSUseInfByClub", bdUseVO);
    }

    /**
     * 커뮤니티에 사용되는 모든 게시판 사용정보를 삭제한다.
     *
     * @param bdUseInf
     */
    public int deleteAllBBSUseInfByCmmnty(BoardUseInfVO bdUseVO) {
    	return update("BBSUseInfoManageDAO.deleteAllBBSUseInfByCmmnty", bdUseVO);
    }

    /**
     * 동호회에 사용되는 모든 게시판 사용정보를 삭제한다.
     *
     * @param bdUseInf
     */
    public int deleteAllBBSUseInfByClub(BoardUseInfVO bdUseVO) {
    	return update("BBSUseInfoManageDAO.deleteAllBBSUseInfByClub", bdUseVO);
    }

    /**
     * 게시판 사용정보를 등록한다.
     *
     * @param bdUseInf
     */
    public int insertBBSUseInf(BoardUseInf bdUseInf) {
    	return insert("BBSUseInfoManageDAO.insertBBSUseInf", bdUseInf);
    }

    /**
     * 게시판 사용정보 목록을 조회한다.
     *
     * @param bdUseVO
     * @return
     */
    public List<BoardUseInfVO> selectBBSUseInfs(BoardUseInfVO bdUseVO) {
    	return selectList("BBSUseInfoManageDAO.selectBBSUseInfs", bdUseVO);
    }

    /**
     *
     * @param bdUseVO
     * @return
     */
    public int selectBBSUseInfsCnt(BoardUseInfVO bdUseVO) {
    	return (Integer)selectOne("BBSUseInfoManageDAO.selectBBSUseInfsCnt", bdUseVO);
    }

    /**
     * 게시판 사용정보에 대한 상세정보를 조회한다.
     *
     * @param bdUseVO
     * @return
     */
    public BoardUseInfVO selectBBSUseInf(BoardUseInfVO bdUseVO) {
    	return (BoardUseInfVO)selectOne("BBSUseInfoManageDAO.selectBBSUseInf", bdUseVO);
    }

    /**
     * 게시판 사용정보를 수정한다.
     *
     * @param bdUseInf
     */
    public int updateBBSUseInf(BoardUseInf bdUseInf) {
    	return update("BBSUseInfoManageDAO.updateBBSUseInf", bdUseInf);
    }

    /**
     * 게시판에 대한 사용정보를 삭제한다.
     *
     * @param bdUseInf
     */
    public int deleteBBSUseInfByBoardId(BoardUseInf bdUseInf) {
    	return update("BBSUseInfoManageDAO.deleteBBSUseInfByBoardId", bdUseInf);
    }
}
