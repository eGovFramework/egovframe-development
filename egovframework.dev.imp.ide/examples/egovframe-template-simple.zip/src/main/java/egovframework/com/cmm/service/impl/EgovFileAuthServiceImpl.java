package egovframework.com.cmm.service.impl;

import org.egovframe.rte.fdl.cmmn.exception.EgovBizException;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.let.cop.bbs.service.impl.BBSManageDAO;
import egovframework.let.cop.smt.sim.service.impl.IndvdlSchdulManageDao;
import jakarta.annotation.Resource;

/**
 * 첨부파일 업무 객체 접근 권한 검증
 */
@Service("EgovFileAuthService")
public class EgovFileAuthServiceImpl {

	@Resource(name = "BBSManageDAO")
	private BBSManageDAO bbsManageDAO;

	@Resource(name = "indvdlSchdulManageDao")
	private IndvdlSchdulManageDao indvdlSchdulManageDao;

	public void assertFileAccess(String atchFileId) throws Exception {
		if (!EgovUserDetailsHelper.isAuthenticated()) {
			throw new EgovBizException("fail.common.login");
		}

		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		if (user == null || user.getUniqId() == null) {
			throw new EgovBizException("fail.common.login");
		}

		int ownerCount = bbsManageDAO.countArticleByAtchFileIdAndOwner(atchFileId, user.getUniqId());
		if (ownerCount > 0) {
			return;
		}

		int scheduleCount = indvdlSchdulManageDao.countByAtchFileId(atchFileId);
		if (scheduleCount > 0) {
			return;
		}

		int linkedCount = bbsManageDAO.countArticleByAtchFileId(atchFileId);
		if (linkedCount == 0) {
			return;
		}

		throw new EgovBizException("fail.common.login");
	}
}
