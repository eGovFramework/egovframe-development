package egovframework.com.cmm.web;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;
import org.egovframe.rte.fdl.crypto.EgovCryptoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.EgovWebUtil;
import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.EgovProperties;
import egovframework.com.cmm.service.FileVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import jakarta.annotation.Resource;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * 파일 다운로드를 위한 컨트롤러 클래스
 *
 * <pre>
 * 2009.03.25 이삼섭 최초 생성
 * 2022.12.02 윤창원 File ID 암호화 처리
 * </pre>
 *
 * @author 공통서비스개발팀 이삼섭
 * @since 2009.06.01
 */
@Controller
public class EgovFileDownloadController {

	/** 로그설정 */
	private static final Logger LOGGER = LoggerFactory.getLogger(EgovFileDownloadController.class);
	
	/** 암호화서비스 */
	@Resource(name = "egovARIACryptoService")
	private EgovCryptoService cryptoService;

	@Resource(name = "EgovFileMngService")
	private EgovFileMngService fileService;

	// 주의 : 반드시 기본값 "egovframe"을 다른것으로 변경하여 사용하시기 바랍니다.
	public static final String ALGORITHM_KEY = EgovProperties.getProperty("Globals.File.algorithmKey");
		

	/**
	 * Content-Disposition 헤더 지정 (RFC 6266 filename* UTF-8 인코딩).
	 */
	private void setDisposition(String filename, HttpServletResponse response) {
		ContentDisposition disposition = ContentDisposition.attachment().filename(filename, StandardCharsets.UTF_8).build();
		response.setHeader(HttpHeaders.CONTENT_DISPOSITION, disposition.toString());
	}

	/**
	 * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
	 *
	 * @param commandMap
	 * @param response
	 */
	@PostMapping("/cmm/fms/FileDown.do")
	public void cvplFileDownload(@RequestParam Map<String, Object> commandMap, HttpServletRequest request, HttpServletResponse response) {

		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		if (isAuthenticated) {

			// 암호화된 atchFileId 를 복호화. (2022.12.06 추가) - 파일아이디가 유추 불가능하도록 조치
			String param_atchFileId = (String) commandMap.get("atchFileId");
			param_atchFileId = param_atchFileId.replaceAll(" ", "+");
			byte[] decodedBytes = Base64.getDecoder().decode(param_atchFileId);
			String decodedString = new String(cryptoService.decrypt(decodedBytes, ALGORITHM_KEY));

			// 세션 바인딩 검증 - 발급 당시 세션과 현재 세션이 일치해야 한다.
			String issuedSessionId = StringUtils.substringBefore(decodedString, "|");
			if (issuedSessionId == null || issuedSessionId.isEmpty() || !issuedSessionId.equals(EgovWebUtil.sessionFingerprint(request))) {
				try {
					response.sendError(HttpServletResponse.SC_FORBIDDEN);
				} catch (IOException e) {
					throw new BaseRuntimeException(e);
				}
				return;
			}

			String decodedFileId = StringUtils.substringAfter(decodedString, "|");
			String fileSn = (String) commandMap.get("fileSn");
	
			FileVO fileVO = new FileVO();
			fileVO.setAtchFileId(decodedFileId);
			fileVO.setFileSn(fileSn);
			FileVO fvo = fileService.selectFileInf(fileVO);
			if (fvo == null) {
				try {
					response.sendError(HttpServletResponse.SC_NOT_FOUND);
				} catch (IOException e) {
					throw new BaseRuntimeException(e);
				}
				return;
			}

			String fileStreCours = EgovWebUtil.filePathBlackList(fvo.getFileStreCours());
			String streFileNm = EgovWebUtil.filePathBlackList(fvo.getStreFileNm());
			File uFile = new File(fileStreCours, streFileNm);
			long fSize = uFile.length();

			if (fSize > 0) {
				String mimetype = "application/x-msdownload";

				response.setContentType(mimetype);
				setDisposition(fvo.getOrignlFileNm(), response);

				BufferedInputStream in = null;
				BufferedOutputStream out = null;

				try {
					in = new BufferedInputStream(new FileInputStream(uFile));
					out = new BufferedOutputStream(response.getOutputStream());

					FileCopyUtils.copy(in, out);
					out.flush();
				} catch (IOException ex) {
					LOGGER.debug("IGNORED: {}", ex.getMessage());
				} finally {
					if (in != null) {
						try {
							in.close();
						} catch (IOException ignore) {
							LOGGER.debug("IGNORED: {}", ignore.getMessage());
						}
					}
					if (out != null) {
						try {
							out.close();
						} catch (IOException ignore) {
							LOGGER.debug("IGNORED: {}", ignore.getMessage());
						}
					}
				}

			} else {
				try {
					request.getRequestDispatcher("/cmm/error/egovBizException.jsp").forward(request, response);
				} catch (ServletException | IOException e) {
					throw new BaseRuntimeException(e);
				}
			}
		}
	}
}
