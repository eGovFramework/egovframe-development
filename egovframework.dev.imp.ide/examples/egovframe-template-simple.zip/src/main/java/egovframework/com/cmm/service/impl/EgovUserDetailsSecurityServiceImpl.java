package egovframework.com.cmm.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.security.userdetails.EgovUserDetails;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import egovframework.com.cmm.service.EgovUserDetailsService;

/**
 * Spring Security 의 SecurityContext 에서 인증 사용자 정보를 조회한다.
 */
public class EgovUserDetailsSecurityServiceImpl implements EgovUserDetailsService {

	@Override
	public Object getAuthenticatedUser() {
		Authentication authentication = currentAuthentication();
		if (authentication != null && authentication.getPrincipal() instanceof EgovUserDetails userDetails) {
			return userDetails.getEgovUserVO();
		}
		return null;
	}

	@Override
	public List<String> getAuthorities() {
		Authentication authentication = currentAuthentication();
		if (authentication == null) {
			return List.of();
		}
		return authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList();
	}

	@Override
	public Boolean isAuthenticated() {
		return currentAuthentication() != null;
	}

	/** 익명이 아닌 인증 정보 (없으면 null) */
	private static Authentication currentAuthentication() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null || !authentication.isAuthenticated() || authentication instanceof AnonymousAuthenticationToken) {
			return null;
		}
		return authentication;
	}
}
