package egovframework.com.cmm;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.regex.Pattern;

import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;

import jakarta.servlet.http.HttpServletRequest;

/**
 * 교차접속 스크립트 공격 취약성 방지(파라미터 문자열 교체)
 *
 * <pre>
 * 2011.10.10 한성곤 최초 생성
 * 2026.10.26 -      sessionFingerprint() 추가 (파일 ID 토큰에 세션 ID 원문 노출 방지)
 * </pre>
 */

public class EgovWebUtil {

	// 성능: 매 호출마다 Pattern.compile이 반복되지 않도록 정규식은 클래스 로딩 시 1회만 컴파일한다.
	// (정규식 의미가 없는 문자 그대로의 치환은 String.replace 로 대체 — 패턴 컴파일 자체가 불필요)
	private static final Pattern SPACE_PATTERN = Pattern.compile("\\p{Space}");
	private static final Pattern IP_PATTERN = Pattern.compile("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}");

	public static String clearXSSMinimum(String value) {
		if (value == null || value.trim().equals("")) {
			return "";
		}

		String returnValue = value;

		returnValue = returnValue.replace("&", "&amp;");
		returnValue = returnValue.replace("<", "&lt;");
		returnValue = returnValue.replace(">", "&gt;");
		returnValue = returnValue.replace("\"", "&#34;");
		returnValue = returnValue.replace("\'", "&#39;");
		returnValue = returnValue.replace(".", "&#46;");
		returnValue = returnValue.replace("%2E", "&#46;");
		returnValue = returnValue.replace("%2F", "&#47;");
		return returnValue;
	}

	public static String clearXSSMaximum(String value) {
		String returnValue = value;
		returnValue = clearXSSMinimum(returnValue);

		// 널 바이트(%00) 제거
		returnValue = returnValue.replace("%00", "");

		returnValue = returnValue.replace("%", "&#37;");

		returnValue = returnValue.replace("../", ""); // ../
		returnValue = returnValue.replace("..\\", ""); // ..\
		returnValue = returnValue.replace("./", ""); // ./
		returnValue = returnValue.replace("%2F", "");

		return returnValue;
	}

	public static String filePathBlackList(String value) {
		String returnValue = value;
		if (returnValue == null || returnValue.trim().equals("")) {
			return "";
		}

		returnValue = returnValue.replace("..", "");

		return returnValue;
	}

	/**
	 * 파일경로 보안취약점 조치
	 * # 주의사항
	 * 1. basePath는 반드시 지정해야 한다.
	 * 2. basePath는 ROOT Path "/" 사용 금지 한다.
	 * 3. basePath 하위 디렉토리는 업로드한 파일이 존재하도록 구성하며 중요파일이 존재하지 않도록 관리한다.
	 *
	 * @param value 파일명
	 * @param basePath 기본 경로
	 * @return
	 */
	public static String filePathBlackList(String value, String basePath) {
		if ( basePath == null || "".equals(basePath) )
			throw new SecurityException("base path is empty.");
		if ( File.separator.equals(basePath) || "/".equals(basePath) )
			throw new SecurityException("base path does not allow Root.");
		return filePathBlackList(basePath + value);
	}
	
	/**
	 * 행안부 보안취약점 점검 조치 방안.
	 *
	 * @param value
	 * @return
	 */
	public static String filePathReplaceAll(String value) {
		String returnValue = value;
		if (returnValue == null || returnValue.trim().equals("")) {
			return "";
		}

		returnValue = returnValue.replace("/", "");
		returnValue = returnValue.replace("\\", ""); // \
		returnValue = returnValue.replace("..", ""); // ..
		returnValue = returnValue.replace("&", "");

		return returnValue;
	}
	
	public static String fileInjectPathReplaceAll(String value) {
		String returnValue = value;
		if (returnValue == null || returnValue.trim().equals("")) {
			return "";
		}

		// 구분자(/,\)를 먼저 제거한 뒤 ".." 를 제거 (".\." → ".." 우회 방지)
		returnValue = returnValue.replace("/", "");
		returnValue = returnValue.replace("\\", ""); // \
		returnValue = returnValue.replace("..", ""); // ..
		returnValue = returnValue.replace("&", "");

		return returnValue;
	}

	public static String filePathWhiteList(String value) {
		return value;
	}

	public static boolean isIPAddress(String str) {
		return IP_PATTERN.matcher(str).matches();
    }

	public static String removeCRLF(String parameter) {
		return parameter.replace("\r", "").replace("\n", "");
	}

	public static String removeSQLInjectionRisk(String parameter) {
		return SPACE_PATTERN.matcher(parameter).replaceAll("").replace("*", "").replace("%", "").replace(";", "").replace("-", "").replace("+", "").replace(",", "");
	}

	public static String removeOSCmdRisk(String parameter) {
		return SPACE_PATTERN.matcher(parameter).replaceAll("").replace("*", "").replace("|", "").replace(";", "");
	}

	/**
	 * 세션 ID 의 SHA-256 해시(Base64URL). 파일 ID 토큰 등 클라이언트에 전달되는 값에
	 * 세션 ID 원문이 포함되지 않도록 세션 바인딩 값으로 사용한다.
	 */
	public static String sessionFingerprint(HttpServletRequest request) {
		try {
			byte[] hash = MessageDigest.getInstance("SHA-256").digest(request.getSession().getId().getBytes(StandardCharsets.UTF_8));
			return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
		} catch (NoSuchAlgorithmException e) {
			throw new BaseRuntimeException(e);
		}
	}

}
