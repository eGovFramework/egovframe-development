package egovframework.com.cmm.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.security.access.prepost.PreAuthorize;

/**
 * 관리자(ROLE_ADMIN) 권한이 필요한 컨트롤러 메소드에 사용하는 애노테이션.
 * Spring Security 메소드 보안(egov-com-security.xml)이 실행 전에 권한을 검증한다.
 */
@Target({ ElementType.METHOD, ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@PreAuthorize("hasRole('ADMIN')")
public @interface RequireAdmin {
}
