package egovframework.com.cmm;

import org.egovframe.rte.fdl.cmmn.trace.handler.TraceHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 공통서비스의 trace 처리 클래스
 *
 * <pre>
 * 2011.09.30 JJY
 * </pre>
 *
 * @author JJY
 * @since 2011.09.30
 */
public class EgovComTraceHandler implements TraceHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovComTraceHandler.class);

	/**
	 * 발생된 메시지를 출력한다.
	 */
	@Override
	public void todo(Class<?> clazz, String message) {
		LOGGER.debug("[TRACE]CLASS::: {}", clazz.getName());
		LOGGER.debug("[TRACE]MESSAGE::: {}", message);
		//이곳에서 후속처리로 필요한 액션을 취할 수 있다.
	}
}
