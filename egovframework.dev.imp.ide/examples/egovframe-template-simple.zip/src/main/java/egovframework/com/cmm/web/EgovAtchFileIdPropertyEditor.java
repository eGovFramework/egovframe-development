package egovframework.com.cmm.web;

import java.beans.PropertyEditorSupport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * atchFileId 파라미터 복호화 클래스
 *
 * <pre>
 * 2022.12.22 신용호 최초 생성
 * </pre>
 *
 * @author 표준프레임워크팀 신용호
 * @since 2022.12.22
 */

public class EgovAtchFileIdPropertyEditor extends PropertyEditorSupport {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EgovAtchFileIdPropertyEditor.class);
	
	public void setAsText(String text) throws IllegalArgumentException {
		LOGGER.debug("===>>> setText : "+text);
		String decryptText = "";
		// 26.03.04 KISA 보안취약점 조치
		// 불필요한 try-catch 제거
		if (text != null && !"".equals(text) ) {
			decryptText = EgovFileMngController.decrypt(text);
		}
		this.setValue(decryptText);

	}


	public String getAsText() {
		LOGGER.debug("===>>> getText : "+getValue());
		return String.valueOf(getValue());

	}

}
