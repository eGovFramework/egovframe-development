package egovframework.com.cmm;

import org.egovframe.rte.fdl.cmmn.exception.handler.ExceptionHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 공통서비스의 exception 처리 클래스
 *
 * <pre>
 * 2009.03.13 이삼섭
 * </pre>
 *
 * @author 공통 서비스 개발팀 이삼섭
 * @since 2009.03.13
 */
public class EgovComExcepHndlr implements ExceptionHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovComExcepHndlr.class);

    /**
     * 발생된 Exception을 처리한다.
     */
    @Override
	public void occur(Exception ex, String packageName) {
    	LOGGER.debug("[HANDLER][PACKAGE]::: {}", packageName);
		LOGGER.debug("[HANDLER][Exception]:::{}", ex);
    }
}
