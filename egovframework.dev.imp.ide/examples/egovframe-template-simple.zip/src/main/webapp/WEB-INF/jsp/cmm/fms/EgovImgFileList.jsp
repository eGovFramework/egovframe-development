<%-- EgovImgFileList.jsp : 이미지 파일 조회화면(include) (2009.03.31 이삼섭) --%>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<table>
    <c:forEach var="fileVO" items="${fileList}" varStatus="status">
        <tr>
            <td>
                <img src='<c:url value='/cmm/fms/getImage.do'/>?atchFileId=<c:out value="${fileVO.atchFileId}"/>&amp;fileSn=<c:out value="${fileVO.fileSn}"/>' width="640" alt="파일보기링크" />
            </td>
        </tr>
    </c:forEach>
</table>
