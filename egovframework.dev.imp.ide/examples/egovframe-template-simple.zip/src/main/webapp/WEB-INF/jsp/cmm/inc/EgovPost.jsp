<%-- EgovPost.jsp : 화면 이동 POST 전송 공통 스크립트(include) - EgovIncHeader.jsp 및 팝업 화면에서 사용 (2026.10.27 -) --%>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<script type="text/javascript">
    window.EGOV_CSRF = { name: "<c:out value='${_csrf.parameterName}'/>", token: "<c:out value='${_csrf.token}'/>" };
</script>
<script type="text/javascript" src="<c:url value='/js/EgovPost.js'/>"></script>
