<%-- EgovIncTopnav.jsp : 상단메뉴(include) (2011.08.31 JJY) --%>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="sec" uri="http://www.springframework.org/security/tags" %>

<!-- gnb -->
<div class="gnb">
    <ul>
        <li><a href="<c:url value='/EgovPageLink.do?menuNo=11&linkIndex=9'/>">사이트소개</a></li>
        <li><a href="<c:url value='/EgovPageLink.do?menuNo=21&linkIndex=13'/>">정보마당</a></li>
        <li><a href="<c:url value='/EgovPageLink.do?menuNo=31&linkIndex=15'/>">고객지원</a></li>
        <li><a href="<c:url value='/cop/smt/sim/EgovIndvdlSchdulManageWeekList.do?menuNo=42'/>">알림마당</a></li>
        <sec:authorize access="isAuthenticated()">
        <li><a href="<c:url value='/cop/smt/sim/EgovIndvdlSchdulManageMonthList.do?menuNo=52'/>" class="manager">사이트관리</a></li>
        </sec:authorize>
    </ul>
</div>
<!--// gnb -->