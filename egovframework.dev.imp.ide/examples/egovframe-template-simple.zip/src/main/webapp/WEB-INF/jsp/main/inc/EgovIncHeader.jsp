<%-- EgovIncHeader.jsp : 화면상단 Header(include) (2011.08.31 JJY) --%>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="sec" uri="http://www.springframework.org/security/tags" %>
<jsp:include page="/WEB-INF/jsp/cmm/inc/EgovPost.jsp"/>

<!-- Header -->
<div class="header">
    <div class="inner">
        <div class="left_col">
            <div class="logo_area">
                <p class="logo_txt">표준프레임워크 <span>심플 홈페이지</span></p>
                <h1 class="logo">
                    <a href="<c:url value='/cmm/main/mainPage.do' />">
                        <img src="<c:url value='/images/logo_hq.png' />" alt="표준프레임워크 포털 eGovFrame 샘플 포털" />
                    </a>
                </h1>
            </div>
        </div>

        <sec:authorize access="isAuthenticated()">
            <div class="top_menu">
                <span class="t"><span><sec:authentication property="principal.egovUserVO.name" htmlEscape="true"/>님</span>, 로그인하셨습니다.</span>
            </div>
        </sec:authorize>

        <!-- gnb -->
        <div class="gnb">
            <ul>
                <li><a href="<c:url value='/EgovPageLink.do?menuNo=11&linkIndex=9'/>">사이트소개</a></li>
                <li><a href="<c:url value='/EgovPageLink.do?menuNo=21&linkIndex=13'/>">정보마당</a></li>
                <li><a href="<c:url value='/EgovPageLink.do?menuNo=31&linkIndex=15'/>">고객지원</a></li>
                <li><a href="<c:url value='/cop/smt/sim/EgovIndvdlSchdulManageWeekList.do?menuNo=42'/>">알림마당</a></li>
                <sec:authorize access="hasRole('ADMIN')">
                <li><a href="<c:url value='/cop/smt/sim/EgovIndvdlSchdulManageMonthList.do?menuNo=51'/>" class="manager">사이트관리</a></li>
                </sec:authorize>
            </ul>
        </div>
        <!--// gnb -->

        <!-- util menu -->
        <div class="util_menu">
            <ul>
                <sec:authorize access="!isAuthenticated()">
                <li><a href="<c:url value='/uat/uia/egovLoginUsr.do'/>" class="login">로그인</a></li>
                </sec:authorize>
                <sec:authorize access="isAuthenticated()">
                <li>
                    <a href="#" onclick="document.logoutForm.submit(); return false;" class="logout">로그아웃</a>
                    <form name="logoutForm" method="post" action="<c:url value='/uat/uia/actionLogout.do'/>" style="display:none;"><input type="hidden" name="${_csrf.parameterName}" value="${_csrf.token}"/></form>
                </li>
                </sec:authorize>
            </ul>
        </div>
        <!--// util menu -->

    </div>
</div>
<!--// Header -->
