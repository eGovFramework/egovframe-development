<%-- EgovQARegist.jsp : 샘플화면 - 묻고답하기 문의 작성(sample) --%>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="sec" uri="http://www.springframework.org/security/tags" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>문의하기 - 표준프레임워크 심플 홈페이지템플릿</title>
    <link rel="stylesheet" href="<c:url value='/css/base.css'/>">
    <link rel="stylesheet" href="<c:url value='/css/layout.css'/>">
    <link rel="stylesheet" href="<c:url value='/css/component.css'/>">
    <link rel="stylesheet" href="<c:url value='/css/page.css'/>">
    <script src="<c:url value='/js/jquery-1.11.2.min.js'/>"></script>
    <script src="<c:url value='/js/ui.js'/>"></script>
    <script>
    // 필수 입력값 확인 후 목록으로 이동 (샘플 화면이므로 실제 저장은 하지 않음)
    function fn_egov_regist_qa(form) {
        if ($.trim(form.qa_subject.value) === "") {
            alert("제목을 입력하세요.");
            form.qa_subject.focus();
            return false;
        }
        if ($.trim(form.qa_content.value) === "") {
            alert("문의 내용을 입력하세요.");
            form.qa_content.focus();
            return false;
        }
        alert("문의가 등록되었습니다. (샘플 화면으로 실제 저장되지 않습니다)");
        return true;
    }
    </script>
</head>
<body>
<noscript>자바스크립트를 지원하지 않는 브라우저에서는 일부 기능을 사용하실 수 없습니다.</noscript>
<!-- 현재 페이지는 기능이 없는 디자인 샘플 페이지 입니다! -->

<!-- Skip navigation -->
<a href="#contents" class="skip_navi">본문 바로가기</a>

<div class="wrap">
    <!-- Header -->
    <jsp:include page="/WEB-INF/jsp/main/inc/EgovIncHeader.jsp"/>
    <!--// Header -->

    <div class="container">
        <div class="sub_layout">
            <div class="sub_in">
                <div class="layout">
                    <!-- Left menu -->
                    <jsp:include page="/WEB-INF/jsp/main/inc/EgovIncLeftmenu.jsp"/>
                    <!--// Left menu -->

                    <div class="content_wrap">
                        <div id="contents" class="content">
                            <!-- Location -->
                            <div class="location">
                                <ul>
                                    <li><a class="home" href="<c:url value='/cmm/main/mainPage.do'/>">Home</a></li>
                                    <li><a href="<c:url value='/EgovPageLink.do?menuNo=31&linkIndex=15'/>">고객지원</a></li>
                                    <li><a href="<c:url value='/EgovPageLink.do?linkIndex=16'/>">묻고답하기</a></li>
                                    <li>문의하기</li>
                                </ul>
                            </div>
                            <!--// Location -->

                            <h1 class="tit_1">고객지원</h1>
                            <p class="txt_1">궁금하신 사항을 남겨주시면 친절하게 답변해 드립니다.</p>
                            <h2 class="tit_2">문의하기</h2>

                            <!-- Form Section (목록 화면과 같은 data_table / btn_area 스타일) -->
                            <form class="qa_regist_form" action="<c:url value='/EgovPageLink.do?linkIndex=16'/>" method="post" onsubmit="return fn_egov_regist_qa(this);">
                                <input type="hidden" name="${_csrf.parameterName}" value="${_csrf.token}"/>

                                <div class="data_table">
                                    <table>
                                        <caption>문의 작성</caption>
                                        <colgroup>
                                            <col style="width: 160px;">
                                            <col style="width: auto;">
                                        </colgroup>
                                        <tbody>
                                            <tr>
                                                <th scope="row"><label for="qa_subject" class="required">제목</label></th>
                                                <td class="align_left input_cell"><input type="text" id="qa_subject" name="qa_subject" maxlength="100" placeholder="문의 제목을 입력하세요"></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">작성자</th>
                                                <td class="align_left"><sec:authentication property="name"/></td>
                                            </tr>
                                            <tr>
                                                <th scope="row" class="valign_top"><label for="qa_content" class="required">문의 내용</label></th>
                                                <td class="align_left"><textarea id="qa_content" name="qa_content" rows="12" placeholder="문의하실 내용을 입력하세요."></textarea></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- 버튼 -->
                                <div class="btn_area">
                                    <a href="<c:url value='/EgovPageLink.do?linkIndex=16'/>" class="btn_upload btn_cancel">취소</a>
                                    <button type="submit" class="btn_upload">✏️ 등록</button>
                                </div>
                                <!--// 버튼 -->
                            </form>
                            <!--// Form Section -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <jsp:include page="/WEB-INF/jsp/main/inc/EgovIncFooter.jsp"/>
    <!--// Footer -->
</div>

</body>
</html>
