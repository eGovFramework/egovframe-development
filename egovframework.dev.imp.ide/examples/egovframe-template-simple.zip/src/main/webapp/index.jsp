<%-- index.jsp : 최초화면으로 메인화면으로 이동한다. (2011.08.31 JJY) --%>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%--
<jsp:forward page="/cmm/main/mainPage.do"/>
--%>
<script type="text/javaScript">document.location.href="<c:url value='/cmm/main/mainPage.do'/>"</script> 