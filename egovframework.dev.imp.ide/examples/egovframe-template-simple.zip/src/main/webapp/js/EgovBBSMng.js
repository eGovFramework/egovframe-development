/* EgovBBSMng.js : 게시판 화면 공통 JavaScript (2009.03.10 이삼섭) */

function fn_egov_trim(str) {
    if (str == null) {
        return '';
    }
    var count = str.length;
    var len = count;
    var st = 0;

    while ((st < len) && (str.charAt(st) <= ' ')) {
        st++;
    }
    
    while ((st < len) && (str.charAt(len - 1) <= ' ')) {
        len--;
    }
    
    return ((st > 0) || (len < count)) ? str.substring(st, len) : str;
}
