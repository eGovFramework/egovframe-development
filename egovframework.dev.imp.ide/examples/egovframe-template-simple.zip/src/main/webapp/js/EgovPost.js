/**
 * EgovPost.js : 화면 이동을 POST 로 전송하는 공통 함수 (메뉴를 제외한 화면 이동에 사용)
 * - fn_egov_post(url, params, target) : url 의 쿼리스트링과 params 를 hidden 필드로 옮겨 POST 전송
 * - fn_egov_post_form(form, url, target) : 기존 form 을 POST 로 전송 (CSRF 토큰 자동 추가)
 * - <a href="/x.do?a=1" data-egov-post[="_blank"]> : 링크 클릭을 POST 로 전송 (값 지정 시 해당 창 · iframe 으로)
 * CSRF 토큰은 EgovPost.jsp 가 설정한 window.EGOV_CSRF 를 사용한다.
 */

function fn_egov_post(url, params, target) {
    var form = document.createElement("form");
    var queryIndex = url.indexOf("?");
    form.method = "post";
    form.action = queryIndex < 0 ? url : url.substring(0, queryIndex);
    form.style.display = "none";
    if (target) {
        form.target = target;
    }

    var fields = [];
    if (queryIndex >= 0) {
        url.substring(queryIndex + 1).split("&").forEach(function(pair) {
            if (pair) {
                var eq = pair.indexOf("=");
                var name = eq < 0 ? pair : pair.substring(0, eq);
                var value = eq < 0 ? "" : pair.substring(eq + 1);
                fields.push([fn_egov_post_decode(name), fn_egov_post_decode(value)]);
            }
        });
    }
    for (var key in (params || {})) {
        fields.push([key, params[key] == null ? "" : String(params[key])]);
    }
    if (window.EGOV_CSRF) {
        fields.push([window.EGOV_CSRF.name, window.EGOV_CSRF.token]);
    }

    fields.forEach(function(field) {
        var input = document.createElement("input");
        input.type = "hidden";
        input.name = field[0];
        input.value = field[1];
        form.appendChild(input);
    });

    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}

function fn_egov_post_form(form, url, target) {
    form.method = "post";
    if (url) {
        form.action = url;
    }
    if (target) {
        form.target = target;
    }
    if (window.EGOV_CSRF && !form.querySelector("input[name='" + window.EGOV_CSRF.name + "']")) {
        var input = document.createElement("input");
        input.type = "hidden";
        input.name = window.EGOV_CSRF.name;
        input.value = window.EGOV_CSRF.token;
        form.appendChild(input);
    }
    form.submit();
}

function fn_egov_post_decode(value) {
    return decodeURIComponent(value.replace(/\+/g, " "));
}

document.addEventListener("click", function(event) {
    var link = event.target.closest ? event.target.closest("a[data-egov-post]") : null;
    if (!link || event.defaultPrevented) {
        return;
    }
    event.preventDefault();
    fn_egov_post(link.getAttribute("href"), null, link.getAttribute("data-egov-post") || null);
});
