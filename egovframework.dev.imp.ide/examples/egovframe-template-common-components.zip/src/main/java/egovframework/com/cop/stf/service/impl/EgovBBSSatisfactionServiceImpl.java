package egovframework.com.cop.stf.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;
import org.egovframe.rte.fdl.cmmn.exception.FdlException;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cop.bbs.service.BoardMaster;
import egovframework.com.cop.bbs.service.BoardMasterVO;
import egovframework.com.cop.bbs.service.EgovBBSSatisfactionService;
import egovframework.com.cop.bbs.service.Satisfaction;
import egovframework.com.cop.bbs.service.SatisfactionVO;
import egovframework.com.cop.bbs.service.impl.BBSAddedOptionsDAO;
import jakarta.annotation.Resource;

/**
 * 만족도조사를 위한 서비스 구현 클래스
 * @author 공통컴포넌트개발팀 한성곤
 * @since 2009.06.29
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.06.29  한성곤          최초 생성
 *   2011.09.15  서준식          addedOptions 적용 방법 수정
 *   2011.10.18  서준식          StsfdgNo 자동 생성 방식으로 변경
 * </pre>
 */
@Service("EgovBBSSatisfactionService")
public class EgovBBSSatisfactionServiceImpl extends EgovAbstractServiceImpl implements EgovBBSSatisfactionService {

    @Resource(name = "BBSAddedOptionsDAO")
    private BBSAddedOptionsDAO addedOptionsDAO;

    @Resource(name = "BBSSatisfactionDAO")
    private BBSSatisfactionDAO bbsSatisfactionDAO;

    @Resource(name = "egovStsfdgNoGnrService")
    private EgovIdGnrService egovStsfdgNoGnrService;

    /**
     * 만족도조사 사용 가능 여부를 확인한다.
     */
    @Override
	public boolean canUseSatisfaction(String bbsId) {
	//String flag = EgovProperties.getProperty("Globals.addedOptions");
	//if (flag != null && flag.trim().equalsIgnoreCase("true")) {//2011.09.15
	    BoardMaster vo = new BoardMaster();

	    vo.setBbsId(bbsId);

	    BoardMasterVO options = addedOptionsDAO.selectAddedOptionsInf(vo);

	    if (options == null) {
		return false;
	    }

	    if (options.getStsfdgAt().equals("Y")) {
		return true;
	    }
	//}

	return false;
    }

    /**
     * 만족도조사에 대한 목록을 조회 한다.
     */
    @Override
	public Map<String, Object> selectSatisfactionList(SatisfactionVO satisfactionVO) {
	List<SatisfactionVO> result = bbsSatisfactionDAO.selectSatisfactionList(satisfactionVO);
	int cnt = bbsSatisfactionDAO.selectSatisfactionListCnt(satisfactionVO);
	float summary = bbsSatisfactionDAO.getSummary(satisfactionVO);

	Map<String, Object> map = new HashMap<>();

	map.put("resultList", result);
	map.put("resultCnt", Integer.toString(cnt));
	map.put("summary", Float.toString(summary));

	return map;
    }

    /**
     * 만족도조사를 등록한다.
     */
    @Override
	public void insertSatisfaction(Satisfaction satisfaction) {

    try {
		satisfaction.setStsfdgNo(egovStsfdgNoGnrService.getNextLongId() + "");//2011.10.18
	} catch (FdlException e) {
		throw new BaseRuntimeException(e);
	}
	bbsSatisfactionDAO.insertSatisfaction(satisfaction);
    }

    /**
     * 만족도조사를 삭제한다.
     */
    @Override
	public void deleteSatisfaction(SatisfactionVO satisfactionVO) {
	bbsSatisfactionDAO.deleteSatisfaction(satisfactionVO);
    }

    /**
     * 만족도조사에 대한 내용을 조회한다.
     */
    @Override
	public Satisfaction selectSatisfaction(SatisfactionVO satisfactionVO) {
	return bbsSatisfactionDAO.selectSatisfaction(satisfactionVO);
    }

    /**
     * 만족도조사에 대한 내용을 수정한다.
     */
    @Override
	public void updateSatisfaction(Satisfaction satisfaction) {
	bbsSatisfactionDAO.updateSatisfaction(satisfaction);
    }

    /**
     * 만족도조사 패스워드를 가져온다.
     */
    @Override
	public String getSatisfactionPassword(Satisfaction satisfaction) {
	return bbsSatisfactionDAO.getSatisfactionPassword(satisfaction);
    }
}
