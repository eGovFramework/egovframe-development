package egovframework.com.cop.cmy.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;
import org.egovframe.rte.fdl.cmmn.exception.FdlException;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cop.cmy.service.Community;
import egovframework.com.cop.cmy.service.CommunityVO;
import egovframework.com.cop.cmy.service.EgovCommuMasterService;
import jakarta.annotation.Resource;

@Service("EgovCommuMasterService")
public class EgovCommuMasterServiceImpl extends EgovAbstractServiceImpl implements EgovCommuMasterService{

	@Resource(name = "EgovCommuMasterDAO")
    private EgovCommuMasterDAO egovCommuMasterDAO;

    @Resource(name = "egovCmmntyIdGnrService")
    private EgovIdGnrService idgenService;

	@Override
	public Map<String, Object> selectCommuMasterList(CommunityVO cmmntyVO) {

		List<CommunityVO> result = egovCommuMasterDAO.selectCommuMasterList(cmmntyVO);
		int cnt = egovCommuMasterDAO.selectCommuMasterListCnt(cmmntyVO);

		Map<String, Object> map = new HashMap<>();

		map.put("resultList", result);
		map.put("resultCnt", Integer.toString(cnt));

		return map;
	}

	@Override
	public String insertCommuMaster(Community community) {
		//게시판 ID 채번
		String cmmntyId;
		try {
			cmmntyId = idgenService.getNextStringId();
		} catch (FdlException e) {
			throw new BaseRuntimeException(e);
		}
		community.setCmmntyId(cmmntyId);

		egovCommuMasterDAO.insertCommuMaster(community);

		return cmmntyId;
	}

	@Override
	public CommunityVO selectCommuMaster(CommunityVO cmmntyVO) {
		CommunityVO resultVO = egovCommuMasterDAO.selectCommuMasterDetail(cmmntyVO);
        if (resultVO == null) {
			throw new BaseRuntimeException(processException("info.nodata.msg"));
		}
        return resultVO;
	}

	@Override
	public void updateCommuMaster(Community community) {
		egovCommuMasterDAO.updateCommuMaster(community);
	}

	@Override
	public void deleteBBSMasterInf(Community community) {
		egovCommuMasterDAO.deleteCommuMaster(community);
	}

	@Override
	public List<CommunityVO> selectCommuMasterListPortlet(CommunityVO cmmntyVO) {
		return egovCommuMasterDAO.selectCommuMasterListPortlet(cmmntyVO);
	}

}
