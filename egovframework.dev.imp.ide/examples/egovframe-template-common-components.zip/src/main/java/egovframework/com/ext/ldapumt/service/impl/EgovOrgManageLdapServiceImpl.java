/*
 * eGovFrame LDAP조직도관리
 * Copyright The eGovFrame Open Community (http://open.egovframe.go.kr)).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @author 전우성(슈퍼개발자K3)
 */
package egovframework.com.ext.ldapumt.service.impl;

import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.ldap.support.LdapEncoder;
import org.springframework.stereotype.Service;

import egovframework.com.ext.ldapumt.service.EgovOrgManageLdapService;
import egovframework.com.ext.ldapumt.service.LdapTreeObject;
import egovframework.com.ext.ldapumt.service.UcorgVO;
import egovframework.com.ext.ldapumt.service.UserVO;
import jakarta.annotation.Resource;

/**
*
* 조직도 기능 관련 서비스 객체
* @author 전우성
* @since 2014.10.12
* @version 1.0
* @see
*
* <pre>
* << 개정이력(Modification Information) >>
*
*  수정일               수정자             수정내용
*  ----------   --------   ---------------------------
*  2014.10.12   전우성            최초 생성
*  2020.08.28   정진오            표준프레임워크 v3.10 개선
*  2023.08.10   신용호            LDAP 오류 수정
*
* </pre>
*/
@Service("orgManageLdapService")
public class EgovOrgManageLdapServiceImpl extends EgovAbstractServiceImpl implements EgovOrgManageLdapService {

	@Resource(name = "DeptManageLdapDAO")
	private DeptManageLdapDAO deptManageLdapDAO;

	@Resource(name = "UserManageLdapDAO")
	private UserManageLdapDAO userManageLdapDAO;

	/**
	 * 등록된 부서의 정보를 조회한다.
	 */
	@Override
	public Map<Object, Object> selectDeptManage(String dn) {
		UcorgVO vo = deptManageLdapDAO.selectDeptManageByDn(dn);

		Map<Object, Object> map = new org.apache.commons.beanutils.BeanMap(vo);

		return map;
	}

	/**
	 * 등록된 사용자의 정보를 조회한다.
	 */
	@Override
	public Map<Object, Object> selectUserManage(String dn) {
		UserVO vo = userManageLdapDAO.selectUserManageByDn(dn);

		Map<Object, Object> map = new org.apache.commons.beanutils.BeanMap(vo);

		return map;
	}

	/**
	 * 등록된 부서의 목록을 조회한다.
	 */
	@Override
	public Map<Object, Object> selectDeptManageSubList(String dn) throws Exception {
		UcorgVO u = deptManageLdapDAO.selectDeptManageByDn(dn);

		LdapTreeObject object = new LdapTreeObject(u.getOu(), dn);

		List<Object> list = deptManageLdapDAO.selectDeptManageSubList(dn);

		for (Object o : list) {
			UcorgVO vo = (UcorgVO) o;
			boolean hasChildren = deptManageLdapDAO.hasChildren(vo.getDn());
			object.addChild(vo, hasChildren);
		}

		List<Object> userList = userManageLdapDAO.selectUserManageList(dn);

		for (Object o : userList) {
			UserVO vo = (UserVO) o;
			object.addChild(vo);
		}

		Map<Object, Object> map = new org.apache.commons.beanutils.BeanMap(object);

		return map;
	}

	/**
	 * ouCode로 하위부서의 목록을 조회한다.
	 */
	@Override
	public List<Object> selectDeptManageSubListByOuCode(String ouCode) throws Exception {
		return deptManageLdapDAO.selectDeptManageSubListByOuCode(ouCode);
	}

	/**
	 * VO의 조건에 부합하는 부서를 조회한다.
	 */
	@Override
	public UcorgVO selectDeptManage(UcorgVO vo) throws Exception {
		return deptManageLdapDAO.selectDeptManage(vo);
	}


	/**
	 * 기등록된 부서정보를 수정한다.
	 */
	@Override
	public void updateDeptManage(UcorgVO vo) throws Exception {
		deptManageLdapDAO.updateDeptManage(vo);
	}

	/**
	 * 부서를 추가한다.
	 */
	@Override
	public Map<Object, Object> insertDeptManage(String parentDn, String ou) throws Exception {
		// 2026.07.13 NCSC 보안점검 조치: 컨트롤러의 문자 제한 검증에 더해, LDAP DN 이스케이프를 한 번 더 적용하여 DN/RDN 주입을 방지(심층 방어)
		String encodedOu = LdapEncoder.nameEncode(ou);
		UcorgVO vo = new UcorgVO();
		if ("j1_1".equals(parentDn)) { // Root에서 생성
			vo.setDn("ou=" + encodedOu);
		} else { // Root에서 생성
			vo.setDn("ou=" + encodedOu + ", " + parentDn);
		}
		vo.setOu(ou);
		vo.setOuCode("0000000");

		deptManageLdapDAO.insertDeptManage(vo);
		LdapTreeObject object = new LdapTreeObject(vo.getOu(), vo.getDn());

		Map<Object, Object> map = new org.apache.commons.beanutils.BeanMap(object);

		return map;
	}

	/**
	 * 사용자를 추가한다.
	 */
	@Override
	public Map<Object, Object> insertUserManage(String parentDn, String cn) throws Exception {
		// 2026.07.13 NCSC 보안점검 조치: LDAP DN 이스케이프 적용(심층 방어)
		UserVO vo = new UserVO();
		vo.setDn("cn=" + LdapEncoder.nameEncode(cn) + ", " + parentDn);
		vo.setCn(cn);

		userManageLdapDAO.insertUserManage(vo);

		LdapTreeObject object = new LdapTreeObject(vo.getOu(), vo.getDn());

		Map<Object, Object> map = new org.apache.commons.beanutils.BeanMap(object);

		return map;
	}

	/**
	 * 사용자 정보를 삭제한다.
	 */
	@Override
	public void deleteDeptManage(String dn) {
		deptManageLdapDAO.deleteDeptManage(dn);
	}

	/**
	 * 부서의 이름을 변경한다.
	 */
	@Override
	public void renameDeptManage(String dn, String name) {
		// 2026.07.13 NCSC 보안점검 조치: 컨트롤러의 문자 제한 검증(validateRdnValue)에 더해 LDAP DN 이스케이프를 한 번 더 적용(심층 방어)하여
		// name 값에 쉼표(,), 더하기(+), 등호(=) 등 DN 구분자가 포함되어 있어도 리터럴 RDN 값으로만 처리되도록 한다.
		String[] nodes = dn.split(",");
		nodes[0] = "ou=" + LdapEncoder.nameEncode(name);

		String newDn = "";
		for (String node : nodes) {
			newDn = newDn + "," + node;
		}

		newDn = newDn.substring(1);
		deptManageLdapDAO.moveDeptManage(dn, newDn);
	}

	/**
	 * 사용자의 이름을 변경한다.
	 */
	@Override
	public void renameUserManage(String dn, String name) {
		// 2026.07.13 NCSC 보안점검 조치: LDAP DN 이스케이프 적용(심층 방어)
		String[] nodes = dn.split(",");
		nodes[0] = "cn=" + LdapEncoder.nameEncode(name);

		String newDn = "";
		for (String node : nodes) {
			newDn = newDn + "," + node;
		}

		newDn = newDn.substring(1);
		userManageLdapDAO.moveUserManage(dn, newDn);
	}

	/**
	 * 조직을 이동한다.
	 */
	@Override
	public void moveOrgManage(String dn, String parentDn) {
		String name = dn.split(",")[0];

		deptManageLdapDAO.moveDeptManage(dn, name + "," + parentDn);
	}

	/**
	 * 부서정보를 수정한다.
	 */
	@Override
	public void modifyDeptManage(UcorgVO ucorgVO) throws Exception {
		deptManageLdapDAO.updateDeptManage(ucorgVO);
	}

	/**
	 * 사용자의 정보를 수정한다.
	 */
	@Override
	public void modifyUserManage(UserVO userVO) {
		userManageLdapDAO.updateUserManage(userVO);
	}

}
