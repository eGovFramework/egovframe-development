package egovframework.com.cop.tpl.web;

import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.service.CmmnDetailCode;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.cop.tpl.service.EgovTemplateManageService;
import egovframework.com.cop.tpl.service.TemplateInf;
import egovframework.com.cop.tpl.service.TemplateInfVO;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 * 템플릿 관리를 위한 컨트롤러 클래스
 * @author 공통서비스개발팀 이삼섭
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------        --------    ---------------------------
 *   2009.03.18  이삼섭          최초 생성
 *   2011.08.26	 정진오			IncludedInfo annotation 추가
 *
 * </pre>
 */
@Controller
public class EgovTemplateManageController {

	@Resource(name = "EgovTemplateManageService")
	private EgovTemplateManageService tmplatService;

	@Resource(name = "EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	@Resource(name = "propertiesService")
	protected EgovPropertyService propertyService;

	//Logger log = Logger.getLogger(this.getClass());

	/**
	 * 템플릿 목록을 조회한다.
	 *
	 * @param searchVO
	 * @param model
	 * @return
	 */
	@IncludedInfo(name = "템플릿관리", order = 200, gid = 40)
	@RequestMapping("/cop/tpl/selectTemplateInfs.do")
	public String selectTemplateInfs(@ModelAttribute("searchVO") TemplateInfVO tmplatInfVO, ModelMap model) {
		tmplatInfVO.setPageUnit(propertyService.getInt("pageUnit"));
		tmplatInfVO.setPageSize(propertyService.getInt("pageSize"));

		PaginationInfo paginationInfo = new PaginationInfo();

		paginationInfo.setCurrentPageNo(tmplatInfVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(tmplatInfVO.getPageUnit());
		paginationInfo.setPageSize(tmplatInfVO.getPageSize());

		tmplatInfVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		tmplatInfVO.setLastIndex(paginationInfo.getLastRecordIndex());
		tmplatInfVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		Map<String, Object> map = tmplatService.selectTemplateInfs(tmplatInfVO);
		int totCnt = Integer.parseInt((String) map.get("resultCnt"));

		paginationInfo.setTotalRecordCount(totCnt);

		model.addAttribute("resultList", map.get("resultList"));
		model.addAttribute("resultCnt", map.get("resultCnt"));
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/cop/tpl/EgovTemplateList";
	}

	/**
	 * 템플릿에 대한 상세정보를 조회한다.
	 *
	 * @param searchVO
	 * @param model
	 * @return
	 */
	@PostMapping("/cop/tpl/selectTemplateInf.do")
	public String selectTemplateInf(@ModelAttribute("searchVO") TemplateInfVO tmplatInfVO, ModelMap model) {

		ComDefaultCodeVO codeVO = new ComDefaultCodeVO();

		codeVO.setCodeId("COM005");
		List<CmmnDetailCode> result = cmmUseService.selectCmmCodeDetail(codeVO);

		TemplateInfVO vo = tmplatService.selectTemplateInf(tmplatInfVO);
		if (!isAdminManagedDefault(vo)) {
			EgovAuthorizationHelper.assertOwner(vo == null ? null : vo.getFrstRegisterId());
		}

		model.addAttribute("TemplateInfVO", vo);
		model.addAttribute("resultList", result);

		return "egovframework/com/cop/tpl/EgovTemplateUpdt";
	}

	/**
	 * 템플릿 정보를 등록한다.
	 *
	 * @param searchVO
	 * @param tmplatInfo
	 * @param model
	 * @return
	 */
	@PostMapping("/cop/tpl/insertTemplateInf.do")
	public String insertTemplateInf(@ModelAttribute("searchVO") TemplateInfVO searchVO,
			@Valid @ModelAttribute("templateInf") TemplateInf templateInf, BindingResult bindingResult,
			SessionStatus status, ModelMap model) {

		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		if (bindingResult.hasErrors()) {
			ComDefaultCodeVO vo = new ComDefaultCodeVO();

			vo.setCodeId("COM005");

			List<CmmnDetailCode> result = cmmUseService.selectCmmCodeDetail(vo);

			model.addAttribute("resultList", result);

			return "egovframework/com/cop/tpl/EgovTemplateRegist";
		}

		if (isAuthenticated) {
			templateInf.setFrstRegisterId(user.getUniqId());
			tmplatService.insertTemplateInf(templateInf);
		}

		return "forward:/cop/tpl/selectTemplateInfs.do";
	}

	/**
	 * 템플릿 등록을 위한 등록페이지로 이동한다.
	 *
	 * @param searchVO
	 * @param model
	 * @return
	 */
	@PostMapping("/cop/tpl/addTemplateInf.do")
	public String addTemplateInf(@ModelAttribute("searchVO") TemplateInfVO searchVO, ModelMap model) {
		ComDefaultCodeVO vo = new ComDefaultCodeVO();

		vo.setCodeId("COM005");

		List<CmmnDetailCode> result = cmmUseService.selectCmmCodeDetail(vo);

		model.addAttribute("resultList", result);

		return "egovframework/com/cop/tpl/EgovTemplateRegist";
	}

	/**
	 * 템플릿 정보를 수정한다.
	 *
	 * @param searchVO
	 * @param tmplatInfo
	 * @param model
	 * @return
	 */
	@PostMapping("/cop/tpl/updateTemplateInf.do")
	public String updateTemplateInf(@ModelAttribute("searchVO") TemplateInfVO tmplatInfVO,
			@Valid @ModelAttribute("templateInf") TemplateInf templateInf, BindingResult bindingResult,
			SessionStatus status, ModelMap model) {

		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		TemplateInfVO lookup = new TemplateInfVO();
		lookup.setTmplatId(templateInf.getTmplatId());
		TemplateInfVO stored = tmplatService.selectTemplateInf(lookup);
		if (!isAdminManagedDefault(stored)) {
			EgovAuthorizationHelper.assertOwner(stored == null ? null : stored.getFrstRegisterId());
		}

		if (bindingResult.hasErrors()) {
			ComDefaultCodeVO codeVO = new ComDefaultCodeVO();

			codeVO.setCodeId("COM005");

			List<CmmnDetailCode> result = cmmUseService.selectCmmCodeDetail(codeVO);

			TemplateInfVO vo = tmplatService.selectTemplateInf(tmplatInfVO);

			model.addAttribute("TemplateInfVO", vo);
			model.addAttribute("resultList", result);

			return "egovframework/com/cop/tpl/EgovTemplateUpdt";
		}

		if (isAuthenticated) {
			templateInf.setLastUpdusrId(user.getUniqId());
			tmplatService.updateTemplateInf(templateInf);
		}

		return "forward:/cop/tpl/selectTemplateInfs.do";
	}

	/**
	 * 템플릿 정보를 삭제한다.
	 *
	 * @param searchVO
	 * @param tmplatInfo
	 * @param model
	 * @return
	 */
	@PostMapping("/cop/bbs/deleteTemplateInf.do")
	public String deleteTemplateInf(@ModelAttribute("searchVO") TemplateInfVO searchVO, @ModelAttribute("tmplatInf") TemplateInf tmplatInf, SessionStatus status, ModelMap model) {

		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		if (isAuthenticated) {
			TemplateInfVO lookup = new TemplateInfVO();
			lookup.setTmplatId(tmplatInf.getTmplatId());
			TemplateInfVO stored = tmplatService.selectTemplateInf(lookup);
			if (!isAdminManagedDefault(stored)) {
				EgovAuthorizationHelper.assertOwner(stored == null ? null : stored.getFrstRegisterId());
			}

			tmplatInf.setLastUpdusrId(user.getUniqId());
			tmplatService.deleteTemplateInf(tmplatInf);
		}

		return "forward:/cop/tpl/selectTemplateInfs.do";
	}

	/**
	 * 팝업을 위한 템플릿 목록을 조회한다.
	 *
	 * @param searchVO
	 * @param model
	 * @return
	 */
	@RequestMapping("/cop/tpl/selectTemplateInfsPop.do")
	public String selectTemplateInfsPop(@ModelAttribute("searchVO") TemplateInfVO tmplatInfVO, @RequestParam Map<String, Object> commandMap, ModelMap model) {

		String typeFlag = (String) commandMap.get("typeFlag");

		if ("CLB".equals(typeFlag)) {
			tmplatInfVO.setTypeFlag(typeFlag);
			tmplatInfVO.setTmplatSeCode("TMPT03");
		} else if ("CMY".equals(typeFlag)) {
			tmplatInfVO.setTypeFlag(typeFlag);
			tmplatInfVO.setTmplatSeCode("TMPT02");
		} else {
			tmplatInfVO.setTypeFlag(typeFlag);
			tmplatInfVO.setTmplatSeCode("TMPT01");
		}

		tmplatInfVO.setPageUnit(propertyService.getInt("pageUnit"));
		tmplatInfVO.setPageSize(propertyService.getInt("pageSize"));
		//CMY, CLB

		PaginationInfo paginationInfo = new PaginationInfo();

		paginationInfo.setCurrentPageNo(tmplatInfVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(tmplatInfVO.getPageUnit());
		paginationInfo.setPageSize(tmplatInfVO.getPageSize());

		tmplatInfVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		tmplatInfVO.setLastIndex(paginationInfo.getLastRecordIndex());
		tmplatInfVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		Map<String, Object> map = tmplatService.selectTemplateInfs(tmplatInfVO);
		int totCnt = Integer.parseInt((String) map.get("resultCnt"));

		paginationInfo.setTotalRecordCount(totCnt);

		model.addAttribute("resultList", map.get("resultList"));
		model.addAttribute("resultCnt", map.get("resultCnt"));
		model.addAttribute("typeFlag", typeFlag);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/cop/tpl/EgovTemplateInqirePopup";
	}

	/**
	 * 등록자가 SYSTEM 인 기본 템플릿(초기 데이터)을 관리자가 다루는 경우. 그 외 템플릿은 작성자 본인만 상세·수정·삭제한다.
	 */
	private static boolean isAdminManagedDefault(TemplateInfVO stored) {
		return stored != null && "SYSTEM".equals(stored.getFrstRegisterId()) && EgovAuthorizationHelper.isAdmin();
	}
}
