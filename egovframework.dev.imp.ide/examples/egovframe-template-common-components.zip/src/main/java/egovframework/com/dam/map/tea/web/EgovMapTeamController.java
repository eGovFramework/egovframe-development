package egovframework.com.dam.map.tea.web;

import egovframework.com.cmm.annotation.RequireAdmin;

import java.util.List;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.dam.map.tea.service.EgovMapTeamService;
import egovframework.com.dam.map.tea.service.MapTeam;
import egovframework.com.dam.map.tea.service.MapTeamVO;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 * <pre>
 * 개요
 * - 지식맵(조직별)에 대한 controller 클래스를 정의한다.
 *
 * 상세내용
 * - 지식맵(조직별)에 대한 등록, 수정, 삭제, 조회 기능을 제공한다.
 * - 지식맵(조직별)의 조회기능은 목록조회, 상세조회로 구분된다.
 * </pre>
 * 
 * @author 박종선
 * @since 2010.07.22
 * @version 1.0
 * @see
 * 
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2010.07.22  박종선          최초 생성
 *   2011.08.26  정진오          IncludedInfo annotation 추가
 *   2018.08.03  신용호          updateMapTeam method 수정 않되는 문제 처리
 *   2025.06.16  이백행          PMD로 소프트웨어 보안약점 진단하고 제거하기-LocalVariableNamingConventions(지역 변수 명명 규칙)
 *
 *      </pre>
 */

@Controller
public class EgovMapTeamController {

	@Resource(name = "MapTeamService")
	private EgovMapTeamService mapTeamService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/**
	 * 등록된 지식맵(조직별) 정보를 조회 한다.
	 * 
	 * @param mapTeamVO- 지식맵(조직별) VO
	 * @return String - 리턴 Url
	 *
	 * @param MapTeamVO
	 */
	@IncludedInfo(name = "지식맵관리(조직)", listUrl = "/dam/map/tea/EgovComDamMapTeamList.do", order = 1261, gid = 80)
	@RequestMapping(value = "/dam/map/tea/EgovComDamMapTeamList.do")
	public String selectMapTeamList(@ModelAttribute("loginVO") LoginVO loginVO,
			@ModelAttribute("searchVO") MapTeamVO searchVO, ModelMap model) throws Exception {
		/** EgovPropertyService.mapTeam */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** paging */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<MapTeamVO> resultList = mapTeamService.selectMapTeamList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = mapTeamService.selectMapTeamTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		return "egovframework/com/dam/map/tea/EgovComDamMapTeamList";
	}

	/**
	 * 지식맵(조직별)상세 정보를 조회 한다.
	 * 
	 * @param MapTeamVO - 지식맵(조직별) VO
	 * @return String - 리턴 Url
	 *
	 * @param MapTeamVO
	 */
	@PostMapping("/dam/map/tea/EgovComDamMapTeamDetail.do")
	@RequireAdmin
	public String selectMapTeamDetail(@ModelAttribute("loginVO") LoginVO loginVO, MapTeam mapTeam, ModelMap model)
			throws Exception {
		MapTeam vo = mapTeamService.selectMapTeamDetail(mapTeam);
		model.addAttribute("result", vo);
		return "egovframework/com/dam/map/tea/EgovComDamMapTeamDetail";
	}

	/**
	 * 지식맵(조직별) 등록 화면으로 이동한다.
	 *
	 * @return String - 리턴 Url
	 */
	@PostMapping("/dam/map/tea/EgovComDamMapTeamRegistView.do")
	@RequireAdmin
	public String insertMapTeamView(@ModelAttribute("mapTeam") MapTeam mapTeam) throws Exception {
		return "egovframework/com/dam/map/tea/EgovComDamMapTeamRegist";
	}

	/**
	 * 지식맵(조직별) 정보를 신규로 등록한다.
	 *
	 * @param orgnztNm - 지식맵(조직별) model
	 * @return String - 리턴 Url
	 *
	 * @param mapTeam
	 */
	@PostMapping("/dam/map/tea/EgovComDamMapTeamRegist.do")
	@RequireAdmin
	public String insertMapTeam(@ModelAttribute("loginVO") LoginVO loginVO, @Valid @ModelAttribute("mapTeam") MapTeam mapTeam,
			BindingResult bindingResult) throws Exception {

		if (bindingResult.hasErrors()) {
			return "egovframework/com/dam/map/tea/EgovComDamMapTeamRegist";
		}

		mapTeam.setFrstRegisterId(loginVO.getUniqId());
		try {
			mapTeamService.insertMapTeam(mapTeam);
			return "forward:/dam/map/tea/EgovComDamMapTeamList.do";
		} catch (DuplicateKeyException e) {
			bindingResult.rejectValue("orgnztId", "error.orgnztId", "이미 등록된 조직ID입니다.");
			return "egovframework/com/dam/map/tea/EgovComDamMapTeamRegist";
		}
	}

	/**
	 * 지식맵(조직별) 수정 화면으로 이동한다.
	 *
	 * @param mapTeam - 지식맵(조직별) model
	 * @return String - 리턴 Url
	 */
	@PostMapping("/dam/map/tea/EgovComDamMapTeamModifyView.do")
	@RequireAdmin
	public String updateMapTeamView(@ModelAttribute("mapTeam") MapTeam mapTeam, ModelMap model) throws Exception {
		MapTeam vo = mapTeamService.selectMapTeamDetail(mapTeam);
		model.addAttribute("mapTeam", vo);
		return "egovframework/com/dam/map/tea/EgovComDamMapTeamModify";
	}

	/**
	 * 기 등록 된 지식맵(조직별) 정보를 수정 한다.
	 *
	 * @param orgnztNm - 지식맵(조직별) model
	 * @return String - 리턴 Url
	 *
	 * @param mapTeam
	 */
	@PostMapping("/dam/map/tea/EgovComDamMapTeamModify.do")
	@RequireAdmin
	public String updateMapTeam(@ModelAttribute("loginVO") LoginVO loginVO, @Valid @ModelAttribute("mapTeam") MapTeam mapTeam,
			BindingResult bindingResult, ModelMap model) throws Exception {

		if (bindingResult.hasErrors()) {
			return "egovframework/com/dam/map/tea/EgovComDamMapTeamModify";
		}

		mapTeam.setFrstRegisterId(loginVO.getUniqId());
		mapTeam.setLastUpdusrId(loginVO.getUniqId());
		mapTeamService.updateMapTeam(mapTeam);
		return "forward:/dam/map/tea/EgovComDamMapTeamList.do";
	}

	/**
	 * 기 등록된 지식맵(조직별) 정보를 삭제한다.
	 * 
	 * @param orgnztNm - 지식맵(조직별) model
	 * @return String - 리턴 Url
	 *
	 * @param orgnztNm
	 */
	@PostMapping("/dam/map/tea/EgovComDamMapTeamRemove.do")
	@RequireAdmin
	public String deleteMapTeam(@ModelAttribute("loginVO") LoginVO loginVO, MapTeam mapTeam, ModelMap model)
			throws Exception {
		mapTeamService.deleteMapTeam(mapTeam);
		return "forward:/dam/map/tea/EgovComDamMapTeamList.do";
	}

}