package egovframework.com.cop.cmt.web;

import egovframework.com.cmm.util.EgovAuthorizationHelper;

import java.util.HashMap;
import java.util.Map;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cop.bbs.service.EgovArticleService;
import egovframework.com.cop.bbs.service.BoardVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.cop.cmt.service.Comment;
import egovframework.com.cop.cmt.service.CommentVO;
import egovframework.com.cop.cmt.service.EgovArticleCommentService;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

/**
 * 댓글 관리를 위한 컨트롤러 클래스
 * @author 공통서비스개발팀 신용호
 * @since 2016.07.22
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------       --------    ---------------------------
 *   2016.07.22   신용호              최초 생성
 *   2018.06.27     신용호		    댓글 등록후 처리 예외 수정
 * </pre>
 */

@Controller
public class EgovArticleCommentController {

	@Resource(name = "EgovArticleCommentService")
    protected EgovArticleCommentService egovArticleCommentService;

	@Resource(name = "EgovArticleService")
	private EgovArticleService egovArticleService;

    @Resource(name="propertiesService")
    protected EgovPropertyService propertyService;

    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;

    //protected Logger log = Logger.getLogger(this.getClass());

    /**
     * 댓글관리 목록 조회를 제공한다.
     *
     * @param boardVO
     * @param model
     * @return
     */
    @RequestMapping("/cop/cmt/selectArticleCommentList.do")
    public String selectArticleCommentList(@ModelAttribute("searchVO") CommentVO commentVO, ModelMap model) {

    	CommentVO articleCommentVO = new CommentVO();

		// 수정 처리된 후 댓글 등록 화면으로 처리되기 위한 구현
		if (commentVO.isModified()) {
		    commentVO.setCommentNo("");
		    commentVO.setCommentCn("");
		}

		// 수정을 위한 처리
		if (commentVO.getCommentNo() != null && !"".equals(commentVO.getCommentNo())) {
		    return "forward:/cop/cmt/updateArticleCommentView.do";
		}

		LoginVO user = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();
   	 	// KISA 보안취약점 조치 (2018-12-10, 신용호)
        Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

        if(!isAuthenticated) {
            return "redirect:/uat/uia/egovLoginUsr.do";
        }

		// 부모 글이 비밀글이면 작성자만 — 게시글 상세와 같은 검사. 조회수는 올리지 않는다
		BoardVO parent = new BoardVO();
		parent.setBbsId(commentVO.getBbsId());
		parent.setNttId(commentVO.getNttId());
		parent = egovArticleService.selectArticleDetailNoCount(parent);
		if (parent != null) {
			EgovAuthorizationHelper.assertArticleReadable(parent.getSecretAt(), parent.getFrstRegisterId());
		}

		model.addAttribute("sessionUniqId", user == null ? "" : EgovStringUtil.isNullToString(user.getUniqId()));

		commentVO.setWrterNm(user == null ? "" : EgovStringUtil.isNullToString(user.getName()));

//		commentVO.setSubPageUnit(propertyService.getInt("pageUnit"));
//		commentVO.setSubPageSize(propertyService.getInt("pageSize"));

		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(commentVO.getSubPageIndex());
		paginationInfo.setRecordCountPerPage(commentVO.getSubPageUnit());
		paginationInfo.setPageSize(commentVO.getSubPageSize());

		commentVO.setSubFirstIndex(paginationInfo.getFirstRecordIndex());
		commentVO.setSubLastIndex(paginationInfo.getLastRecordIndex());
		commentVO.setSubRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		Map<String, Object> map = egovArticleCommentService.selectArticleCommentList(commentVO);
		int totCnt = Integer.parseInt((String)map.get("resultCnt"));

		paginationInfo.setTotalRecordCount(totCnt);

		model.addAttribute("resultList", map.get("resultList"));
		model.addAttribute("resultCnt", map.get("resultCnt"));
		model.addAttribute("paginationInfo", paginationInfo);
		model.addAttribute("type", "body");	// 댓글 페이지 body import용

		model.addAttribute("articleCommentVO", articleCommentVO);	// validator 용도

		commentVO.setCommentCn("");	// 등록 후 댓글 내용 처리

		return "egovframework/com/cop/cmt/EgovArticleCommentList";
    }


    /**
     * 댓글을 등록한다.
     *
     * @param commentVO
     * @param comment
     * @param bindingResult
     * @param model
     * @return
     */
    @PostMapping("/cop/cmt/insertArticleComment.do")
    public String insertArticleComment(@ModelAttribute("searchVO") CommentVO commentVO, @Valid @ModelAttribute("comment") Comment comment,
	    BindingResult bindingResult, ModelMap model, @RequestParam HashMap<String, String> map) {

		LoginVO user = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		if (bindingResult.hasErrors()) {
		    model.addAttribute("msg", "댓글내용은 필수 입력값입니다.");

		    return "forward:/cop/bbs/selectArticleDetail.do";
		}

		if (isAuthenticated) {
		    // 부모 글이 비밀글이면 작성자만 — 게시글 상세와 같은 검사. 조회수는 올리지 않는다
		    BoardVO parent = new BoardVO();
		    parent.setBbsId(comment.getBbsId());
		    parent.setNttId(comment.getNttId());
		    parent = egovArticleService.selectArticleDetailNoCount(parent);
		    if (parent != null) {
		    	EgovAuthorizationHelper.assertArticleReadable(parent.getSecretAt(), parent.getFrstRegisterId());
		    }
		    comment.setFrstRegisterId(user == null ? "" : EgovStringUtil.isNullToString(user.getUniqId()));
		    comment.setWrterId(user == null ? "" : EgovStringUtil.isNullToString(user.getUniqId()));
		    comment.setWrterNm(user == null ? "" : EgovStringUtil.isNullToString(user.getName()));


		    egovArticleCommentService.insertArticleComment(comment);

		    commentVO.setCommentCn("");
		    commentVO.setCommentNo("");
		}

		String chkBlog = map.get("blogAt");

		if("Y".equals(chkBlog)){
			return "forward:/cop/bbs/selectArticleBlogList.do";
		}else{
			return "forward:/cop/bbs/selectArticleDetail.do";
		}

    }


    /**
     * 댓글을 삭제한다.
     *
     * @param commentVO
     * @param comment
     * @param model
     * @return
     */
    @PostMapping("/cop/cmt/deleteArticleComment.do")
    public String deleteArticleComment(HttpServletRequest request, @ModelAttribute("searchVO") CommentVO commentVO, @ModelAttribute("comment") Comment comment,
			ModelMap model, @RequestParam HashMap<String, String> map) {
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		if (isAuthenticated) {
		    checkCommentOwner(request, commentVO.getCommentNo());
		    egovArticleCommentService.deleteArticleComment(commentVO);
		}

		commentVO.setCommentCn("");
		commentVO.setCommentNo("");

		String chkBlog = map.get("blogAt");

		if("Y".equals(chkBlog)){
			return "forward:/cop/bbs/selectArticleBlogList.do";
		}else{
			return "forward:/cop/bbs/selectArticleDetail.do";
		}
    }


    /**
     * 댓글 수정 페이지로 이동한다.
     *
     * @param commentVO
     * @param model
     * @return
     */
    @PostMapping("/cop/cmt/updateArticleCommentView.do")
    public String updateArticleCommentView(@ModelAttribute("searchVO") CommentVO commentVO, ModelMap model) {

	LoginVO user = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();
	 //KISA 보안취약점 조치 (2018-12-10, 신용호)
    Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

    if(!isAuthenticated) {
        return "redirect:/uat/uia/egovLoginUsr.do";
    }

	CommentVO articleCommentVO = new CommentVO();

	commentVO.setWrterNm(user == null ? "" : EgovStringUtil.isNullToString(user.getName()));

	commentVO.setSubPageUnit(propertyService.getInt("pageUnit"));
	commentVO.setSubPageSize(propertyService.getInt("pageSize"));

	PaginationInfo paginationInfo = new PaginationInfo();
	paginationInfo.setCurrentPageNo(commentVO.getSubPageIndex());
	paginationInfo.setRecordCountPerPage(commentVO.getSubPageUnit());
	paginationInfo.setPageSize(commentVO.getSubPageSize());

	commentVO.setSubFirstIndex(paginationInfo.getFirstRecordIndex());
	commentVO.setSubLastIndex(paginationInfo.getLastRecordIndex());
	commentVO.setSubRecordCountPerPage(paginationInfo.getRecordCountPerPage());

	Map<String, Object> map = egovArticleCommentService.selectArticleCommentList(commentVO);
	int totCnt = Integer.parseInt((String)map.get("resultCnt"));

	paginationInfo.setTotalRecordCount(totCnt);

	model.addAttribute("resultList", map.get("resultList"));
	model.addAttribute("resultCnt", map.get("resultCnt"));
	model.addAttribute("paginationInfo", paginationInfo);
	model.addAttribute("type", "body");	// body import

	articleCommentVO = egovArticleCommentService.selectArticleCommentDetail(commentVO);
	// 2026.07.30 보안 조치 - 소유자 검증
	// 2026.09.21 식별자 교정 - 댓글 WRTER_ID 는 등록 시 uniqId 로 저장하므로 uniqId 기준으로 비교한다.
	EgovAuthorizationHelper.assertOwner(articleCommentVO == null ? null : articleCommentVO.getWrterId());

	model.addAttribute("articleCommentVO", articleCommentVO);


	return "egovframework/com/cop/cmt/EgovArticleCommentList";
    }


    /**
     * 댓글을 수정한다.
     *
     * @param commentVO
     * @param comment
     * @param bindingResult
     * @param model
     * @return
     */
    @PostMapping("/cop/cmt/updateArticleComment.do")
    public String updateArticleComment(HttpServletRequest request, @ModelAttribute("searchVO") CommentVO commentVO, @Valid @ModelAttribute("comment") Comment comment,
	    BindingResult bindingResult, ModelMap model) {

		LoginVO user = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		if (bindingResult.hasErrors()) {
		    model.addAttribute("msg", "내용은 필수 입력 값입니다.");

		    return "forward:/cop/bbs/selectArticleDetail.do";
		}

		if (isAuthenticated) {
		    checkCommentOwner(request, comment.getCommentNo());
		    comment.setLastUpdusrId(user == null ? "" : EgovStringUtil.isNullToString(user.getUniqId()));

		    egovArticleCommentService.updateArticleComment(comment);

		    commentVO.setCommentCn("");
		    commentVO.setCommentNo("");
		}

		return "forward:/cop/bbs/selectArticleDetail.do";
    }

    private void checkCommentOwner(HttpServletRequest request, String commentNo) {
		CommentVO ownerVO = new CommentVO();
		ownerVO.setCommentNo(commentNo);

		CommentVO data = egovArticleCommentService.selectArticleCommentDetail(ownerVO);
		EgovAuthorizationHelper.assertOwner(data == null ? null : data.getWrterId());
    }


}
