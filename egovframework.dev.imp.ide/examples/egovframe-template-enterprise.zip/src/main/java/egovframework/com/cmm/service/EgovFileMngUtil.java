package egovframework.com.cmm.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;
import org.egovframe.rte.fdl.cmmn.exception.FdlException;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import egovframework.com.cmm.EgovWebUtil;
import egovframework.let.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;

/**
 * @author 공통 서비스 개발팀 이삼섭
 * @version 1.0
 * @Class Name  : EgovFileMngUtil.java
 * @Description : 메시지 처리 관련 유틸리티
 * @Modification Information
 *
 *     수정일         수정자                   수정내용
 *     -------          --------        ---------------------------
 *   2009.02.13       이삼섭                  최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *
 * @see
 * @since 2009. 02. 13
 */
@Component("EgovFileMngUtil")
public class EgovFileMngUtil {

    public static final int BUFF_SIZE = 2048;

    @Resource(name = "propertiesService")
    protected EgovPropertyService propertyService;

    @Resource(name = "egovFileIdGnrService")
    private EgovIdGnrService idgenService;

    /**
     * 첨부파일에 대한 목록 정보를 취득한다.
     *
     * @param files
     * @return
     */
    public List<FileVO> parseFileInf(Map<String, MultipartFile> files, String KeyStr, int fileKeyParam, String atchFileId, String storePath) {
    	int fileKey = fileKeyParam;

    	String storePathString = "";
    	String atchFileIdString = "";

    	if (storePath == null || "".equals(storePath)) {
    		storePathString = propertyService.getString("Globals.fileStorePath");
    	} else {
    		storePathString = propertyService.getString(storePath);
    	}

    	if (atchFileId == null || "".equals(atchFileId)) {
    		try {
				atchFileIdString = idgenService.getNextStringId();
			} catch (FdlException e) {
				throw new BaseRuntimeException(e);
			}
    	} else {
    		atchFileIdString = atchFileId;
    	}

    	File saveFolder = new File(EgovWebUtil.filePathBlackList(storePathString));

    	if (!saveFolder.exists() || saveFolder.isFile()) {
    		saveFolder.mkdirs();
    	}

		Iterator<Entry<String, MultipartFile>> itr = files.entrySet().iterator();
		MultipartFile file;
		String filePath = "";
		List<FileVO> result  = new ArrayList<FileVO>();
		FileVO fvo;

		while (itr.hasNext()) {
			Entry<String, MultipartFile> entry = itr.next();

		    file = entry.getValue();
		    String orginFileName = file.getOriginalFilename();

		    // 원 파일명이 없는 경우 처리
		    // (첨부가 되지 않은 input file type)
		    if ("".equals(orginFileName)) {
		    	continue;
		    }
		    ////------------------------------------

		    int index = orginFileName.lastIndexOf(".");
		    String fileExt = orginFileName.substring(index + 1);
		    String newName = KeyStr + EgovStringUtil.getTimeStamp() + fileKey;
		    long _size = file.getSize();

		    if (!"".equals(orginFileName)) {
				filePath = storePathString + File.separator + newName;
				try {
					file.transferTo(new File(EgovWebUtil.filePathBlackList(filePath)));
				} catch (IllegalStateException | IOException e) {
					throw new BaseRuntimeException(e);
				}
		    }

		    fvo = new FileVO();
		    fvo.setFileExtsn(fileExt);
		    fvo.setFileStreCours(storePathString);
		    fvo.setFileMg(Long.toString(_size));
		    fvo.setOrignlFileNm(orginFileName);
		    fvo.setStreFileNm(newName);
		    fvo.setAtchFileId(atchFileIdString);
		    fvo.setFileSn(String.valueOf(fileKey));

		    result.add(fvo);

		    fileKey++;
		}

		return result;
    }

}
