package egovframework.com.sec.security;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

/**
 * 서비스 계층 메서드 보안 활성화 (Root ApplicationContext)
 */
@Configuration
@EnableMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class EgovMethodSecurityConfiguration {
}
