package egovframework.com.sec.security.web;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

/**
 * 컨트롤러 계층 메서드 보안 활성화 (Servlet ApplicationContext)
 */
@Configuration
@EnableMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class EgovWebMethodSecurityConfiguration {
}
