package egovframework.com.sec.security;

import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.springframework.stereotype.Component;

import egovframework.com.cmm.LoginVO;
import egovframework.let.cop.bbs.service.impl.BBSManageDAO;
import jakarta.annotation.Resource;

/**
 * 파일 메서드 보안 SpEL 평가 Bean ({@code @egovFileAuth})
 */
@Component("egovFileAuth")
public class EgovFileAuthorizer {

	@Resource(name = "BBSManageDAO")
	private BBSManageDAO bbsManageDAO;

	public boolean isAdmin() {
		return EgovUserDetailsHelper.getAuthorities() != null
				&& EgovUserDetailsHelper.getAuthorities().contains("ROLE_ADMIN");
	}

	public boolean isAuthenticated() {
		return EgovUserDetailsHelper.isAuthenticated();
	}

	public boolean canAccess(String atchFileId) throws Exception {
		if (!isAuthenticated()) {
			return false;
		}
		if (isAdmin()) {
			return true;
		}
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		int ownerCount = bbsManageDAO.countArticleByAtchFileIdAndOwner(atchFileId, user.getUniqId());
		if (ownerCount > 0) {
			return true;
		}
		int linkedCount = bbsManageDAO.countArticleByAtchFileId(atchFileId);
		return linkedCount == 0;
	}
}
