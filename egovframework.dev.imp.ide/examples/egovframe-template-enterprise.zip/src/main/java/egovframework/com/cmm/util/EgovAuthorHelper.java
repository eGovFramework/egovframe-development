package egovframework.com.cmm.util;

import java.util.List;

import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;

import egovframework.com.cmm.LoginVO;

/**
 * 로그인 사용자의 권한(ROLE_ADMIN / ROLE_USER) 여부를 판단하는 헬퍼 클래스.
 * 컨트롤러와 JSP 에서 화면/기능 권한 분기에 공통으로 사용한다.
 */
public final class EgovAuthorHelper {

	private EgovAuthorHelper() {
	}

	/**
	 * 관리자(ROLE_ADMIN) 권한을 가진 로그인 사용자인지 확인한다.
	 */
	public static boolean isAdmin() {
		if (!Boolean.TRUE.equals(EgovUserDetailsHelper.isAuthenticated())) {
			return false;
		}
		List<String> authorities = EgovUserDetailsHelper.getAuthorities();
		return authorities != null && authorities.contains("ROLE_ADMIN");
	}

	/**
	 * 관리자 권한이 없는 일반 로그인 사용자(ROLE_USER)인지 확인한다.
	 */
	public static boolean isUser() {
		return Boolean.TRUE.equals(EgovUserDetailsHelper.isAuthenticated()) && !isAdmin();
	}

	/**
	 * 인증된 로그인 사용자 정보를 반환한다. (미인증 시 null)
	 */
	public static LoginVO getLoginUser() {
		if (!Boolean.TRUE.equals(EgovUserDetailsHelper.isAuthenticated())) {
			return null;
		}
		return (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
	}

	/**
	 * 인증된 로그인 사용자의 고유ID(ESNTL_ID)를 반환한다. (미인증 시 null)
	 */
	public static String getLoginUniqId() {
		LoginVO user = getLoginUser();
		return user == null ? null : user.getUniqId();
	}

	/**
	 * 로그인 사용자가 등록자 본인인지 확인한다. (등록자 ID가 고유ID(ESNTL_ID)로 저장된 경우)
	 *
	 * @param frstRegisterId 최초등록자 ID
	 */
	public static boolean isRegister(String frstRegisterId) {
		String uniqId = getLoginUniqId();
		return uniqId != null && uniqId.equals(frstRegisterId);
	}

	/**
	 * 로그인 사용자가 등록자 본인인지 확인한다. (등록자 ID가 로그인 ID로 저장된 경우)
	 *
	 * @param frstRegisterId 최초등록자 ID
	 */
	public static boolean isRegisterByLoginId(String frstRegisterId) {
		LoginVO user = getLoginUser();
		return user != null && user.getId() != null && user.getId().equals(frstRegisterId);
	}
}
