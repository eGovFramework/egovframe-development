package egovframework.com.cmm.util;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

/**
 * Open Redirect 방지를 위한 내부 리다이렉트 URL 검증
 */
public final class EgovRedirectUrlValidator {

	private static final String DEFAULT_REDIRECT = "/cmm/main/mainPage.do";

	private EgovRedirectUrlValidator() {
	}

	public static String sanitizeInternalRedirectUrl(String returnUrl) {
		return sanitizeInternalRedirectUrl(returnUrl, DEFAULT_REDIRECT);
	}

	public static String sanitizeInternalRedirectUrl(String returnUrl, String defaultUrl) {
		if (returnUrl == null || returnUrl.isBlank()) {
			return defaultUrl;
		}

		String url = returnUrl.trim();
		try {
			url = URLDecoder.decode(url, StandardCharsets.UTF_8);
		} catch (IllegalArgumentException ignored) {
			return defaultUrl;
		}

		if (url.contains("\\") || url.contains("\r") || url.contains("\n")) {
			return defaultUrl;
		}
		if (url.startsWith("//") || url.matches("(?i)^[a-z][a-z0-9+\\-.]*:")) {
			return defaultUrl;
		}
		if (!url.startsWith("/") || url.startsWith("//")) {
			return defaultUrl;
		}

		return url;
	}
}
