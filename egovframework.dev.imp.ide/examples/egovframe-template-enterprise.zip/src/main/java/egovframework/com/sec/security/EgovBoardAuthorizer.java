package egovframework.com.sec.security;

import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.springframework.stereotype.Component;

import egovframework.com.cmm.LoginVO;
import egovframework.let.cop.bbs.service.Board;
import egovframework.let.cop.bbs.service.BoardVO;
import egovframework.let.cop.bbs.service.impl.BBSManageDAO;
import jakarta.annotation.Resource;

/**
 * 게시판 메서드 보안 SpEL 평가 Bean ({@code @egovBoardAuth})
 */
@Component("egovBoardAuth")
public class EgovBoardAuthorizer {

	@Resource(name = "BBSManageDAO")
	private BBSManageDAO bbsManageDAO;

	public boolean isAdmin() {
		return EgovUserDetailsHelper.getAuthorities() != null
				&& EgovUserDetailsHelper.getAuthorities().contains("ROLE_ADMIN");
	}

	public boolean isAuthenticated() {
		return EgovUserDetailsHelper.isAuthenticated();
	}

	public boolean canModifyArticle(String bbsId, long nttId) throws Exception {
		if (!isAuthenticated()) {
			return false;
		}
		if (isAdmin()) {
			return true;
		}
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		BoardVO searchVO = new BoardVO();
		searchVO.setBbsId(bbsId);
		searchVO.setNttId(nttId);
		BoardVO article = bbsManageDAO.selectBoardArticle(searchVO);
		return article != null && user.getUniqId().equals(article.getFrstRegisterId());
	}

	public boolean canModifyBoard(Board board) throws Exception {
		if (board == null) {
			return false;
		}
		return canModifyArticle(board.getBbsId(), board.getNttId());
	}
}
