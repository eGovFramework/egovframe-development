package egovframework.com.cmm.service.impl;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

/**
 * 첨부파일 업무 객체 접근 권한 검증
 */
@Service("EgovFileAuthService")
public class EgovFileAuthServiceImpl {

	@PreAuthorize("@egovFileAuth.canAccess(#atchFileId)")
	public void assertFileAccess(String atchFileId) throws Exception {
		// 메서드 보안 SpEL(@egovFileAuth)에서 권한 검증
	}
}
