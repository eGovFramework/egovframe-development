package egovframework.let.sec.gmt.web;

import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import egovframework.com.cmm.util.EgovAuthorHelper;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.let.sec.gmt.service.EgovGroupManageService;
import egovframework.let.sec.gmt.service.GroupManage;
import egovframework.let.sec.gmt.service.GroupManageVO;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 * 그룹관리에 관한 controller 클래스를 정의한다.
 * @author 공통서비스 개발팀 이문준
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *   
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.03.11  이문준          최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성 
 *
 * </pre>
 */

@Controller
public class EgovGroupManageController {
	
    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;

    @Resource(name = "egovGroupManageService")
    private EgovGroupManageService egovGroupManageService;

    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** Message ID Generation */
    @Resource(name="egovGroupIdGnrService")    
    private EgovIdGnrService egovGroupIdGnrService;
    
    /**
	 * 그룹 목록화면 이동
	 * @return String
	 * @exception Exception
	 */
    @RequestMapping("/sec/gmt/EgovGroupListView.do")
    public String selectGroupListView()
            throws Exception {
        return "/sec/gmt/EgovGroupManage";
    }   

	/**
	 * 시스템사용 목적별 그룹 목록 조회
	 * @param groupManageVO GroupManageVO
	 * @return String
	 * @exception Exception
	 */
    @GetMapping(value = "/sec/gmt/EgovGroupList.do")
	public String selectGroupList(@ModelAttribute("groupManageVO") GroupManageVO groupManageVO, Model model)
			throws Exception {
    	/** paging */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(groupManageVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(groupManageVO.getPageUnit());
		paginationInfo.setPageSize(groupManageVO.getPageSize());
		
		groupManageVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		groupManageVO.setLastIndex(paginationInfo.getLastRecordIndex());
		groupManageVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		groupManageVO.setGroupManageList(egovGroupManageService.selectGroupList(groupManageVO));
        model.addAttribute("groupList", groupManageVO.getGroupManageList());
        
        int totCnt = egovGroupManageService.selectGroupListTotCnt(groupManageVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

        return "/sec/gmt/EgovGroupManage";
	}

	/**
	 * 검색조건에 따른 그룹정보를 조회
	 * @param groupManageVO GroupManageVO
	 * @return String
	 * @exception Exception
	 */
    @GetMapping(value = "/sec/gmt/EgovGroup.do")
	public String selectGroup(@ModelAttribute("groupManageVO") GroupManageVO groupManageVO, Model model)
			throws Exception {

	    GroupManageVO result = egovGroupManageService.selectGroup(groupManageVO);
	    model.addAttribute("groupManage", result);
	    // 등록자 본인에게만 수정/삭제 버튼을 노출한다.
	    model.addAttribute("isRegister", result != null && EgovAuthorHelper.isRegister(result.getFrstRegisterId()));
	    return "/sec/gmt/EgovGroupUpdate";
	}

    /**
	 * 그룹 등록화면 이동
	 * @return String
	 * @exception Exception
	 */
    @GetMapping(value="/sec/gmt/EgovGroupInsertView.do")
    public String insertGroupView(Model model)
            throws Exception {
        model.addAttribute("groupManage", new GroupManage());
        return "/sec/gmt/EgovGroupInsert";
    }

	/**
	 * 그룹 기본정보를 화면에서 입력하여 항목의 정합성을 체크하고 데이터베이스에 저장
	 * @param groupManage GroupManage
	 * @param groupManageVO GroupManageVO
	 * @return String
	 * @exception Exception
	 */ 
    @PostMapping(value = "/sec/gmt/EgovGroupInsert.do")
	public String insertGroup(@Valid @ModelAttribute("groupManage") GroupManage groupManage,
			BindingResult bindingResult, @ModelAttribute("groupManageVO") GroupManageVO groupManageVO, 
			SessionStatus status, Model model, RedirectAttributes redirectAttributes) throws Exception {

    	if (bindingResult.hasErrors()) {
			model.addAttribute("groupManage", groupManage);
			return "/sec/gmt/EgovGroupInsert";
		} else {
	    	groupManage.setGroupId(egovGroupIdGnrService.getNextStringId());
	        groupManageVO.setGroupId(groupManage.getGroupId());

	        // 등록자는 요청 파라미터가 아닌 로그인 사용자로 지정한다.
	        groupManage.setFrstRegisterId(EgovAuthorHelper.getLoginUniqId());
	        egovGroupManageService.insertGroup(groupManage, groupManageVO);

	        status.setComplete();
	        redirectAttributes.addAttribute("message", egovMessageSource.getMessage("success.common.insert"));
	        addAttributeSearch(groupManageVO, redirectAttributes);
			return "redirect:/sec/gmt/EgovGroupList.do";
		}
	}
    
	/**
	 * 화면에 조회된 그룹의 기본정보를 수정하여 항목의 정합성을 체크하고 수정된 데이터를 데이터베이스에 반영
	 * @param groupManage GroupManage
	 * @return String
	 * @exception Exception
	 */     
    @PostMapping(value = "/sec/gmt/EgovGroupUpdate.do")
	public String updateGroup(final GroupManageVO groupManageVO, @Valid @ModelAttribute("groupManage") GroupManage groupManage,
			BindingResult bindingResult, SessionStatus status, Model model, RedirectAttributes redirectAttributes) throws Exception {
		// 등록자 본인만 수정/삭제할 수 있다.
		if (!isGroupRegister(groupManage.getGroupId())) {
			return "cmm/error/accessDenied";
		}
		model.addAttribute("isRegister", true);


    	if (bindingResult.hasErrors()) { 
			return "/sec/gmt/EgovGroupUpdate";
		} else {
    	    egovGroupManageService.updateGroup(groupManage);
            status.setComplete();
            redirectAttributes.addAttribute("message", egovMessageSource.getMessage("success.common.update"));
            addAttributeSearch(groupManageVO, redirectAttributes);
			return "redirect:/sec/gmt/EgovGroup.do";
		}
	}	
	
	/**
	 * 불필요한 그룹정보를 화면에 조회하여 데이터베이스에서 삭제
	 * @param groupManage GroupManage
	 * @return String
	 * @exception Exception
	 */
    @PostMapping(value = "/sec/gmt/EgovGroupDelete.do")
	public String deleteGroup(final GroupManageVO groupManageVO, @ModelAttribute("groupManage") GroupManage groupManage,
			SessionStatus status, Model model, RedirectAttributes redirectAttributes) throws Exception {
		// 등록자 본인만 수정/삭제할 수 있다.
		if (!isGroupRegister(groupManage.getGroupId())) {
			return "cmm/error/accessDenied";
		}

		egovGroupManageService.deleteGroup(groupManage);
		status.setComplete();
		redirectAttributes.addAttribute("message", egovMessageSource.getMessage("success.common.delete"));
		addAttributeSearch(groupManageVO, redirectAttributes);
		return "redirect:/sec/gmt/EgovGroupList.do";
	}

	/**
	 * 불필요한 그룹정보 목록을 화면에 조회하여 데이터베이스에서 삭제
	 * @param groupIds String
	 * @param groupManage GroupManage
	 * @return String
	 * @exception Exception
	 */   
    @PostMapping(value = "/sec/gmt/EgovGroupListDelete.do")
	public String deleteGroupList(@RequestParam("groupIds") String groupIds, final GroupManageVO groupManageVO,
			@ModelAttribute("groupManage") GroupManage groupManage, SessionStatus status, Model model, RedirectAttributes redirectAttributes)
			throws Exception {
		// 등록자 본인이 등록한 정보만 삭제할 수 있다. (하나라도 아니면 전체 거부)
		for (String key : groupIds.split(";")) {
			if (!isGroupRegister(key)) {
				return "cmm/error/accessDenied";
			}
		}

    	String [] strGroupIds = groupIds.split(";");
    	for(int i=0; i<strGroupIds.length;i++) {
    		groupManage.setGroupId(strGroupIds[i]);
    		egovGroupManageService.deleteGroup(groupManage);
    	}
		status.setComplete();
		redirectAttributes.addAttribute("message", egovMessageSource.getMessage("success.common.delete"));
		addAttributeSearch(groupManageVO, redirectAttributes);
		return "redirect:/sec/gmt/EgovGroupList.do";
	}
	
    /**
	 * 그룹팝업 화면 이동
	 * @return String
	 * @exception Exception
	 */
    @GetMapping("/sec/gmt/EgovGroupSearchView.do")
    public String selectGroupSearchView()
            throws Exception {
        return "/sec/gmt/EgovGroupSearch";
    }   
	    
	/**
	 * 시스템사용 목적별 그룹 목록 조회
	 * @param groupManageVO GroupManageVO
	 * @return String
	 * @exception Exception
	 */
    @GetMapping(value = "/sec/gmt/EgovGroupSearchList.do")
	public String selectGroupSearchList(@ModelAttribute("groupManageVO") GroupManageVO groupManageVO, Model model)
			throws Exception {
    	/** paging */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(groupManageVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(groupManageVO.getPageUnit());
		paginationInfo.setPageSize(groupManageVO.getPageSize());
		
		groupManageVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		groupManageVO.setLastIndex(paginationInfo.getLastRecordIndex());
		groupManageVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		groupManageVO.setGroupManageList(egovGroupManageService.selectGroupList(groupManageVO));
        model.addAttribute("groupList", groupManageVO.getGroupManageList());
        
        int totCnt = egovGroupManageService.selectGroupListTotCnt(groupManageVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

        return "/sec/gmt/EgovGroupSearch";
	}
    
    private void addAttributeSearch(final GroupManageVO groupManageVO, final RedirectAttributes redirectAttributes) {
    	redirectAttributes.addAttribute("searchCondition", groupManageVO.getSearchCondition());
    	redirectAttributes.addAttribute("searchKeyword", groupManageVO.getSearchKeyword());
    	redirectAttributes.addAttribute("pageIndex", groupManageVO.getPageIndex());
    	redirectAttributes.addAttribute("groupId", groupManageVO.getGroupId());
	}

	/**
	 * 로그인 사용자가 해당 정보의 등록자 본인인지 확인한다.
	 *
	 * @param key 대상 키
	 * @return 등록자 본인이면 true
	 */
	private boolean isGroupRegister(String key) throws Exception {
		GroupManageVO searchVO = new GroupManageVO();
		searchVO.setGroupId(key);
		GroupManageVO vo = egovGroupManageService.selectGroup(searchVO);
		return vo != null && EgovAuthorHelper.isRegister(vo.getFrstRegisterId());
	}
}
