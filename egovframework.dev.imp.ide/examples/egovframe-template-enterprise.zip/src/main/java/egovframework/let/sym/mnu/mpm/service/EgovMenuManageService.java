package  egovframework.let.sym.mnu.mpm.service;

import java.io.InputStream;
import java.util.List;

import egovframework.com.cmm.ComDefaultVO;

/**
 * 메뉴관리에 관한 서비스 인터페이스 클래스를 정의한다.
 * @author 개발환경 개발팀 이용
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.03.20  이  용          최초 생성
 *   2011.07.01  서준식			자기 메뉴 정보를 상위메뉴 정보로 참조하는 메뉴정보가 있는지 조회하는
 *   							selectUpperMenuNoByPk() 메서드 추가
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *
 * </pre>
 */

public interface EgovMenuManageService {

	/**
	 * 메뉴 상세정보를 조회
	 * @param vo ComDefaultVO
	 * @return MenuManageVO
	 */
	MenuManageVO selectMenuManage(ComDefaultVO vo);

	/**
	 * 메뉴 목록을 조회
	 * @param vo ComDefaultVO
	 * @return List
	 */
	List<?> selectMenuManageList(ComDefaultVO vo);

	/**
	 * 메뉴목록 총건수를 조회한다.
	 * @param vo ComDefaultVO
	 * @return int
	 */
	int selectMenuManageListTotCnt(ComDefaultVO vo);

	/**
	 * 메뉴번호 존재 여부를 조회한다.
	 * @param vo ComDefaultVO
	 * @return int
	 */
	int selectMenuNoByPk(MenuManageVO vo);


	int selectUpperMenuNoByPk(MenuManageVO vo);

	/**
	 * 메뉴 정보를 등록
	 * @param vo MenuManageVO
	 */
	void insertMenuManage(MenuManageVO vo);

	/**
	 * 메뉴 정보를 수정
	 * @param vo MenuManageVO
	 */
	void updateMenuManage(MenuManageVO vo);

	/**
	 * 메뉴 정보를 삭제
	 * @param vo MenuManageVO
	 */
	void deleteMenuManage(MenuManageVO vo);

	/**
	 * 화면에 조회된 메뉴 목록 정보를 데이터베이스에서 삭제
	 * @param checkedMenuNoForDel String
	 */
	void deleteMenuManageList(String checkedMenuNoForDel);


	/*  메뉴 생성 관리  */

	/**
	 * 메뉴 목록을 조회
	 * @return List
	 */
	List<?> selectMenuList();

	/*### 메뉴관련 프로세스 ###*/
	/**
	 * MainMenu Head Menu 조회
	 * @param vo MenuManageVO
	 * @return List
	 */
	List<?> selectMainMenuHead(MenuManageVO vo);

	/**
	 * MainMenu Head Left 조회
	 * @param vo MenuManageVO
	 * @return List
	 */
	List<?> selectMainMenuLeft(MenuManageVO vo);

	/**
	 * MainMenu Head MenuURL 조회
	 * @param iMenuNo int
	 * @param sUniqId String
	 * @return String
	 */
	String selectLastMenuURL(int iMenuNo, String sUniqId);

	/* 일괄처리 프로세스   */

	/**
	 * 메뉴일괄초기화 프로세스 메뉴목록테이블, 프로그램 목록테이블 전체 삭제
	 * @return boolean
	 */
	boolean menuBndeAllDelete();

	/**
	 * 일괄삭제(초기화) 대상 메뉴/프로그램이 모두 지정한 등록자가 등록한 것인지 확인한다.
	 * @param frstRegisterId 등록자 고유ID
	 * @return 모두 해당 등록자가 등록했으면 true
	 */
	boolean isAllBndeRegister(String frstRegisterId);

	/**
	 * 메뉴일괄등록 프로세스
	 * @param  vo MenuManageVO
	 * @param  inputStream InputStream
	 */
	String menuBndeRegist(MenuManageVO vo, InputStream inputStream);


}