package egovframework.let.sym.mnu.mpm.web;

import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import egovframework.com.cmm.util.EgovAuthorHelper;
import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.let.sym.mnu.mpm.service.EgovMenuManageService;
import egovframework.let.sym.mnu.mpm.service.MenuManageVO;
import egovframework.let.sym.prm.service.EgovProgrmManageService;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

/**
 * 메뉴목록 관리및 메뉴생성, 사이트맵 생성을 처리하는 비즈니스 구현 클래스
 * 
 * @author 개발환경 개발팀 이용
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 *      <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.03.20  이  용          최초 생성
 *	 2011.07.01	 서준식	   메뉴정보 삭제시 참조되고 있는 하위 메뉴가 있는지 체크하는 로직 추가
 *	 2011.07.27	 서준식	   deleteMenuManageList() 메서드에서 메뉴 멀티 삭제 버그 수정
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *      </pre>
 */
@Controller
public class EgovMenuManageController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovMenuManageController.class);

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/** EgovMenuManageService */
	@Resource(name = "meunManageService")
	private EgovMenuManageService menuManageService;

	/** EgovMenuManageService */
	@Resource(name = "progrmManageService")
	private EgovProgrmManageService progrmManageService;

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	/**
	 * 메뉴정보목록을 상세화면 호출 및 상세조회한다.
	 * 
	 * @param req_menuNo String
	 * @return 출력페이지정보 "sym/mnu/mpm/EgovMenuDetailSelectUpdt"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/mnu/mpm/EgovMenuManageListDetailSelect.do")
	public String selectMenuManage(@RequestParam("req_menuNo") String req_menuNo,
			@ModelAttribute("searchVO") ComDefaultVO searchVO, ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (isAuthenticated == null || !isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "uat/uia/EgovLoginUsr";
		}
		searchVO.setSearchKeyword(req_menuNo);

		MenuManageVO resultVO = menuManageService.selectMenuManage(searchVO);
		model.addAttribute("menuManageVO", resultVO);
		// 등록자 본인에게만 수정/삭제 버튼을 노출한다.
		model.addAttribute("isRegister", resultVO != null && EgovAuthorHelper.isRegister(resultVO.getFrstRegisterId()));

		return "sym/mnu/mpm/EgovMenuDetailSelectUpdt";
	}

	/**
	 * 메뉴목록 리스트조회한다.
	 * 
	 * @param searchVO ComDefaultVO
	 * @return 출력페이지정보 "sym/mnu/mpm/EgovMenuManage"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/mnu/mpm/EgovMenuManageSelect.do")
	public String selectMenuManageList(@ModelAttribute("searchVO") ComDefaultVO searchVO, ModelMap model)
			throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (isAuthenticated == null || !isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "uat/uia/EgovLoginUsr";
		}
		// 내역 조회
		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		model.addAttribute("list_menumanage", menuManageService.selectMenuManageList(searchVO));

		int totCnt = menuManageService.selectMenuManageListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "sym/mnu/mpm/EgovMenuManage";
	}

	/**
	 * 메뉴목록 멀티 삭제한다.
	 * 
	 * @param checkedMenuNoForDel String
	 * @return 출력페이지정보 "forward:/sym/mnu/mpm/EgovMenuManageSelect.do"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/mnu/mpm/EgovMenuManageListDelete.do", method = RequestMethod.POST)
	public String deleteMenuManageList(@RequestParam("checkedMenuNoForDel") String checkedMenuNoForDel,
			@ModelAttribute("menuManageVO") MenuManageVO menuManageVO, ModelMap model)
			throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (isAuthenticated == null || !isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "uat/uia/EgovLoginUsr";
		}
		String sLocationUrl = null;
		String resultMsg = "";
		String[] delMenuNo = checkedMenuNoForDel != null ? checkedMenuNoForDel.split(",") : new String[0];
		if (delMenuNo.length == 0) {
			resultMsg = egovMessageSource.getMessage("fail.common.delete");
			sLocationUrl = "forward:/sym/mnu/mpm/EgovMenuManageSelect.do";
		} else {
			// 등록자 본인이 등록한 메뉴만 삭제할 수 있다. (하나라도 아니면 전체 거부)
			for (String menuNo : delMenuNo) {
				if (!isMenuRegister(menuNo)) {
					return "cmm/error/accessDenied";
				}
			}
			menuManageVO.setMenuNo(Integer.parseInt(delMenuNo[0]));
			if (menuManageService.selectUpperMenuNoByPk(menuManageVO) != 0) {
				resultMsg = egovMessageSource.getMessage("fail.common.delete.upperMenuExist");
				sLocationUrl = "forward:/sym/mnu/mpm/EgovMenuManageSelect.do";
			} else {
				menuManageService.deleteMenuManageList(checkedMenuNoForDel);
				resultMsg = egovMessageSource.getMessage("success.common.delete");
				sLocationUrl = "forward:/sym/mnu/mpm/EgovMenuManageSelect.do";
			}
		}
		model.addAttribute("resultMsg", resultMsg);
		return sLocationUrl;
	}

	/**
	 * 메뉴정보 등록화면으로 이동 (GET)
	 * 
	 * @return 출력페이지정보 "sym/mnu/mpm/EgovMenuRegist"
	 * @exception Exception
	 */
	@GetMapping(value = "/sym/mnu/mpm/EgovMenuRegistInsert.do")
	public String insertMenuManageView(ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (isAuthenticated == null || !isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "uat/uia/EgovLoginUsr";
		}

		model.addAttribute("menuManageVO", new MenuManageVO());
		return "sym/mnu/mpm/EgovMenuRegist";
	}

	/**
	 * 메뉴정보를 등록 한다 (POST)
	 * 
	 * @param menuManageVO MenuManageVO
	 * @return 출력페이지정보 등록처리시 "forward:/sym/mnu/mpm/EgovMenuManageSelect.do"
	 * @exception Exception
	 */
	@PostMapping(value = "/sym/mnu/mpm/EgovMenuRegistInsert.do")
	public String insertMenuManage(@Valid @ModelAttribute("menuManageVO") MenuManageVO menuManageVO,
			BindingResult bindingResult,
			ModelMap model) throws Exception {
		String sLocationUrl = null;
		String resultMsg = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (isAuthenticated == null || !isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "uat/uia/EgovLoginUsr";
		}

		if (bindingResult.hasErrors()) {
			model.addAttribute("menuManageVO", menuManageVO);
			return "sym/mnu/mpm/EgovMenuRegist";
		}

		if (menuManageService.selectMenuNoByPk(menuManageVO) == 0) {
			ComDefaultVO searchVO = new ComDefaultVO();
			searchVO.setSearchKeyword(menuManageVO.getProgrmFileNm());
			if (progrmManageService.selectProgrmNMTotCnt(searchVO) == 0) {
				resultMsg = egovMessageSource.getMessage("fail.common.insert");
				sLocationUrl = "sym/mnu/mpm/EgovMenuRegist";
			} else {
				// 등록자는 요청 파라미터가 아닌 로그인 사용자로 지정한다.
				menuManageVO.setFrstRegisterId(EgovAuthorHelper.getLoginUniqId());
				menuManageService.insertMenuManage(menuManageVO);
				resultMsg = egovMessageSource.getMessage("success.common.insert");
				sLocationUrl = "forward:/sym/mnu/mpm/EgovMenuManageSelect.do";
			}
		} else {
			resultMsg = egovMessageSource.getMessage("common.isExist.msg");
			sLocationUrl = "sym/mnu/mpm/EgovMenuRegist";
		}
		model.addAttribute("resultMsg", resultMsg);

		return sLocationUrl;
	}

	/**
	 * 메뉴정보를 수정 한다.
	 * 
	 * @param menuManageVO MenuManageVO
	 * @return 출력페이지정보 "forward:/sym/mnu/mpm/EgovMenuManageSelect.do"
	 * @exception Exception
	 */
	@PostMapping(value = "/sym/mnu/mpm/EgovMenuDetailSelectUpdt.do")
	public String updateMenuManage(@Valid @ModelAttribute("menuManageVO") MenuManageVO menuManageVO,
			BindingResult bindingResult, ModelMap model) throws Exception {
		String sLocationUrl = null;
		String resultMsg = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (isAuthenticated == null || !isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "uat/uia/EgovLoginUsr";
		}

		// 등록자 본인만 수정/삭제할 수 있다.
		if (!isMenuRegister(String.valueOf(menuManageVO.getMenuNo()))) {
			return "cmm/error/accessDenied";
		}
		model.addAttribute("isRegister", true);

		if (bindingResult.hasErrors()) {
			model.addAttribute("menuManageVO", menuManageVO);
			return "sym/mnu/mpm/EgovMenuDetailSelectUpdt";
		}
		ComDefaultVO searchVO = new ComDefaultVO();
		searchVO.setSearchKeyword(menuManageVO.getProgrmFileNm());
		if (progrmManageService.selectProgrmNMTotCnt(searchVO) == 0) {
			resultMsg = egovMessageSource.getMessage("fail.common.update");
			model.addAttribute("menuManageVO", menuManageVO);
			model.addAttribute("resultMsg", resultMsg);
			return "sym/mnu/mpm/EgovMenuDetailSelectUpdt";
		} else {
			menuManageService.updateMenuManage(menuManageVO);
			resultMsg = egovMessageSource.getMessage("success.common.update");
			sLocationUrl = "forward:/sym/mnu/mpm/EgovMenuManageSelect.do";
		}
		model.addAttribute("resultMsg", resultMsg);

		return sLocationUrl;
	}

	/**
	 * 메뉴정보를 삭제 한다.
	 * 
	 * @param menuManageVO MenuManageVO
	 * @return 출력페이지정보 "forward:/sym/mnu/mpm/EgovMenuManageSelect.do"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/mnu/mpm/EgovMenuManageDelete.do", method = RequestMethod.POST)
	public String deleteMenuManage(@ModelAttribute("menuManageVO") MenuManageVO menuManageVO, ModelMap model)
			throws Exception {
		String resultMsg = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (isAuthenticated == null || !isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "uat/uia/EgovLoginUsr";
		}
		// 등록자 본인만 수정/삭제할 수 있다.
		if (!isMenuRegister(String.valueOf(menuManageVO.getMenuNo()))) {
			return "cmm/error/accessDenied";
		}
		if (menuManageService.selectUpperMenuNoByPk(menuManageVO) != 0) {
			resultMsg = egovMessageSource.getMessage("fail.common.delete.upperMenuExist");
			model.addAttribute("resultMsg", resultMsg);
			return "forward:/sym/mnu/mpm/EgovMenuManageSelect.do";
		}

		menuManageService.deleteMenuManage(menuManageVO);
		resultMsg = egovMessageSource.getMessage("success.common.delete");
		String _MenuNm = "%";
		menuManageVO.setMenuNm(_MenuNm);
		model.addAttribute("resultMsg", resultMsg);

		return "forward:/sym/mnu/mpm/EgovMenuManageSelect.do";
	}

	/* ### 일괄처리 프로세스 ### */

	/**
	 * 메뉴생성 일괄삭제프로세스
	 * 
	 * @param menuManageVO MenuManageVO
	 * @return 출력페이지정보 "sym/mnu/mpm/EgovMenuBndeRegist"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/mnu/mpm/EgovMenuBndeAllDelete.do")
	public String menuBndeAllDelete(@ModelAttribute("menuManageVO") MenuManageVO menuManageVO, ModelMap model)
			throws Exception {
		String resultMsg = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (isAuthenticated == null || !isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "uat/uia/EgovLoginUsr";
		}
		// 전체 메뉴/프로그램이 모두 본인 등록인 경우에만 일괄삭제할 수 있다.
		if (!menuManageService.isAllBndeRegister(EgovAuthorHelper.getLoginUniqId())) {
			return "cmm/error/accessDenied";
		}
		menuManageService.menuBndeAllDelete();
		resultMsg = egovMessageSource.getMessage("success.common.delete");
		model.addAttribute("resultMsg", resultMsg);

		return "sym/mnu/mpm/EgovMenuBndeRegist";
	}

	/**
	 * 메뉴일괄등록화면 호출 및 메뉴일괄등록처리 프로세스
	 * 
	 * @param commandMap   Map
	 * @param menuManageVO MenuManageVO
	 * @param request      HttpServletRequest
	 * @return 출력페이지정보 "sym/mnu/mpm/EgovMenuBndeRegist"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/mnu/mpm/EgovMenuBndeRegist.do")
	public String menuBndeRegist(@RequestParam Map<String, Object> commandMap, final HttpServletRequest request,
			@ModelAttribute("menuManageVO") MenuManageVO menuManageVO,
			ModelMap model) throws Exception {
		String sLocationUrl = null;
		String resultMsg = "";
		String sMessage = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (isAuthenticated == null || !isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "uat/uia/EgovLoginUsr";
		}
		String sCmd = commandMap.get("cmd") == null ? "" : (String) commandMap.get("cmd");
		if (sCmd.equals("bndeInsert")) {
			// 일괄등록은 기존 메뉴/프로그램을 모두 삭제하므로, 모두 본인 등록인 경우에만 허용한다.
			if (!menuManageService.isAllBndeRegister(EgovAuthorHelper.getLoginUniqId())) {
				return "cmm/error/accessDenied";
			}
			final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
			final Map<String, MultipartFile> files = multiRequest.getFileMap();
			Iterator<Entry<String, MultipartFile>> itr = files.entrySet().iterator();
			MultipartFile file = null;
			InputStream fis = null;
			while (itr.hasNext()) {
				Entry<String, MultipartFile> entry = itr.next();
				try {
					file = entry.getValue();
					fis = file.getInputStream();
					if (file.getOriginalFilename() != null && !"".equals(file.getOriginalFilename())) {
						// 2011.10.07 업로드 파일에 대한 확장자를 체크
						if (file.getOriginalFilename().toLowerCase().endsWith(".xls")
								|| file.getOriginalFilename().toLowerCase().endsWith(".xlsx")) {
							if (menuManageService.menuBndeAllDelete()) {
								sMessage = menuManageService.menuBndeRegist(menuManageVO, fis);
								resultMsg = sMessage;
							} else {
								resultMsg = egovMessageSource.getMessage("fail.common.msg");
								menuManageVO.setTmp_Cmd("EgovMenuBndeRegist Error!!");
								model.addAttribute("resultVO", menuManageVO);
							}
						} else {
							resultMsg = egovMessageSource.getMessage("fail.common.msg");
							model.addAttribute("resultMsg", resultMsg);
							return "egovframework/com/sym/mnu/mpm/EgovMenuBndeRegist";
						}
						// *********** 끝 ***********

					} else {
						resultMsg = egovMessageSource.getMessage("fail.common.msg");
					}

				} finally {
					try {
						if (fis != null) {
							fis.close();
						}
					} catch (IOException ee) {
						LOGGER.debug("{}", ee);
					}
				}

			}
			sLocationUrl = "sym/mnu/mpm/EgovMenuBndeRegist";
			model.addAttribute("resultMsg", resultMsg);
		} else {
			sLocationUrl = "sym/mnu/mpm/EgovMenuBndeRegist";
		}
		return sLocationUrl;
	}

	/**
	 * 로그인 사용자가 해당 메뉴의 등록자 본인인지 확인한다.
	 *
	 * @param menuNo 메뉴번호
	 * @return 등록자 본인이면 true
	 */
	private boolean isMenuRegister(String menuNo) throws Exception {
		ComDefaultVO searchVO = new ComDefaultVO();
		searchVO.setSearchKeyword(menuNo);
		MenuManageVO vo = menuManageService.selectMenuManage(searchVO);
		return vo != null && EgovAuthorHelper.isRegister(vo.getFrstRegisterId());
	}
}
