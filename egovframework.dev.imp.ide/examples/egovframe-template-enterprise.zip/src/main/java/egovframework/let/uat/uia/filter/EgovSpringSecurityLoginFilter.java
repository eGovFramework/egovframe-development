package egovframework.let.uat.uia.filter;

import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import egovframework.let.uat.uap.service.EgovLoginPolicyService;
import egovframework.let.uat.uap.service.LoginPolicyVO;
import egovframework.let.utl.sim.service.EgovClntInfo;
import jakarta.annotation.Resource;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;

/**
 * 로그인 폼(id/password)을 Spring Security 폼 파라미터(username/password)로 변환하는 브리지 필터.
 * 비밀번호 검증은 Spring Security(DaoAuthenticationProvider + BCryptPasswordEncoder)가 수행하고,
 * 이 필터는 사용자 구분 접두어(USR) 부여와 로그인정책(IP 접속제한) 확인만 담당한다.
 */
@Component("egovSpringSecurityLoginFilter")
public class EgovSpringSecurityLoginFilter extends OncePerRequestFilter {

	/** egov-security-config.properties 의 loginFailureUrl 과 동일해야 한다. */
	private static final String LOGIN_FAILURE_PATH = "/uat/uia/egovLoginUsr.do?login_error=1";

	/** egov-security-config.properties 의 loginProcessUrl 과 동일해야 한다. */
	private static final String LOGIN_PROCESS_PATH = "/uat/uia/actionLogin.do";

	/** 로그인 대상 사용자 구분(업무사용자). jdbcUsersByUsernameQuery 의 접두어와 동일해야 한다. */
	private static final String USER_SE = "USR";

	@Resource(name = "egovLoginPolicyService")
	private EgovLoginPolicyService egovLoginPolicyService;

	/** 로그인 처리 요청(POST loginProcessUrl)에만 동작한다. */
	@Override
	protected boolean shouldNotFilter(HttpServletRequest request) {
		String path = request.getRequestURI().substring(request.getContextPath().length());
		return !("POST".equalsIgnoreCase(request.getMethod()) && LOGIN_PROCESS_PATH.equals(path));
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String id = request.getParameter("id");
		String password = request.getParameter("password");
		if (!StringUtils.hasText(id) || !StringUtils.hasText(password)) {
			redirectLoginFailure(request, response);
			return;
		}
		id = id.trim();

		SecurityContextHolder.clearContext();

		try {
			if (!isLoginPolicyAllowed(id, EgovClntInfo.getClntIP(request))) {
				redirectLoginFailure(request, response);
				return;
			}
		} catch (Exception e) {
			logger.error("Login policy check failed", e);
			redirectLoginFailure(request, response);
			return;
		}

		filterChain.doFilter(new LoginFormSpringSecurityParameterWrapper(request, USER_SE + id, password), response);
	}

	private boolean isLoginPolicyAllowed(String emplyrId, String userIp) throws Exception {
		LoginPolicyVO loginPolicyVO = new LoginPolicyVO();
		loginPolicyVO.setEmplyrId(emplyrId);
		loginPolicyVO = egovLoginPolicyService.selectLoginPolicy(loginPolicyVO);

		if (loginPolicyVO != null && "Y".equals(loginPolicyVO.getLmttAt())) {
			return userIp.equals(loginPolicyVO.getIpInfo());
		}
		return true;
	}

	/**
	 * 로그인 실패 시 로그인 화면으로 리다이렉트한다.
	 * Spring Security 필터 체인보다 앞이므로 forward 대신 리다이렉트로 CsrfFilter 를 거친 화면을 다시 그린다.
	 */
	private static void redirectLoginFailure(HttpServletRequest request, HttpServletResponse response) throws IOException {
		var session = request.getSession(false);
		if (session != null) {
			session.removeAttribute("loginVO");
			session.removeAttribute("accessUser");
		}
		response.sendRedirect(request.getContextPath() + LOGIN_FAILURE_PATH);
	}

	private static final class LoginFormSpringSecurityParameterWrapper extends HttpServletRequestWrapper {

		private final String securityUsername;
		private final String securityPassword;
		private Map<String, String[]> cachedParameterMap;

		LoginFormSpringSecurityParameterWrapper(HttpServletRequest request, String securityUsername,
				String securityPassword) {
			super(request);
			this.securityUsername = securityUsername;
			this.securityPassword = securityPassword;
		}

		@Override
		public String getParameter(String name) {
			if ("username".equals(name)) {
				return securityUsername;
			}
			if ("password".equals(name)) {
				return securityPassword;
			}
			return super.getParameter(name);
		}

		@Override
		public String[] getParameterValues(String name) {
			if ("username".equals(name)) {
				return new String[] { securityUsername };
			}
			if ("password".equals(name)) {
				return new String[] { securityPassword };
			}
			return super.getParameterValues(name);
		}

		@Override
		public Map<String, String[]> getParameterMap() {
			if (cachedParameterMap == null) {
				Map<String, String[]> map = new HashMap<>(super.getParameterMap());
				map.put("username", new String[] { securityUsername });
				map.put("password", new String[] { securityPassword });
				cachedParameterMap = Collections.unmodifiableMap(map);
			}
			return cachedParameterMap;
		}

		@Override
		public Enumeration<String> getParameterNames() {
			Vector<String> names = new Vector<>(Collections.list(super.getParameterNames()));
			if (!names.contains("username")) {
				names.add("username");
			}
			if (!names.contains("password")) {
				names.add("password");
			}
			return names.elements();
		}
	}
}
