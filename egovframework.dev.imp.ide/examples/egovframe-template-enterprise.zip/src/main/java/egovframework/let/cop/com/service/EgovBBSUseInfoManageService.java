package egovframework.let.cop.com.service;

import java.util.Map;


/**
 * 게시판 이용정보를 관리하기 위한 서비스 인터페이스 클래스
 * @author 공통서비스개발팀 이삼섭
 * @since 2009.04.02
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *   
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.04.02  이삼섭          최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성 
 *
 * </pre>
 */
public interface EgovBBSUseInfoManageService {

    /**
     * 게시판 사용 정보를 삭제한다.
     * 
     * @param bdUseInf
     */
    public void deleteBBSUseInf(BoardUseInf bdUseInf);

    /**
     * 커뮤니티에 사용되는 게시판 사용정보를 삭제한다.
     * 
     * @param bdUseInf
     */
    public void deleteBBSUseInfByCmmnty(BoardUseInfVO bdUseVO);

    /**
     * 동호회에 사용되는 게시판 사용정보를 삭제한다.
     * 
     * @param bdUseInf
     */
    public void deleteBBSUseInfByClub(BoardUseInfVO bdUseVO);

    /**
     * 커뮤니티에 사용되는 모든 게시판 사용정보를 삭제한다.
     * 
     * @param bdUseInf
     */
    public void deleteAllBBSUseInfByCmmnty(BoardUseInfVO bdUseVO);

    /**
     * 동호회에 사용되는 모든 게시판 사용정보를 삭제한다.
     * 
     * @param bdUseInf
     */
    public void deleteAllBBSUseInfByClub(BoardUseInfVO bdUseVO);

    /**
     * 게시판 사용정보를 등록한다.
     * 
     * @param bdUseInf
     */
    public void insertBBSUseInf(BoardUseInf bdUseInf);

    /**
     * 게시판 사용정보 목록을 조회한다.
     * 
     * @param bdUseVO
     * @return
     */
    public Map<String, Object> selectBBSUseInfs(BoardUseInfVO bdUseVO);

    /**
     * 게시판 사용정보를 수정한다.
     * 
     * @param bdUseInf
     */
    public void updateBBSUseInf(BoardUseInf bdUseInf);

    /**
     * 게시판 사용정보에 대한 상세정보를 조회한다.
     * 
     * @param bdUseVO
     * @return
     */
    public BoardUseInfVO selectBBSUseInf(BoardUseInfVO bdUseVO);

    /**
     * 게시판에 대한 사용정보를 삭제한다.
     * 
     * @param bdUseInf
     */
    public void deleteBBSUseInfByBoardId(BoardUseInf bdUseInf);

    /**
     * 커뮤니티, 동호회에 사용되는 게시판 사용정보에 대한 목록을 조회한다.
     * 
     * @param bdUseVO
     * @return
     */
    public Map<String, Object> selectBBSUseInfsByTrget(BoardUseInfVO bdUseVO);

    /**
     * 커뮤니티, 동호회에 사용되는 게시판 사용정보를 수정한다.
     * 
     * @param bdUseInf
     */
    public void updateBBSUseInfByTrget(BoardUseInf bdUseInf);

}
