package egovframework.let.sec.ram.web;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import egovframework.com.cmm.util.EgovAuthorHelper;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.let.sec.ram.service.AuthorManage;
import egovframework.let.sec.ram.service.AuthorManageVO;
import egovframework.let.sec.ram.service.EgovAuthorManageService;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 * 권한관리에 관한 controller 클래스를 정의한다.
 * @author 공통서비스 개발팀 이문준
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.03.11  이문준          최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *
 * </pre>
 */

@Controller
public class EgovAuthorManageController {

	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	@Resource(name = "egovAuthorManageService")
	private EgovAuthorManageService egovAuthorManageService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/**
	 * 권한 목록화면 이동
	 * @return String
	 * @exception Exception
	 */
	@GetMapping("/sec/ram/EgovAuthorListView.do")
	public String selectAuthorListView() throws Exception {
		return "/sec/ram/EgovAuthorManage";
	}

	/**
	 * 권한 목록을 조회한다
	 * @param authorManageVO AuthorManageVO
	 * @return String
	 * @exception Exception
	 */
	@GetMapping(value = "/sec/ram/EgovAuthorList.do")
	public String selectAuthorList(@ModelAttribute("authorManageVO") AuthorManageVO authorManageVO, Model model) throws Exception {
		
		/** paging */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(authorManageVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(authorManageVO.getPageUnit());
		paginationInfo.setPageSize(authorManageVO.getPageSize());

		authorManageVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		authorManageVO.setLastIndex(paginationInfo.getLastRecordIndex());
		authorManageVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		authorManageVO.setAuthorManageList(egovAuthorManageService.selectAuthorList(authorManageVO));
		model.addAttribute("authorList", authorManageVO.getAuthorManageList());

		int totCnt = egovAuthorManageService.selectAuthorListTotCnt(authorManageVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

		return "/sec/ram/EgovAuthorManage";
	}

	/**
	 * 권한 세부정보를 조회한다.
	 * @param authorCode String
	 * @param authorManageVO AuthorManageVO
	 * @return String
	 * @exception Exception
	 */
	@GetMapping(value = "/sec/ram/EgovAuthor.do")
	public String selectAuthor(@RequestParam("authorCode") String authorCode, @ModelAttribute("authorManageVO") AuthorManageVO authorManageVO, Model model) throws Exception {

		authorManageVO.setAuthorCode(authorCode);

		AuthorManageVO result = egovAuthorManageService.selectAuthor(authorManageVO);
		model.addAttribute("authorManage", result);
		// 등록자 본인에게만 수정/삭제 버튼을 노출한다.
		model.addAttribute("isRegister", result != null && EgovAuthorHelper.isRegister(result.getFrstRegisterId()));
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));
		return "/sec/ram/EgovAuthorUpdate";
	}

	/**
	 * 권한 등록화면 이동
	 * @return String
	 * @exception Exception
	 */
	@GetMapping("/sec/ram/EgovAuthorInsertView.do")
	public String insertAuthorView(final AuthorManageVO authorManageVO, final Model model) throws Exception {
		model.addAttribute("authorManage", new AuthorManage());
		return "/sec/ram/EgovAuthorInsert";
	}

	/**
	 * 권한 세부정보를 등록한다.
	 * @param authorManage AuthorManage
	 * @param bindingResult BindingResult
	 * @return String
	 * @exception Exception
	 */
	@PostMapping(value = "/sec/ram/EgovAuthorInsert.do")
	public String insertAuthor(final AuthorManageVO authorManageVO,
			@Valid @ModelAttribute("authorManage") AuthorManage authorManage, BindingResult bindingResult,
			SessionStatus status, Model model, RedirectAttributes redirectAttributes) throws Exception {

		if (bindingResult.hasErrors()) {
			model.addAttribute("authorManage", authorManage);
			return "/sec/ram/EgovAuthorInsert";
		} else {
			// 등록자는 요청 파라미터가 아닌 로그인 사용자로 지정한다.
			authorManage.setFrstRegisterId(EgovAuthorHelper.getLoginUniqId());
			egovAuthorManageService.insertAuthor(authorManage);
			status.setComplete();
			redirectAttributes.addAttribute("message", egovMessageSource.getMessage("success.common.insert"));
			addAttributeSearch(authorManageVO, redirectAttributes);
			return "redirect:/sec/ram/EgovAuthor.do";
		}
	}

	/**
	 * 권한 세부정보를 수정한다.
	 * @param authorManage AuthorManage
	 * @param bindingResult BindingResult
	 * @return String
	 * @exception Exception
	 */
	@PostMapping(value = "/sec/ram/EgovAuthorUpdate.do")
	public String updateAuthor(final AuthorManageVO authorManageVO,
			@Valid @ModelAttribute("authorManage") AuthorManage authorManage, BindingResult bindingResult,
			SessionStatus status, Model model, RedirectAttributes redirectAttributes) throws Exception {
		// 등록자 본인만 수정/삭제할 수 있다.
		if (!isAuthorRegister(authorManage.getAuthorCode())) {
			return "cmm/error/accessDenied";
		}
		model.addAttribute("isRegister", true);


		if (bindingResult.hasErrors()) {
			return "/sec/ram/EgovAuthorUpdate";
		} else {
			egovAuthorManageService.updateAuthor(authorManage);
			status.setComplete();
			redirectAttributes.addAttribute("message", egovMessageSource.getMessage("success.common.update"));
			addAttributeSearch(authorManageVO, redirectAttributes);
			return "redirect:/sec/ram/EgovAuthor.do";
		}
	}

	/**
	 * 권한 세부정보를 삭제한다.
	 * @param authorManage AuthorManage
	 * @return String
	 * @exception Exception
	 */
	@PostMapping(value = "/sec/ram/EgovAuthorDelete.do")
	public String deleteAuthor(final AuthorManageVO authorManageVO,
			@ModelAttribute("authorManage") AuthorManage authorManage, SessionStatus status, Model model, RedirectAttributes redirectAttributes)
			throws Exception {
		// 등록자 본인만 수정/삭제할 수 있다.
		if (!isAuthorRegister(authorManage.getAuthorCode())) {
			return "cmm/error/accessDenied";
		}


		egovAuthorManageService.deleteAuthor(authorManage);
		status.setComplete();
		redirectAttributes.addAttribute("message", egovMessageSource.getMessage("success.common.delete"));
		addAttributeSearch(authorManageVO, redirectAttributes);
		return "redirect:/sec/ram/EgovAuthorList.do";
	}

	/**
	 * 권한목록을 삭제한다.
	 * @param authorCodes String
	 * @param authorManage AuthorManage
	 * @return String
	 * @exception Exception
	 */
	@PostMapping(value = "/sec/ram/EgovAuthorListDelete.do")
	public String deleteAuthorList(@RequestParam("authorCodes") String authorCodes, final AuthorManageVO authorManageVO,
			@ModelAttribute("authorManage") AuthorManage authorManage, SessionStatus status, Model model, RedirectAttributes redirectAttributes)
			throws Exception {
		// 등록자 본인이 등록한 정보만 삭제할 수 있다. (하나라도 아니면 전체 거부)
		for (String key : authorCodes.split(";")) {
			if (!isAuthorRegister(key)) {
				return "cmm/error/accessDenied";
			}
		}


		String[] strAuthorCodes = authorCodes.split(";");
		for (int i = 0; i < strAuthorCodes.length; i++) {
			authorManage.setAuthorCode(strAuthorCodes[i]);
			egovAuthorManageService.deleteAuthor(authorManage);
		}
		status.setComplete();
		redirectAttributes.addAttribute("message", egovMessageSource.getMessage("success.common.delete"));
		addAttributeSearch(authorManageVO, redirectAttributes);
		return "redirect:/sec/ram/EgovAuthorList.do";
	}

	/**
	 * 권한제한 화면 이동
	 * @return String
	 * @exception Exception
	 */
	@GetMapping("/sec/ram/accessDenied.do")
	public String accessDenied() throws Exception {
		return "sec/accessDenied";
	}
	
	private void addAttributeSearch(final AuthorManageVO authorManageVO, final RedirectAttributes redirectAttributes) {
		redirectAttributes.addAttribute("searchCondition", authorManageVO.getSearchCondition());
		redirectAttributes.addAttribute("searchKeyword", authorManageVO.getSearchKeyword());
		redirectAttributes.addAttribute("pageIndex", authorManageVO.getPageIndex());
		redirectAttributes.addAttribute("authorCode", authorManageVO.getAuthorCode());
	}

	/**
	 * 로그인 사용자가 해당 정보의 등록자 본인인지 확인한다.
	 *
	 * @param key 대상 키
	 * @return 등록자 본인이면 true
	 */
	private boolean isAuthorRegister(String key) throws Exception {
		AuthorManageVO searchVO = new AuthorManageVO();
		searchVO.setAuthorCode(key);
		AuthorManageVO vo = egovAuthorManageService.selectAuthor(searchVO);
		return vo != null && EgovAuthorHelper.isRegister(vo.getFrstRegisterId());
	}
}
