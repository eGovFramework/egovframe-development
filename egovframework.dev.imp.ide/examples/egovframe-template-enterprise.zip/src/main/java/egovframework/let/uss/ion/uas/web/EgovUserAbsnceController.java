package egovframework.let.uss.ion.uas.web;

import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import egovframework.com.cmm.util.EgovAuthorHelper;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.RequireAdmin;
import egovframework.let.uss.ion.uas.service.EgovUserAbsnceService;
import egovframework.let.uss.ion.uas.service.UserAbsnce;
import egovframework.let.uss.ion.uas.service.UserAbsnceVO;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 * 사용자부재에 대한 controller 클래스를 정의한다.
 * 사용자부재에 대한 등록, 수정, 삭제, 조회, 반영확인 기능을 제공한다.
 * 사용자부재의 조회기능은 목록조회, 상세조회로 구분된다.
 * @author 공통서비스개발팀 lee.m.j
 * @since 2009.08.03
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.08.03  lee.m.j        최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *
 * </pre>
 */
@Controller
public class EgovUserAbsnceController {

	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	@Resource(name = "egovUserAbsnceService")
	private EgovUserAbsnceService egovUserAbsnceService;

	/**
	 * 사용자부재 목록화면 이동
	 * @return String
	 * @exception Exception
	 */
	@GetMapping("/uss/ion/uas/selectUserAbsnceListView.do")
	public String selectUserAbsnceListView() throws Exception {
		return "/uss/ion/uas/EgovUserAbsnceList";
	}

	/**
	 * 사용자부재정보를 관리하기 위해 등록된 사용자부재 목록을 조회한다.
	 * @param userAbsnceVO - 사용자부재 VO
	 * @return String - 리턴 Url
	 */
	@GetMapping("/uss/ion/uas/selectUserAbsnceList.do")
	public String selectUserAbsnceList(@RequestParam(value="selAbsnceAt", defaultValue="A") String selAbsnceAt, @ModelAttribute("userAbsnceVO") UserAbsnceVO userAbsnceVO, Model model) throws Exception {

		/** paging */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(userAbsnceVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(userAbsnceVO.getPageUnit());
		paginationInfo.setPageSize(userAbsnceVO.getPageSize());

		userAbsnceVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		userAbsnceVO.setLastIndex(paginationInfo.getLastRecordIndex());
		userAbsnceVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		userAbsnceVO.setSelAbsnceAt(selAbsnceAt);
		userAbsnceVO.setUserAbsnceList(egovUserAbsnceService.selectUserAbsnceList(userAbsnceVO));

		model.addAttribute("userAbsnceList", userAbsnceVO.getUserAbsnceList());

		int totCnt = egovUserAbsnceService.selectUserAbsnceListTotCnt(userAbsnceVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

		return "/uss/ion/uas/EgovUserAbsnceList";
	}

	/**
	 * 등록된 사용자부재 상세정보를 조회한다.
	 * @param userAbsnceVO - 사용자부재 VO
	 * @return String - 리턴 Url
	 */
	@GetMapping("/uss/ion/uas/getUserAbsnce.do")
	public String selectUserAbsnce(@ModelAttribute("userAbsnceVO") UserAbsnceVO userAbsnceVO, Model model) throws Exception {

		// 소유권 검증 - 요청 파라미터가 아닌 로그인한 본인의 사용자ID만 조회할 수 있다.
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		userAbsnceVO.setUserId(user.getId());
		model.addAttribute("userAbsnce", egovUserAbsnceService.selectUserAbsnce(userAbsnceVO));
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

		UserAbsnceVO vo = (UserAbsnceVO) model.getAttribute("userAbsnce");
		if (vo == null || vo.getRegYn() == null || vo.getRegYn().equals("N"))
			return "/uss/ion/uas/EgovUserAbsnceRegist";
		else
			return "/uss/ion/uas/EgovUserAbsnceUpdt";
	}

	/**
	 * 사용자부재정보를 신규로 등록한다.
	 * @param userAbsnce - 사용자부재 model
	 * @return String - 리턴 Url
	 */
	@GetMapping("/uss/ion/uas/addViewUserAbsnce.do")
	public String insertUserAbsnceView(@ModelAttribute("userAbsnceVO") UserAbsnceVO userAbsnceVO, Model model) throws Exception {
		// 소유권 검증 - 요청 파라미터가 아닌 로그인한 본인의 사용자ID로만 등록화면을 구성한다.
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		userAbsnceVO.setUserId(user.getId());
		model.addAttribute("userAbsnce", egovUserAbsnceService.selectUserAbsnce(userAbsnceVO));
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

		return "/uss/ion/uas/EgovUserAbsnceRegist";
	}

	/**
	 * 사용자부재정보를 신규로 등록한다.
	 * @param userAbsnce - 사용자부재 model
	 * @return String - 리턴 Url
	 */
	@PostMapping("/uss/ion/uas/addUserAbsnce.do")
	public String insertUserAbsnce(@Valid @ModelAttribute("userAbsnce") UserAbsnce userAbsnce, BindingResult bindingResult, @ModelAttribute("userAbsnceVO") UserAbsnceVO userAbsnceVO,
			Model model) throws Exception {

		if (bindingResult.hasErrors()) {
			model.addAttribute("userAbsnceVO", userAbsnceVO);
			return "/uss/ion/uas/EgovUserAbsnceRegist";
		} else {
			LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
			// 소유권 검증 - 요청 파라미터가 아닌 로그인한 본인의 사용자ID로만 등록할 수 있다.
			userAbsnce.setUserId(user.getId());
			userAbsnceVO.setUserId(user.getId());
			userAbsnce.setLastUpdusrId(user.getId());

			model.addAttribute("userAbsnce", egovUserAbsnceService.insertUserAbsnce(userAbsnce, userAbsnceVO));
			model.addAttribute("message", egovMessageSource.getMessage("success.common.insert"));

			return "/uss/ion/uas/EgovUserAbsnceUpdt";
		}
	}

	/**
	 * 기 등록된 사용자부재정보를 수정한다.
	 * @param userAbsnce - 사용자부재 model
	 * @return String - 리턴 Url
	 */
	@PostMapping("/uss/ion/uas/updtUserAbsnce.do")
	public String updateUserAbsnce(@Valid @ModelAttribute("userAbsnce") UserAbsnce userAbsnce, BindingResult bindingResult, Model model) throws Exception {

		if (bindingResult.hasErrors()) {
			model.addAttribute("userAbsnceVO", userAbsnce);
			return "/uss/ion/uas/EgovUserAbsnceUpdt";
		} else {

			LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
			// 소유권 검증 - 요청 파라미터가 아닌 로그인한 본인의 사용자ID만 수정할 수 있다.
			userAbsnce.setUserId(user.getId());
			userAbsnce.setLastUpdusrId(user.getId());

			egovUserAbsnceService.updateUserAbsnce(userAbsnce);
			return "forward:/uss/ion/uas/getUserAbsnce.do";
		}
	}

	/**
	 * 기 등록된 사용자부재정보를 삭제한다.
	 * @param userAbsnce - 사용자부재 model
	 * @return String - 리턴 Url
	 */
	@PostMapping("/uss/ion/uas/removeUserAbsnce.do")
	public String deleteUserAbsnce(UserAbsnceVO userAbsnceVO, @ModelAttribute("userAbsnce") UserAbsnce userAbsnce,
			Model model, RedirectAttributes redirectAttributes) throws Exception {

		// 소유권 검증 - 요청 파라미터가 아닌 로그인한 본인의 사용자ID만 삭제할 수 있다.
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		userAbsnce.setUserId(user.getId());

		egovUserAbsnceService.deleteUserAbsnce(userAbsnce);
		redirectAttributes.addAttribute("message", egovMessageSource.getMessage("success.common.delete"));
		addAttributeSearch(userAbsnceVO, redirectAttributes);
		return "redirect:/uss/ion/uas/selectUserAbsnceList.do";
	}

	/**
	 * 기 등록된 사용자부재정보를 삭제한다.
	 * @param userAbsnce - 사용자부재 model
	 * @return String - 리턴 Url
	 */
	@RequireAdmin
	@PostMapping("/uss/ion/uas/removeUserAbsnceList.do")
	public String deleteUserAbsnceList(@RequestParam("userIds") String userIds, @ModelAttribute("userAbsnce") UserAbsnce userAbsnce, Model model) throws Exception {
		String[] strUserIds = userIds != null ? userIds.split(";") : new String[0];

		if (strUserIds.length == 0) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.delete"));
			return "forward:/uss/ion/uas/selectUserAbsnceList.do";
		}

		// 등록자 본인이 등록한 부재정보만 삭제할 수 있다. (하나라도 아니면 전체 거부)
		for (int i = 0; i < strUserIds.length; i++) {
			UserAbsnceVO searchVO = new UserAbsnceVO();
			searchVO.setUserId(strUserIds[i]);
			UserAbsnceVO vo = egovUserAbsnceService.selectUserAbsnce(searchVO);
			if (vo == null || !EgovAuthorHelper.isRegisterByLoginId(vo.getFrstRegisterId())) {
				return "cmm/error/accessDenied";
			}
		}

		for (int i = 0; i < strUserIds.length; i++) {
			userAbsnce.setUserId(strUserIds[i]);
			egovUserAbsnceService.deleteUserAbsnce(userAbsnce);
		}

		model.addAttribute("message", egovMessageSource.getMessage("success.common.delete"));
		return "forward:/uss/ion/uas/selectUserAbsnceList.do";
	}

	/**
	 * MyPage에 사용자부재정보를 제공하기 위해 목록을 조회한다.
	 * @param userAbsnceVO - 사용자부재 VO
	 * @return String - 리턴 Url
	 */
	@GetMapping("/uss/ion/uas/selectUserAbsnceMainList.do")
	public String selectUserAbsnceMainList(@ModelAttribute("userAbsnceVO") UserAbsnceVO userAbsnceVO, Model model) throws Exception {

		/** paging */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(userAbsnceVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(5);
		paginationInfo.setPageSize(userAbsnceVO.getPageSize());

		userAbsnceVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		userAbsnceVO.setLastIndex(paginationInfo.getLastRecordIndex());
		userAbsnceVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		userAbsnceVO.setSelAbsnceAt("A");
		userAbsnceVO.setUserAbsnceList(egovUserAbsnceService.selectUserAbsnceList(userAbsnceVO));

		model.addAttribute("userAbsnceList", userAbsnceVO.getUserAbsnceList());

		return "/uss/ion/uas/EgovUserAbsnceMainList";
	}
	
	private void addAttributeSearch(UserAbsnceVO userAbsnceVO, RedirectAttributes redirectAttributes) {
		redirectAttributes.addAttribute("searchCondition", userAbsnceVO.getSearchCondition());
		redirectAttributes.addAttribute("searchKeyword", userAbsnceVO.getSearchKeyword());
		redirectAttributes.addAttribute("pageIndex", userAbsnceVO.getPageIndex());
		redirectAttributes.addAttribute("selAbsnceAt", userAbsnceVO.getSelAbsnceAt());
	}
}
