package egovframework.let.uat.uia.filter;

import java.io.IOException;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;

/**
 * 로그아웃 요청(/uat/uia/actionLogout.do)을 Spring Security logoutUrl 경로로 변환하는 브리지 필터.
 */
@Component("egovSpringSecurityLogoutFilter")
public class EgovSpringSecurityLogoutFilter extends OncePerRequestFilter {

	private static final String ACTION_LOGOUT_PATH = "/uat/uia/actionLogout.do";
	private static final String SECURITY_LOGOUT_PATH = "/uat/uia/actionSecurityLogout.do";

	@Override
	protected boolean shouldNotFilter(HttpServletRequest request) {
		String uri = stripContextPath(request);
		return !uri.equals(ACTION_LOGOUT_PATH);
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		SecurityContextHolder.clearContext();

		var session = request.getSession(false);
		if (session != null) {
			session.removeAttribute("loginVO");
			session.removeAttribute("accessUser");
			session.removeAttribute("menuNo");
			session.removeAttribute("baseMenuNo");
		}

		HttpServletRequest wrapped = new SecurityLogoutPathRequestWrapper(request, SECURITY_LOGOUT_PATH);
		filterChain.doFilter(wrapped, response);
	}

	private static String stripContextPath(HttpServletRequest request) {
		String contextPath = request.getContextPath();
		String uri = request.getRequestURI();
		if (StringUtils.hasText(contextPath) && uri.startsWith(contextPath)) {
			return uri.substring(contextPath.length());
		}
		return uri;
	}

	private static final class SecurityLogoutPathRequestWrapper extends HttpServletRequestWrapper {

		private final String securityLogoutPath;

		SecurityLogoutPathRequestWrapper(HttpServletRequest request, String securityLogoutPath) {
			super(request);
			this.securityLogoutPath = securityLogoutPath;
		}

		@Override
		public String getServletPath() {
			return securityLogoutPath;
		}

		@Override
		public String getPathInfo() {
			return null;
		}

		@Override
		public String getRequestURI() {
			String cp = getContextPath();
			if (ObjectUtils.isEmpty(cp)) {
				return securityLogoutPath;
			}
			return cp + securityLogoutPath;
		}

		@Override
		public StringBuffer getRequestURL() {
			StringBuffer url = new StringBuffer();
			url.append(getScheme()).append("://").append(getServerName());
			int port = getServerPort();
			if (port > 0 && (("http".equalsIgnoreCase(getScheme()) && port != 80)
					|| ("https".equalsIgnoreCase(getScheme()) && port != 443))) {
				url.append(':').append(port);
			}
			url.append(getRequestURI());
			return url;
		}
	}
}
