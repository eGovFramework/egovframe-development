package egovframework.let.sym.log.clg.service.impl;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;
import org.springframework.stereotype.Repository;

import egovframework.let.sym.log.clg.service.LoginLog;

/**
 * 시스템 로그 관리를 위한 데이터 접근 클래스
 * @author 공통서비스개발팀 이삼섭
 * @since 2009.03.11
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.03.11  이삼섭          최초 생성
 *   2011.07.01  이기하          패키지 분리(sym.log -> sym.log.clg)
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *   2026.06.20  이백행          [2026년 컨트리뷰션] 불필요한 예외 제거
 *
 * </pre>
 */
@Repository("loginLogDAO")
public class LoginLogDAO extends EgovAbstractMapper {

	/**
	 * 접속로그를 기록한다.
	 *
	 * @param LoginLog
	 * @return
	 */
	public void logInsertLoginLog(LoginLog loginLog) {
		insert("LoginLogDAO.logInsertLoginLog", loginLog);
	}

	/**
	 * 접속로그를 조회한다.
	 *
	 * @param loginLog
	 * @return loginLog
	 */
	public LoginLog selectLoginLog(LoginLog loginLog) {

		return (LoginLog) selectOne("LoginLogDAO.selectLoginLog", loginLog);
	}

	/**
	 * 접속로그를 목록을 조회한다.
	 *
	 * @param loginLog
	 * @return
	 */
	public List<?> selectLoginLogInf(LoginLog loginLog) {
		return selectList("LoginLogDAO.selectLoginLogInf", loginLog);
	}

	/**
	 * 접속로그 목록의 숫자를 조회한다.
	 * @param loginLog
	 * @return
	 */
	public int selectLoginLogInfCnt(LoginLog loginLog) {

		return (Integer)selectOne("LoginLogDAO.selectLoginLogInfCnt", loginLog);
	}

}
