package egovframework.let.uat.uia.filter;

import java.io.IOException;

import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import egovframework.com.cmm.LoginVO;
import egovframework.let.sym.log.clg.service.EgovLoginLogService;
import egovframework.let.sym.log.clg.service.LoginLog;
import egovframework.let.utl.sim.service.EgovClntInfo;
import jakarta.annotation.Resource;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Spring Security 인증 컨텍스트와 HTTP 세션의 loginVO를 동기화한다.
 * Spring Security 필터 체인 직후·DispatcherServlet 이전에 실행되어야 한다.
 * 인증 후 최초 동기화 시점에 접속 IP를 기록하고 로그인 로그를 남긴다.
 */
@Component("egovLoginSessionSyncFilter")
public class EgovLoginSessionSyncFilter extends OncePerRequestFilter {

	@Resource(name = "EgovLoginLogService")
	private EgovLoginLogService loginLogService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		syncLoginSession(request);

		filterChain.doFilter(request, response);

		if (request.getRequestURI().endsWith(".do")) {
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
			response.setHeader("Pragma", "no-cache");
			response.setDateHeader("Expires", 0);
		}
	}

	private void syncLoginSession(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session == null) {
			return;
		}

		if (Boolean.TRUE.equals(EgovUserDetailsHelper.isAuthenticated())) {
			Object principal = EgovUserDetailsHelper.getAuthenticatedUser();
			if (principal instanceof LoginVO loginVO) {
				if (session.getAttribute("loginVO") == null) {
					loginVO.setIp(EgovClntInfo.getClntIP(request));
					writeLoginLog(loginVO);
				}
				session.setAttribute("loginVO", loginVO);
			}
		} else {
			session.removeAttribute("loginVO");
			session.removeAttribute("accessUser");
		}
	}

	private void writeLoginLog(LoginVO loginVO) {
		LoginLog loginLog = new LoginLog();
		loginLog.setLoginId(loginVO.getUniqId());
		loginLog.setLoginIp(loginVO.getIp());
		loginLog.setLoginMthd("I"); // 로그인:I, 로그아웃:O
		loginLog.setErrOccrrAt("N");
		loginLog.setErrorCode("");
		try {
			loginLogService.logInsertLoginLog(loginLog);
		} catch (Exception e) {
			logger.warn("Login log insert failed", e);
		}
	}
}
