package egovframework.let.cop.bbs.util;

import java.util.List;

import org.springframework.security.access.AccessDeniedException;

import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.let.cop.bbs.service.BoardVO;

/**
 * 게시판 객체 수준 권한 검증 유틸리티
 */
public final class EgovBBSAuthUtil {

	private EgovBBSAuthUtil() {
	}

	public static boolean isAdminUser() {
		List<String> authorities = EgovUserDetailsHelper.getAuthorities();
		return authorities != null && authorities.contains("ROLE_ADMIN");
	}

	public static void assertAdminUser() {
		if (!EgovUserDetailsHelper.isAuthenticated() || !isAdminUser()) {
			throw new AccessDeniedException("관리자 권한이 필요합니다.");
		}
	}

	public static void assertCanModifyArticle(BoardVO article, LoginVO user) {
		if (user == null || user.getUniqId() == null || user.getUniqId().isEmpty()) {
			throw new AccessDeniedException("인증이 필요합니다.");
		}
		if (isAdminUser()) {
			return;
		}
		if (article == null || article.getFrstRegisterId() == null || article.getFrstRegisterId().isEmpty()) {
			throw new AccessDeniedException("게시글을 찾을 수 없습니다.");
		}
		if (!user.getUniqId().equals(article.getFrstRegisterId())) {
			throw new AccessDeniedException("게시글 수정 권한이 없습니다.");
		}
	}
}
