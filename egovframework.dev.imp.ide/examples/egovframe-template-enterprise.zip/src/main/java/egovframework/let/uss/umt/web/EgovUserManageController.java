package egovframework.let.uss.umt.web;

import java.util.Map;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import egovframework.com.cmm.util.EgovAuthorHelper;
import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.let.uss.umt.service.EgovUserManageService;
import egovframework.let.uss.umt.service.UserDefaultVO;
import egovframework.let.uss.umt.service.UserManageVO;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

/**
 * 업무사용자관련 요청을  비지니스 클래스로 전달하고 처리된결과를  해당   웹 화면으로 전달하는  Controller를 정의한다
 * @author 공통서비스 개발팀 조재영
 * @since 2009.04.10
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.04.10  조재영          최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *
 * </pre>
 */
@Controller
public class EgovUserManageController {

	/** userManageService */
	@Resource(name = "userManageService")
	private EgovUserManageService userManageService;

	/** 비밀번호 암호화(BCrypt) */
	@Resource(name = "passwordEncoder")
	private PasswordEncoder passwordEncoder;

	/** cmmUseService */
	@Resource(name = "EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/**
	 * 사용자목록을 조회한다. (pageing)
	 * @param userSearchVO 검색조건정보
	 * @param model 화면모델
	 * @return cmm/uss/umt/EgovUserManage
	 * @throws Exception
	 */
	@GetMapping(value = "/uss/umt/user/EgovUserManage.do")
	public String selectUserList(@ModelAttribute("userSearchVO") UserDefaultVO userSearchVO, Model model,
			HttpServletRequest request) throws Exception {

		// 메인화면에서 넘어온 경우 메뉴 갱신을 위해 추가
		request.getSession().setAttribute("baseMenuNo", "6000000");
		
		// 미인증 사용자에 대한 보안처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}
    	
		/** EgovPropertyService */
		userSearchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		userSearchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(userSearchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(userSearchVO.getPageUnit());
		paginationInfo.setPageSize(userSearchVO.getPageSize());

		userSearchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		userSearchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		userSearchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		model.addAttribute("resultList", userManageService.selectUserList(userSearchVO));

		int totCnt = userManageService.selectUserListTotCnt(userSearchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		//사용자상태코드를 코드정보로부터 조회
		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		vo.setCodeId("COM013");
		model.addAttribute("emplyrSttusCode_result", cmmUseService.selectCmmCodeDetail(vo));//사용자상태코드목록

		return "cmm/uss/umt/EgovUserManage";
	}

	/**
	 * 사용자등록화면으로 이동한다.
	 * @param userSearchVO 검색조건정보
	 * @param userManageVO 사용자초기화정보
	 * @param model 화면모델
	 * @return cmm/uss/umt/EgovUserInsert
	 * @throws Exception
	 */
	@GetMapping("/uss/umt/user/EgovUserInsertView.do")
	public String insertUserView(@ModelAttribute("userSearchVO") UserDefaultVO userSearchVO, @ModelAttribute("userManageVO") UserManageVO userManageVO, Model model)
			throws Exception {

		// 미인증 사용자에 대한 보안처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}

		ComDefaultCodeVO vo = new ComDefaultCodeVO();

		//패스워드힌트목록을 코드정보로부터 조회
		vo.setCodeId("COM022");
		model.addAttribute("passwordHint_result", cmmUseService.selectCmmCodeDetail(vo)); //패스워트힌트목록

		//성별구분코드를 코드정보로부터 조회
		vo.setCodeId("COM014");
		model.addAttribute("sexdstnCode_result", cmmUseService.selectCmmCodeDetail(vo));

		//사용자상태코드를 코드정보로부터 조회
		vo.setCodeId("COM013");
		model.addAttribute("emplyrSttusCode_result", cmmUseService.selectCmmCodeDetail(vo));

		//소속기관코드를 코드정보로부터 조회 - COM025
		vo.setCodeId("COM025");
		model.addAttribute("insttCode_result", cmmUseService.selectCmmCodeDetail(vo));

		//조직정보를 조회 - ORGNZT_ID정보
		vo.setTableNm("LETTNORGNZTINFO");
		model.addAttribute("orgnztId_result", cmmUseService.selectOgrnztIdDetail(vo));

		//그룹정보를 조회 - GROUP_ID정보
		vo.setTableNm("LETTNORGNZTINFO");
		model.addAttribute("groupId_result", cmmUseService.selectGroupIdDetail(vo));

		return "cmm/uss/umt/EgovUserInsert";
	}

	/**
	 * 사용자등록처리후 목록화면으로 이동한다.
	 * @param userManageVO 사용자등록정보
	 * @param bindingResult 입력값검증용 bindingResult
	 * @param model 화면모델
	 * @return forward:/uss/umt/user/EgovUserManage.do
	 * @throws Exception
	 */
	@PostMapping("/uss/umt/user/EgovUserInsert.do")
	public String insertUser(@Valid @ModelAttribute("userManageVO") UserManageVO userManageVO, BindingResult bindingResult, Model model,
			RedirectAttributes redirectAttributes) throws Exception {

		// 미인증 사용자에 대한 보안처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}

		// 비밀번호 최소 길이 검증(8자 이상)
		if (userManageVO.getPassword() == null || userManageVO.getPassword().length() < 8) {
			bindingResult.rejectValue("password", "size", new Object[] { 8, 20 }, "비밀번호는 8자 이상이어야 합니다.");
		}

		if (bindingResult.hasErrors()) {
			ComDefaultCodeVO vo = new ComDefaultCodeVO();
			//패스워드힌트목록을 코드정보로부터 조회
			vo.setCodeId("COM022");
			model.addAttribute("passwordHint_result", cmmUseService.selectCmmCodeDetail(vo)); //패스워트힌트목록

			//성별구분코드를 코드정보로부터 조회
			vo.setCodeId("COM014");
			model.addAttribute("sexdstnCode_result", cmmUseService.selectCmmCodeDetail(vo));

			//사용자상태코드를 코드정보로부터 조회
			vo.setCodeId("COM013");
			model.addAttribute("emplyrSttusCode_result", cmmUseService.selectCmmCodeDetail(vo));

			//소속기관코드를 코드정보로부터 조회 - COM025
			vo.setCodeId("COM025");
			model.addAttribute("insttCode_result", cmmUseService.selectCmmCodeDetail(vo));

			//조직정보를 조회 - ORGNZT_ID정보
			vo.setTableNm("LETTNORGNZTINFO");
			model.addAttribute("orgnztId_result", cmmUseService.selectOgrnztIdDetail(vo));

			//그룹정보를 조회 - GROUP_ID정보
			vo.setTableNm("LETTNORGNZTINFO");
			model.addAttribute("groupId_result", cmmUseService.selectGroupIdDetail(vo));
			return "cmm/uss/umt/EgovUserInsert";
		} else {
			// 등록자는 요청 파라미터가 아닌 로그인 사용자로 지정한다.
			userManageVO.setFrstRegisterId(EgovAuthorHelper.getLoginUniqId());
			userManageService.insertUser(userManageVO);
			//Exception 없이 진행시 등록성공메시지
			redirectAttributes.addAttribute("resultMsg", "success.common.insert");
		}
		addAttributeSearch(userManageVO, redirectAttributes);

		return "redirect:/uss/umt/user/EgovUserManage.do";
	}

	/**
	 * 로그인 사용자가 해당 사용자정보의 등록자 본인인지 확인한다.
	 *
	 * @param uniqId 대상 사용자 고유ID
	 * @return 등록자 본인이면 true
	 */
	private boolean isUserRegister(String uniqId) throws Exception {
		UserManageVO vo = userManageService.selectUser(uniqId);
		return vo != null && EgovAuthorHelper.isRegister(vo.getFrstRegisterId());
	}

	/**
	 * 사용자정보 수정을 위해 사용자정보를 상세조회한다.
	 * @param uniqId 상세조회대상 사용자아이디
	 * @param userSearchVO 검색조건
	 * @param model 화면모델
	 * @return cmm/uss/umt/EgovUserSelectUpdt
	 * @throws Exception
	 */
	@GetMapping("/uss/umt/user/EgovUserSelectUpdtView.do")
	public String updateUserView(@RequestParam("selectedId") String uniqId, @ModelAttribute("searchVO") UserDefaultVO userSearchVO, Model model) throws Exception {

		// 미인증 사용자에 대한 보안처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}

		ComDefaultCodeVO vo = new ComDefaultCodeVO();

		//패스워드힌트목록을 코드정보로부터 조회
		vo.setCodeId("COM022");
		model.addAttribute("passwordHint_result", cmmUseService.selectCmmCodeDetail(vo));

		//성별구분코드를 코드정보로부터 조회
		vo.setCodeId("COM014");
		model.addAttribute("sexdstnCode_result", cmmUseService.selectCmmCodeDetail(vo));

		//사용자상태코드를 코드정보로부터 조회
		vo.setCodeId("COM013");
		model.addAttribute("emplyrSttusCode_result", cmmUseService.selectCmmCodeDetail(vo));

		//소속기관코드를 코드정보로부터 조회 - COM025
		vo.setCodeId("COM025");
		model.addAttribute("insttCode_result", cmmUseService.selectCmmCodeDetail(vo));

		//조직정보를 조회 - ORGNZT_ID정보
		vo.setTableNm("LETTNORGNZTINFO");
		model.addAttribute("orgnztId_result", cmmUseService.selectOgrnztIdDetail(vo));

		//그룹정보를 조회 - GROUP_ID정보
		vo.setTableNm("LETTNORGNZTINFO");
		model.addAttribute("groupId_result", cmmUseService.selectGroupIdDetail(vo));

		UserManageVO userManageVO = new UserManageVO();
		userManageVO = userManageService.selectUser(uniqId);
		model.addAttribute("userSearchVO", userSearchVO);
		model.addAttribute("userManageVO", userManageVO);
		// 등록자 본인에게만 수정/삭제 버튼을 노출한다.
		model.addAttribute("isRegister", userManageVO != null && EgovAuthorHelper.isRegister(userManageVO.getFrstRegisterId()));

		return "cmm/uss/umt/EgovUserSelectUpdt";
	}

	/**
	 * 사용자정보 수정후 목록조회 화면으로 이동한다.
	 * @param userManageVO 사용자수정정보
	 * @param bindingResult 입력값검증용 bindingResult
	 * @param model 화면모델
	 * @return forward:/uss/umt/user/EgovUserManage.do
	 * @throws Exception
	 */
	@PostMapping("/uss/umt/user/EgovUserSelectUpdt.do")
	public String updateUser(@Valid @ModelAttribute("userManageVO") UserManageVO userManageVO, BindingResult bindingResult, Model model,
			RedirectAttributes redirectAttributes) throws Exception {

		// 미인증 사용자에 대한 보안처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}

		// 등록자 본인만 수정/삭제할 수 있다.
		if (!isUserRegister(userManageVO.getUniqId())) {
			return "cmm/error/accessDenied";
		}

		if (bindingResult.hasErrors()) {

			ComDefaultCodeVO vo = new ComDefaultCodeVO();

			//패스워드힌트목록을 코드정보로부터 조회
			vo.setCodeId("COM022");
			model.addAttribute("passwordHint_result", cmmUseService.selectCmmCodeDetail(vo));

			//성별구분코드를 코드정보로부터 조회
			vo.setCodeId("COM014");
			model.addAttribute("sexdstnCode_result", cmmUseService.selectCmmCodeDetail(vo));

			//사용자상태코드를 코드정보로부터 조회
			vo.setCodeId("COM013");
			model.addAttribute("emplyrSttusCode_result", cmmUseService.selectCmmCodeDetail(vo));

			//소속기관코드를 코드정보로부터 조회 - COM025
			vo.setCodeId("COM025");
			model.addAttribute("insttCode_result", cmmUseService.selectCmmCodeDetail(vo));

			//조직정보를 조회 - ORGNZT_ID정보
			vo.setTableNm("LETTNORGNZTINFO");
			model.addAttribute("orgnztId_result", cmmUseService.selectOgrnztIdDetail(vo));

			//그룹정보를 조회 - GROUP_ID정보
			vo.setTableNm("LETTNORGNZTINFO");
			model.addAttribute("groupId_result", cmmUseService.selectGroupIdDetail(vo));
			model.addAttribute("isRegister", true);
			return "cmm/uss/umt/EgovUserSelectUpdt";
		} else {
			//업무사용자 수정시 히스토리 정보를 등록한다.
			userManageService.insertUserHistory(userManageVO);
			userManageService.updateUser(userManageVO);
			//Exception 없이 진행시 수정성공메시지
			redirectAttributes.addAttribute("resultMsg", "success.common.update");
			
			addAttributeSearch(userManageVO, redirectAttributes);

			return "redirect:/uss/umt/user/EgovUserManage.do";
		}
	}

	/**
	 * 사용자정보삭제후 목록조회 화면으로 이동한다.
	 * @param checkedIdForDel 삭제대상아이디 정보
	 * @param userSearchVO 검색조건
	 * @param model 화면모델
	 * @return forward:/uss/umt/user/EgovUserManage.do
	 * @throws Exception
	 */
	@PostMapping("/uss/umt/user/EgovUserDelete.do")
	public String deleteUser(@RequestParam("checkedIdForDel") String checkedIdForDel, @ModelAttribute("searchVO") UserDefaultVO userSearchVO, Model model,
			RedirectAttributes redirectAttributes) throws Exception {

		// 미인증 사용자에 대한 보안처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}

		// 등록자 본인이 등록한 사용자만 삭제할 수 있다. (하나라도 아니면 전체 거부)
		for (String delId : checkedIdForDel.split(",")) {
			String[] id = delId.split(":");
			if (id.length > 1 && !isUserRegister(id[1])) {
				return "cmm/error/accessDenied";
			}
		}

		userManageService.deleteUser(checkedIdForDel);
		//Exception 없이 진행시 등록성공메시지
		redirectAttributes.addAttribute("resultMsg", "success.common.delete");
		
		addAttributeSearch(userSearchVO, redirectAttributes);

		return "redirect:/uss/umt/user/EgovUserManage.do";
	}

	/**
	 * 입력한 사용자아이디의 중복확인화면 이동
	 * @param model 화면모델
	 * @return cmm/uss/umt/EgovIdDplctCnfirm
	 * @throws Exception
	 */
	@GetMapping(value = "/uss/umt/cmm/EgovIdDplctCnfirmView.do")
	public String checkIdDplct(Model model) throws Exception {

		// 미인증 사용자에 대한 보안처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}

		model.addAttribute("checkId", "");
		model.addAttribute("usedCnt", "-1");
		return "cmm/uss/umt/EgovIdDplctCnfirm";
	}

	/**
	 * 입력한 사용자아이디의 중복여부를 체크하여 사용가능여부를 확인
	 * @param commandMap 파라메터전달용 commandMap
	 * @param model 화면모델
	 * @return cmm/uss/umt/EgovIdDplctCnfirm
	 * @throws Exception
	 */
	@GetMapping(value = "/uss/umt/cmm/EgovIdDplctCnfirm.do")
	public String checkIdDplct(@RequestParam Map<String, Object> commandMap, Model model) throws Exception {

		// 미인증 사용자에 대한 보안처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}

		String checkId = (String) commandMap.get("checkId");
		if (checkId == null || checkId.isEmpty())
			return "forward:/uss/umt/cmm/EgovIdDplctCnfirmView.do";
		checkId = new String(checkId.getBytes("ISO-8859-1"), "UTF-8");

		int usedCnt = userManageService.checkIdDplct(checkId);
		model.addAttribute("usedCnt", usedCnt);
		model.addAttribute("checkId", checkId);

		return "cmm/uss/umt/EgovIdDplctCnfirm";
	}

	/**
	 * 업무사용자 암호 수정처리 후 화면 이동
	 * @param model 화면모델
	 * @param commandMap 파라메터전달용 commandMap
	 * @param userSearchVO 검색조 건
	 * @param userManageVO 사용자수정정보(비밀번호)
	 * @return cmm/uss/umt/EgovUserPasswordUpdt
	 * @throws Exception
	 */
	@PostMapping(value = "/uss/umt/user/EgovUserPasswordUpdt.do")
	public String updatePassword(Model model, @RequestParam Map<String, Object> commandMap, @ModelAttribute("searchVO") UserDefaultVO userSearchVO,
			@ModelAttribute("userManageVO") UserManageVO userManageVO) throws Exception {

		// 미인증 사용자에 대한 보안처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}

		String oldPassword = (String) commandMap.get("oldPassword");
		String newPassword = (String) commandMap.get("newPassword");
		String newPassword2 = (String) commandMap.get("newPassword2");
		String uniqId = (String) commandMap.get("uniqId");

		// 등록자 본인만 수정/삭제할 수 있다.
		if (!isUserRegister(uniqId)) {
			return "cmm/error/accessDenied";
		}

		// 새 비밀번호 필수 입력 체크
		if (newPassword == null || newPassword.trim().isEmpty()) {
			model.addAttribute("userManageVO", userManageVO);
			model.addAttribute("userSearchVO", userSearchVO);
			model.addAttribute("resultMsg", "fail.user.passwordUpdate3");
			return "cmm/uss/umt/EgovUserPasswordUpdt";
		}

		// 새 비밀번호 길이 체크(8~20자, 등록 시 정책과 동일)
		if (newPassword.length() < 8 || newPassword.length() > 20) {
			model.addAttribute("userManageVO", userManageVO);
			model.addAttribute("userSearchVO", userSearchVO);
			model.addAttribute("resultMsg", "fail.user.passwordUpdate4");
			return "cmm/uss/umt/EgovUserPasswordUpdt";
		}

		boolean isCorrectPassword = false;
		UserManageVO resultVO = new UserManageVO();
		userManageVO.setPassword(newPassword);
		userManageVO.setOldPassword(oldPassword);
		userManageVO.setUniqId(uniqId);
		if (userManageVO.getEmplyrId() == null || userManageVO.getEmplyrId().isEmpty()) {
			model.addAttribute("userManageVO", userManageVO);
			model.addAttribute("userSearchVO", userSearchVO);
			model.addAttribute("resultMsg", "fail.common.msg");
			return "cmm/uss/umt/EgovUserPasswordUpdt";
		}

		String resultMsg = "";
		resultVO = userManageService.selectPassword(userManageVO);
		if (resultVO != null && oldPassword != null && passwordEncoder.matches(oldPassword, resultVO.getPassword())) {
			if (newPassword.equals(newPassword2)) {
				isCorrectPassword = true;
			} else {
				isCorrectPassword = false;
				resultMsg = "fail.user.passwordUpdate2";
			}
		} else {
			isCorrectPassword = false;
			resultMsg = "fail.user.passwordUpdate1";
		}

		if (isCorrectPassword) {
			userManageVO.setPassword(passwordEncoder.encode(newPassword));
			userManageService.updatePassword(userManageVO);
			resultMsg = "success.common.update";
		}
		// 비밀번호(평문·해시)는 화면 모델에 남기지 않는다.
		userManageVO.setPassword(null);
		userManageVO.setOldPassword(null);
		model.addAttribute("userManageVO", userManageVO);
		model.addAttribute("userSearchVO", userSearchVO);
		model.addAttribute("resultMsg", resultMsg);

		return "cmm/uss/umt/EgovUserPasswordUpdt";
	}

	/**
	 * 업무사용자 암호 수정  화면 이동
	 * @param model 화면모델
	 * @param commandMap 파라메터전달용 commandMap
	 * @param userSearchVO 검색조건
	 * @param userManageVO 사용자수정정보(비밀번호)
	 * @return cmm/uss/umt/EgovUserPasswordUpdt
	 * @throws Exception
	 */
	@GetMapping(value = "/uss/umt/user/EgovUserPasswordUpdtView.do")
	public String updatePasswordView(Model model, @RequestParam Map<String, Object> commandMap, @ModelAttribute("searchVO") UserDefaultVO userSearchVO,
			@ModelAttribute("userManageVO") UserManageVO userManageVO) throws Exception {

		// 미인증 사용자에 대한 보안처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}

		String userTyForPassword = (String) commandMap.get("userTyForPassword");
		userManageVO.setUserTy(userTyForPassword);

		model.addAttribute("userManageVO", userManageVO);
		model.addAttribute("userSearchVO", userSearchVO);
		return "cmm/uss/umt/EgovUserPasswordUpdt";
	}
	
	private void addAttributeSearch(UserDefaultVO userDefaultVO, RedirectAttributes redirectAttributes) {
		redirectAttributes.addAttribute("searchCondition", userDefaultVO.getSearchCondition());
		redirectAttributes.addAttribute("searchKeyword", userDefaultVO.getSearchKeyword());
		redirectAttributes.addAttribute("pageIndex", userDefaultVO.getPageIndex());
	}

}
