package egovframework.let.uss.olp.qqm.service.impl;

import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;
import org.egovframe.rte.fdl.cmmn.exception.FdlException;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.let.uss.olp.qqm.service.EgovQustnrQestnManageService;
import egovframework.let.uss.olp.qqm.service.QustnrQestnManageVO;
import jakarta.annotation.Resource;
/**
 * 설문문항을 처리하는 ServiceImpl Class 구현
 * @author 공통서비스 장동한
 * @since 2009.03.20
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.03.20  장동한          최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *
 * </pre>
 */
@Service("egovQustnrQestnManageService")
public class EgovQustnrQestnManageServiceImpl extends EgovAbstractServiceImpl implements EgovQustnrQestnManageService{

	@Resource(name="qustnrQestnManageDao")
	private QustnrQestnManageDao dao;

	@Resource(name="egovQustnrQestnManageIdGnrService")
	private EgovIdGnrService idgenService;


    /**
	 * 설문조사 응답자답변내용결과/기타답변내용결과 통계를 조회한다.
	 * @param Map - 설문지 정보가 담김 Parameter
	 * @return Map
	 */
	@Override
	public List<?> selectQustnrManageStatistics2(Map<?, ?> map) {
		return dao.selectQustnrManageStatistics2(map);
	}

    /**
	 * 설문조사 통계를 조회한다.
	 * @param Map - 설문지 정보가 담김 Parameter
	 * @return Map
	 */
	@Override
	public List<?> selectQustnrManageStatistics(Map<?, ?> map) {
		return dao.selectQustnrManageStatistics(map);
	}
    /**
	 * 설문지정보 설문제목을 조회한다.
	 * @param Map - 설문지 정보가 담김 Parameter
	 * @return Map
	 */
	@Override
	public Map<?, ?> selectQustnrManageQestnrSj(Map<?, ?> map) {
		return dao.selectQustnrManageQestnrSj(map);
	}

    /**
	 * 설문문항 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return List
	 */
	@Override
	public List<?> selectQustnrQestnManageList(ComDefaultVO searchVO) {
		return dao.selectQustnrQestnManageList(searchVO);
	}

    /**
	 * 설문문항를(을) 상세조회 한다.
	 * @param QustnrQestnManage - 회정정보가 담김 VO
	 * @return List
	 */
	@Override
	public List<?> selectQustnrQestnManageDetail(QustnrQestnManageVO qustnrQestnManageVO) {
		return dao.selectQustnrQestnManageDetail(qustnrQestnManageVO);
	}

    /**
	 * 설문문항를(을) 목록 전체 건수를(을) 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return int
	 */
	@Override
	public int selectQustnrQestnManageListCnt(ComDefaultVO searchVO) {
		return dao.selectQustnrQestnManageListCnt(searchVO);
	}

    /**
	 * 설문문항를(을) 등록한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 */
	@Override
	public void insertQustnrQestnManage(QustnrQestnManageVO qustnrQestnManageVO) {
		String sMakeId;
		try {
			sMakeId = idgenService.getNextStringId();
		} catch (FdlException e) {
			throw new BaseRuntimeException(e);
		}

		qustnrQestnManageVO.setQestnrQesitmId(sMakeId);

		dao.insertQustnrQestnManage(qustnrQestnManageVO);
	}

    /**
	 * 설문문항를(을) 수정한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 */
	@Override
	public void updateQustnrQestnManage(QustnrQestnManageVO qustnrQestnManageVO) {
		dao.updateQustnrQestnManage(qustnrQestnManageVO);
	}

    /**
	 * 설문문항를(을) 삭제한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 */
	@Override
	public void deleteQustnrQestnManage(QustnrQestnManageVO qustnrQestnManageVO) {
		dao.deleteQustnrQestnManage(qustnrQestnManageVO);
	}
}
