package egovframework.let.uss.olh.qna.service.impl;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractMapper;
import org.springframework.stereotype.Repository;

import egovframework.let.uss.olh.qna.service.QnaManageDefaultVO;
import egovframework.let.uss.olh.qna.service.QnaManageVO;
/**
 *
 * Q&A정보를 처리하는 DAO 클래스
 * @author 공통서비스 개발팀 박정규
 * @since 2009.04.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.04.01  박정규          최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *
 * </pre>
 */
@Repository("QnaManageDAO")
public class QnaManageDAO extends EgovAbstractMapper {


    /**
	 * Q&A 글 목록에 대한 상세내용을 조회한다.
	 * @param vo
	 * @return 조회한 글
	 */
    public QnaManageVO selectQnaListDetail(QnaManageVO vo) {

        return (QnaManageVO) selectOne("QnaManageDAO.selectQnaListDetail", vo);

    }

	/**
	 * Q&A 글을 수정한다.(조회수를 수정)
	 * @param vo
	 */
    public void updateQnaInqireCo(QnaManageVO vo) {

        update("QnaManageDAO.updateQnaInqireCo", vo);

    }

    /**
	 * Q&A 글 목록을 조회한다.
	 * @param searchVO
	 * @return 글 목록
	 */
	public List<?> selectQnaList(QnaManageDefaultVO searchVO) {

        return selectList("QnaManageDAO.selectQnaList", searchVO);

    }

    /**
	 * Q&A 글 총 갯수를 조회한다.
	 * @param searchVO
	 * @return 글 총 갯수
	 */
    public int selectQnaListTotCnt(QnaManageDefaultVO searchVO) {

        return (Integer)selectOne("QnaManageDAO.selectQnaListTotCnt", searchVO);

    }

	/**
	 * Q&A 글을 등록한다.
	 * @param vo
	 */
    public void insertQnaCn(QnaManageVO vo) {

        insert("QnaManageDAO.insertQnaCn", vo);

    }

	/**
	 * Q&A 글을 수정한다.
	 * @param vo
	 */
    public void updateQnaCn(QnaManageVO vo) {

        update("QnaManageDAO.updateQnaCn", vo);

    }

	/**
	 * Q&A 글을 삭제한다.
	 * @param vo
	 */
    public void deleteQnaCn(QnaManageVO vo) {

        delete("QnaManageDAO.deleteQnaCn", vo);

    }


    /**
	 * Q&A 답변 글 목록에 대한 상세내용을 조회한다.
	 * @param vo
	 * @return 조회한 글
	 */
    public QnaManageVO selectQnaAnswerListDetail(QnaManageVO vo) {

        return (QnaManageVO) selectOne("QnaManageDAO.selectQnaAnswerListDetail", vo);

    }


    /**
	 * Q&A 답변 글 목록을 조회한다.
	 * @param searchVO
	 * @return 글 목록
	 */
	public List<?> selectQnaAnswerList(QnaManageDefaultVO searchVO) {

        return selectList("QnaManageDAO.selectQnaAnswerList", searchVO);

    }

    /**
	 * Q&A 답변 글 총 갯수를 조회한다.
	 * @param searchVO
	 * @return 글 총 갯수
	 */
    public int selectQnaAnswerListTotCnt(QnaManageDefaultVO searchVO) {

        return (Integer)selectOne("QnaManageDAO.selectQnaAnswerListTotCnt", searchVO);

    }

	/**
	 * Q&A 답변 글을 수정한다.
	 * @param vo
	 */
    public void updateQnaCnAnswer(QnaManageVO vo) {

        update("QnaManageDAO.updateQnaCnAnswer", vo);

    }


}
