package egovframework.let.uss.olp.qrm.service;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

/**
 * 설문응답자관리 VO Class 구현
 * @author 공통서비스 장동한
 * @since 2009.03.20
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.03.20  장동한          최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *
 * </pre>
 */
@Getter
@Setter
public class QustnrRespondManageVO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/** 설문지ID */
	private String qestnrId = "";

	/** 설문응답자아이디 */
	private String qestnrRespondId = "";

	/** 설별코드 */
	@EgovNullCheck
	private String sexdstnCode = "";

	/** 직업유형코드 */
	@EgovNullCheck
	private String occpTyCode = "";

	/** 응답자명 */
	@EgovNullCheck
	@Size(max=50)
	private String respondNm = "";

	/** 생년월일 */
	private String brth = "";

	/** 첫번째전화번호 */
	@EgovNullCheck
	@Size(max=4)
	@Pattern(regexp = "^[0-9]*$", message = "{validation.integer.check}")
	private String areaNo = "";

	/** 두번째전화번호 */
	@EgovNullCheck
	@Size(max=4)
	@Pattern(regexp = "^[0-9]*$", message = "{validation.integer.check}")
	private String middleTelno = "";

	/** 마지막전화번호 */
	@EgovNullCheck
	@Size(max=4)
	@Pattern(regexp = "^[0-9]*$", message = "{validation.integer.check}")
	private String endTelno = "";

	/** 최초등록시점 */
	private String frstRegisterPnttm = "";

	/** 최초등록자ID */
	private String frstRegisterId = "";

	/** 최종수정시점 */
	private String lastUpdusrPnttm = "";

	/** 최종수정ID */
	private String lastUpdusrId = "";

	/** 설문템플릿ID */
	private String qestnrTmplatId = "";

	/**
     * toString 메소드를 대치한다.
     */
    public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }

}
