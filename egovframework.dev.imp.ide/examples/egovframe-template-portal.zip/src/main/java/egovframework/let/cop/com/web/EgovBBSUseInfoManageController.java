package egovframework.let.cop.com.web;

import java.util.Map;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;

import egovframework.com.cmm.util.EgovOwnerAuthUtil;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.RequireAdmin;
import egovframework.let.cop.com.service.BoardUseInf;
import egovframework.let.cop.com.service.BoardUseInfVO;
import egovframework.let.cop.com.service.EgovBBSUseInfoManageService;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

/**
 * 게시판의 이용정보를 관리하기 위한 컨트롤러 클래스
 * @author 공통서비스개발팀 이삼섭
 * @since 2009.04.02
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.04.02  이삼섭          최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *
 * </pre>
 */
@Controller
public class EgovBBSUseInfoManageController {

	@Resource(name = "EgovBBSUseInfoManageService")
	private EgovBBSUseInfoManageService bbsUseService;

	@Resource(name = "propertiesService")
	protected EgovPropertyService propertyService;

	/**
	 * 게시판 사용 정보를 삭제한다.
	 *
	 * @param bdUseVO
	 * @param bdUseInf
	 * @param sessionVO
	 * @param status
	 * @param model
	 * @return
	 */
	@RequireAdmin
	@RequestMapping(value = "/cop/com/deleteBBSUseInf.do", method = RequestMethod.POST)
	public String deleteBBSUseInf(@ModelAttribute("searchVO") BoardUseInfVO bdUseVO, @ModelAttribute("bdUseInf") BoardUseInf bdUseInf, SessionStatus status, ModelMap model) {

		// 등록자 본인만 삭제 가능
		assertBBSUseInfOwner(bdUseVO);

		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		if (isAuthenticated) {
			bbsUseService.deleteBBSUseInf(bdUseInf);
		}

		return "forward:/cop/com/selectBBSUseInfs.do";
	}

	/**
	 * 게사판 사용정보 등록을 위한 등록페이지로 이동한다.
	 *
	 * @param bdUseVO
	 * @param sessionVO
	 * @param model
	 * @return
	 */
	@RequireAdmin
	@RequestMapping("/cop/com/addBBSUseInf.do")
	public String addBBSUseInf(@ModelAttribute("searchVO") BoardUseInfVO bdUseVO, ModelMap model) {
		return "cop/com/EgovBoardUseInfRegist";
	}

	/**
	 * 게시판 사용정보를 등록한다.
	 *
	 * @param bdUseVO
	 * @param bdUseInf
	 * @param sessionVO
	 * @param status
	 * @param model
	 * @return
	 */
	@RequireAdmin
	@RequestMapping(value = "/cop/com/insertBBSUseInf.do", method = RequestMethod.POST)
	public String insertBBSUseInf(@ModelAttribute("searchVO") BoardUseInfVO bdUseVO, @Valid @ModelAttribute("boardUseInf") BoardUseInf boardUseInf, BindingResult bindingResult,
			@RequestParam Map<String, Object> commandMap, ModelMap model) {

		if (bindingResult.hasErrors()) {
			return "cop/com/EgovBoardUseInfRegist";
		}

		// 인증 서비스 확인
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		LoginVO user = null;

		if (isAuthenticated) {
			user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		}

		if (!isAuthenticated || user == null) {
			model.addAttribute("message", "로그인이 필요합니다.");
			return "uat/uia/EgovLoginUsr";
		}

		String trgetType = (String) commandMap.get("param_trgetType");
		String registSeCode = "";

		// CMMNTY 06/CLUB 05/SYSTEM(REGC01)
		if ("CMMNTY".equals(trgetType)) {
			registSeCode = "REGC06";
		} else if ("CLUB".equals(trgetType)) {
			registSeCode = "REGC05";
		} else {
			registSeCode = "REGC01";
		}

		boardUseInf.setUseAt("Y");
		boardUseInf.setFrstRegisterId(user.getUniqId());
		boardUseInf.setRegistSeCode(registSeCode);

		bbsUseService.insertBBSUseInf(boardUseInf);

		return "forward:/cop/com/selectBBSUseInfs.do";
	}

	/**
	 * 게시판 사용정보 목록을 조회한다.
	 *
	 * @param bdUseVO
	 * @param sessionVO
	 * @param model
	 * @return
	 */
	@RequireAdmin
	@RequestMapping("/cop/com/selectBBSUseInfs.do")
	public String selectBBSUseInfs(@ModelAttribute("searchVO") BoardUseInfVO bdUseVO, ModelMap model) {

		bdUseVO.setPageUnit(propertyService.getInt("pageUnit"));
		bdUseVO.setPageSize(propertyService.getInt("pageSize"));

		PaginationInfo paginationInfo = new PaginationInfo();

		paginationInfo.setCurrentPageNo(bdUseVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(bdUseVO.getPageUnit());
		paginationInfo.setPageSize(bdUseVO.getPageSize());

		bdUseVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		bdUseVO.setLastIndex(paginationInfo.getLastRecordIndex());
		bdUseVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		Map<String, Object> map = bbsUseService.selectBBSUseInfs(bdUseVO);
		int totCnt = Integer.parseInt((String) map.get("resultCnt"));

		paginationInfo.setTotalRecordCount(totCnt);

		model.addAttribute("resultList", map.get("resultList"));
		model.addAttribute("resultCnt", map.get("resultCnt"));
		model.addAttribute("paginationInfo", paginationInfo);

		return "cop/com/EgovBoardUseInfList";
	}

	/**
	 * 게시판 사용정보를 수정한다.
	 *
	 * @param bdUseVO
	 * @param bdUseInf
	 * @param sessionVO
	 * @param status
	 * @param model
	 * @return
	 */
	@RequireAdmin
	@RequestMapping(value = "/cop/com/updateBBSUseInf.do", method = RequestMethod.POST)
	public String updateBBSUseInf(@ModelAttribute("searchVO") BoardUseInfVO bdUseVO, @Valid @ModelAttribute("boardUseInf") BoardUseInf boardUseInf, BindingResult bindingResult, HttpServletRequest request,
			ModelMap model) {

		// 등록자 본인만 수정 가능
		assertBBSUseInfOwner(bdUseVO);

		if (bindingResult.hasErrors()) {
			return "cop/com/EgovBoardUseInfInqire";
		}

		// 인증 서비스 확인
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		if (!isAuthenticated) {
			model.addAttribute("message", "로그인이 필요합니다.");
			return "uat/uia/EgovLoginUsr";
		}

		bbsUseService.updateBBSUseInf(boardUseInf);

		return "forward:/cop/com/selectBBSUseInfs.do";
	}

	/**
	 * 게시판 사용정보에 대한 상세정보를 조회한다.
	 *
	 * @param bdUseVO
	 * @param sessionVO
	 * @param model
	 * @return
	 */
	@RequireAdmin
	@RequestMapping("/cop/com/selectBBSUseInf.do")
	public String selectBBSUseInf(@ModelAttribute("searchVO") BoardUseInfVO bdUseVO, ModelMap model) {
		BoardUseInfVO vo = bbsUseService.selectBBSUseInf(bdUseVO);

		// 시스템 사용 게시판의 경우 URL 표시
		if ("SYSTEM_DEFAULT_BOARD".equals(vo.getTrgetId())) {
			if (vo.getBbsTyCode().equals("BBST02")) { // 익명게시판
				vo.setProvdUrl("/cop/bbs/anonymous/selectBoardList.do?bbsId=" + vo.getBbsId());
			} else {
				vo.setProvdUrl("/cop/bbs/selectBoardList.do?bbsId=" + vo.getBbsId());
			}
		}

		model.addAttribute("bdUseVO", vo);
		// 저장 버튼은 등록자 본인에게만 노출
		model.addAttribute("ownerAt", EgovOwnerAuthUtil.ownerAt(vo.getFrstRegisterId()));
		return "cop/com/EgovBoardUseInfInqire";
	}

	/**
	 * 커뮤니티, 동호회에 사용되는 게시판 사용정보에 대한 목록을 조회한다.
	 *
	 * @param bdUseVO
	 * @param model
	 * @return
	 */
	@RequireAdmin
	@RequestMapping("/cop/com/selectBBSUseInfsByTrget.do")
	public String selectBBSUseInfsByTrget(@ModelAttribute("searchVO") BoardUseInfVO bdUseVO, ModelMap model) {

		bdUseVO.setPageUnit(propertyService.getInt("pageUnit"));
		bdUseVO.setPageSize(propertyService.getInt("pageSize"));

		PaginationInfo paginationInfo = new PaginationInfo();

		paginationInfo.setCurrentPageNo(bdUseVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(bdUseVO.getPageUnit());
		paginationInfo.setPageSize(bdUseVO.getPageSize());

		bdUseVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		bdUseVO.setLastIndex(paginationInfo.getLastRecordIndex());
		bdUseVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		Map<String, Object> map = bbsUseService.selectBBSUseInfsByTrget(bdUseVO);
		int totCnt = Integer.parseInt((String) map.get("resultCnt"));

		paginationInfo.setTotalRecordCount(totCnt);

		model.addAttribute("resultList", map.get("resultList"));
		model.addAttribute("resultCnt", map.get("resultCnt"));
		model.addAttribute("trgetId", bdUseVO.getTrgetId());
		model.addAttribute("trgetType", bdUseVO.getTrgetType());
		model.addAttribute("paginationInfo", paginationInfo);

		return "cop/com/EgovBdUseInfListByTrget";
	}

	/**
	 * 커뮤니티, 동호회에 사용되는 게시판 사용정보를 수정한다.
	 *
	 * @param bdUseVO
	 * @param boardUseInf
	 * @param status
	 * @param model
	 * @return
	 */
	@RequireAdmin
	@RequestMapping(value = "/cop/com/updateBBSUseInfByTrget.do", method = RequestMethod.POST)
	public String updateBBSUseInfByTrget(@ModelAttribute("searchVO") BoardUseInfVO bdUseVO, @ModelAttribute("boardUseInf") BoardUseInf boardUseInf,
			@RequestParam Map<String, Object> commandMap, SessionStatus status, ModelMap model) {

		String param_trgetId = (String) commandMap.get("param_trgetId");

		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		if (isAuthenticated) {
			boardUseInf.setTrgetId(param_trgetId);
			bbsUseService.updateBBSUseInfByTrget(boardUseInf);
		}

		return "forward:/cop/com/selectBBSUseInfsByTrget.do";
	}

	/**
	 * 커뮤니티, 동호회에 사용되는 게시판 사용정보를 등록한다.
	 *
	 * @param bdUseVO
	 * @param boardUseInf
	 * @param status
	 * @param model
	 * @return
	 */
	@RequireAdmin
	@RequestMapping(value = "/cop/com/insertBBSUseInfByTrget.do", method = RequestMethod.POST)
	public String insertBBSUseInfByTrget(@ModelAttribute("searchVO") BoardUseInfVO bdUseVO, @ModelAttribute("boardUseInf") BoardUseInf boardUseInf,
			@RequestParam Map<String, Object> commandMap, SessionStatus status, ModelMap model) {

		String paramTrgetId = (String) commandMap.get("param_trgetId");
		String bbsId = (String) commandMap.get("bbsId");

		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();

		if (isAuthenticated) {
			boardUseInf.setUseAt("Y");
			boardUseInf.setFrstRegisterId(user.getUniqId());
			boardUseInf.setRegistSeCode("REGC07");
			boardUseInf.setBbsId(bbsId);
			boardUseInf.setTrgetId(paramTrgetId);

			bbsUseService.insertBBSUseInf(boardUseInf);
		}

		return "forward:/cop/com/selectBBSUseInfsByTrget.do";
	}

	/**
	 * 게시판 사용정보의 등록자 본인 여부를 검증한다.
	 *
	 * @param bdUseVO
	 */
	private void assertBBSUseInfOwner(BoardUseInfVO bdUseVO) {
		BoardUseInfVO existing = bbsUseService.selectBBSUseInf(bdUseVO);
		EgovOwnerAuthUtil.assertOwner(existing == null ? null : existing.getFrstRegisterId());
	}
}
