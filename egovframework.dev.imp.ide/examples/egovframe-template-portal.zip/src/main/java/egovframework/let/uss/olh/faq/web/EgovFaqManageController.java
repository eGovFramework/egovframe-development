package egovframework.let.uss.olh.faq.web;

import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.fdl.security.userdetails.util.EgovUserDetailsHelper;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.RequireAdmin;
import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.EgovFileMngUtil;
import egovframework.com.cmm.service.FileVO;
import egovframework.let.uss.olh.faq.service.EgovFaqManageService;
import egovframework.let.uss.olh.faq.service.FaqManageDefaultVO;
import egovframework.let.uss.olh.faq.service.FaqManageVO;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
/**
 *
 * FAQ내용을 처리하는 비즈니스 구현 클래스
 * @author 공통서비스 개발팀 박정규
 * @since 2009.04.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.04.01  박정규          최초 생성
 *   2011.08.31  JJY            경량환경 템플릿 커스터마이징버전 생성
 *   2026.08.18  유지보수        FAQ 등록/수정/삭제를 관리자 전용으로 정리(@RequireAdmin)
 *
 * </pre>
 */
@Controller
public class EgovFaqManageController {

    @Resource(name = "FaqManageService")
    private EgovFaqManageService faqManageService;

    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

	// 첨부파일 관련
	@Resource(name="EgovFileMngService")
	private EgovFileMngService fileMngService;

	@Resource(name="EgovFileMngUtil")
	private EgovFileMngUtil fileUtil;

	/** EgovMessageSource */
    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;

    /**
     * 개별 배포시 메인메뉴를 조회한다.
     * @param model
     * @return	"/uss/olh/faq/"
     */
    @RequestMapping(value="/uss/olh/faq/EgovMain.do")
    public String EgovMain(ModelMap model) {
    	model.addAttribute("mainContents", "mainContentsSampleValue");
    	return "/uss/olh/faq/EgovMain";
    }

    /**
     * 메뉴를 조회한다.
     * @param model
     * @return	"/uss/olh/faq/EgovLeft"
     */
    @RequestMapping(value="/uss/olh/faq/EgovLeft.do")
    public String EgovLeft(ModelMap model) {
    	model.addAttribute("leftContents", "leftContentsSampleValue");
    	return "/uss/olh/faq/EgovLeft";
    }

    /**
     * FAQ 목록을 조회한다.
     * @param searchVO
     * @param model
     * @return	"/uss/olh/faq/EgovFaqListInqire"
     */
    @RequestMapping(value="/uss/olh/faq/FaqListInqire.do")
    public String selectFaqList(@ModelAttribute("searchVO") FaqManageDefaultVO searchVO, ModelMap model, HttpServletRequest request) {
    		// 메인화면에서 넘어온 경우 메뉴 갱신을 위해 추가
    		request.getSession().setAttribute("menuNo", "4000000");
    	
    	/** EgovPropertyService.SiteList */
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));

    	/** pageing */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        model.addAttribute("resultList", faqManageService.selectFaqList(searchVO));

        int totCnt = faqManageService.selectFaqListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);

        return "/uss/olh/faq/EgovFaqListInqire";
    }

    /**
     * FAQ 목록에 대한 상세정보를 조회한다.
     * @param faqManageVO
     * @param searchVO
     * @param model
     * @return	"/uss/olh/faq/EgovFaqDetailInqire"
     */
    @RequestMapping("/uss/olh/faq/FaqListDetailInqire.do")
    public String	selectFaqListDetail(FaqManageVO faqManageVO,
            @ModelAttribute("searchVO") FaqManageDefaultVO searchVO,
            ModelMap model, HttpServletRequest request) {

		FaqManageVO vo = faqManageService.selectFaqListDetail(faqManageVO);

		model.addAttribute("result", vo);

		// 첨부파일 목록 조회
		if(vo != null && vo.getAtchFileId() != null && !vo.getAtchFileId().isEmpty()) {
			FileVO fileVO = new FileVO();
			fileVO.setAtchFileId(vo.getAtchFileId());
			List<FileVO> fileList = fileMngService.selectFileInfs(fileVO);
			
			// FileId를 유추하지 못하도록 세션ID와 함께 암호화하여 표시한다.
			String sessionId = request.getSession().getId();
			for (FileVO file : fileList) {
				file.setAtchFileId(egovframework.com.cmm.web.EgovFileMngController.encryptSession(file.getAtchFileId(), sessionId));
			}
			
			model.addAttribute("fileList", fileList);
			model.addAttribute("updateFlag", "N");
			model.addAttribute("fileListCnt", fileList.size());
			model.addAttribute("atchFileId", egovframework.com.cmm.web.EgovFileMngController.encrypt(vo.getAtchFileId()));
		} else {
			model.addAttribute("fileList", new java.util.ArrayList<FileVO>());
			model.addAttribute("updateFlag", "N");
			model.addAttribute("fileListCnt", 0);
		}

        return	"/uss/olh/faq/EgovFaqDetailInqire";
    }

    /**
     * FAQ 조회수를  수정처리
     * @param faqManageVO
     * @param searchVO
     * @return	"forward:/uss/olh/faq/FaqListDetailInqire.do"
     */
    @RequestMapping("/uss/olh/faq/FaqInqireCoUpdt.do")
    public String updateFaqInqireCo(
            FaqManageVO faqManageVO,
            @ModelAttribute("searchVO") FaqManageDefaultVO searchVO) {
    	LoginVO	loginVO;
    	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		loginVO  = new LoginVO();
    		loginVO.setUniqId("_aunonymous");
    	}else{
    		loginVO  = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();
    	}
    	// 로그인VO에서  사용자 정보 가져오기


    	String	lastUpdusrId = loginVO.getUniqId();

    	faqManageVO.setLastUpdusrId(lastUpdusrId);    	// 최종수정자ID

    	faqManageService.updateFaqInqireCo(faqManageVO);

        return "forward:/uss/olh/faq/FaqListDetailInqire.do";

    }

    /**
     * FAQ를 등록하기 위한 전 처리
     * @param searchVO
     * @param model
     * @return	"/uss/olh/faq/EgovFaqCnRegist"
     */
    // FAQ 는 관리자 전용 콘텐츠
    @RequireAdmin
    @RequestMapping("/uss/olh/faq/FaqCnRegistView.do")
    public String insertFaqCnView(
            @ModelAttribute("searchVO") FaqManageDefaultVO searchVO, Model model) {
    	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
        	return "uat/uia/EgovLoginUsr";
    	}
        model.addAttribute("faqManageVO", new FaqManageVO());

        return "/uss/olh/faq/EgovFaqCnRegist";

    }

    /**
     * FAQ를 등록한다.
     * @param multiRequest
     * @param searchVO
     * @param faqManageVO
     * @param bindingResult
     * @return	"forward:/uss/olh/faq/FaqListInqire.do"
     */
    // 관리자 전용
    @RequireAdmin
    @RequestMapping("/uss/olh/faq/FaqCnRegist.do")
    public String insertFaqCn(
    		final MultipartHttpServletRequest multiRequest,		// 첨부파일을 위한...
            @ModelAttribute("searchVO") FaqManageDefaultVO searchVO,
            @Valid @ModelAttribute("faqManageVO") FaqManageVO faqManageVO,
            BindingResult bindingResult) {

		if(bindingResult.hasErrors()){
			return "/uss/olh/faq/EgovFaqCnRegist";
		}

    	// 첨부파일 관련 첨부파일ID 생성
		List<FileVO> _result = null;
		String _atchFileId = "";

		final Map<String, MultipartFile> files = multiRequest.getFileMap();

        if (!files.isEmpty()) {
            // 실제로 파일이 선택되었는지 확인
            boolean hasFile = false;
            for (Map.Entry<String, MultipartFile> entry : files.entrySet()) {
                MultipartFile file = entry.getValue();
                if (file != null && !file.isEmpty() && file.getOriginalFilename() != null
                        && !file.getOriginalFilename().isEmpty()) {
                    hasFile = true;
                    break;
                }
            }

            if (hasFile) {
                _result = fileUtil.parseFileInf(files, "FAQ_", 0, "", "");
                if (_result != null && !_result.isEmpty()) {
                    _atchFileId = fileMngService.insertFileInfs(_result); // 파일이 생성되고나면 생성된 첨부파일 ID를 리턴한다.
                }
            }
        }

        // 리턴받은 첨부파일ID를 셋팅한다.. (첨부 없으면 NULL : '' 는 LETTNFILE FK 위반)
        faqManageVO.setAtchFileId(_atchFileId.isEmpty() ? null : _atchFileId); // 첨부파일 ID

        // 로그인VO에서 사용자 정보 가져오기
        LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        String frstRegisterId = loginVO.getUniqId();

    	faqManageVO.setFrstRegisterId(frstRegisterId);		// 최초등록자ID
    	faqManageVO.setLastUpdusrId(frstRegisterId);    	// 최종수정자ID

        faqManageService.insertFaqCn(faqManageVO);


        return "forward:/uss/olh/faq/FaqListInqire.do";
    }

    /**
     * FAQ를 수정하기 위한 전 처리
     * @param faqId
     * @param searchVO
     * @param model
     * @return	"/uss/olh/faq/EgovFaqCnUpdt"
     */
    // 관리자 전용
    @RequireAdmin
    @RequestMapping("/uss/olh/faq/FaqCnUpdtView.do")
    public String updateFaqCnView(@RequestParam("faqId") String faqId ,
            @ModelAttribute("searchVO") FaqManageDefaultVO searchVO, ModelMap model, HttpServletRequest request) {
    	
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "uat/uia/EgovLoginUsr";
		}

        FaqManageVO faqManageVO = new FaqManageVO();

        // Primary Key 값 세팅
        faqManageVO.setFaqId(faqId);

        // 변수명은 CoC 에 따라
        model.addAttribute(selectFaqListDetail(faqManageVO, searchVO, model, request));

        // 변수명은 CoC 에 따라 JSTL사용을 위해
        model.addAttribute("faqManageVO", faqManageService.selectFaqListDetail(faqManageVO));

        return "/uss/olh/faq/EgovFaqCnUpdt";
    }

    /**
     * FAQ를 수정처리한다.
     * @param atchFileAt
     * @param multiRequest
     * @param searchVO
     * @param faqManageVO
     * @param bindingResult
     * @param model
     * @return	"forward:/uss/olh/faq/FaqListInqire.do"
     */
    // 관리자 전용
    @RequireAdmin
    @RequestMapping("/uss/olh/faq/FaqCnUpdt.do")
    public String updateFaqCn(@RequestParam("atchFileAt") String atchFileAt ,
    		final MultipartHttpServletRequest multiRequest,
            @ModelAttribute("searchVO") FaqManageDefaultVO searchVO,
            @Valid @ModelAttribute("faqManageVO") FaqManageVO faqManageVO,
            BindingResult bindingResult,
            ModelMap model) {

		if(bindingResult.hasErrors()){
			return "/uss/olh/faq/EgovFaqCnUpdt";
		}

    	// 첨부파일 관련 ID 생성 start....
		String _atchFileId = faqManageVO.getAtchFileId();

		final Map<String, MultipartFile> files = multiRequest.getFileMap();

		if(!files.isEmpty()){
			// 실제로 파일이 선택되었는지 확인
			boolean hasFile = false;
			for(MultipartFile file : files.values()) {
				if(file != null && !file.isEmpty() && file.getOriginalFilename() != null && !file.getOriginalFilename().isEmpty()) {
					hasFile = true;
					break;
				}
			}
			
			if(hasFile) {
				if("N".equals(atchFileAt)){
					List<FileVO> _result = fileUtil.parseFileInf(files, "FAQ_", 0, _atchFileId, "");
					if(_result != null && !_result.isEmpty()) {
						_atchFileId = fileMngService.insertFileInfs(_result);
						// 첨부파일 ID 셋팅
						faqManageVO.setAtchFileId(_atchFileId);    	// 첨부파일 ID
					}
				}else{
					FileVO fvo = new FileVO();
					fvo.setAtchFileId(_atchFileId);
					int _cnt = fileMngService.getMaxFileSN(fvo);
					List<FileVO> _result = fileUtil.parseFileInf(files, "FAQ_", _cnt, _atchFileId, "");
					if(_result != null && !_result.isEmpty()) {
						fileMngService.updateFileInfs(_result);
					}
				}
			}
		}
		// 첨부파일 관련 ID 생성 end...

		// 첨부 없으면 NULL : 폼의 빈 atchFileId('')는 LETTNFILE FK 위반
		if (faqManageVO.getAtchFileId() != null && faqManageVO.getAtchFileId().isEmpty()) {
			faqManageVO.setAtchFileId(null);
		}


    	// 로그인VO에서  사용자 정보 가져오기
    	LoginVO	loginVO = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();

    	String	lastUpdusrId = loginVO.getUniqId();

    	faqManageVO.setLastUpdusrId(lastUpdusrId);    	// 최종수정자ID

    	faqManageService.updateFaqCn(faqManageVO);

        return "forward:/uss/olh/faq/FaqListInqire.do";

    }

    /**
     * FAQ를 삭제처리한다.
     * @param faqManageVO
     * @param searchVO
     * @return	"forward:/uss/olh/faq/FaqListInqire.do"
     */
    // 관리자 전용
    @RequireAdmin
    @RequestMapping("/uss/olh/faq/FaqCnDelete.do")
    public String deleteFaqCn(
            FaqManageVO faqManageVO,
            @ModelAttribute("searchVO") FaqManageDefaultVO searchVO) {


    	// 첨부파일 삭제를 위한 ID 생성 start....
		String _atchFileId = faqManageVO.getAtchFileId();

    	faqManageService.deleteFaqCn(faqManageVO);

    	// 첨부파일을 삭제하기 위한  Vo
    	FileVO fvo = new FileVO();
    	fvo.setAtchFileId(_atchFileId);

    	fileMngService.deleteAllFileInf(fvo);
    	// 첨부파일 삭제 End.............

        return "forward:/uss/olh/faq/FaqListInqire.do";
    }

}
