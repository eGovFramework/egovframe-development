<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%--
  게시판 목록 화면

  @Modification Information
   수정일      수정자    수정내용
   ----------  --------  ----------------------------------------
   2009.02.01            최초 생성
   2026.10.29  유지보수  KRDS 디자인 적용
   2026.10.29  유지보수  목록 조회(검색·페이지 이동) POST 전송, 검색조건 문자열 비교
   2026.10.29  유지보수  boot-sample 현행화 (페이징 단위 선택, 검색 결과 건수, 스크립트 함수명 통일)
   2026.10.29  유지보수  목록을 KRDS 구조화 목록(PC 표형, 모바일 기본형)으로 변경, 페이지당 표시 건수·검색 결과 건수 다국어 처리

  @author 실행환경 개발팀
  @since 2009.02.01

  Copyright (C) 2009 by MOPAS All right reserved.
--%>
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><spring:message code="title.sample" /></title>

	<%-- KRDS 스타일 --%>
	<link rel="stylesheet" type="text/css" href="<c:url value='/css/component/output.css'/>" />
	<link rel="stylesheet" type="text/css" href="<c:url value='/css/egovframe.css'/>" />
	<script type="text/javascript" src="<c:url value='/js/jquery.min.js'/>"></script>
	<script type="text/javascript" src="<c:url value='/js/egovframework/common.js'/>" defer></script>
	<script type="text/javascript" defer>
		function sampleSearch() {
			if (notNullCheck($('#searchKeyword').val())) {
				$('#pageIndex').val(1);
				$('#listForm').attr('method', 'post').attr('action', "<c:url value='/egovSampleList.do'/>").submit();
			} else {
				alert("<spring:message code='search.error' javaScriptEscape='true'/>");
			}
		}

		function samplePagination(pageIndex) {
			$('#pageIndex').val(pageIndex);
			$('#listForm').attr('method', 'post').attr('action', "<c:url value='/egovSampleList.do'/>").submit();
		}

		function sampleCreate() {
			$('#id').val(null);
			$('#listForm').attr('method', 'post').attr('action', "<c:url value='/addSampleView.do'/>").submit();
		}

		function sampleDetail(id) {
			$('#id').val(id);
			$('#listForm').attr('method', 'post').attr('action', "<c:url value='/updateSampleView.do'/>").submit();
		}
	</script>
</head>

<body>
<div id="container" class="inner">

	<%-- 타이틀 --%>
	<h2 class="heading-large"><spring:message code="list.sample" /></h2>
	
	<div id="content_pop">
		<form:form modelAttribute="sampleVO" id="listForm" name="listForm" method="post">
			<input type="hidden" id="id" name="id" />
			<input type="hidden" id="pageIndex" name="pageIndex" value="${sampleVO.pageIndex}" />
			<form:hidden path="pageSize" />
	
			<%-- 검색 --%>
			<div class="form-group">
				<div class="search-wrap">
					<div class="search-body">
						<div class="form-conts searchOption">
							<select id="searchCondition" name="searchCondition" class="krds-form-select medium" title="<spring:message code='search.choose'/>">
								<option value="1" <c:if test ="${not empty sampleVO.searchCondition and sampleVO.searchCondition eq '1'}">selected="selected"</c:if>>Name</option>
								<option value="0" <c:if test ="${not empty sampleVO.searchCondition and sampleVO.searchCondition eq '0'}">selected="selected"</c:if>>ID</option>
							</select>
						</div>
						<div class="form-conts btn-ico-wrap searchKeyword">
							<input type="text" id="searchKeyword" name="searchKeyword" value="${sampleVO.searchKeyword}" maxlength="100" class="krds-input medium" placeholder="<spring:message code='search.keyword'/>">
							<button type="button" class="krds-btn medium icon" onclick="sampleSearch()">
								<span class="sr-only"><spring:message code="button.search" /></span>
								<i class="svg-icon ico-sch"></i>
							</button>
						</div>
					</div>
					<div class="page-btn-wrap">
						<label for="pageUnit" class="sr-only"><spring:message code="page.unit.label" /></label>
						<form:select path="pageUnit" cssClass="krds-form-select medium page-unit-select" onchange="samplePagination(1)">
							<c:set var="pageUnits" value="5,10,20,50,100" />
							<c:set var="currentPageUnit" value=",${sampleVO.pageUnit}," />
							<c:if test="${not fn:contains(',5,10,20,50,100,', currentPageUnit)}">
								<form:option value="${sampleVO.pageUnit}"><spring:message code="page.unit.option" arguments="${sampleVO.pageUnit}" /></form:option>
							</c:if>
							<c:forEach var="unit" items="${pageUnits}">
								<form:option value="${unit}"><spring:message code="page.unit.option" arguments="${unit}" /></form:option>
							</c:forEach>
						</form:select>
						<button type="button" class="krds-btn medium" onclick="sampleCreate()"><spring:message code="button.create" /></button>
					</div>
				</div>
			</div>
		</form:form>
	
		<%-- 목록 --%>
		<p class="search-result-count" role="status">
			<spring:message code="search.result.count" arguments="${paginationInfo.totalRecordCount}" htmlEscape="false" />
		</p>
		<c:choose>
			<c:when test="${not empty resultList}">
				<%-- KRDS 구조화 목록(표형) : PC 화면 --%>
				<div class="krds-structured-list-table sample-list-table">
					<div class="krds-table-wrap">
						<table class="tbl col data">
							<caption><spring:message code="title.sample.caption" /></caption>
							<colgroup>
								<col style="width: 8%;">
								<col style="width: 16%;">
								<col style="width: 22%;">
								<col>
								<col style="width: 10%;">
								<col style="width: 12%;">
							</colgroup>
							<thead>
								<tr>
									<th scope="col">No</th>
									<th scope="col"><spring:message code="title.sample.id" /></th>
									<th scope="col"><spring:message code="title.sample.name" /></th>
									<th scope="col"><spring:message code="title.sample.description" /></th>
									<th scope="col"><spring:message code="title.sample.useYn" /></th>
									<th scope="col"><spring:message code="title.sample.regUser" /></th>
								</tr>
							</thead>
							<tbody>
								<c:forEach var="result" items="${resultList}" varStatus="status">
									<tr>
										<td class="list-no"><c:out value="${paginationInfo.totalRecordCount+1 - ((sampleVO.pageIndex-1) * paginationInfo.recordCountPerPage + status.count)}"/></td>
										<td><c:out value="${result.id}"/></td>
										<td class="text-left"><a href="#" onclick="sampleDetail('<c:out value="${result.id}"/>'); return false;"><c:out value="${result.name}"/></a></td>
										<td class="text-left"><c:out value="${result.description}"/></td>
										<td>
											<c:choose>
												<c:when test="${result.useYn == 'Y'}"><spring:message code="input.yes" /></c:when>
												<c:when test="${result.useYn == 'N'}"><spring:message code="input.no" /></c:when>
												<c:otherwise>-</c:otherwise>
											</c:choose>
										</td>
										<td><c:out value="${result.regUser}"/></td>
									</tr>
								</c:forEach>
							</tbody>
						</table>
					</div>
				</div>
				<%-- KRDS 구조화 목록(기본) : 모바일 화면 --%>
				<ul class="krds-structured-list type-full sample-list">
					<c:forEach var="result" items="${resultList}" varStatus="status">
						<li class="structured-item">
							<div class="in">
								<div class="card-top">
									<span class="list-no"><span class="sr-only">No</span><c:out value="${paginationInfo.totalRecordCount+1 - ((sampleVO.pageIndex-1) * paginationInfo.recordCountPerPage + status.count)}"/></span>
								</div>
								<div class="card-body">
									<a href="#" class="c-text" onclick="sampleDetail('<c:out value="${result.id}"/>'); return false;">
										<p class="c-date">
											<strong class="key"><spring:message code="title.sample.id" /></strong>
											<span class="value"><c:out value="${result.id}"/></span>
										</p>
										<p class="c-tit"><span class="span"><c:out value="${result.name}"/></span></p>
										<p class="c-txt"><c:out value="${result.description}"/></p>
										<p class="c-date">
											<strong class="key"><spring:message code="title.sample.useYn" /></strong>
											<span class="value">
												<c:choose>
													<c:when test="${result.useYn == 'Y'}"><spring:message code="input.yes" /></c:when>
													<c:when test="${result.useYn == 'N'}"><spring:message code="input.no" /></c:when>
													<c:otherwise>-</c:otherwise>
												</c:choose>
											</span>
										</p>
										<p class="c-date">
											<strong class="key"><spring:message code="title.sample.regUser" /></strong>
											<span class="value"><c:out value="${result.regUser}"/></span>
										</p>
									</a>
								</div>
							</div>
						</li>
					</c:forEach>
				</ul>
			</c:when>
			<c:otherwise>
				<p class="sample-list-empty"><spring:message code="info.nodata.msg" /></p>
			</c:otherwise>
		</c:choose>

		<%-- 페이지네이션 --%>
		<div id="paging" class="krds-pagination w-page">
			<ui:pagination paginationInfo="${paginationInfo}" type="krds" jsFunction="samplePagination" />
		</div>

	</div>

</div>

</body>
</html>
