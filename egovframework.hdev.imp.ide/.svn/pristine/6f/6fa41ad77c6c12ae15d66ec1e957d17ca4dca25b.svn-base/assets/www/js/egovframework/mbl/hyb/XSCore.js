/**
 * @mainpage [XecureSmart] eGovFrame javascript Interface
 * @section intro 소개
 * - 소개 : 폰갭 인터페이스를 이용하여 모바일에서 NPKI 서비스 제공
 * @section CREATEINFO 작성정보
 * - 작성자 : sukbum@softforum.com
 * - 작성일 : 2012.08.01
 *
 * @file XSCore.js
 */
//*class XecureSmartPlugin{

//*var xgateAddress; ///<xgate 서버 주소
//*var keySharpIP; ///<키샵에서 사용할 IP
//*var keySharpPort; ///<키샵에서 사용하는 port
function XecureSmartPlugin ()
{
	this.pluginName = "XSPGPlugin";
	this.xgateAddress = window.location.hostname + ":10443:19999";
	this.keySharpIP = "211.32.131.182";
	this.keySharpPort = "9500";
}

/**
 * @brief 키샾에서 인증번호를 가져온다.
 * @param successCB 성공 시 콜백함수
 * @param failCB 실패 시 콜백함수
 * @param ssn 가져올 인증서의 주민등록번호/사업자등록번호
 */
//*void keySharpGetConfirmNumber (successCB, failCB, ssn);
XecureSmartPlugin.prototype.keySharpGetConfirmNumber = function (successCB, failCB, ssn)
{
	var args = Array.prototype.slice.call (arguments);
	args = args.slice (2);

	args = [this.keySharpIP, this.keySharpPort].concat (args);

	return Cordova.exec (successCB, failCB, this.pluginName, "keySharpGetConfirmNumber", args);
}

/**
 * @brief 키샾에서 받아온 인증서를 저장한다.
 * @param successCB 성공 시 콜백함수
 * @param failCB 실패 시 콜백함수
 */
//*void keySharpSaveCert (successCB, failCB);
XecureSmartPlugin.prototype.keySharpSaveCert = function (successCB, failCB)
{
	var args = Array.prototype.slice.call (arguments);
	args = args.slice (2);

	return Cordova.exec (successCB, failCB, this.pluginName, "keySharpSaveCert", args);
}

/**
 * @brief 장치의 인증서 목록을 가져온다.<br>searchType과 searchValue를 함께 사용하여 검색이 가능하며, searchSerial를 이용해 일련 번호로 검색도 가능하다.
 * @param successCB 성공 시 콜백함수
 * @param failCB 실패 시 콜백함수
 * @param certType 타입<br>0 : 루트인증서<br>1 : CA인증서<br>2 : 사용자인증서<br>3 : 전체인증서
 * @param searchType 검색조건<br>0 : 검색 하지 않음<br>10 : subjectDN의 CN과 일치<br>11 : subjectDN의 OU와 일치<br>12 : subjectDN의 O와 일치<br>13 : subjectDN의 C와 일치<br>14 : subjectDN과 일치<br>20 : issuerDN의 CN과 일치<br>21 : issuerDN의 OU와 일치<br>22 : issuerDN의 O와 일치<br>23 : issuerDN의 C와 일치<br>24 : issuerDN과 일치
 * @param contentLevel 결과값의 레벨<br>0 : 자세한 정보<br>5 : 간략한 정보
 * @param searchValue 검색값
 * @param searchSerial 검색할 일련 번호
 * @return successCB에 결과값으로 반환되며, contentLevel에 따라 다음과 같은 형식을 가진다.<br>0 : 자세한 정보<br><b>상태$버전$일련 번호$서명 알고리즘$발급자$발급일$만료일$주체$공개키 알고리즘$공개키$서명$CA키 고유번호$정책$기본 제약$주체 대체 이름$CRL 분배점$사용자 알림$CPS$기관정보 액세스/t/n...</b><br>5 : 간략한 정보<br><b>상태$용도$주체$발급자$만료일$일련 번호/t/n...</b>
 */
//*void getCertTree (successCB, failCB, certType, searchType, contentLevel, searchValue, searchSerial);
XecureSmartPlugin.prototype.getCertTree = function (successCB, failCB, certType, searchType, contentLevel, searchValue, searchSerial)
{
	var args = Array.prototype.slice.call (arguments);
	args = args.slice (2);

	return Cordova.exec (successCB, failCB, this.pluginName, "getCertTree", args);
}

/**
 * @brief 전자서명한다.<br>issuerDN과 serial의 조합으로 unique한 인증서를 검색하자.
 * @param successCB 성공 시 콜백함수
 * @param failCB 실패 시 콜백함수
 * @param issuerDN 서명에 사용할 인증서의 발급자
 * @param certSerial 서명에 사용할 인증서의 일련 번호
 * @param password 서명에 사용할 인증서의 암호
 * @param password 서명할 원문
 */
//*void signDataCMS (successCB, failCB, issuerDN, certSerial, password, plainText);
XecureSmartPlugin.prototype.signDataCMS = function (successCB, failCB, issuerDN, certSerial, password, plainText)
{
	var args = Array.prototype.slice.call (arguments);
	args = args.slice (2);

	args = [this.xgateAddress].concat (args);

	return Cordova.exec (successCB, failCB, this.pluginName, "signDataCMS", args);
}
//*}

