package egovframework.hyb.mbl.stm.service;

import egovframework.com.cmm.vo.DefaultSearchVO;

/**  
 * @Class Name : StreamingMediaAPIDefaultVO.java
 * @Description : StreamingMediaAPIDefaultVO Class
 * @Modification Information  
 * @
 * @  수정일            수정자        수정내용
 * @ ---------        ---------    -------------------------------
 * @ 2017. 7. 14.     장성호        최초생성
 * 
 * @author 디바이스 API 실행환경 팀
 * @since 2016. 7. 14.
 * @version 1.0
 * @see
 * 
 */
public class StreamingMediaAPIDefaultVO extends DefaultSearchVO {

    /** serialVersionUID */
    private static final long serialVersionUID = 1L;

}
