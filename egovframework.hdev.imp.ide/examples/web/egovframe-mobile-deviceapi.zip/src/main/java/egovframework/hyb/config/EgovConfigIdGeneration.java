package egovframework.hyb.config;

import javax.sql.DataSource;

import org.egovframe.rte.fdl.idgnr.impl.EgovTableIdGnrServiceImpl;
import org.egovframe.rte.fdl.idgnr.impl.strategy.EgovIdGnrStrategyImpl;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * ID 생성 설정. 업로드 파일 일련번호(COMTECOPSEQ.FILE)
 */
@Configuration
public class EgovConfigIdGeneration {

	@Bean
	EgovIdGnrStrategyImpl filePrefix() {
		EgovIdGnrStrategyImpl egovIdGnrStrategyImpl = new EgovIdGnrStrategyImpl();
		egovIdGnrStrategyImpl.setCipers(10);
		return egovIdGnrStrategyImpl;
	}

	@Bean(name = "egovFileIdGnrService", destroyMethod = "destroy")
	EgovTableIdGnrServiceImpl egovFileIdGnrService(@Qualifier("dataSource") DataSource dataSource) {
		EgovTableIdGnrServiceImpl egovTableIdGnrServiceImpl = new EgovTableIdGnrServiceImpl();
		egovTableIdGnrServiceImpl.setDataSource(dataSource);
		egovTableIdGnrServiceImpl.setStrategy(filePrefix());
		egovTableIdGnrServiceImpl.setBlockSize(10);
		egovTableIdGnrServiceImpl.setTable("COMTECOPSEQ");
		egovTableIdGnrServiceImpl.setTableName("FILE");
		return egovTableIdGnrServiceImpl;
	}

}
