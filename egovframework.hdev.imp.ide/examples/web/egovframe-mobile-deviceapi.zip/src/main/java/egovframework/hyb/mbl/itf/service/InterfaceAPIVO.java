/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.hyb.mbl.itf.service;

import java.io.Serializable;

import egovframework.hyb.validation.EgovNotNull;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

/**
 * 통합 Interface API VO Class (Android/iOS 공통)
 *
 * 수정이력
 * 2025.10.28 통합개발팀 Android/iOS 패키지 통합
 */
@Getter
@Setter
@Schema(description = "인터페이스 API VO")
public class InterfaceAPIVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 일련번호 */
    private int sn;

    /** 기기식별코드 */
    @Size(max = 36, message = "{interface.uuid.maxlength}")
    private String uuid;

    /** 아이디 */
    @EgovNotNull(message = "{interface.userId.required}")
    @Size(max = 20, message = "{interface.userId.maxlength}")
    private String userId;

    /** 요청은 평문 비밀번호. 저장값은 서버가 만든 BCrypt 해시 */
    @EgovNotNull(message = "{interface.userPw.required}")
    @Size(min = 1, max = 200, message = "{interface.userPw.invalid}")
    private String userPw;

    /** E-mail */
    @Email(message = "{interface.emails.invalid}")
    @Size(max = 100, message = "{interface.emails.maxlength}")
    private String emails;

    /** resultState */
    private String resultState;

    /** resultMessage */
    private String resultMessage;
}
