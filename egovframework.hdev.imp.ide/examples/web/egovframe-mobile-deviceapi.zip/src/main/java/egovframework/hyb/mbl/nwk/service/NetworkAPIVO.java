/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.hyb.mbl.nwk.service;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

/**
 * 통합 Network API VO
 *
 * 수정이력
 * 2025.10.28 통합개발팀 Android/iOS 패키지 통합
 */
@Getter
@Setter
@Schema(description = "네트워크 API VO")
public class NetworkAPIVO extends NetworkAPIDefaultVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 일련번호 */
    @Schema(description = "일련번호")
    private int sn;
    
    /** 기기식별 */
    @Schema(description = "기기식별코드")
    private String uuid;
    
    /** 네트워크 유형 */
    @Schema(description = "네트워크 유형")
    private String networktype;
    
    /** 사용여부 */
    @Schema(description = "사용여부")
    private String useYn;
}

