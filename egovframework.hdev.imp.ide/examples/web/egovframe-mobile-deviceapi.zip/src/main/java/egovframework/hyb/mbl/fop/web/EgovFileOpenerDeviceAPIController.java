package egovframework.hyb.mbl.fop.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import egovframework.hyb.mbl.fop.service.EgovFileOpenerDeviceAPIService;
import egovframework.hyb.mbl.fop.service.FileOpenerDeviceAPIVO;
import egovframework.hyb.utils.DeviceUuidCheck;
import egovframework.hyb.utils.EgovFileMngUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 통합 File Opener API Controller
 */
@Controller
@Tag(name = "11. FileOpener Guide Program Service", description = "파일 오프너 API 관리")
public class EgovFileOpenerDeviceAPIController {

    @Resource(name = "EgovFileOpenerDeviceAPIService")
    private EgovFileOpenerDeviceAPIService egovFileOpenerDeviceAPIService;

	@Resource(name = "egovFileMngUtil")
	private EgovFileMngUtil egovFileMngUtil;

	@Operation(summary = "파일 오프너 정보 목록 조회", description = "기기 UUID에 해당하는 파일 오프너 정보 목록을 조회합니다.")
	@GetMapping("/fop/selectFileOpenerList.do")
    public ResponseEntity<Map<String, Object>> selectFileOpenerList(
    		@Parameter(description = "기기 식별코드") FileOpenerDeviceAPIVO searchVO) {
		if (DeviceUuidCheck.isBlank(searchVO.getUuid())) {
			return DeviceUuidCheck.requiredResponse();
		}
		Map<String, Object> response = new HashMap<>();
		List<FileOpenerDeviceAPIVO> fileOpenerDeviceAPIVO = egovFileOpenerDeviceAPIService.selectFileOpenerList(searchVO);
		response.put("resultSet", fileOpenerDeviceAPIVO);
		response.put("resultState","OK");
		return ResponseEntity.ok(response);
    }

    @Operation(summary = "파일 오프너 파일 다운로드", description = "기기 UUID 소유권을 검증한 뒤 파일을 다운로드합니다.")
    @GetMapping("/fop/fileDownload.do")
	public void fileDownload(
			@Parameter(description = "기기 식별코드") @RequestParam("uuid") String uuid,
			@Parameter(description = "파일 일련번호") @RequestParam("fileSn") int fileSn,
			HttpServletResponse response) throws IOException {
		if (DeviceUuidCheck.isBlank(uuid)) {
			egovFileMngUtil.writeDownloadError(response, HttpServletResponse.SC_BAD_REQUEST, "uuid is required");
			return;
		}
		try {
			egovFileMngUtil.fileDownload(response, fileSn, uuid);
		} catch (SecurityException e) {
			egovFileMngUtil.writeDownloadError(response, HttpServletResponse.SC_FORBIDDEN, "파일 접근 권한이 없습니다.");
			return;
		} catch (IOException e) {
			egovFileMngUtil.writeDownloadError(response, HttpServletResponse.SC_NOT_FOUND, "파일을 찾을 수 없습니다.");
		}
	}

}
