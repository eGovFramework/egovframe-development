package egovframework.hyb.mbl.frw.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import egovframework.hyb.mbl.fop.service.EgovFileOpenerDeviceAPIService;
import egovframework.hyb.mbl.fop.service.FileOpenerDeviceAPIVO;
import egovframework.hyb.mbl.frw.service.EgovFileReaderWriterAPIService;
import egovframework.hyb.mbl.frw.service.FileReaderWriterAPIVO;
import egovframework.hyb.utils.DeviceUuidCheck;
import egovframework.hyb.utils.EgovFileMngUtil;
import egovframework.hyb.utils.EgovFileService;
import egovframework.hyb.utils.FileVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import java.io.IOException;

/**
 * 통합 FileReaderWriter API Controller
 */
@Controller
@Tag(name = "05. FileReaderWriter Guide Program Service", description = "파일 읽기/쓰기 API 관리")
public class EgovFileReaderWriterAPIController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovFileReaderWriterAPIController.class);

    @Resource(name = "EgovFileReaderWriterAPIService")
    private EgovFileReaderWriterAPIService egovFileReaderWriterAPIService;

    @Resource(name = "EgovFileOpenerDeviceAPIService")
    private EgovFileOpenerDeviceAPIService egovFileOpenerDeviceAPIService;

    @Resource(name = "egovFileMngUtil")
    private EgovFileMngUtil fileMngUtil;

    @Resource(name = "EgovFileService")
    private EgovFileService fileService;

    @Operation(summary = "파일 읽기/쓰기 정보 목록 조회", description = "파일 읽기/쓰기 정보 목록을 조회합니다.")
    @GetMapping("/frw/selectFileReaderWriterInfoList.do")
    public ResponseEntity<Map<String, Object>> selectFileReaderWriterInfoList(FileReaderWriterAPIVO searchVO) throws Exception {
        if (DeviceUuidCheck.isBlank(searchVO.getUuid())) {
            return DeviceUuidCheck.requiredResponse();
        }
        Map<String, Object> response = new HashMap<>();
        List<FileReaderWriterAPIVO> fileReaderWriterInfoList = egovFileReaderWriterAPIService.selectFileReaderWriterInfoList(searchVO);
        response.put("fileReaderWriterInfoList", fileReaderWriterInfoList);
        response.put("resultState", "OK");
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "파일 읽기/쓰기 정보 등록", description = "파일 읽기/쓰기 정보를 등록합니다.")
    @PostMapping("/frw/insertFileReaderWriterInfo.do")
    public ResponseEntity<Map<String, Object>> insertFileReaderWriterInfo(FileReaderWriterAPIVO fileReaderWriterVO) throws Exception {
        Map<String, Object> response = new HashMap<>();

        String uuid = fileReaderWriterVO.getUuid();
        int fileSn = fileReaderWriterVO.getFileSn();

        if (uuid == null || uuid.isBlank()) {
            response.put("resultState", "FAIL");
            response.put("resultMessage", "기기 식별코드가 필요합니다.");
            return ResponseEntity.ok(response);
        }

        if (fileService.selectFileDetailInfo(fileSn) == null) {
            response.put("resultState", "FAIL");
            response.put("resultMessage", "존재하지 않는 파일입니다.");
            return ResponseEntity.ok(response);
        }

        if (fileService.isFileOwnedByUuid(fileSn, uuid)) {
            response.put("resultState", "OK");
            response.put("resultMessage", "insert success");
            return ResponseEntity.ok(response);
        }

        if (fileService.isFileRegistered(fileSn)) {
            response.put("resultState", "FAIL");
            response.put("resultMessage", "다른 기기에 등록된 파일입니다.");
            return ResponseEntity.ok(response);
        }

        response.put("resultState", "FAIL");
        response.put("resultMessage", "파일 업로드 후 등록이 필요합니다.");
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "파일 읽기/쓰기 정보 삭제", description = "파일 읽기/쓰기 정보를 삭제합니다.")
    @DeleteMapping("/frw/deleteFileReaderWriterInfo.do")
    public ResponseEntity<Map<String, Object>> deleteFileReaderWriterInfo(FileReaderWriterAPIVO fileReaderWriterVO) throws Exception {
        if (DeviceUuidCheck.isBlank(fileReaderWriterVO.getUuid())) {
            return DeviceUuidCheck.requiredResponse();
        }
        Map<String, Object> response = new HashMap<>();
        int cnt = egovFileReaderWriterAPIService.deleteFileReaderWriterInfo(fileReaderWriterVO);
        if(cnt > 0) {
			response.put("resultState","OK");
			response.put("resultMessage","delete success");
		} else {
			response.put("resultState","FAIL");
			response.put("resultMessage","delete fail");
		}
        return ResponseEntity.ok(response);
    }
    
    @Operation(summary = "파일 업로드", description = "파일을 업로드합니다. (단일 또는 여러 파일 지원, 확장자 제한 없음)")
    @PostMapping("/frw/fileupload.do")
    public ResponseEntity<Map<String, Object>> uploadFile(
            @Parameter(description = "업로드할 파일") @RequestParam("files") MultipartFile[] files,
            @Parameter(description = "기기 식별코드") @RequestParam("uuid") String uuid) throws Exception {
        if (DeviceUuidCheck.isBlank(uuid)) {
            return DeviceUuidCheck.requiredResponse();
        }
        Map<String, Object> response = new HashMap<>();
        try {
            if (files == null || files.length == 0) {
                response.put("resultState", "FAIL");
                response.put("resultMessage", "업로드할 파일이 없습니다.");
                return ResponseEntity.ok(response);
            }
            
            // MultipartFile 배열을 List로 변환
            List<MultipartFile> fileList = new ArrayList<>();
            for (MultipartFile file : files) {
                if (file != null && !file.isEmpty()) {
                    fileList.add(file);
                }
            }
            
            if (fileList.isEmpty()) {
                response.put("resultState", "FAIL");
                response.put("resultMessage", "유효한 파일이 없습니다.");
                return ResponseEntity.ok(response);
            }
            
            // 일괄 업로드 처리 (확장자 제한 없음)
            List<FileVO> uploadedFiles = fileMngUtil.writeUploadedFile(fileList, false);

            for (FileVO fileVO : uploadedFiles) {
                registerUploadedFile(uuid, fileVO);
            }
            
            // 단일 파일인 경우 기존 형식과 호환되도록 응답 구성
            if (uploadedFiles.size() == 1) {
                FileVO fileVO = uploadedFiles.get(0);
                response.put("resultState", "OK");
                response.put("fileVO", fileVO);
                response.put("fileSn", fileVO.getFileSn());
            } else {
                // 여러 파일인 경우
                List<Map<String, Object>> fileResults = new ArrayList<>();
                for (FileVO fileVO : uploadedFiles) {
                    Map<String, Object> result = new LinkedHashMap<>();
                    result.put("fileSn", fileVO.getFileSn());
                    result.put("fileName", fileVO.getOrignlFileNm());
                    result.put("fileSize", fileVO.getFileSize());
                    result.put("fileExtsn", fileVO.getFileExtsn());
                    fileResults.add(result);
                }
                
                response.put("resultState", "OK");
                response.put("totalFiles", uploadedFiles.size());
                response.put("fileResults", fileResults);
            }
            
        } catch (Exception e) {
            LOGGER.error("파일 업로드 실패", e);
            response.put("resultState", "FAIL");
            response.put("resultMessage", "업로드에 실패했습니다");
        }
        
        return ResponseEntity.ok(response);
    }

    private void registerUploadedFile(String uuid, FileVO fileVO) throws Exception {
        FileReaderWriterAPIVO vo = new FileReaderWriterAPIVO();
        vo.setUuid(uuid);
        vo.setFileSn(fileVO.getFileSn());
        vo.setFileNm(fileVO.getOrignlFileNm());
        vo.setFileStreCours(fileVO.getFileStreCours());
        vo.setFileType(fileVO.getFileExtsn());
        vo.setFileSize(fileVO.getFileSize());
        vo.setUseYn("Y");
        egovFileReaderWriterAPIService.insertFileReaderWriterInfo(vo);

        FileOpenerDeviceAPIVO opener = new FileOpenerDeviceAPIVO();
        opener.setUuid(uuid);
        opener.setFileSn(fileVO.getFileSn());
        egovFileOpenerDeviceAPIService.insertFileOpenerList(opener);
    }

    @Operation(summary = "파일 다운로드", description = "기기 UUID 소유권을 검증한 뒤 파일을 다운로드합니다.")
    @GetMapping("/frw/fileDownload.do")
    public void fileDownload(
            @Parameter(description = "기기 식별코드") @RequestParam("uuid") String uuid,
            @Parameter(description = "파일 일련번호") @RequestParam("fileSn") int fileSn,
            HttpServletResponse response) throws IOException {
        if (DeviceUuidCheck.isBlank(uuid)) {
            fileMngUtil.writeDownloadError(response, HttpServletResponse.SC_BAD_REQUEST, "uuid is required");
            return;
        }
        try {
            fileMngUtil.fileDownload(response, fileSn, uuid);
        } catch (SecurityException e) {
            fileMngUtil.writeDownloadError(response, HttpServletResponse.SC_FORBIDDEN, "파일 접근 권한이 없습니다.");
            return;
        } catch (IOException e) {
            fileMngUtil.writeDownloadError(response, HttpServletResponse.SC_NOT_FOUND, "파일을 찾을 수 없습니다.");
        }
    }

}
