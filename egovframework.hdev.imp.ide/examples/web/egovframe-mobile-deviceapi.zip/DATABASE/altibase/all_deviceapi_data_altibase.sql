-- 아래순서로 기초데이터 입력

-- ID Generation (첨부파일 FILE_SN 채번)
INSERT INTO COMTECOPSEQ VALUES('FILE',1);
