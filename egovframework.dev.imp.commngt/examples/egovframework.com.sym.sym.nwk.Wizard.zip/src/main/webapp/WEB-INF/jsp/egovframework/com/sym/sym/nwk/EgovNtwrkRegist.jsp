<%--
/**
 * @Class Name  : EgovNtwrkRegist.java
 * @Description : EgovNtwrkRegist jsp
 * @Modification Information
 * @
 * @ 수정일               수정자              수정내용
 * @ ----------   --------    ---------------------------
 * @ 2010.07.01   lee.m.j     최초 생성
 *   2018.09.07   신용호             공통컴포넌트 3.8 개선
 *   2022.06.10   김해준			ip validation segment 별 alert 반복 호출 개선
 *
 *  @author lee.m.j
 *  @since 2010.07.01
 *  @version 1.0
 *  @see
 *
 *  Copyright (C) 2009 by MOPAS  All rights reserved.
 */
--%>

<%@ page contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><spring:message code="comSymSymNwk.ntwrkRegist.title"/></title><!-- 네트워크 등록 -->
<link href="<c:url value="/css/egovframework/com/com.css"/>" rel="stylesheet" type="text/css">
<link href="<c:url value="/css/egovframework/com/button.css"/>" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<c:url value="/js/egovframework/com/cmm/EgovValidation.js" />"></script>
<link type="text/css" rel="stylesheet" href="<c:url value='/css/egovframework/com/cmm/jqueryui.css' />">
<script src="<c:url value='/js/egovframework/com/cmm/jquery.js' />"></script>
<script src="<c:url value='/js/egovframework/com/cmm/jqueryui.js' />"></script>
<script type="text/javaScript" language="javascript" defer="defer">
<!--
function initCalendar(){

	$("#regstYmd").datepicker( 
	        {dateFormat:'yy-mm-dd'
	         , showOn: 'button'
	         , buttonImage: '<c:url value='/images/egovframework/com/cmm/icon/bu_icon_carlendar.gif'/>'  
	         , buttonImageOnly: true 
	         
	         , showMonthAfterYear: true
	         , showOtherMonths: true
		     , selectOtherMonths: true
				
	         , changeMonth: true // 월선택 select box 표시 (기본은 false)
	         , changeYear: true  // 년선택 selectbox 표시 (기본은 false)
	         , showButtonPanel: true // 하단 today, done  버튼기능 추가 표시 (기본은 false)
	});

}

function fncSelectNtwrkList() {
    var varFrom = document.getElementById("ntwrk");
    varFrom.action = "<c:url value='/sym/sym/nwk/selectNtwrkList.do'/>";
    varFrom.submit();
}

function fncNtwrkInsert() {


    var varFrom = document.getElementById("ntwrk");

    varFrom.action = "<c:url value='/sym/sym/nwk/addNtwrk.do'/>";

    if(confirm("<spring:message code="comSymSymNwk.ntwrkRegist.validate.save"/>")){ //저장 하시겠습니까?
        if(!validateNtwrk(varFrom)){
            return;
        } else {
        	if(!ipValidate(varFrom.ntwrkIp.value, ''))
                return;
            else if(!ipValidate(varFrom.gtwy.value, '<spring:message code="comSymSymNwk.ntwrkRegist.gtwy"/>')) //게이트웨이
                return;
            else if(!ipValidate(varFrom.subnet.value, '<spring:message code="comSymSymNwk.ntwrkRegist.subnet"/>')) //서브넷
                return;
            else if(!ipValidate(varFrom.domnServer.value, '<spring:message code="comSymSymNwk.ntwrkRegist.domnServer"/>')) //DNS
                return;
            else
            	varFrom.submit();
        }
    }
}

function ipValidate(ipValue, ipName) {

    var varFrom = document.getElementById("ntwrk");
    // var IPvalue = varFrom.gtwy.value;
    var IPvalue = ipValue;
    var IPName = ipName;

    var ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
    var ipArray = IPvalue.match(ipPattern);

    var result = true;
    var thisSegment;

    if(IPvalue == "0.0.0.0") {
        alert(IPvalue + " : <spring:message code="comSymSymNwk.ntwrkRegist.validate.ip.notAllowed"/>"); //예외 아이피 입니다.
        result = false;
    } else if (IPvalue == "255.255.255.255") {
        alert(result =IPvalue + " : <spring:message code="comSymSymNwk.ntwrkRegist.validate.ip.notAllowed"/>"); //예외 아이피 입니다.
        result = false;
    } else {
        result = true;
    }

    if(ipArray == null) {
        alert(IPName+" : <spring:message code="comSymSymNwk.ntwrkRegist.validate.ip.formatMismatch"/>"); //IP 형식이 일치 하지않습니다.
        result = false;
    } else {
        for (var i=1; i<5; i++) {

            thisSegment = ipArray[i];

            if (thisSegment > 255) {			// 22.06.10 segment 별 alert 반복 호출 수정
                alert(IPName+" : <spring:message code="comSymSymNwk.ntwrkRegist.validate.ip.formatMismatch"/>"); //IP 형식이 일치 하지않습니다.
                result = false;
                break;
            }

            if ((i == 0) && (thisSegment > 255)) {
                alert(IPName+" : <spring:message code="comSymSymNwk.ntwrkRegist.validate.ip.formatMismatch"/>"); //IP 형식이 일치 하지않습니다.
                result = false;
                break;
            }
        }
    }

    return result;
}

-->
</script>
</head>

<body onload="initCalendar()">
<noscript class="noScriptTitle"><spring:message code="common.noScriptTitle.msg" /></noscript><!-- 자바스크립트를 지원하지 않는 브라우저에서는 일부 기능을 사용하실 수 없습니다. -->

<div class="wTableFrm">
	<!-- 타이틀 -->
	<h2><spring:message code="comSymSymNwk.ntwrkRegist.pageTop.title"/></h2><!-- 네트워크 등록 -->

    <form:form modelAttribute="ntwrk" name="ntwrk" id="ntwrk" method="post" action="${pageContext.request.contextPath}/sym/sym/nwk/addNtwrk.do">

		<!-- 등록폼 -->
		<table class="wTable">
			<colgroup>
				<col style="width:16%" />
				<col style="" />
			</colgroup>
			<tr>
				<th><spring:message code="comSymSymNwk.ntwrkRegist.ntwrkIp"/> <span class="pilsu">*</span></th><!-- IP -->
				<td class="left">
				    <label for="ntwrkIp"><form:input path="ntwrkIp" id="ntwrkIp" maxlength="23" cssStyle="width:200px" />&nbsp;<form:errors path="ntwrkIp" /></label>
				</td>
			</tr>
			<tr>
				<th><spring:message code="comSymSymNwk.ntwrkRegist.gtwy"/> <span class="pilsu">*</span></th><!-- 게이트웨이 -->
				<td class="left">
				    <label for="gtwy"><form:input path="gtwy" id="gtwy" maxlength="23" cssStyle="width:200px" />&nbsp;<form:errors path="gtwy" /></label>
				</td>
			</tr>
			<tr>
				<th><spring:message code="comSymSymNwk.ntwrkRegist.subnet"/> <span class="pilsu">*</span></th><!-- 서브넷 -->
				<td class="left">
				    <label for="subnet"><form:input path="subnet" id="subnet" maxlength="23" cssStyle="width:200px" />&nbsp;<form:errors path="subnet" /></label>
				</td>
			</tr>
			<tr>
				<th><spring:message code="comSymSymNwk.ntwrkRegist.domnServer"/> <span class="pilsu">*</span></th><!-- DNS -->
				<td class="left">
				    <label for="domnServer"><form:input path="domnServer" id="domnServer" maxlength="23" cssStyle="width:200px" />&nbsp;<form:errors path="domnServer" /></label>
				</td>
			</tr>
			<tr>
				<th><spring:message code="comSymSymNwk.ntwrkRegist.manageIem"/> <span class="pilsu">*</span></th><!-- 관리항목 -->
				<td class="left">
				    <label for="manageIem">
				      <select name="manageIem">
				        <c:forEach var="cmmCodeDetail" items="${cmmCodeDetailList}" varStatus="status">
				          <option value="<c:out value="${cmmCodeDetail.code}"/>" <c:if test="${cmmCodeDetail.code == ntwrk.manageIem}">selected</c:if> ><c:out value="${cmmCodeDetail.codeNm}"/></option>
				        </c:forEach>
				      </select>
				      &nbsp;<form:errors path="manageIem" />
			        </label>
				</td>
			</tr>
			<tr>
				<th><spring:message code="comSymSymNwk.ntwrkRegist.userNm"/> <span class="pilsu">*</span></th><!-- 사용자명 -->
				<td class="left">
				    <label for="userNm"><form:input path="userNm" id="userNm" maxlength="30" cssStyle="width:128px" />&nbsp;<form:errors path="userNm" /></label>
				</td>
			</tr>
			<tr>
				<th><spring:message code="comSymSymNwk.ntwrkRegist.useAt"/> <span class="pilsu">*</span></th><!-- 사용여부 -->
				<td class="left">
				    <label for="useAt">
			          <select name="useAt">
			              <option value="Y" <c:if test="${ntwrk.useAt == 'Y'}">selected</c:if> >Y</option>
			              <option value="N" <c:if test="${ntwrk.useAt == 'N'}">selected</c:if> >N</option>
			          </select>
			          &nbsp;<form:errors path="useAt" />
			       </label>
				</td>
			</tr>
			<tr>
				<th><spring:message code="comSymSymNwk.ntwrkRegist.regstYmd"/> <span class="pilsu">*</span></th><!-- 등록일자 -->
				<td class="left">
				    <label for="regstYmd">
			        	<input type="hidden" name="cal_url" id="cal_url" value="<c:url value='/sym/cal/EgovNormalCalPopup.do'/>" >
			            <!--  <form:input path="regstYmd" id="regstYmd" size="10" maxlength="10" title="등록일자" cssClass="readOnlyClass" readonly="true" onClick="javascript:fn_egov_NormalCalendar(document.ntwrk, document.ntwrk.registerDate, document.ntwrk.regstYmd);" onKeyDown="javascript:if (event.keyCode == 13) { fn_egov_NormalCalendar(document.ntwrk, document.ntwrk.registerDate, document.ntwrk.regstYmd); }" /> -->
			            <form:input path="regstYmd" id="regstYmd" maxlength="10" cssStyle="width:70px"/><!-- 등록일자 -->
			            <input type="hidden" name="registerDate" value=""/>
			            &nbsp;<form:errors path="regstYmd" />
			        </label>
				</td>
			</tr>
		</table>
	
		<!-- 하단 버튼 -->
		<div class="btn">
			<input class="s_submit" type="submit" value='<spring:message code="button.save" />' onclick="fncNtwrkInsert(); return false;" /><!-- 저장 -->
			<span class="btn_s"><a href="javascript:void(0);" onclick="fncSelectNtwrkList(); return false;"><spring:message code="button.list" /></a></span><!-- 목록 -->
		</div>
		<div style="clear:both;"></div>
	
	    <!-- 검색조건 유지 -->
	    <input type="hidden" name="strManageIem" value="<c:out value='${ntwrkVO.strManageIem}'/>" />
	    <input type="hidden" name="strUserNm" value="<c:out value='${ntwrkVO.strUserNm}'/>" />
	    <input type="hidden" name="pageIndex" value="<c:out value='${ntwrkVO.pageIndex}'/>" >
	</form:form>

</div>

</body>
</html>
