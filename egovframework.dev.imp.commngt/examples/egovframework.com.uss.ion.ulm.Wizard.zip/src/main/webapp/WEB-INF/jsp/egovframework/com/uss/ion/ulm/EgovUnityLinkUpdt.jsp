<%--
  Class Name : EgovUnityLinkUpdt.jsp
  Description : 통합링크관리 수정 페이지
  Modification Information

       수정일               수정자            수정내용
    ----------   --------   ---------------------------
    2008.03.09   장동한			최초 생성
    2018.08.16   이정은			공통컴포넌트 3.8 개선
    2019.12.10   신용호			KISA 보안약점 조치 (HTMLArea Editor삭제)
    2024.10.29   권태성			fn_egov_save_UnityLink 함수내에서 varFrom.onsubmit(); 코드 제거

    author   : 공통서비스 개발팀 장동한
    since    : 2009.03.09

    Copyright (C) 2009 by MOPAS  All rights reserved.
--%>
<%@ page contentType="text/html; charset=utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%pageContext.setAttribute("crlf", "\r\n"); %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><spring:message code="uss.ion.ulm.unityLinkUpdt.unityLinkUpdate"/></title><!-- 통합링크관리 관리 -->
<link href="<c:url value="/css/egovframework/com/com.css"/>" rel="stylesheet" type="text/css">
<link href="<c:url value="/css/egovframework/com/button.css"/>" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<c:url value="/js/egovframework/com/cmm/EgovValidation.js" />"></script>
<script type="text/javaScript" language="javascript">
/* ********************************************************
 * 저장처리화면
 ******************************************************** */
function fn_egov_save_UnityLink(){
	var varFrom = document.unityLink;
	varFrom.action =  "<c:url value='/uss/ion/ulm/updtUnityLink.do' />";

	if(!validateUnityLink(varFrom)){
		return;
	}

	if(confirm("<spring:message code="common.save.msg" />")){
		varFrom.submit();
	}
}
</script>
</head>
<body>

<%-- noscript 테그 --%>
<noscript class="noScriptTitle"><spring:message code="common.noScriptTitle.msg"/></noscript><!-- 자바스크립트를 지원하지 않는 브라우저에서는 일부 기능을 사용하실 수 없습니다. -->

<form:form modelAttribute="unityLink" name="unityLink" action="${pageContext.request.contextPath}/uss/ion/ulm/updtUnityLink.do" method="post" enctype="multipart/form-data" >

<div class="wTableFrm">
	<!-- 타이틀 -->
	<h2><spring:message code="uss.ion.ulm.unityLinkUpdt.unityLinkUpdate"/></h2><!-- 통합링크관리 수정 -->

	<!-- 등록폼 -->
	<table class="wTable">
		<colgroup>
			<col style="width:16%" />
			<col style="" />
		</colgroup>
		<tr>
			<th><spring:message code="uss.ion.ulm.unityLinkUpdt.unityLinkNm"/> <span class="pilsu">*</span></th><!-- 통합링크명 -->
			<td class="left">
			    <form:input path="unityLinkNm" size="73" cssClass="txaIpt" maxlength="255"/>
      			<div><form:errors path="unityLinkNm" cssClass="error" /></div>
			</td>
		</tr>
		<tr>
			<th><spring:message code="uss.ion.ulm.unityLinkUpdt.unityLinkGroup"/> <span class="pilsu">*</span></th><!-- 통합링크그룹 -->
			<td class="left">
			    <form:select path="unityLinkSeCode">
			    	<c:set var="cSelect"><spring:message code="input.cSelect"/></c:set>
					<form:option value="" label="${cSelect}"/><!-- 선택 -->
					<form:options items="${unityLinkSeCodeList}" itemValue="code" itemLabel="codeNm"/>
				</form:select>
				<div><form:errors path="unityLinkSeCode" cssClass="error" /></div>
			</td>
		</tr>
		<tr>
			<th><spring:message code="uss.ion.ulm.unityLinkUpdt.unityLinkUrl"/> <span class="pilsu">*</span></th><!-- 통합링크URL -->
			<td class="left">
			    <form:input path="unityLinkUrl" size="73" cssClass="txaIpt" maxlength="255"/>
      			<div><form:errors path="unityLinkUrl" cssClass="error" /></div>
			</td>
		</tr>
		<tr>
			<th><spring:message code="uss.ion.ulm.unityLinkUpdt.unityLinkDc"/> <span class="pilsu">*</span></th><!-- 통합링크설명 -->
			<td class="left">
			    <form:textarea path="unityLinkDc" rows="75" cols="14" cssClass="txaClass2" cssStyle="height:356px"/>
				<div><form:errors path="unityLinkDc" cssClass="error" /></div>
			</td>
		</tr>
	</table>

	<!-- 하단 버튼 -->
	<div class="btn">
		<input class="s_submit" type="submit" value='<spring:message code="button.save" />' onclick="fn_egov_save_UnityLink(); return false;" />
		<span class="btn_s"><a href="<c:url value='/uss/ion/ulm/listUnityLink.do' />" onclick=""><spring:message code="button.list" /></a></span>
	</div>
	<div style="clear:both;"></div>
</div>
<input name="unityLinkId" type="hidden" value="${unityLink.unityLinkId}">
<input name="cmd" type="hidden" value="<c:out value='save'/>"/>
</form:form>
</body>
</html>
