package egovframework.com.sym.prm.web;

import egovframework.com.cmm.annotation.RequireAdmin;

import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.cop.ems.service.EgovSndngMailRegistService;
import egovframework.com.cop.ems.service.SndngMailVO;
import egovframework.com.sym.prm.service.EgovProgrmManageService;
import egovframework.com.sym.prm.service.ProgrmManageDtlVO;
import egovframework.com.sym.prm.service.ProgrmManageVO;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 * 프로그램목록 관리및 변경을 처리하는 비즈니스 구현 클래스
 * 
 * @author 개발환경 개발팀 이용
 * @since 2009.03.20
 * @version 1.0
 * @see
 *
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.03.20  이용           최초 생성
 *   2011.08.22  서준식          selectProgrmChangRequstProcess() 메서드 처리일자 trim 처리
 *   2011.08.26  정진오          IncludedInfo annotation 추가
 *   2024.09.04  권태성          등록 화면과 데이터를 처리하는 method 분리, validation 적용
 *   2025.07.21  이백행          2025년 컨트리뷰션 PMD로 소프트웨어 보안약점 진단하고 제거하기-FormalParameterNamingConventions(변수명에 밑줄 사용)
 *   2025.07.21  이백행          2025년 컨트리뷰션 PMD로 소프트웨어 보안약점 진단하고 제거하기-LocalVariableNamingConventions(final이 아닌 변수는 밑줄을 포함할 수 없음)
 *
 *      </pre>
 */
@Controller
public class EgovProgrmManageController {

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/** EgovProgrmManageService */
	@Resource(name = "progrmManageService")
	private EgovProgrmManageService progrmManageService;

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	/** EgovSndngMailRegistService */
	@Resource(name = "sndngMailRegistService")
	private EgovSndngMailRegistService sndngMailRegistService;

	/**
	 * 프로그램목록을 상세화면 호출 및 상세조회한다.
	 * 
	 * @param progrmFileNm String
	 * @return 출력페이지정보 "sym/prm/EgovProgramListDetailSelectUpdt"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/prm/EgovProgramListDetailSelect.do")
	@RequireAdmin
	public String selectProgrm(@RequestParam("progrmFileNm") String progrmFileNm,
			@ModelAttribute("searchVO") ComDefaultVO searchVO, ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		ProgrmManageVO vo = new ProgrmManageVO();
		vo.setProgrmFileNm(progrmFileNm);
		ProgrmManageVO progrmManageVO = progrmManageService.selectProgrm(vo);
		model.addAttribute("progrmManageVO", progrmManageVO);
		return "egovframework/com/sym/prm/EgovProgramListDetailSelectUpdt";
	}

	/**
	 * 프로그램목록 리스트조회한다.
	 * 
	 * @param searchVO ComDefaultVO
	 * @return 출력페이지정보 "sym/prm/EgovProgramListManage"
	 * @exception Exception
	 */
	@IncludedInfo(name = "프로그램관리", order = 1111, gid = 60)
	@RequestMapping(value = "/sym/prm/EgovProgramListManageSelect.do")
	public String selectProgrmList(@ModelAttribute("searchVO") ComDefaultVO searchVO, ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 내역 조회
		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<ProgrmManageVO> resultList = progrmManageService.selectProgrmList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = progrmManageService.selectProgrmListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/sym/prm/EgovProgramListManage";
	}

	/**
	 * 프로그램목록 멀티 삭제한다.
	 * 
	 * @param checkedProgrmFileNmForDel String
	 * @return 출력페이지정보 "forward:/sym/prm/EgovProgramListManageSelect.do"
	 * @exception Exception
	 */
	@PostMapping("/sym/prm/EgovProgrmManageListDelete.do")
	@RequireAdmin
	public String deleteProgrmManageList(@RequestParam("checkedProgrmFileNmForDel") String checkedProgrmFileNmForDel,
			@ModelAttribute("progrmManageVO") ProgrmManageVO progrmManageVO, ModelMap model) throws Exception {
		String sLocationUrl = null;
		String resultMsg = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 2026.03.23 kisa 보안점검 대응 조치
		String[] delProgrmFileNm = null;
		  if (!ObjectUtils.isEmpty(checkedProgrmFileNmForDel)) {
			  delProgrmFileNm = checkedProgrmFileNmForDel.split(",");
		  }
		if (delProgrmFileNm == null || (delProgrmFileNm.length == 0)) {
			resultMsg = egovMessageSource.getMessage("fail.common.delete");
			sLocationUrl = "forward:/sym/prm/EgovProgramListManageSelect.do";
		} else {
			progrmManageService.deleteProgrmManageList(checkedProgrmFileNmForDel);
			resultMsg = egovMessageSource.getMessage("success.common.delete");
			sLocationUrl = "forward:/sym/prm/EgovProgramListManageSelect.do";
		}
		model.addAttribute("resultMsg", resultMsg);
		// status.setComplete();
		return sLocationUrl;
	}

	/**
	 * 프로그램목록 등록화면
	 * 
	 * @param progrmManageVO ProgrmManageVO
	 * @return 출력페이지정보 등록화면 호출시 "sym/prm/EgovProgramListRegist", 출력페이지정보 등록처리시
	 *         "forward:/sym/prm/EgovProgramListManageSelect.do"
	 * @exception Exception
	 */
	@PostMapping("/sym/prm/EgovProgramListRegistView.do")
	@RequireAdmin
	public String insertProgrmListView(@ModelAttribute("progrmManageVO") ProgrmManageVO progrmManageVO, ModelMap model)
			throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		return "egovframework/com/sym/prm/EgovProgramListRegist";
	}

	/**
	 * 프로그램목록을 등록한다.
	 * 
	 * @param progrmManageVO
	 * @param bindingResult
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/sym/prm/EgovProgramListRegist.do")
	@RequireAdmin
	public String insertProgrmList(@Valid @ModelAttribute("progrmManageVO") ProgrmManageVO progrmManageVO,
			BindingResult bindingResult, ModelMap model) throws Exception {
		String resultMsg = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		if (bindingResult.hasErrors()) {
			model.addAttribute("programManageVO",progrmManageVO);
			return "egovframework/com/sym/prm/EgovProgramListRegist";
		}
		if (progrmManageVO.getProgrmDc() == null || progrmManageVO.getProgrmDc().equals("")) {
			progrmManageVO.setProgrmDc(" ");
		}
		progrmManageService.insertProgrm(progrmManageVO);
		resultMsg = egovMessageSource.getMessage("success.common.insert");
		model.addAttribute("resultMsg", resultMsg);
		return "redirect:/sym/prm/EgovProgramListManageSelect.do";
	}

	/**
	 * 프로그램목록을 수정 한다.
	 * 
	 * @param progrmManageVO ProgrmManageVO
	 * @return 출력페이지정보 "forward:/sym/prm/EgovProgramListManageSelect.do"
	 * @exception Exception
	 */
	/* 프로그램목록수정 */
	@PostMapping("/sym/prm/EgovProgramListDetailSelectUpdt.do")
	@RequireAdmin
	public String updateProgrmList(@Valid @ModelAttribute("progrmManageVO") ProgrmManageVO progrmManageVO,
			BindingResult bindingResult,@ModelAttribute("searchVO") ComDefaultVO searchVO, Model model) throws Exception {
		String resultMsg = "";
		String sLocationUrl = null;
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		if (bindingResult.hasErrors()) {
		    model.addAttribute("progrmManageVO", progrmManageVO);
		    model.addAttribute("searchVO", searchVO);
		    return "egovframework/com/sym/prm/EgovProgramListDetailSelectUpdt";
			
		}
		if (progrmManageVO.getProgrmDc() == null || progrmManageVO.getProgrmDc().equals("")) {
			progrmManageVO.setProgrmDc(" ");
		}
		progrmManageService.updateProgrm(progrmManageVO);
		resultMsg = egovMessageSource.getMessage("success.common.update");
		sLocationUrl = "forward:/sym/prm/EgovProgramListManageSelect.do";
		model.addAttribute("resultMsg", resultMsg);
		return sLocationUrl;
	}
	

	/**
	 * 프로그램목록을 삭제 한다.
	 * 
	 * @param progrmManageVO ProgrmManageVO
	 * @return 출력페이지정보 "forward:/sym/prm/EgovProgramListManageSelect.do"
	 * @exception Exception
	 */
	@PostMapping("/sym/prm/EgovProgramListManageDelete.do")
	@RequireAdmin
	public String deleteProgrmList(@ModelAttribute("progrmManageVO") ProgrmManageVO progrmManageVO, ModelMap model)
			throws Exception {
		String resultMsg = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		progrmManageService.deleteProgrm(progrmManageVO);
		resultMsg = egovMessageSource.getMessage("success.common.delete");
		model.addAttribute("resultMsg", resultMsg);
		return "forward:/sym/prm/EgovProgramListManageSelect.do";
	}

	/**
	 * 프로그램변경요청목록 조회한다.
	 * 
	 * @param searchVO ComDefaultVO
	 * @return 출력페이지정보 "sym/prm/EgovProgramChangeRequst"
	 * @exception Exception
	 */
	@IncludedInfo(name = "프로그램변경요청관리", order = 1112, gid = 60)
	@RequestMapping(value = "/sym/prm/EgovProgramChangeRequstSelect.do")
	public String selectProgrmChangeRequstList(@ModelAttribute("searchVO") ComDefaultVO searchVO, ModelMap model)
			throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 내역 조회
		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<ProgrmManageDtlVO> resultList = progrmManageService.selectProgrmChangeRequstList(searchVO);
		model.addAttribute("list_changerequst", resultList);

		int totCnt = progrmManageService.selectProgrmChangeRequstListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/sym/prm/EgovProgramChangeRequst";
	}

	/**
	 * 프로그램변경요청목록을 상세조회한다.
	 * 
	 * @param progrmManageDtlVO ProgrmManageDtlVO
	 * @return 출력페이지정보 "sym/prm/EgovProgramChangRequstDetailSelectUpdt"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/prm/EgovProgramChangRequstDetailSelect.do")
	@RequireAdmin
	public String selectProgrmChangeRequst(@ModelAttribute("progrmManageDtlVO") ProgrmManageDtlVO progrmManageDtlVO,
			ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		if (progrmManageDtlVO.getProgrmFileNm() == null || progrmManageDtlVO.getProgrmFileNm().equals("")) {
			progrmManageDtlVO.setProgrmFileNm(progrmManageDtlVO.getTmpProgrmNm());
			int tmpNo = progrmManageDtlVO.getTmpRqesterNo();
			progrmManageDtlVO.setRqesterNo(tmpNo);
		}
		ProgrmManageDtlVO resultVO = progrmManageService.selectProgrmChangeRequst(progrmManageDtlVO);
		model.addAttribute("progrmManageDtlVO", resultVO);
		return "egovframework/com/sym/prm/EgovProgramChangRequstDetailSelectUpdt";
	}

	/**
	 * 프로그램변경요청 화면을 호출및 프로그램변경요청을 등록한다.
	 * 
	 * @param progrmManageDtlVO ProgrmManageDtlVO
	 * @param commandMap        Map
	 * @return 출력페이지정보 등록화면 호출시 "sym/prm/EgovProgramChangRequstStre", 출력페이지정보 등록처리시
	 *         "forward:/sym/prm/EgovProgramChangeRequstSelect.do"
	 * @exception Exception
	 */
	/* 프로그램변경요청등록 */
	@PostMapping("/sym/prm/EgovProgramChangRequstStre.do")
	@RequireAdmin
	public String insertProgrmChangeRequst(@RequestParam Map<?, ?> commandMap,
			@Valid @ModelAttribute("progrmManageDtlVO") ProgrmManageDtlVO progrmManageDtlVO, BindingResult bindingResult,
			ModelMap model) throws Exception {
		String resultMsg = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 로그인 객체 선언
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		String sLocationUrl = null;
		String sCmd = commandMap.get("cmd") == null ? "" : (String) commandMap.get("cmd");
		if (sCmd.equals("insert")) {
			// beanValidator 처리
			if (bindingResult.hasErrors()) {
				model.addAttribute("progrmManageDtlVO",progrmManageDtlVO);
				sLocationUrl = "egovframework/com/sym/prm/EgovProgramChangRequstStre";
				return sLocationUrl;
			}
			if (progrmManageDtlVO.getChangerqesterCn() == null || progrmManageDtlVO.getChangerqesterCn().equals("")) {
				progrmManageDtlVO.setChangerqesterCn("");
			}
			if (progrmManageDtlVO.getRqesterProcessCn() == null || progrmManageDtlVO.getRqesterProcessCn().equals("")) {
				progrmManageDtlVO.setRqesterProcessCn("");
			}
			// 요청자는 요청값이 아니라 로그인 사용자다(타인 명의 등록 차단)
			progrmManageDtlVO.setRqesterPersonId((user == null || user.getUniqId() == null) ? "" : user.getUniqId());
			progrmManageService.insertProgrmChangeRequst(progrmManageDtlVO);
			resultMsg = egovMessageSource.getMessage("success.common.insert");
			sLocationUrl = "forward:/sym/prm/EgovProgramChangeRequstSelect.do";
		} else {
			/* MAX요청번호 조회 */
			ProgrmManageDtlVO resultVO = progrmManageService.selectProgrmChangeRequstNo(progrmManageDtlVO);
			progrmManageDtlVO.setRqesterNo(resultVO.getRqesterNo());
			progrmManageDtlVO.setRqesterPersonId((user == null || user.getUniqId() == null) ? "" : user.getUniqId());
			sLocationUrl = "egovframework/com/sym/prm/EgovProgramChangRequstStre";
		}
		model.addAttribute("resultMsg", resultMsg);
		return sLocationUrl;
	}

	/**
	 * 프로그램변경 요청을 수정 한다.
	 * 
	 * @param progrmManageDtlVO ProgrmManageDtlVO
	 * @return 출력페이지정보 "forward:/sym/prm/EgovProgramChangeRequstSelect.do"
	 * @exception Exception
	 */
	@PostMapping("/sym/prm/EgovProgramChangRequstDetailSelectUpdt.do")
	@RequireAdmin
	public String updateProgrmChangeRequst(@Valid @ModelAttribute("progrmManageDtlVO") ProgrmManageDtlVO progrmManageDtlVO,
			BindingResult bindingResult, ModelMap model) throws Exception {
		String sLocationUrl = null;
		String resultMsg = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		// 요청자 확인은 요청값이 아니라 DB 원본으로 하고, 저장도 원본 요청자로 한다(타인 요청 탈취 차단)
		ProgrmManageDtlVO stored = progrmManageService.selectProgrmChangeRequst(progrmManageDtlVO);
		EgovAuthorizationHelper.assertOwner(stored == null ? null : stored.getRqesterPersonId());
		progrmManageDtlVO.setRqesterPersonId(stored.getRqesterPersonId());
		// beanValidator 처리
		if (bindingResult.hasErrors()) {
			model.addAttribute("progrmManageDtlVO",progrmManageDtlVO);
			sLocationUrl = "egovframework/com/sym/prm/EgovProgramChangRequstDetailSelectUpdt";
			return sLocationUrl;
		}

		// KISA 보안약점 조치 (2018-10-29, 윤창원)
		if (EgovStringUtil.isNullToString(progrmManageDtlVO.getRqesterPersonId())
				.equals(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()))) {
			if (progrmManageDtlVO.getChangerqesterCn() == null || progrmManageDtlVO.getChangerqesterCn().equals("")) {
				progrmManageDtlVO.setChangerqesterCn(" ");
			}
			if (progrmManageDtlVO.getRqesterProcessCn() == null || progrmManageDtlVO.getRqesterProcessCn().equals("")) {
				progrmManageDtlVO.setRqesterProcessCn(" ");
			}
			progrmManageService.updateProgrmChangeRequst(progrmManageDtlVO);
			resultMsg = egovMessageSource.getMessage("success.common.update");
			sLocationUrl = "forward:/sym/prm/EgovProgramChangeRequstSelect.do";
		} else {
			resultMsg = "수정이 실패하였습니다. 변경요청 수정은 변경요청자만 수정가능합니다.";
			progrmManageDtlVO.setTmpProgrmNm(progrmManageDtlVO.getProgrmFileNm());
			progrmManageDtlVO.setTmpRqesterNo(progrmManageDtlVO.getRqesterNo());
			sLocationUrl = "forward:/sym/prm/EgovProgramChangRequstDetailSelect.do";
		}
		model.addAttribute("resultMsg", resultMsg);
		return sLocationUrl;
	}

	/**
	 * 프로그램변경 요청을 삭제 한다.
	 * 
	 * @param progrmManageDtlVO ProgrmManageDtlVO
	 * @return 출력페이지정보 "forward:/sym/prm/EgovProgramChangeRequstSelect.do"
	 * @exception Exception
	 */
	@PostMapping("/sym/prm/EgovProgramChangRequstDelete.do")
	@RequireAdmin
	public String deleteProgrmChangeRequst(@ModelAttribute("progrmManageDtlVO") ProgrmManageDtlVO progrmManageDtlVO,
			ModelMap model) throws Exception {
		String sLocationUrl = null;
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		// 저장된 변경요청의 요청자(RQESTER_ID, uniqId) 본인만 삭제 가능
		ProgrmManageDtlVO stored = progrmManageService.selectProgrmChangeRequst(progrmManageDtlVO);
		EgovAuthorizationHelper.assertOwner(stored == null ? null : stored.getRqesterPersonId());
		// KISA 보안약점 조치 (2018-10-29, 윤창원)
		if (EgovStringUtil.isNullToString(progrmManageDtlVO.getRqesterPersonId())
				.equals(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()))) {
			model.addAttribute("resultMsg", egovMessageSource.getMessage("success.common.delete"));
			progrmManageService.deleteProgrmChangeRequst(progrmManageDtlVO);
			sLocationUrl = "forward:/sym/prm/EgovProgramChangeRequstSelect.do";
		} else {
			model.addAttribute("resultMsg",
					egovMessageSource.getMessage("comSymPrm.progrmManageController.checkRqesterPersonId")); // 삭제에
																											// 실패하였습니다.
																											// 변경요청자만
																											// 삭제가능합니다.
			sLocationUrl = "forward:/sym/prm/EgovProgramChangRequstDetailSelect.do";
		}
		return sLocationUrl;
	}

	/**
	 * 프로그램변경 요청에 대한 처리 사항을 조회한다.
	 * 
	 * @param searchVO ComDefaultVO
	 * @return 출력페이지정보 "sym/prm/EgovProgramChangeRequstProcess"
	 * @exception Exception
	 */
	@IncludedInfo(name = "프로그램변경요청처리", order = 1113, gid = 60)
	@RequestMapping(value = "/sym/prm/EgovProgramChangeRequstProcessListSelect.do")
	public String selectProgrmChangeRequstProcessList(@ModelAttribute("searchVO") ComDefaultVO searchVO, ModelMap model)
			throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 내역 조회
		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<?> resultList = progrmManageService.selectChangeRequstProcessList(searchVO);
		model.addAttribute("list_changerequst", resultList);

		int totCnt = progrmManageService.selectChangeRequstProcessListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/sym/prm/EgovProgramChangeRequstProcess";
	}

	/**
	 * 프로그램변경 요청에 대한 처리 사항을 상세조회한다.
	 * 
	 * @param progrmManageDtlVO ProgrmManageDtlVO
	 * @return 출력페이지정보 "sym/prm/EgovProgramChangRequstProcessDetailSelectUpdt"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/prm/EgovProgramChangRequstProcessDetailSelect.do")
	@RequireAdmin
	public String selectProgrmChangRequstProcess(
			@ModelAttribute("progrmManageDtlVO") ProgrmManageDtlVO progrmManageDtlVO, ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		if (progrmManageDtlVO.getProgrmFileNm() == null) {
			progrmManageDtlVO.setProgrmFileNm(progrmManageDtlVO.getTmpProgrmNm());
			progrmManageDtlVO.setRqesterNo(progrmManageDtlVO.getTmpRqesterNo());
		}
		ProgrmManageDtlVO resultVO = progrmManageService.selectProgrmChangeRequst(progrmManageDtlVO);
		if (resultVO == null) {
			model.addAttribute("resultMsg", egovMessageSource.getMessage("fail.common.select"));
			return "forward:/sym/prm/EgovProgramChangeRequstProcessListSelect.do";
		}
		if (resultVO.getProcessDe() != null) {
			resultVO.setProcessDe(resultVO.getProcessDe().trim());// 2011.08.22
		}

		if (resultVO.getOpetrId() == null) {
			LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
			resultVO.setOpetrId(user == null ? "" : EgovStringUtil.isNullToString(user.getId()));
		}
		model.addAttribute("progrmManageDtlVO", resultVO);
		return "egovframework/com/sym/prm/EgovProgramChangRequstProcessDetailSelectUpdt";
	}

	/**
	 * 프로그램변경요청처리 내용을 수정 한다.
	 * 
	 * @param progrmManageDtlVO ProgrmManageDtlVO
	 * @return 출력페이지정보
	 *         "forward:/sym/prm/EgovProgramChangeRequstProcessListSelect.do"
	 * @exception Exception
	 */
	@PostMapping("/sym/prm/EgovProgramChangRequstProcessDetailSelectUpdt.do")
	@RequireAdmin
	public String updateProgrmChangRequstProcess(
			@Valid @ModelAttribute("progrmManageDtlVO") ProgrmManageDtlVO progrmManageDtlVO, BindingResult bindingResult,
			ModelMap model) throws Exception {
		String sLocationUrl = null;
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		if (bindingResult.hasErrors()) {
//			sLocationUrl = "forward:/sym/prm/EgovProgramChangRequstProcessDetailSelect.do";
			model.addAttribute("progrmManageDtlVO",progrmManageDtlVO);
			return "egovframework/com/sym/prm/EgovProgramChangRequstProcessDetailSelectUpdt";
//			return sLocationUrl;
		}

		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		// KISA 보안약점 조치 (2018-10-29, 윤창원)
		if (progrmManageDtlVO.getOpetrId() != null) {
			if (progrmManageDtlVO.getOpetrId()
					.equals(user == null ? "" : EgovStringUtil.isNullToString(user.getId()))) {
				if (progrmManageDtlVO.getChangerqesterCn() == null
						|| progrmManageDtlVO.getChangerqesterCn().equals("")) {
					progrmManageDtlVO.setChangerqesterCn(" ");
				}
				if (progrmManageDtlVO.getRqesterProcessCn() == null
						|| progrmManageDtlVO.getRqesterProcessCn().equals("")) {
					progrmManageDtlVO.setRqesterProcessCn(" ");
				}
				progrmManageService.updateProgrmChangeRequstProcess(progrmManageDtlVO);
				model.addAttribute("resultMsg", egovMessageSource.getMessage("success.common.update"));

				ProgrmManageDtlVO vo = new ProgrmManageDtlVO();
				vo = progrmManageService.selectRqesterEmail(progrmManageDtlVO);
				String sTemp = null;
				// KISA 보안약점 조치 (2018-10-29, 윤창원)
				if ("A".equals(progrmManageDtlVO.getProcessSttus())) {
					sTemp = egovMessageSource.getMessage("comSymPrm.progrmManageController.processSttusA"); // 신청중
				} else if ("P".equals(progrmManageDtlVO.getProcessSttus())) {
					sTemp = egovMessageSource.getMessage("comSymPrm.progrmManageController.processSttusP"); // 진행중
				} else if ("R".equals(progrmManageDtlVO.getProcessSttus())) {
					sTemp = egovMessageSource.getMessage("comSymPrm.progrmManageController.processSttusR"); // 반려
				} else if ("C".equals(progrmManageDtlVO.getProcessSttus())) {
					sTemp = egovMessageSource.getMessage("comSymPrm.progrmManageController.processSttusC"); // 처리완료
				}
				// 프로그램 변경요청 사항을 이메일로 발송한다.(메일연동솔루션 활용)
				SndngMailVO sndngMailVO = new SndngMailVO();
				sndngMailVO.setDsptchPerson(user == null ? "" : EgovStringUtil.isNullToString(user.getId()));
				sndngMailVO.setRecptnPerson(vo.getTmpEmail());
				sndngMailVO.setSj(egovMessageSource.getMessage("comSymPrm.progrmManageController.email.Sj")); // 프로그램변경요청
																												// 처리.
				sndngMailVO.setEmailCn(
						egovMessageSource.getMessage("comSymPrm.progrmManageController.email.emailCn") + " : " + sTemp); // 프로그램
																															// 변경요청
																															// 사항이
																															// 처리
																															// 되었습니다
				sndngMailVO.setAtchFileId(null);
				sndngMailRegistService.insertSndngMail(sndngMailVO);
				sLocationUrl = "forward:/sym/prm/EgovProgramChangeRequstProcessListSelect.do";
			} else {
				model.addAttribute("resultMsg", egovMessageSource
						.getMessage("comSymPrm.progrmManageController.updateProgrmChangRequstProcess.fail")); // 수정이
																												// 실패하였습니다.
																												// 변경요청처리
																												// 수정은
																												// 변경처리해당
																												// 담당자만
																												// 처리가능합니다.
				progrmManageDtlVO.setTmpProgrmNm(progrmManageDtlVO.getProgrmFileNm());
				progrmManageDtlVO.setTmpRqesterNo(progrmManageDtlVO.getRqesterNo());
				sLocationUrl = "forward:/sym/prm/EgovProgramChangRequstProcessDetailSelect.do";
			}
		}
		return sLocationUrl;
	}

	/**
	 * 프로그램변경요청처리를 삭제 한다.
	 * 
	 * @param progrmManageDtlVO ProgrmManageDtlVO
	 * @return 출력페이지정보
	 *         "forward:/sym/prm/EgovProgramChangeRequstProcessListSelect.do"
	 * @exception Exception
	 */
	/* 프로그램변경요청처리 삭제 */
	@PostMapping("/sym/prm/EgovProgramChangRequstProcessDelete.do")
	@RequireAdmin
	public String deleteProgrmChangRequstProcess(
			@ModelAttribute("progrmManageDtlVO") ProgrmManageDtlVO progrmManageDtlVO, ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 저장된 변경요청의 요청자(RQESTER_ID, uniqId) 본인만 삭제 가능
		ProgrmManageDtlVO stored = progrmManageService.selectProgrmChangeRequst(progrmManageDtlVO);
		EgovAuthorizationHelper.assertOwner(stored == null ? null : stored.getRqesterPersonId());
		progrmManageService.deleteProgrmChangeRequst(progrmManageDtlVO);

		return "forward:/sym/prm/EgovProgramChangeRequstProcessListSelect.do";
	}

	/**
	 * 프로그램변경이력리스트를 조회한다.
	 * 
	 * @param searchVO ComDefaultVO
	 * @return 출력페이지정보 "sym/prm/EgovProgramChgHst"
	 * @exception Exception
	 */
	@IncludedInfo(name = "프로그램변경이력", order = 1114, gid = 60)
	@RequestMapping(value = "/sym/prm/EgovProgramChgHstListSelect.do")
	public String selectProgrmChgHstList(@ModelAttribute("searchVO") ComDefaultVO searchVO, ModelMap model)
			throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 내역 조회
		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<ProgrmManageDtlVO> resultList = progrmManageService.selectProgrmChangeRequstList(searchVO);
		model.addAttribute("list_changerequst", resultList);

		int totCnt = progrmManageService.selectProgrmChangeRequstListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/sym/prm/EgovProgramChgHst";
	}

	/* 프로그램변경이력상세조회 */
	/**
	 * 프로그램변경이력을 상세조회한다.
	 * 
	 * @param progrmManageDtlVO ProgrmManageDtlVO
	 * @return 출력페이지정보 "sym/prm/EgovProgramChgHstDetail"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/prm/EgovProgramChgHstListDetailSelect.do")
	@RequireAdmin
	public String selectProgramChgHstListDetail(
			@ModelAttribute("progrmManageDtlVO") ProgrmManageDtlVO progrmManageDtlVO, ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		progrmManageDtlVO.setProgrmFileNm(progrmManageDtlVO.getTmpProgrmNm());
		progrmManageDtlVO.setRqesterNo(progrmManageDtlVO.getTmpRqesterNo());

		ProgrmManageDtlVO resultVO = progrmManageService.selectProgrmChangeRequst(progrmManageDtlVO);
		model.addAttribute("resultVO", resultVO);
		return "egovframework/com/sym/prm/EgovProgramChgHstDetail";
	}

	/**
	 * 프로그램파일명을 조회한다.
	 * 
	 * @param searchVO ComDefaultVO
	 * @return 출력페이지정보 "sym/prm/EgovFileNmSearch"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/prm/EgovProgramListSearch.do")
	@RequireAdmin
	public String selectProgrmListSearch(@ModelAttribute("searchVO") ComDefaultVO searchVO, ModelMap model)
			throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 내역 조회
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<ProgrmManageVO> resultList = progrmManageService.selectProgrmList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = progrmManageService.selectProgrmListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/sym/prm/EgovFileNmSearch";
	}

	/**
	 * 프로그램파일명을 조회한다. (New)
	 * 
	 * @param searchVO ComDefaultVO
	 * @return 출력페이지정보 "sym/prm/EgovFileNmSearch"
	 * @exception Exception
	 */
	@RequestMapping(value = "/sym/prm/EgovProgramListSearchNew.do")
	@RequireAdmin
	public String selectProgrmListSearchNew(@ModelAttribute("searchVO") ComDefaultVO searchVO, ModelMap model)
			throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}
		// 내역 조회
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<ProgrmManageVO> resultList = progrmManageService.selectProgrmList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = progrmManageService.selectProgrmListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/sym/prm/EgovFileNmSearchNew";
	}
}