package egovframework.com.uss.olh.omm.web;

import egovframework.com.cmm.annotation.RequireAdmin;

import java.util.List;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.service.CmmnDetailCode;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.uss.olh.omm.service.EgovOnlineManualService;
import egovframework.com.uss.olh.omm.service.OnlineManualVO;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

/**
 * 온라인메뉴얼를 처리하는 Controller Class 구현
 * 
 * @author 공통서비스 장동한
 * @since 2009.07.03
 * @version 1.0
 * @see
 *
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.07.03  장동한          최초 생성
 *   2011.08.26  정진오          IncludedInfo annotation 추가
 *   2016.08.12  김연호          표준프레임워크 3.6 개선
 *   2025.08.21  이백행          2025년 컨트리뷰션 PMD로 소프트웨어 보안약점 진단하고 제거하기-LocalVariableNamingConventions(final이 아닌 변수는 밑줄을 포함할 수 없음)
 *
 *      </pre>
 */
@Controller
public class EgovOnlineManualController {
	private static final Logger LOGGER = LoggerFactory.getLogger(EgovOnlineManualController.class);

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	/** egovOnlinePollService */
	@Resource(name = "EgovOnlineManualService")
	private EgovOnlineManualService egovOnlineManualService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/** Egov Common Code Service */
	@Resource(name = "EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	/**
	 * 사용자 온라인메뉴얼 목록을 조회한다.
	 * 
	 * @param searchVO
	 * @param onlineManual
	 * @param model
	 * @return "egovframework/com/uss/olh/omn/EgovOnlineManualList"
	 * @throws Exception
	 */
	@IncludedInfo(name = "사용자온라인매뉴얼", order = 571, gid = 50)
	@RequestMapping(value = "/uss/olh/omn/selectOnlineManualList.do")
	public String selectOnlineManualUserList(@ModelAttribute("searchVO") OnlineManualVO searchVO, ModelMap model)
			throws Exception {

		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<OnlineManualVO> resultList = egovOnlineManualService.selectOnlineManualList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = egovOnlineManualService.selectOnlineManualListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/uss/olh/omm/EgovOnlineManualUserList";
	}

	/**
	 * 사용자온라인메뉴얼 상세조회 조회한다.
	 * 
	 * @param searchVO
	 * @param onlineManualVO
	 * @param model
	 * @return "/uss/olh/omn/EgovOnlineManualUserDetail"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/omn/selectOnlineManualDetail.do")
	@RequireAdmin
	public String selectOnlineManualUserDetail(@ModelAttribute("searchVO") OnlineManualVO searchVO,
			OnlineManualVO onlineManualVO, ModelMap model) throws Exception {

		OnlineManualVO result = egovOnlineManualService.selectOnlineManualDetail(onlineManualVO);
		model.addAttribute("result", result);

		return "egovframework/com/uss/olh/omm/EgovOnlineManualUserDetail";
	}

	/**
	 * 온라인메뉴얼 목록을 조회한다.
	 * 
	 * @param searchVO
	 * @param onlineManual
	 * @param model
	 * @return "egovframework/com/uss/olh/omm/EgovOnlineManualList"
	 * @throws Exception
	 */
	@IncludedInfo(name = "온라인매뉴얼", order = 570, gid = 50)
	@RequestMapping(value = "/uss/olh/omm/selectOnlineManualList.do")
	public String selectOnlineManualList(@ModelAttribute("searchVO") OnlineManualVO searchVO, ModelMap model)
			throws Exception {

		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<OnlineManualVO> resultList = egovOnlineManualService.selectOnlineManualList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = egovOnlineManualService.selectOnlineManualListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/uss/olh/omm/EgovOnlineManualList";
	}

	/**
	 * 온라인메뉴얼 상세조회 조회한다.
	 * 
	 * @param searchVO
	 * @param onlineManualVO
	 * @param model
	 * @return "/uss/olh/omm/EgovOnlineManualDetail"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/omm/selectOnlineManualDetail.do")
	@RequireAdmin
	public String selectOnlineManualDetail(@ModelAttribute("searchVO") OnlineManualVO searchVO,
			OnlineManualVO onlineManualVO, ModelMap model) throws Exception {

		OnlineManualVO result = egovOnlineManualService.selectOnlineManualDetail(onlineManualVO);
		model.addAttribute("result", result);

		return "egovframework/com/uss/olh/omm/EgovOnlineManualDetail";
	}

	/**
	 * 온라인메뉴얼을 등록하기 위한 전 처리(공통코드 처리)
	 * 
	 * @param searchVO
	 * @param model
	 * @return "/uss/olh/omm/EgovOnlineManualRegist"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/omm/insertOnlineManualView.do")
	@RequireAdmin
	public String insertOnlineManualView(@ModelAttribute("searchVO") OnlineManualVO searchVO, Model model)
			throws Exception {

		// 공통코드를 가져오기 위한 Vo
		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		vo.setCodeId("COM041");

		List<CmmnDetailCode> onlineMnlSeCode = cmmUseService.selectCmmCodeDetail(vo);
		model.addAttribute("onlineMnlSeCode", onlineMnlSeCode);

		model.addAttribute("onlineManualVO", new OnlineManualVO());

		return "egovframework/com/uss/olh/omm/EgovOnlineManualRegist";

	}

	/**
	 * 온라인메뉴얼을 등록한다.
	 * 
	 * @param searchVO
	 * @param onlineManualVO
	 * @param bindingResult
	 * @return "forward:/uss/olh/awm/selectAdministrationWordManageList.do"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/omm/insertOnlineManual.do")
	@RequireAdmin
	public String insertOnlineManual(@ModelAttribute("searchVO") OnlineManualVO searchVO,
			@Valid @ModelAttribute("onlineManualVO") OnlineManualVO onlineManualVO, BindingResult bindingResult,
			Model model)
			throws Exception {

		if (bindingResult.hasErrors()) {
			ComDefaultCodeVO vo = new ComDefaultCodeVO();
			vo.setCodeId("COM041");

			List<CmmnDetailCode> onlineMnlSeCode = cmmUseService.selectCmmCodeDetail(vo);
			model.addAttribute("onlineMnlSeCode", onlineMnlSeCode);
			return "egovframework/com/uss/olh/omm/EgovOnlineManualRegist";
		}

		// 로그인VO에서 사용자 정보 가져오기
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		String frstRegisterId = loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId());

		onlineManualVO.setFrstRegisterId(frstRegisterId); // 최초등록자ID
		onlineManualVO.setLastUpdusrId(frstRegisterId); // 최종수정자ID

		egovOnlineManualService.insertOnlineManual(onlineManualVO);

		return "forward:/uss/olh/omm/selectOnlineManualList.do";
	}

	/**
	 * 온라인메뉴얼을 수정하기 위한 전 처리(공통코드 처리)
	 * 
	 * @param onlineMnlId
	 * @param searchVO
	 * @param model
	 * @return "/uss/olh/omm/EgovOnlineManualUpdt"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/omm/updateOnlineManualView.do")
	@RequireAdmin
	public String updateOnlineManualView(@RequestParam("onlineMnlId") String onlineMnlId,
			@ModelAttribute("searchVO") OnlineManualVO searchVO, ModelMap model) throws Exception {

		// 공통코드를 가져오기 위한 Vo
		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		vo.setCodeId("COM041");

		List<CmmnDetailCode> onlineMnlSeCode = cmmUseService.selectCmmCodeDetail(vo);
		model.addAttribute("onlineMnlSeCode", onlineMnlSeCode);

		OnlineManualVO onlineManualVO = new OnlineManualVO();
		onlineManualVO.setOnlineMnlId(onlineMnlId);

		OnlineManualVO stored = EgovAuthorizationHelper.requireTarget(egovOnlineManualService.selectOnlineManualDetail(onlineManualVO));
		model.addAttribute("onlineManualVO", stored);

		return "egovframework/com/uss/olh/omm/EgovOnlineManualUpdt";
	}

	/**
	 * 온라인메뉴얼을 수정한다.
	 * 
	 * @param searchVO
	 * @param onlineManualVO
	 * @param bindingResult
	 * @return "forward:/uss/olh/omm/selectOnlineManualList.do"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/omm/updateOnlineManual.do")
	@RequireAdmin
	public String updateOnlineManual(HttpServletRequest request, @ModelAttribute("searchVO") OnlineManualVO searchVO,
			@Valid @ModelAttribute("onlineManualVO") OnlineManualVO onlineManualVO, BindingResult bindingResult,
			Model model)
			throws Exception {


		if (bindingResult.hasErrors()) {
			ComDefaultCodeVO vo = new ComDefaultCodeVO();
			vo.setCodeId("COM041");

			List<CmmnDetailCode> onlineMnlSeCode = cmmUseService.selectCmmCodeDetail(vo);
			model.addAttribute("onlineMnlSeCode", onlineMnlSeCode);
			return "egovframework/com/uss/olh/omm/EgovOnlineManualUpdt";
		}

		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		String lastUpdusrId = loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId());

		onlineManualVO.setLastUpdusrId(lastUpdusrId); // 최종수정자ID
		egovOnlineManualService.updateOnlineManual(onlineManualVO);

		return "forward:/uss/olh/omm/selectOnlineManualList.do";

	}

	/**
	 * 온라인메뉴얼을 삭제한다.
	 * 
	 * @param onlineManualVO
	 * @param searchVO
	 * @return "forward:/uss/olh/omm/selectOnlineManualList.do"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/omm/deleteOnlineManual.do")
	@RequireAdmin
	public String deleteOnlineManual(HttpServletRequest request, OnlineManualVO onlineManualVO,
			@ModelAttribute("searchVO") OnlineManualVO searchVO) throws Exception {


		egovOnlineManualService.deleteOnlineManual(onlineManualVO);

		return "forward:/uss/olh/omm/selectOnlineManualList.do";
	}
}
