<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%-- <%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%> --%>
<c:set var="pageTitle"><spring:message code="comCopBbs.articleVO.title"/></c:set>
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript" src="<c:url value='/js/egovframework/com/cmm/egovPostNavigate.js' />"></script>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>${pageTitle} <spring:message code="title.list" /></title><!-- 블로그 메인 목록 -->

<link type="text/css" rel="stylesheet" href="<c:url value='/css/egovframework/com/cop/bbs/style.css' />">
<script src="<c:url value='/js/egovframework/com/cmm/jquery-1.12.4.min.js' />"></script>

<!-- 댓글 작성 스크립트  -->
<script type="text/javascript" src="<c:url value="/js/egovframework/com/cmm/EgovValidation.js" />"></script>

<script>
var csrfHeaderName = "${_csrf.headerName}";
var csrfToken = "${_csrf.token}";
var sessionUniqId = "<c:out value='${sessionUniqId}'/>";
function egovCsrfBeforeSend(xhr) {
	if (csrfHeaderName && csrfToken) {
		xhr.setRequestHeader(csrfHeaderName, csrfToken);
	}
}

// 2026.07.30 보안 조치 - innerHTML/.html()에 삽입되는 값 이스케이프
function escapeHtml(value) {
	if (value == null) {
		return '';
	}
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}


/*********************************************************
 * 페이징 처리 함수
 ******************************************************** */
function fn_egov_select_linkPage(pageNo){
	document.articleForm.pageIndex.value = pageNo;
	document.articleForm.action = "<c:url value='/cop/bbs/selectArticleBlogList.do'/>";
   	document.articleForm.submit();
}

function layer_toggle(ma) {
	 if (ma.style.display == 'none') {
		 ma.style.display = 'block'; 
		 document.getElementById('blog_cnt').style.display = 'none';
	}else{
		 ma.style.display = 'none'; 
		 document.getElementById('blog_cnt').style.display = 'block';
	 }
 }

function fn_egov_loadBdList(bbsId,blogNm,cnt){
	document.blogfrm.bbsId.value = bbsId;
	var searchCnd = document.postCnt.searchCnd.value;
	$('#sub').text(blogNm);
	$(".comm_List").empty();
	$.ajax({
		beforeSend: egovCsrfBeforeSend,
		url :"<c:url value='/cop/bbs/selectArticleBlogDetail.do'/>"
        ,type: "POST"
        	,data : {"bbsId":bbsId, "searchCnd":searchCnd}
        ,dataType: 'json'  	   
        ,success : function(data){
        	var innerHtml = "";
        	var innerReply = "";
        	var innerPaging = "";
        	var length = data['blogSubJectList'].length;
        	if(length > 0) {
        		var targetSet = false;
        		$.each(data['blogSubJectList'], function(i) {
        	          innerHtml += '<tr>';
        	          // 비밀글이며 작성자가 본인이 아닌 경우(클릭 불가) — 게시판 목록(EgovArticleList.jsp)과 같다
        	          if(data['blogSubJectList'][i].secretAt == 'Y' && data['blogSubJectList'][i].frstRegisterId != sessionUniqId) {
        	        	  innerHtml +=    '<td><img src="<c:url value='/images/egovframework/com/cop/bbs/icon_lock.png'/>" alt="secret">&nbsp;';
        	          } else {
        	        	  // 진입 시 자동으로 여는 글(#target)은 첫 번째 클릭 가능한 글
        	        	  innerHtml +=    '<td' + (targetSet ? '' : ' id="target"') + ' onclick="fn_clickComm(\'' + bbsId + '\', \''+data['blogSubJectList'][i].nttId+'\', \''+data['blogSubJectList'][i].ntcrId+'\', \''+data['blogSubJectList'][i].replyPosblAt+'\', \''+data['blogSubJectList'][i].blogId+'\', \''+cnt+'\')"; style="cursor:pointer">';
        	        	  targetSet = true;
        	          }
        	          if(data['blogSubJectList'][i].commentCo != "") {
        	        	  innerHtml +=      escapeHtml(data['blogSubJectList'][i].nttSj)+"["+escapeHtml(data['blogSubJectList'][i].commentCo)+"]";
        	          }else{
        	        	  innerHtml +=      escapeHtml(data['blogSubJectList'][i].nttSj);
        	          }
        	          innerHtml +=    '</td>';
        	          innerHtml +=    '<td>';
        	          innerHtml +=      escapeHtml(data['blogSubJectList'][i].frstRegisterPnttm);
        	          innerHtml +=    '</td>';
        	          innerHtml += '</tr>';
        	          
        		});
        		
        		innerPaging += '<ul>';
  	          	innerPaging += '<ui:pagination paginationInfo="${paginationInfo}" type="image" jsFunction="fn_egov_select_linkPage"/>';
  	          	innerPaging += '</ul>';
  	          	
        		$("#subtitle").html(innerHtml);
        		$("#paging").html(innerPaging);
        		$("#target").click(); //댓글표시
        		if(data['blogCnOne'].nttCn != null){
        			$(".cnt").html(data['blogCnOne'].nttCn);	
        		}
        	}
		}
	    ,error: function(){
	    	alert("<spring:message code="comCopBlog.articleBlogList.validate.noResult" />");//게시글이 없습니다!\n게시글을 등록해 주세요.
	    }
	});
}

function fn_blog_cn(blogId){
	var bbsId = document.blogfrm.bbsId.value;
	if (bbsId == '' || bbsId == null) {
		alert('<spring:message code="comCopBlog.articleBlogList.validate.noBoard" />'); //등록된 게시판이 없습니다.\n카테고리등록을 통해 게시판을 생성해주세요.
		return;
	}

	fn_egov_postNavigate("<c:url value='/cop/bbs/insertArticleView.do' />", {bbsId: bbsId, blogAt: 'Y', blogId: blogId}, document.blogfrm);
}

function fn_clickComm(bbsId, nttId, ntcrId, replyPosblAt, blogId, cnt){
	$.ajax({
		beforeSend: egovCsrfBeforeSend,
		url :"<c:url value='/cop/bbs/selectArticleBlogDetailCn.do'/>"
        ,type: "POST"
        ,data : {"bbsId":bbsId, "nttId":nttId}
        ,dataType: 'json'  	   
        ,success : function(data){
        	var length = data['blogCnList'].length;
        	var innerHtml = "";
        	var innerReply = "";
        	if(length > 0) {
        		$.each(data['blogCnList'], function(i) {
                      innerHtml += data['blogCnList'][i].nttCn; // 서버에서 EgovHtmlSanitizer 로 정제한 리치 텍스트
        		});
        		$(".cnt").html(innerHtml);
        		
        		$('input[name=bbsId]').attr('value',bbsId);
        		$('input[name=nttId]').attr('value',nttId);
        		$('input[name=blogId]').attr('value',blogId);
        		
        		$.each(data['resultList'], function(i) {
        			innerReply += "<dl>";
        			innerReply += "<dt>";
        			innerReply += "<strong>";
                    innerReply += escapeHtml(data['resultList'][i].wrterNm);
        			innerReply += "</strong>";
        			innerReply += "<span>"
                    innerReply += escapeHtml(data['resultList'][i].frstRegisterPnttm);
        			innerReply += "</span>"
        			
       				if(cnt == 1) {
           				innerReply += "<div align='right'>";
           				innerReply += '<a href="javascript:fn_egov_deleteCommentList(\''+data['resultList'][i].commentNo+'\', \''+bbsId+'\', \''+nttId+'\', \''+blogId+'\')" ><spring:message code="button.delete" /></a>';//삭제
           				innerReply += "</div>";
           			}
        			
        			innerReply += "</dt>";
        			innerReply += "<dd>";
                    innerReply += escapeHtml(data['resultList'][i].commentCn);
        			innerReply += "</dd>";
        			innerReply += "</dl>";
      			});
        		innerReply += "<dl>";
        		innerReply += "<dd>";
        		innerReply += "<form id='formComment' name='formComment' method='post'><c:if test="${not empty _csrf}"><input type='hidden' name='${_csrf.parameterName}' value='${_csrf.token}'/></c:if>";
        		innerReply += "<textarea name='commentCn' placeholder='<spring:message code="comCopBlog.articleBlogList.validate.limitSize" />'/>";//댓글은 500byte 까지 작성할 수 있습니다.
        		innerReply += "<button type='button' onclick='fn_egov_insert_commentList(\""+bbsId+"\", \""+nttId+"\", \""+blogId+"\");'><spring:message code="title.create"/></button>";//등록
        		innerReply += "<input name='bbsId' type='hidden' value=''>";
        		innerReply += "<input name='nttId' type='hidden' value=''>";
        		innerReply += "<input name='blogId' type='hidden' value=''>";
        		innerReply += "<input name='modified' type='hidden' value=''>";
        		innerReply += "<input name='commentNo' type='hidden' value=''>";
        		innerReply += "<input name='blogAt' type='hidden' value='Y'>";
        		innerReply += "</form>";
        		innerReply += "</dd>";
        		innerReply += "</dl>";
        		$(".comm_List").html(innerReply);
        	}else{
		  	          innerHtml += "<spring:message code="comCopBlog.articleBlogList.validate.noContent" />";//본문 내용이 존재하지 않습니다!
		  	    $(".cnt").html(innerHtml);
        	}
		}
	    ,error: function(){
	    	alert("<spring:message code="comCopBlog.articleBlogList.validate.occurError" />");//에러가 발생했습니다.
	    }
	});
}

function fn_egov_deleteCommentList(commentNo, bbsId, nttId, blogId) {

	var form = document.getElementById("formComment");
	
	if (confirm('<spring:message code="common.delete.msg" />')) {
		form.modified.value = "true";
		form.commentNo.value = commentNo;
		form.bbsId.value = bbsId;
		form.nttId.value = nttId;
		form.blogId.value = blogId;
		form.action = "<c:url value='/cop/cmt/deleteArticleComment.do'/>";
		form.submit();
	}
}

function fn_egov_insert_commentList(bbsId, nttId, blogId) {
	document.formComment.bbsId.value = bbsId;
	document.formComment.nttId.value = nttId;
	document.formComment.blogId.value = blogId;
	document.formComment.modified.value = false;
  	document.formComment.action = "<c:url value='/cop/cmt/insertArticleComment.do'/>";
  	
  	
	if (!validateFormComment(document.formComment)){
		return;
	}
	if (confirm('<spring:message code="common.regist.msg" />')) {
		document.formComment.submit();
	}

  	
}

$(document).ready(function() { 
	$("#titleck").click();
});

</script>
</head>
<body>
<!-- 블로그 -->
<div class="blog_wrap">
	<!-- header -->
	<div class="blog_header">
		<div class="visual_default">
			<h1>${boardMasterVO.blogNm}</h1>
			<p>${boardMasterVO.blogIntrcn}</p>
		</div>
		<div class="h_menu">
			<ul class="gnb">
				<c:forEach items="${blogNameList}" var="resultInfo" varStatus="status">
					<li><a id="titleck" onclick="fn_egov_loadBdList('<c:out value="${resultInfo.bbsId}"/>','<c:out value="${resultInfo.bbsNm}" />','<c:out value="${loginUserCnt}"/>');"><c:out value="${resultInfo.bbsNm}" /></a></li>
				</c:forEach>
			</ul>
		
			<ul class="gnb r">
			<c:choose>
				<c:when test="${loginUserCnt == 1}">
				<li><a href="<c:url value='/cop/bbs/insertBBSMasterView.do?blogId=${boardMasterVO.blogId}&blogAt=Y' />"><spring:message code="comCopBlog.articleBlogList.regCategory" /></a></li><!-- 카테고리등록 -->
				<li><a href="<c:url value='/cop/bbs/selectBlogListManager.do?blogId=${boardMasterVO.blogId}' />" ><spring:message code="comCopBlog.blogUseMgrMain.btnBoard" /></a></li> <!-- 개인블로그관리  -->
			</ul>
				<button class="write" onclick="fn_blog_cn('${boardMasterVO.blogId}')"><spring:message code="button.create" /></button>
				</c:when>
			</c:choose>
		</div>
	</div>
	<!-- header //-->

	<!-- 블로그 리스트 -->
	<div class="post">
		<div class="post_title">
			<p id="sub"></p>
		</div>

		<div class="listBox">
			<table class="tbl_list">
				<caption>${pageTitle} <spring:message code="title.list" /></caption><!-- 블로그 메인 리스트 -->
				<colgroup>
					<col style="width: ;" />
					<col style="width:10%" />
				</colgroup>
				<tbody id=subtitle>
				</tbody>
			</table>
			<form name="postCnt" method="post" onChange="$('#titleck').click();">
				<c:if test="${not empty _csrf}"><input type="hidden" name="${_csrf.parameterName}" value="${_csrf.token}"/></c:if>
				<div class="post_opt">
					<label for="" class="blind"><spring:message code="comCopBlog.articleBlogList.setListNumbers" /></label><!-- 포스트 개수 설정 -->
					<select name="searchCnd" id="searchCnd">
						<option value="5"  <c:if test="${searchVO.searchCnd == '5'}">selected="selected"</c:if>><spring:message code="comCopBlog.articleBlogList.listNumber5" /></option><!-- 5줄 보기 -->
						<option value="10" <c:if test="${searchVO.searchCnd == '10'}">selected="selected"</c:if>><spring:message code="comCopBlog.articleBlogList.listNumber10" /></option><!-- 10줄 보기 -->
						<option value="15" <c:if test="${searchVO.searchCnd == '15'}">selected="selected"</c:if>><spring:message code="comCopBlog.articleBlogList.listNumber15" /></option><!-- 15줄 보기 -->
						<option value="20" <c:if test="${searchVO.searchCnd == '20'}">selected="selected"</c:if>><spring:message code="comCopBlog.articleBlogList.listNumber20" /></option><!-- 20줄 보기 -->
						<option value="30" <c:if test="${searchVO.searchCnd == '30'}">selected="selected"</c:if>><spring:message code="comCopBlog.articleBlogList.listNumber30" /></option><!-- 30줄 보기 -->
					</select>
				</div>
			</form>
			<div id="paging" class="paging">
			</div>
		</div>
	</div>
	<!-- 블로그 리스트 //-->
	
	<!-- 블로그 본문 -->
	<div id="blog_cnt" class="blog_cnt" style="display:block;">
		<div class="blog_title">
		<!-- 본문타이틀 -->
		</div>
		<div class="cnt">
		<!-- 본문내용 -->
		</div>
		<!-- 댓글 -->
		<div class="comm_List" >
		</div>
	</div>
	<!-- 블로그 본문 //-->
</div>

<!-- 블로그 //-->
<form name="blogfrm">
<input name="blogCn" type="hidden" value="">
<input name="blogName" type="hidden" value="">
<input name="bbsId" type="hidden" value="">
</form>
</body>
</html>