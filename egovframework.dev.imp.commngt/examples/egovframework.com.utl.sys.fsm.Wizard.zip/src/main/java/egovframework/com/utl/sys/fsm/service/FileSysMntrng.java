package egovframework.com.utl.sys.fsm.service;

import java.io.Serializable;

import org.egovframe.rte.ptl.reactive.validation.EgovEmailCheck;
import org.egovframe.rte.ptl.reactive.validation.EgovNullCheck;
import jakarta.validation.constraints.Size;

/**
 * 개요
 * - 파일시스템 모니터링대상에 대한 model 클래스를 정의한다.
 *
 * 상세내용
 * - 파일시스템ID, 파일시스템명, 파일시스템관리명, 파일시스템크기, 파일시스템임계치, 파일시스템임계율, 파일시스템사용량, 파일시스템사용률, 관리자명, 관리자이메일주소, 서비스상태, 생성일시 항목을 관리한다.
 * @author 장철호
 * @version 1.0
 * @created 28-6-2010 오전 11:33:26
 */
@SuppressWarnings("serial")
public class FileSysMntrng implements Serializable  {

	/**
	 * 파일시스템ID
	 */
	private String fileSysId;
	/**
	 * 파일시스템명
	 */
	@EgovNullCheck
	@Size(max=60)
	private String fileSysNm;
	/**
	 * 파일시스템관리명
	 */
	@EgovNullCheck
	@Size(max=255)
	private String fileSysManageNm;
	/**
	 * 파일시스템크기
	 */
	@EgovNullCheck
	private Integer fileSysMg;
	/**
	 * 파일시스템임계치
	 */
	@EgovNullCheck
	private Integer fileSysThrhld;
	/**
	 * 파일시스템임계치율
	 */
	private Integer fileSysThrhldRt;
	/**
	 * 파일시스템사용량
	 */
	private Integer fileSysUsgQty;
	/**
	 * 파일시스템사용률
	 */
	private Double fileSysUsgRt;
	/**
	 * 관리자명
	 */
	@EgovNullCheck
	@Size(max=60)
	private String mngrNm;
	/**
	 * 관리자이메일주소
	 */
	@EgovNullCheck
	@EgovEmailCheck
	@Size(max=50)
	private String mngrEmailAddr;
	/**
	 * 로그정보
	 */
	private String logInfo;
	/**
	 * 모니터링상태
	 */
	private String mntrngSttus;
	/**
	 * 생성일시
	 */
	private String creatDt;
	/**
	 * 최초등록자ID
	 */
	private String frstRegisterId = "";
	/**
	 * 최초등록시점
	 */
	private String frstRegisterPnttm = "";
	/**
	 * 최종수정자ID
	 */
	private String lastUpdusrId = "";
	/**
	 * 최종수정시점
	 */
	private String lastUpdusrPnttm = "";

	public String getFileSysId() {
		return fileSysId;
	}
	public void setFileSysId(String fileSysId) {
		this.fileSysId = fileSysId;
	}
	public String getFileSysNm() {
		return fileSysNm;
	}
	public void setFileSysNm(String fileSysNm) {
		this.fileSysNm = fileSysNm;
	}
	public String getFileSysManageNm() {
		return fileSysManageNm;
	}
	public void setFileSysManageNm(String fileSysManageNm) {
		this.fileSysManageNm = fileSysManageNm;
	}
	public Integer getFileSysMg() {
		return fileSysMg;
	}
	public void setFileSysMg(Integer fileSysMg) {
		this.fileSysMg = fileSysMg;
	}
	public Integer getFileSysThrhld() {
		return fileSysThrhld;
	}
	public void setFileSysThrhld(Integer fileSysThrhld) {
		this.fileSysThrhld = fileSysThrhld;
	}
	public Integer getFileSysThrhldRt() {
		return fileSysThrhldRt;
	}
	public void setFileSysThrhldRt(Integer fileSysThrhldRt) {
		this.fileSysThrhldRt = fileSysThrhldRt;
	}
	public Integer getFileSysUsgQty() {
		return fileSysUsgQty;
	}
	public void setFileSysUsgQty(Integer fileSysUsgQty) {
		this.fileSysUsgQty = fileSysUsgQty;
	}
	public Double getFileSysUsgRt() {
		return fileSysUsgRt;
	}
	public void setFileSysUsgRt(double fileSysUsgRt) {
		this.fileSysUsgRt = fileSysUsgRt;
	}
	public String getMngrNm() {
		return mngrNm;
	}
	public void setMngrNm(String mngrNm) {
		this.mngrNm = mngrNm;
	}
	public String getMngrEmailAddr() {
		return mngrEmailAddr;
	}
	public void setMngrEmailAddr(String mngrEmailAddr) {
		this.mngrEmailAddr = mngrEmailAddr;
	}
	public String getLogInfo() {
		return logInfo;
	}
	public void setLogInfo(String logInfo) {
		this.logInfo = logInfo;
	}
	public String getMntrngSttus() {
		return mntrngSttus;
	}
	public void setMntrngSttus(String mntrngSttus) {
		this.mntrngSttus = mntrngSttus;
	}
	public String getCreatDt() {
		return creatDt;
	}
	public void setCreatDt(String creatDt) {
		this.creatDt = creatDt;
	}
	public String getFrstRegisterId() {
		return frstRegisterId;
	}
	public void setFrstRegisterId(String frstRegisterId) {
		this.frstRegisterId = frstRegisterId;
	}
	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}
	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}
	public String getLastUpdusrId() {
		return lastUpdusrId;
	}
	public void setLastUpdusrId(String lastUpdusrId) {
		this.lastUpdusrId = lastUpdusrId;
	}
	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}
	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}


}