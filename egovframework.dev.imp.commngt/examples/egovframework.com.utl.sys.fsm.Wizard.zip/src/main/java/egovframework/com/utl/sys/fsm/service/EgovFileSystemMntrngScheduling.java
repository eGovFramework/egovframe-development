package egovframework.com.utl.sys.fsm.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;

import egovframework.com.cmm.EgovWebUtil;
import egovframework.com.utl.fcc.service.EgovDateUtil;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;

/**
 * 개요
 * - 네트워크서비스 모니터링을 위한 스케줄링클래스를 정의한다.
 *
 * 상세내용
 * - 네트워크서비스 모니터링 기능을 제공한다.
 * - 네트워크서비스 모니터링 결과를 관리자에게 이메일로 전송한다.
 * @author 장철호
 * @version 1.0
 * @created 28-6-2010 오전 11:33:43
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *  수정일       수정자     수정내용
 *  ----------   --------   ---------------------------
 *  2017.03.03 	 조성원 	시큐어코딩(ES)-Null Pointer 역참조[CWE-476]
 *  2022.11.11   김혜준   시큐어코딩 처리
 *  2024.05.02   김수용   NSR 보안조치 (파일시스템명에서 악의적인 문자열 제거)
 *  2026.07.10   EricSeokgon   이메일 본문 생성 시 문자열 연결(+=)을 StringBuilder로 변경(불필요한 중간 String 생성 제거)
 *
 */

@Service("egovFileSysMntrngScheduling")
public class EgovFileSystemMntrngScheduling extends EgovAbstractServiceImpl {

	@Resource(name="EgovFileSysMntrngService")
	private EgovFileSysMntrngService ntwrkSvcMntrngService;

	@Resource(name="mntrngMailSender")
    private MailSender mntrngMailSender;

    @Resource(name="mntrngMessage")
    private SimpleMailMessage mntrngMessage;

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovFileSystemMntrngScheduling.class);

	// 모니터링 대상을 읽기위한 페이지 크기
	private static final int RECORD_COUNT_PER_PAGE = 10000;

	/**
	 * DB서비스 모니터링를 수행한다.
	 *
	 * @param
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void monitorFileSys() throws Exception {
		// 모니터링 대상 정보 읽어들이기
		Map<String, Object> map = null;
		//2017.03.03 	조성원 	시큐어코딩(ES)-Null Pointer 역참조[CWE-476]
		List<FileSysMntrng> targetList = new ArrayList<>();
		FileSysMntrngVO searchVO = new FileSysMntrngVO();
		// 모니터링 대상 검색 조건 초기화
		searchVO.setPageIndex(1);
		searchVO.setFirstIndex(0);
		searchVO.setRecordCountPerPage(RECORD_COUNT_PER_PAGE);
		map = ntwrkSvcMntrngService.selectFileSysMntrngList(searchVO);
		//2017.03.03 	조성원 	시큐어코딩(ES)-Null Pointer 역참조[CWE-476]
		if(map != null){
			targetList = (List<FileSysMntrng>)map.get("resultList");
		}

		LOGGER.debug("조회조건 {}", searchVO);
		LOGGER.debug("Result 건수 : {}", targetList.size());
		// 서비스체크 함수 호출.
		Iterator<FileSysMntrng> iter = targetList.iterator();
		FileSysMntrng target = null;

		String safeFileSysNm = "";
		int fileSysMg = 0;
		int fileSysThrhld = 0;
		int fileSysUsgQty = 0;
		boolean nrmltAt = true;
		while(iter.hasNext()) {
			nrmltAt = true;
			target = iter.next();
			LOGGER.debug("Data : {}", target);
			// 서비스 체크 수행.
			java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.KOREA);
			target.setCreatDt(formatter.format(new java.util.Date()));

			safeFileSysNm = EgovWebUtil.removeCRLF(target.getFileSysNm()).replaceAll("\\|", "").replaceAll("&", "");
			fileSysThrhld = target.getFileSysThrhld();
			try{
				fileSysMg = FileSystemChecker.totalSpaceGb(safeFileSysNm);
				fileSysUsgQty = fileSysMg - FileSystemChecker.freeSpaceGb(safeFileSysNm);

				target.setFileSysMg(fileSysMg);
				target.setFileSysUsgQty(fileSysUsgQty);
			}catch (IOException e1) {
				target.setLogInfo(e1.getMessage());
				nrmltAt = false;
			}

			if(fileSysUsgQty > fileSysThrhld){
				nrmltAt = false;
			}

			// email 전송.
			if (!nrmltAt) {
				target.setMntrngSttus("비정상");
				sendEmail(target);
			}

			// DB에 결과값 저장
			if (nrmltAt) {
				target.setMntrngSttus("01");
			} else {
				target.setMntrngSttus("02");
			}

			target.setLastUpdusrId("SYSTEM");
			ntwrkSvcMntrngService.updateFileSysMntrngSttus(target);
		}
	}

	/**
	 * 이메일을 전송한다.
	 *
	 * @param   target   모니터링 대상정보
	 * @return
	 *
	 */
    private void sendEmail(FileSysMntrng target) {
    	String subject = "";
    	String text = "";
    	String errorContents = "";

    	SimpleMailMessage msg = new SimpleMailMessage(this.mntrngMessage);
        // 수신자
        msg.setTo(target.getMngrEmailAddr());
        // 메일제목
        subject = msg.getSubject();
		// 2022.11.11 시큐어코딩 처리
		if (StringUtils.isNotEmpty(subject)) {
			subject = EgovStringUtil.replace(subject, "{모니터링종류}", "파일시스템모니터링");
	        msg.setSubject(subject);
		}
        // 메일내용
		// 2026.02.28 KISA 취약점 조치
        text = EgovStringUtil.isNullToString(msg.getText());
        // 2022.11.11 시큐어코딩 처리
     	if (StringUtils.isNotEmpty(text)) {
	        text = EgovStringUtil.replace(text, "{모니터링종류}", "파일시스템모니터링");
	        StringBuilder errorContentsBuilder = new StringBuilder();
	        errorContentsBuilder.append("파일시스템명 : ");
	        errorContentsBuilder.append(target.getFileSysNm());
	        errorContentsBuilder.append("\n");
	        errorContentsBuilder.append("파일시스템관리명 : ");
	        errorContentsBuilder.append(target.getFileSysManageNm());
	        errorContentsBuilder.append("\n");
	        if(target.getLogInfo() != null && !target.getLogInfo().equals("")){
		        errorContentsBuilder.append("해당파일의 파일시스템 정보를 가져오는중 에러가 발생하였습니다.");
	        }else{
		        errorContentsBuilder.append("크기 : ");
		        errorContentsBuilder.append(target.getFileSysMg());
		        errorContentsBuilder.append("GB\n");
		        errorContentsBuilder.append("임계치 : ");
		        errorContentsBuilder.append(target.getFileSysThrhld());
		        errorContentsBuilder.append("GB\n");
		        errorContentsBuilder.append("사용량 : ");
		        errorContentsBuilder.append(target.getFileSysUsgQty());
		        errorContentsBuilder.append("GB\n");
	        }
	        errorContentsBuilder.append("상태 : ");
	        errorContentsBuilder.append(target.getMntrngSttus());
	        errorContentsBuilder.append("\n");
	        errorContentsBuilder.append("모니터링 시각 : ");
	        errorContentsBuilder.append(EgovDateUtil.convertDate(target.getCreatDt(), "", "", ""));
	        errorContentsBuilder.append("\n");
	        if(target.getLogInfo() != null && !target.getLogInfo().equals("")){
		        errorContentsBuilder.append(target.getFileSysManageNm()).append(" 의 파일시스템 상태가 비정상입니다.  \n로그를 확인해주세요.");
	        }else{
		        errorContentsBuilder.append(target.getFileSysManageNm()).append(" 의 파일시스템이 임계치를 넘었습니다.");
	        }
	        errorContents = errorContentsBuilder.toString();
	        text = EgovStringUtil.replace(text, "{에러내용}", errorContents);
	        msg.setText(text);
     	}

        this.mntrngMailSender.send(msg);
    }

}
