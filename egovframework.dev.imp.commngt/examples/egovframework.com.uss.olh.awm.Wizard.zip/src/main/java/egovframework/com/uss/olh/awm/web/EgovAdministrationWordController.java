package egovframework.com.uss.olh.awm.web;

import java.util.List;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.annotation.RequireAdmin;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.uss.olh.awm.service.AdministrationWordVO;
import egovframework.com.uss.olh.awm.service.EgovAdministrationWordService;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 * 행정전문용어사전관리를 처리하는 Controller Class 구현
 * 
 * @author 공통서비스 장동한
 * @since 2009.07.03
 * @version 1.0
 * @see
 *
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.07.03  장동한          최초 생성
 *   2011.08.26  정진오          IncludedInfo annotation 추가
 *   2011.09.19  서준식          삭제 후 리스트 상세조회시 다시 삭제되는 문제 수정
 *   2016.08.10  김연호          표준프레임워크 3.6
 *   2025.08.20  이백행          2025년 컨트리뷰션 PMD로 소프트웨어 보안약점 진단하고 제거하기-LocalVariableNamingConventions(final이 아닌 변수는 밑줄을 포함할 수 없음)
 *
 *      </pre>
 */
@Controller
public class EgovAdministrationWordController {

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	/** egovOnlinePollService */
	@Resource(name = "EgovAdministrationWordService")
	private EgovAdministrationWordService egovAdministrationWordService;

	@Resource(name = "EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/**
	 * 행정전문용어사전 목록을 조회한다.
	 * 
	 * @param searchVO
	 * @param administrationWord
	 * @param model
	 * @return "egovframework/com/uss/olh/awm/EgovAdministrationWordList"
	 * @throws Exception
	 */
	@IncludedInfo(name = "행정전문용어사전", order = 560, gid = 50)
	@RequestMapping(value = "/uss/olh/awm/selectAdministrationWordList.do")
	public String egovAdministrationWordList(@ModelAttribute("searchVO") AdministrationWordVO searchVO, ModelMap model)
			throws Exception {

		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<AdministrationWordVO> resultList = egovAdministrationWordService.selectAdministrationWordList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = egovAdministrationWordService.selectAdministrationWordListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/uss/olh/awm/EgovAdministrationWordList";
	}

	/**
	 * 행정전문용어사전 목록을 상세조회 조회한다.
	 * 
	 * @param searchVO
	 * @param administrationWord
	 * @param commandMap
	 * @param model
	 * @return "/uss/olh/awm/EgovAdministrationWordDetail"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/awm/selectAdministrationWordDetail.do")
	@RequireAdmin
	public String selectAdministrationWordDetail(@ModelAttribute("searchVO") AdministrationWordVO searchVO,
			AdministrationWordVO administrationWord, ModelMap model) throws Exception {

		AdministrationWordVO result = egovAdministrationWordService.selectAdministrationWordDetail(administrationWord);
		model.addAttribute("result", result);

		return "egovframework/com/uss/olh/awm/EgovAdministrationWordDetail";
	}

	/**
	 * 행정전문용어사전관리 목록을 조회한다.
	 * 
	 * @param searchVO
	 * @param model
	 * @return "egovframework/com/uss/olh/awm/EgovAdministrationWordManageList"
	 * @throws Exception
	 */
	@IncludedInfo(name = "행정전문용어사전관리", order = 561, gid = 50)
	@RequestMapping(value = "/uss/olh/awm/selectAdministrationWordManageList.do")
	public String egovAdministrationWordManageList(@ModelAttribute("searchVO") AdministrationWordVO searchVO,
			ModelMap model) throws Exception {

		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<AdministrationWordVO> resultList = egovAdministrationWordService.selectAdministrationWordList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = egovAdministrationWordService.selectAdministrationWordListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/uss/olh/awm/EgovAdministrationWordManageList";
	}

	/**
	 * 행정전문용어사전관리 목록을 상세조회 조회한다.
	 * 
	 * @param searchVO
	 * @param administrationWord
	 * @param commandMap
	 * @param model
	 * @return "/uss/olh/awm/EgovAdministrationWordDetail"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/awm/selectAdministrationWordManageDetail.do")
	@RequireAdmin
	public String selectAdministrationWordManageDetail(@ModelAttribute("searchVO") AdministrationWordVO searchVO,
			AdministrationWordVO administrationWord, ModelMap model) throws Exception {

		AdministrationWordVO result = egovAdministrationWordService.selectAdministrationWordDetail(administrationWord);
		model.addAttribute("result", result);

		return "egovframework/com/uss/olh/awm/EgovAdministrationWordManageDetail";
	}

	/**
	 * 행정전문용어사전을 등록하기 위한 전 처리(공통코드 처리)
	 * 
	 * @param searchVO
	 * @param model
	 * @return "/uss/olh/awm/EgovAdministrationWordRegist"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/awm/insertAdministrationWordView.do")
	@RequireAdmin
	public String insertAdministrationWordView(@ModelAttribute("searchVO") AdministrationWordVO searchVO, Model model)
			throws Exception {

		// 공통코드를 가져오기 위한 Vo
		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		vo.setCodeId("COM102");

		List<?> wordSeCode = cmmUseService.selectCmmCodeDetail(vo);
		model.addAttribute("wordSeCode", wordSeCode);

		model.addAttribute("administrationWordVO", new AdministrationWordVO());

		return "egovframework/com/uss/olh/awm/EgovAdministrationWordRegist";

	}

	/**
	 * 행정전문용어사전을 등록한다.
	 * 
	 * @param searchVO
	 * @param administrationWordVO
	 * @param bindingResult
	 * @return "forward:/uss/olh/awm/selectAdministrationWordManageList.do"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/awm/insertAdministrationWord.do")
	@RequireAdmin
	public String insertAdministrationWord(@ModelAttribute("searchVO") AdministrationWordVO searchVO,
			@Valid @ModelAttribute("administrationWordVO") AdministrationWordVO administrationWordVO,
			BindingResult bindingResult,
			Model model) throws Exception {

		if (bindingResult.hasErrors()) {
			ComDefaultCodeVO comDefaultCodeVO = new ComDefaultCodeVO();
			comDefaultCodeVO.setCodeId("COM102");
			
			List<?> wordSeCode = cmmUseService.selectCmmCodeDetail(comDefaultCodeVO);
			model.addAttribute("wordSeCode", wordSeCode);
			return "egovframework/com/uss/olh/awm/EgovAdministrationWordRegist";
		}

		// 로그인VO에서 사용자 정보 가져오기
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		String frstRegisterId = loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId());

		administrationWordVO.setFrstRegisterId(frstRegisterId); // 최초등록자ID
		administrationWordVO.setLastUpdusrId(frstRegisterId); // 최종수정자ID

		egovAdministrationWordService.insertAdministrationWord(administrationWordVO);

		return "forward:/uss/olh/awm/selectAdministrationWordManageList.do";
	}

	/**
	 * 행정전문용어사전을 수정하기 위한 전 처리(공통코드 처리)
	 * 
	 * @param administWordId
	 * @param searchVO
	 * @param model
	 * @return "/uss/olh/hpc/EgovAdministrationWordUpdt"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/awm/updateAdministrationWordView.do")
	@RequireAdmin
	public String updateAdministrationWordView(@RequestParam("administWordId") String administWordId,
			@ModelAttribute("searchVO") AdministrationWordVO searchVO, ModelMap model) throws Exception {

		// 공통코드를 가져오기 위한 Vo
		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		vo.setCodeId("COM102");

		List<?> wordSeCode = cmmUseService.selectCmmCodeDetail(vo);
		model.addAttribute("wordSeCode", wordSeCode);

		AdministrationWordVO administrationWordVO = new AdministrationWordVO();
		administrationWordVO.setAdministWordId(administWordId);

		AdministrationWordVO stored = EgovAuthorizationHelper.requireTarget(egovAdministrationWordService.selectAdministrationWordDetail(administrationWordVO));
		model.addAttribute("administrationWordVO", stored);

		return "egovframework/com/uss/olh/awm/EgovAdministrationWordUpdt";
	}

	/**
	 * 행정전문용어사전을 수정한다.
	 * 
	 * @param searchVO
	 * @param administrationWordVO
	 * @param bindingResult
	 * @return "forward:/uss/olh/awm/selectAdministrationWordManageList.do"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/awm/updateAdministrationWord.do")
	@RequireAdmin
	public String updateAdministrationWord(@ModelAttribute("searchVO") AdministrationWordVO searchVO,
			@Valid @ModelAttribute("administrationWordVO") AdministrationWordVO administrationWordVO,
			BindingResult bindingResult,
			Model model) throws Exception {


		if (bindingResult.hasErrors()) {
			ComDefaultCodeVO comDefaultCodeVO = new ComDefaultCodeVO();
			comDefaultCodeVO.setCodeId("COM102");
			
			List<?> wordSeCode = cmmUseService.selectCmmCodeDetail(comDefaultCodeVO);
			model.addAttribute("wordSeCode", wordSeCode);
			
			return "egovframework/com/uss/olh/awm/EgovAdministrationWordUpdt";
		}

		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		String lastUpdusrId = loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId());

		administrationWordVO.setLastUpdusrId(lastUpdusrId); // 최종수정자ID
		egovAdministrationWordService.updateAdministrationWord(administrationWordVO);

		return "forward:/uss/olh/awm/selectAdministrationWordManageList.do";

	}

	/**
	 * 행정전문용어사전을 삭제한다.
	 * 
	 * @param hpcmVO
	 * @param searchVO
	 * @return "forward:/uss/olh/awm/selectAdministrationWordManageList.do"
	 * @throws Exception
	 */
	@PostMapping("/uss/olh/awm/deleteAdministrationWord.do")
	@RequireAdmin
	public String deleteAdministrationWord(AdministrationWordVO administrationWordVO,
			@ModelAttribute("searchVO") AdministrationWordVO searchVO) throws Exception {


		egovAdministrationWordService.deleteAdministrationWord(administrationWordVO);

		return "forward:/uss/olh/awm/selectAdministrationWordManageList.do";
	}


}
