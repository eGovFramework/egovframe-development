package egovframework.com.uss.ion.bnt.service;

import java.io.InputStream;
import java.util.List;

/**
 * 개요
 * - 당직관리에 대한 Service Interface를 정의한다.
 *
 * 상세내용
 * - 당직관리에 대한 등록, 수정, 삭제, 조회, 반영확인 기능을 제공한다.
 * - 당직관리의 조회기능은 목록조회, 상세조회로 구분된다.
 * @author 이용
 * @version 1.0
 * @created 06-15-2010 오후 2:08:56
 */

public interface EgovBndtManageService {

	/**
	 * 당직관리 정보를 관리하기 위해 등록된 당직관리 목록을 조회한다.
	 * @param bndtManageVO - 당직관리 VO
	 * @return List - 당직관리 목록
	 */
	public List<BndtManageVO> selectBndtManageList(BndtManageVO bndtManageVO) throws Exception;

	/**
	 * 당직관리 목록 총 개수를 조회한다.
	 * @param bndtManageVO - 당직관리 VO
	 * @return int - 당직관리 카운트 수
	 */
	public int selectBndtManageListTotCnt(BndtManageVO bndtManageVO) throws Exception ;

	/**
	 * 등록된 당직관리의 상세정보를 조회한다.
	 * @param bndtManageVO - 당직관리 VO
	 * @return BndtManageVO - 당직관리 VO
	 */
	public BndtManageVO selectBndtManage(BndtManageVO bndtManageVO) throws Exception;

	/**
	 * 당직관리 정보를 신규로 등록한다.
	 * @param bndtManageVO - 당직관리 VO
	 */
	public void insertBndtManage(BndtManageVO bndtManageVO) throws Exception;

	/**
	 * 기 등록된 당직관리 정보를 수정한다.
	 * @param bndtManageVO - 당직관리 VO
	 */
	public void updtBndtManage(BndtManageVO bndtManageVO) throws Exception;

	/**
	 * 기 등록된 당직관리 정보를 삭제한다.
	 * @param bndtManageVO - 당직관리 VO
	 */
	public void deleteBndtManage(BndtManageVO bndtManageVO) throws Exception;

    /**
	 * 당직일지 개수를 조회한다.
	 * @param bndtManageVO - 당직관리 VO
	 * @return int
	 * @exception Exception
	 */
    public int selectBndtDiaryTotCnt(BndtManageVO bndtManageVO) throws Exception;

    /**
	 * 당직일지 등록자를 조회한다. 일지는 한 번에 점검항목 행을 같은 등록자로 넣는다.
	 * @param bndtDiaryVO - bndtId(당직자), bndtDe(당직일자)
	 * @return String - 등록자 고유ID, 일지가 없으면 null
	 * @exception Exception
	 */
    public String selectBndtDiaryRegisterId(BndtDiaryVO bndtDiaryVO) throws Exception;

    /***** 당직 체크관리 *****/
	/**
	 * 당직체크관리 정보를 관리하기 위해 등록된 당직체크관리 목록을 조회한다.
	 * @param bndtCeckManageVO - 당직체크관리 VO
	 * @return List - 당직체크관리 목록
	 */
	public List<BndtCeckManageVO> selectBndtCeckManageList(BndtCeckManageVO bndtCeckManageVO) throws Exception;

	/**
	 * 당직체크관리 목록 총 개수를 조회한다.
	 * @param bndtCeckManageVO - 당직체크관리 VO
	 * @return int - 당직체크관리 카운트 수
	 */
	public int selectBndtCeckManageListTotCnt(BndtCeckManageVO bndtCeckManageVO) throws Exception ;

	/**
	 * 등록된 당직체크관리의 상세정보를 조회한다.
	 * @param bndtCeckManageVO - 당직체크관리 VO
	 * @return BndtCeckManageVO - 당직체크관리 VO
	 */
	public BndtCeckManageVO selectBndtCeckManage(BndtCeckManageVO bndtCeckManageVO) throws Exception;

	/**
	 * 당직체크관리 정보를 신규로 등록한다.
	 * @param bndtCeckManageVO - 당직체크관리 VO
	 */
	public void insertBndtCeckManage(BndtCeckManageVO bndtCeckManageVO) throws Exception;

	/**
	 * 기 등록된 당직체크관리 정보를 수정한다.
	 * @param bndtCeckManageVO - 당직체크관리 VO
	 */
	public void updtBndtCeckManage(BndtCeckManageVO bndtCeckManageVO) throws Exception;

	/**
	 * 기 등록된 당직체크관리 정보를 삭제한다.
	 * @param bndtCeckManageVO - 당직체크관리 VO
	 */
	public void deleteBndtCeckManage(BndtCeckManageVO bndtCeckManageVO) throws Exception;


    /**
	 * 당직체크 중복여부 조회한다.
	 * @param bndtCeckManageVO - 당직체크관리 VO
	 * @return int
	 * @exception Exception
	 */
	public int selectBndtCeckManageDplctAt(BndtCeckManageVO bndtCeckManageVO) throws Exception ;


    /***** 당직 일지 *****/

	/**
	 * 등록된 당직일지관리의 상세정보를 조회한다.
	 * @param bndtDiaryVO - 당직일지관리 VO
	 * @return BndtDiaryVO - 당직일지관리 VO
	 */
	public List<BndtDiaryVO> selectBndtDiary(BndtDiaryVO bndtDiaryVO) throws Exception;

	/**
	 * 당직일지관리 정보를 신규로 등록한다.
	 * @param bndtDiaryVO - 당직일지관리 VO
	 */
	public void insertBndtDiary(BndtDiaryVO bndtDiaryVO, String diaryForInsert) throws Exception;

	/**
	 * 기 등록된 당직일지관리 정보를 수정한다.
	 * @param bndtDiaryVO - 당직일지관리 VO
	 */
	public void updtBndtDiary(BndtDiaryVO bndtDiaryVO, String diaryForUpdt) throws Exception;

	/**
	 * 기 등록된 당직일지관리 정보를 삭제한다.
	 * @param bndtDiaryVO - 당직일지관리 VO
	 */
	public void deleteBndtDiary(BndtDiaryVO bndtDiaryVO) throws Exception;

	/**
	 * 당직자 excel생성
	 * @param  inputStream InputStream
	 * @return  String
	 * @exception Exception
	 */
	public List<BndtManageVO> selectBndtManageBnde(InputStream inputStream) throws Exception;

	/**
	 * 당직자 excel생성 (Xlsx사용시)
	 * @param  inputStream InputStream
	 * @return  String
	 * @exception Exception
	 */
	public List<BndtManageVO> selectBndtManageBndeX(InputStream inputStream) throws Exception;
	
	/**
	 * 당직정보를 일괄등록처리한다.
	 * @param bndtManageVO     - 당직관리 VO
	 * @param String           - 당직자정보
	 */
	public void insertBndtManageBnde(BndtManageVO bndtManageVO, String checkedBndtManageForInsert) throws Exception;

    /**
	 * 당직관리 등록건수 조회한다.
	 * @param bndtManageVO - 당직관리 VO
	 * @return int
	 * @exception Exception
	 */
    public int selectBndtManageMonthCnt(BndtManageVO bndtManageVO) throws Exception;
}