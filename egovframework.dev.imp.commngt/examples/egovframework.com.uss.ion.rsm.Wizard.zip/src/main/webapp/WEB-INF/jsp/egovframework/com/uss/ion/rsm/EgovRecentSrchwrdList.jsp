<%--
  Class Name : EgovRecentSrchwrdList.jsp
  Description : 최근검색어관리 목록 페이지
  Modification Information

       수정일                수정자           수정내용
    ----------   --------   ---------------------------
    2008.03.09   장동한				최초 생성
    2011.12.14   이기하				최근검색어 오류 수정
    2018.08.16   이정은				공통컴포넌트 3.8 개선(다국어처리, 퍼블리싱 확인)
    2019.12.10   신용호				KISA 보안약점 조치
    2024.10.29   권태성				수정 페이지 신규 경로로 변경

    author   : 공통서비스 개발팀 장동한
    since    : 2009.03.09

    Copyright (C) 2009 by MOPAS  All rights reserved.
--%>
<%@ page contentType="text/html; charset=utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags"%>

<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="ajax" uri="http://ajaxtags.sourceforge.net/tags/ajaxtags" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<script type="text/javascript" src="<c:url value='/js/egovframework/com/cmm/egovPostNavigate.js' />"></script>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><spring:message code="ussIonRsm.recentSrchwrdList.recentSrchwrdList"/></title><!-- 최근검색어 관리 목록 -->
<link href="<c:url value="/css/egovframework/com/com.css"/>" rel="stylesheet" type="text/css">
<link href="<c:url value="/css/egovframework/com/button.css"/>" rel="stylesheet" type="text/css">
<link type="text/css" rel="stylesheet" href="<c:url value='/css/egovframework/com/cmm/jqueryui.css' />">

<script src="<c:url value='/js/egovframework/com/cmm/jquery.js' />"></script>
<script src="<c:url value='/js/egovframework/com/cmm/jqueryui.js' />"></script>
<script type="text/javascript" src="<c:url value='/js/egovframework/com/uss/ion/rsm/recentSrchwrd.js' />"></script>
<script type="text/javaScript" language="javascript">

/* ********************************************************
 * 페이징 처리 함수
 ******************************************************** */
function linkPage(pageNo){
	document.listForm.pageIndex.value = pageNo;
	document.listForm.action = "<c:url value='/uss/ion/rsm/listRecentSrchwrd.do'/>";
   	document.listForm.submit();
}
/* ********************************************************
 * 상세회면 처리 함수
 ******************************************************** */
function fn_egov_detail_RecentSrchwrd(srchwrdManageId){
	var vFrom = document.listForm;
	vFrom.srchwrdManageId.value = srchwrdManageId;
	vFrom.action = "<c:url value='/uss/ion/rsm/detailRecentSrchwrd.do' />";
	vFrom.submit();
}

/* ********************************************************
 * 검색 함수
 ******************************************************** */
function fn_egov_search_RecentSrchwrd(){
	var searchKeyword = document.listForm.searchKeyword.value;
	var srchwrdManageId = "SRCMGR_0000000000001"; // 기본값, 실제로는 동적으로 설정 필요
	
	document.listForm.pageIndex.value = 1;
	
	// 검색어가 있을 경우 최근검색어로 저장 (비동기 처리)
	if(searchKeyword && searchKeyword.trim() !== '') {
		// 검색 폼 제출과 동시에 검색어 저장 (비동기이므로 제출을 막지 않음)
		fn_egov_regist_RecentSrchwrdResult(srchwrdManageId, searchKeyword, '', document.listForm);
	}
	
	document.listForm.submit();
}

$(document).ready(function(){
	
	var ajaxUrl = "<c:url value='/uss/ion/rsm/listRecentSrchwrdResultSerach.do' />";
	var defaultSrchwrdManageId = "SRCMGR_0000000000001"; // 기본값, 실제로는 동적으로 설정 필요
	
    $("#searchKeyword").autocomplete({
		source: function(request, response){
			$.ajax({
				url: ajaxUrl
				,contentType: "application/x-www-form-urlencoded; charset=UTF-8"
				,data: {
					srchwrdManageId: defaultSrchwrdManageId
					,searchKeyword: request.term
				}
				,dataType: 'xml'
				,success: function(returnData, status) {
					var items = [];
					$(returnData).find("name").each(function(idx,data) {
						var text = $(data).text();
						if(text && text.trim() !== '') {
							items.push(text);
						}
					});
					response(items);
				}
				,error: function(xhr, status, error) {
					response([]);
				}
			});
		},
		minLength : 1,
		select: function(event, ui){
		   $("#searchKeyword").val(ui.item.value);
		}
    });
    
});
	
</script>
</head>
<body>

<div class="board">
	<h1><spring:message code="ussIonRsm.recentSrchwrdList.recentSrchwrdList"/></h1><!-- 최근검색어관리 목록 -->
	<form:form name="listForm" modelAttribute="searchVO" action="${pageContext.request.contextPath}/uss/ion/rsm/listRecentSrchwrd.do" method="post" onSubmit="fn_egov_search_RecentSrchwrd(); return false;">
	<div class="search_box" title="<spring:message code="common.searchCondition.msg"/>"><!-- 이 레이아웃은 하단 정보를 대한 검색 정보로 구성되어 있습니다. -->
		<ul>
			<li>
				<select name="searchCondition" id="searchCondition" class="select" title="<spring:message code="title.searchCondition"/>"><!-- 검색조건선택 -->
					<option value=''><spring:message code="input.select"/></option><!-- --선택하세요-- -->
					<option value='SRCHWRD_MANAGE_NM' <c:if test="${recentSrchwrd.searchCondition == 'SRCHWRD_MANAGE_NM'}">selected="selected"</c:if>><spring:message code="ussIonRsm.recentSrchwrdList.srchwrdManageNm"/></option><!-- 최근검색어관리명 -->
					<option value='SRCHWRD_CONECT_URL' <c:if test="${recentSrchwrd.searchCondition == 'SRCHWRD_CONECT_URL'}">selected="selected"</c:if>><spring:message code="ussIonRsm.recentSrchwrdList.srchwrdManageUrl"/></option><!-- 최근검색어관리URL -->
				</select>
			</li>
			<!-- 검색키워드 및 조회버튼 -->
			<li>
				<input id="searchKeyword" class="s_input" name="searchKeyword" type="text" value="<c:out value="${recentSrchwrd.searchKeyword}"/>" maxlength="35" size="35" title="<spring:message code="title.search"/> <spring:message code="input.input"/>" /><!-- 검색단어입력 -->
				<input type="submit" class="s_btn" value="<spring:message code="button.inquire" />" title="<spring:message code="title.inquire" /> <spring:message code="input.button" />" />
				<span class="btn_b"><a href="#" onclick="fn_egov_postNavigate('<c:url value='/uss/ion/rsm/registRecentSrchwrdView.do' />'); return false;" title='<spring:message code="button.create" /> <spring:message code="input.button" />'><spring:message code="button.create" /></a></span>
			</li>
		</ul>
	</div>
		<input name="srchwrdManageId" type="hidden" value="">
		<input name="searchMode" type="hidden" value="">
		<input name="pageIndex" type="hidden" value="<c:out value='${recentSrchwrd.pageIndex}'/>"/>
		<!--Ajax Tags 등록 -->
		<input type="hidden" name="rsm_url" id="rsm_url" value="<c:url value='/uss/ion/rsm/registRecentSrchwrdResult.do'/>" >
		<!--Ajax Tags 끝 -->
	

	<table class="board_list">
		<caption></caption>
		<colgroup>
			<col style="width:35px" />
			<col style="width:150px" />
			<col style="" />
			<col style="width:50px" />
			<col style="width:70px" />
			<col style="width:90px" />
		</colgroup>
		<thead>
			<tr>
			   <th scope="col"><spring:message code="ussIonRsm.recentSrchwrdList.srchwrdNum"/></th><!-- 순번 -->
			   <th scope="col"><spring:message code="ussIonRsm.recentSrchwrdList.srchwrdManageNm"/></th><!-- 최근검색어관리명 -->
			   <th scope="col"><spring:message code="ussIonRsm.recentSrchwrdList.srchwrdManageUrl"/></th><!-- 최근검색어관리URL -->
			   <th scope="col"><spring:message code="ussIonRsm.recentSrchwrdList.srchwrdManageResult"/></th><!-- 결과 -->
			   <th scope="col"><spring:message code="ussIonRsm.recentSrchwrdList.frstRegisterNm"/></th><!-- 등록자 -->
			   <th scope="col"><spring:message code="ussIonRsm.recentSrchwrdList.frstRegisterPnttm"/></th><!-- 등록일자 -->
			</tr>
		</thead>
		<tbody>
			<%-- 데이터를 화면에 출력해준다 --%>
			<c:forEach items="${resultList}" var="resultInfo" varStatus="status">
			<tr>
				<td><c:out value="${(recentSrchwrd.pageIndex-1) * recentSrchwrd.pageSize + status.count}"/></td>
				<td>
					<a href="javascript:void(0);" onclick="fn_egov_detail_RecentSrchwrd('${resultInfo.srchwrdManageId}'); return false;"><span class="link"><c:out value="${resultInfo.srchwrdManageNm}"/></span></a>
				</td>
				<td><c:out value="${resultInfo.srchwrdManageUrl}"/></td>
				<td>
					<a href="javascript:void(0);" onclick="fn_egov_detail_RecentSrchwrd('${resultInfo.srchwrdManageId}'); return false;"><span class="link"><spring:message code="ussIonRsm.recentSrchwrdList.view"/></span></a>
				</td>
				<td><c:out value="${resultInfo.frstRegisterNm}"/></td>
				<td><c:out value="${resultInfo.frstRegisterPnttm}"/></td>
			</tr>
			</c:forEach>
			
			<%-- 데이터를 없을때 화면에 메세지를 출력해준다 --%>
			<c:if test="${fn:length(resultList) == 0}">
			<tr>
				<td colspan="6">
					<spring:message code="common.nodata.msg" />
				</td>
			</tr>
			</c:if>
		</tbody>
	</table>

	<!-- paging navigation -->
	<div class="pagination">
		<ul>
			<ui:pagination paginationInfo="${paginationInfo}" type="image" jsFunction="linkPage"/>
		</ul>
	</div>
</form:form>

</div>
</body>
</html>
