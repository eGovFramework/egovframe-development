package egovframework.com.sym.bat.service.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.sym.bat.service.BatchSchdul;
import egovframework.com.sym.bat.service.BatchSchdulDfk;

/**
 * 배치스케줄관리에 대한 DAO 클래스를 정의한다.
 *
 * @author 김진만
 * @since 2010.06.17
 * @version 1.0
 * @updated 17-6-2010 오전 10:27:13
 * @see
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 *   수정일       수정자           수정내용
 *  -------     --------    ---------------------------
 *  2010.06.17   김진만     최초 생성
 * </pre>
 */
@Repository("batchSchdulDao")
public class BatchSchdulDao extends EgovComAbstractDAO {

	/**
	 * 요일정보 일괄조회 IN 절에 한번에 넣는 배치스케줄ID 개수.
	 * 지원 DB 중 Oracle의 IN 절 항목 상한(1000개)이 가장 낮고 초과 시 ORA-01795가 발생하므로 그 값을 기준으로 나눈다.
	 */
	private static final int DFK_SELECT_ID_SIZE = 1000;

	/**
	 * 배치스케줄을 삭제한다.
	 *
	 * @param batchSchdul    삭제할 배치스케줄 VO
	 * @exception Exception Exceptdion
	 */
	public void deleteBatchSchdul(BatchSchdul batchSchdul) {
		// slave 테이블 삭제
		delete("BatchSchdulDao.deleteBatchSchdulDfk", batchSchdul.getBatchSchdulId());
		// master 테이블 삭제
		delete("BatchSchdulDao.deleteBatchSchdul", batchSchdul);
	}

	/**
	 * 배치스케줄을 등록한다.
	 *
	 * @param batchSchdul 저장할 배치스케줄 VO
	 */
	public void insertBatchSchdul(BatchSchdul batchSchdul) {
		// master 테이블 인서트
		insert("BatchSchdulDao.insertBatchSchdul", batchSchdul);
		// slave 테이블 인서트
		if (batchSchdul.getExecutSchdulDfkSes() != null && batchSchdul.getExecutSchdulDfkSes().length != 0) {
			String batchSchdulId = batchSchdul.getBatchSchdulId();
			String [] dfkSes = batchSchdul.getExecutSchdulDfkSes();
			for (String element : dfkSes) {
				BatchSchdulDfk batchSchdulDfk = new BatchSchdulDfk();
				batchSchdulDfk.setBatchSchdulId(batchSchdulId);
				batchSchdulDfk.setExecutSchdulDfkSe(element);
				insert("BatchSchdulDao.insertBatchSchdulDfk", batchSchdulDfk);
			}
		}
	}

	/**
	 * 배치스케줄정보를 상세조회 한다.
	 * @return 배치스케줄정보
	 *
	 * @param batchSchdul    조회할 KEY가 있는 배치스케줄 VO
	 */
	public BatchSchdul selectBatchSchdul(BatchSchdul batchSchdul) {
		BatchSchdul result = (BatchSchdul)selectOne("BatchSchdulDao.selectBatchSchdul", batchSchdul);
		if (result == null) {
			return null;
		}
		// 스케줄요일정보를 가져온다.
		List<BatchSchdulDfk> dfkSeList = selectList("BatchSchdulDao.selectBatchSchdulDfkList", result.getBatchSchdulId());
		String [] dfkSes = new String [dfkSeList.size()];
		for (int j = 0; j < dfkSeList.size(); j++) {
			dfkSes[j] = dfkSeList.get(j).getExecutSchdulDfkSe();
		}
		result.setExecutSchdulDfkSes(dfkSes);
		// 화면표시용 실행스케줄 속성을 만든다.
		result.makeExecutSchdul(dfkSeList);

		return result ;
	}

	/**
	 * 배치스케줄정보목록을  조회한다.
	 * @return 배치스케줄목록
	 *
	 * @param searchVO    조회조건이 저장된 VO
	 */
	public List<BatchSchdul> selectBatchSchdulList(BatchSchdul searchVO) {
		List<BatchSchdul> resultList = selectList("BatchSchdulDao.selectBatchSchdulList", searchVO);
		if (resultList.isEmpty()) {
			return resultList;
		}

		// 스케줄요일정보를 배치스케줄ID 목록으로 일괄 조회한 뒤 ID별로 그룹핑한다. (행별 조회로 인한 N+1 제거)
		List<String> batchSchdulIds = new ArrayList<>();
		for (BatchSchdul result : resultList) {
			batchSchdulIds.add(result.getBatchSchdulId());
		}
		Map<String, List<BatchSchdulDfk>> dfkMap = new HashMap<>();
		for (int fromIndex = 0; fromIndex < batchSchdulIds.size(); fromIndex += DFK_SELECT_ID_SIZE) {
			int toIndex = Math.min(fromIndex + DFK_SELECT_ID_SIZE, batchSchdulIds.size());
			List<BatchSchdulDfk> dfkList = selectList("BatchSchdulDao.selectBatchSchdulDfkListByIds",
					batchSchdulIds.subList(fromIndex, toIndex));
			for (BatchSchdulDfk dfk : dfkList) {
				dfkMap.computeIfAbsent(dfk.getBatchSchdulId(), key -> new ArrayList<>()).add(dfk);
			}
		}

		for (BatchSchdul result : resultList) {
			// 스케줄요일정보를 가져온다.
			List<BatchSchdulDfk> dfkSeList = dfkMap.getOrDefault(result.getBatchSchdulId(), new ArrayList<>());
			String [] dfkSes = new String [dfkSeList.size()];
			for (int j = 0; j < dfkSeList.size(); j++) {
				dfkSes[j] = dfkSeList.get(j).getExecutSchdulDfkSe();
			}
			result.setExecutSchdulDfkSes(dfkSes);
			// 화면표시용 실행스케줄 속성을 만든다.
			result.makeExecutSchdul(dfkSeList);
		}
		return resultList;
	}

	/**
	 * 배치스케줄 목록 전체 건수를(을) 조회한다.
	 * @return 목록건수
	 *
	 * @param searchVO    조회할 정보가 담긴 VO
	 */
	public int selectBatchSchdulListCnt(BatchSchdul searchVO) {
		return (Integer)selectOne("BatchSchdulDao.selectBatchSchdulListCnt", searchVO);
	}

	/**
	 * 배치스케줄정보를 수정한다.
	 *
	 * @param batchSchdul    수정대상 배치스케줄 VO
	 */
	public void updateBatchSchdul(BatchSchdul batchSchdul) {
		update("BatchSchdulDao.updateBatchSchdul", batchSchdul);
		// slave 테이블 삭제
		delete("BatchSchdulDao.deleteBatchSchdulDfk", batchSchdul.getBatchSchdulId());
		// slave 테이블 인서트
		if (batchSchdul.getExecutSchdulDfkSes() != null && batchSchdul.getExecutSchdulDfkSes().length != 0) {
			String batchSchdulId = batchSchdul.getBatchSchdulId();
			String [] dfkSes = batchSchdul.getExecutSchdulDfkSes();
			for (String element : dfkSes) {
				BatchSchdulDfk batchSchdulDfk = new BatchSchdulDfk();
				batchSchdulDfk.setBatchSchdulId(batchSchdulId);
				batchSchdulDfk.setExecutSchdulDfkSe(element);
				insert("BatchSchdulDao.insertBatchSchdulDfk", batchSchdulDfk);
			}
		}
	}

}