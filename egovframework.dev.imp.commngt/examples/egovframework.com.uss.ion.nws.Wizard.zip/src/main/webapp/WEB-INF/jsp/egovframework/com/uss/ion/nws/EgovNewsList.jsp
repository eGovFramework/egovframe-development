<%
 /**
  * @Class Name : EgovNewsList.jsp
  * @Description : EgovNewsList 화면
  * @Modification Information
  * @
  * @  수정일             수정자                   수정내용
  * @ -------    --------    ---------------------------
  * @ 2009.02.01   박정규              최초 생성
  *   2016.06.13   김연호              표준프레임워크 v3.6 개선
  *  @author 공통서비스팀
  *  @since 2009.02.01
  *  @version 1.0
  *  @see
  *
  */
%>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<c:set var="pageTitle"><spring:message code="comUssIonNws.newsVO.title"/></c:set>
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript" src="<c:url value='/js/egovframework/com/cmm/egovPostNavigate.js' />"></script>
<title>${pageTitle} <spring:message code="title.list" /></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<link href="<c:url value="/css/egovframework/com/com.css"/>" rel="stylesheet" type="text/css">
<script type="text/javascript">
/*********************************************************
 * 페이징 처리 함수
 ******************************************************** */
function fn_egov_select_linkPage(pageNo){
	document.newsForm.pageIndex.value = pageNo;
	document.newsForm.action = "<c:url value='/uss/ion/nws/selectNewsList.do'/>";
   	document.newsForm.submit();
}
/*********************************************************
 * 조회 처리 함수
 ******************************************************** */
function fn_egov_search_news(){
	document.newsForm.pageIndex.value = 1;
	document.newsForm.submit();
}
/* ********************************************************
 * 상세화면 처리 함수
 ******************************************************** */
function fn_egov_inquire_newsdetail(newsId) {
	// 뉴스 키값(newsId) 셋팅.
	document.newsForm.newsId.value = newsId;
  	document.newsForm.action = "<c:url value='/uss/ion/nws/selectNewsDetail.do'/>";
  	document.newsForm.submit();
}
</script>
</head>
<body>
<!-- javascript warning tag  -->
<noscript class="noScriptTitle"><spring:message code="common.noScriptTitle.msg" /></noscript>

<form:form name="newsForm" modelAttribute="newsVO" action="${pageContext.request.contextPath}/uss/ion/nws/selectNewsList.do" method="post" onSubmit="fn_egov_search_news(); return false;"> 
<div class="board">
	<h1>${pageTitle} <spring:message code="title.list" /></h1>
	<!-- 하단 버튼 -->
	<div class="search_box" title="<spring:message code="common.searchCondition.msg" />">
		<ul>
			<li>
				<select name="searchCondition" title="<spring:message code="title.searchCondition" /> <spring:message code="input.cSelect" />">
					<option value="0"  <c:if test="${newsVO.searchCondition == '0'}">selected="selected"</c:if> ><spring:message code="comUssIonNws.newsVO.newsSj" /></option><!-- 뉴스제목 -->
					<option value="1"  <c:if test="${newsVO.searchCondition == '1'}">selected="selected"</c:if> ><spring:message code="comUssIonNws.newsVO.newsOrigin" /></option><!-- 뉴스출처 -->
				</select>
			</li>
			<!-- 검색키워드 및 조회버튼 -->
			<li>
				<input class="s_input" name="searchKeyword" type="text"  size="35" title="<spring:message code="title.search" /> <spring:message code="input.input" />" value='<c:out value="${newsVO.searchKeyword}"/>'  maxlength="155" >
				<input type="submit" class="s_btn" value="<spring:message code="button.inquire" />" title="<spring:message code="title.inquire" /> <spring:message code="input.button" />" />
				<span class="btn_b"><a href="#" onclick="fn_egov_postNavigate('<c:url value='/uss/ion/nws/insertNewsView.do' />'); return false;"  title="<spring:message code="button.create" /> <spring:message code="input.button" />"><spring:message code="button.create" /></a></span>
			</li>
		</ul>
	</div>
	
	<!-- 목록영역 -->
	<table class="board_list" summary="<spring:message code="common.summary.list" arguments="${pageTitle}" />">
	<caption>${pageTitle}<spring:message code="title.list" /></caption>
	<colgroup>
		<col style="width: 9%;">
		<col style="width: 40%;">
		<col style="width: 13%;">
		<col style="width: 13%;">
		<col style="width: 13%;">
	</colgroup>
	<thead>
	<tr>
		<th><spring:message code="table.num" /></th><!-- 번호 -->
		<th class="board_th_link"><spring:message code="comUssIonNws.newsVO.newsSj" /></th><!-- 뉴스제목 -->
		<th><spring:message code="comUssIonNws.newsVO.newsOrigin" /></th><!-- 뉴스출처 -->
		<th><spring:message code="comUssIonNws.newsVO.ntceDe" /></th><!-- 게시일자 -->
		<th><spring:message code="table.regdate" /></th><!-- 등록일자 -->
	</tr>
	</thead>
	<tbody class="ov">
	<c:if test="${fn:length(resultList) == 0}">
	<tr>
		<td colspan="5"><spring:message code="common.nodata.msg" /></td>
	</tr>
	</c:if>
	<c:forEach items="${resultList}" var="resultInfo" varStatus="status">
	<tr>
		<td><c:out value="${(newsVO.pageIndex-1) * newsVO.pageSize + status.count}"/></td>
		<td class="left"><a href="javascript:void(0);" onClick="fn_egov_inquire_newsdetail('<c:out value="${resultInfo.newsId}"/>');return false;"><c:out value='${fn:substring(resultInfo.newsSj, 0, 40)}'/></a></td>
		<td><c:out value='${resultInfo.newsOrigin}'/></td>
		<td><c:out value='${resultInfo.ntceDe}'/></td>
		<td><c:out value='${resultInfo.frstRegisterPnttm}'/></td>
	</tr>
	</c:forEach>
	</tbody>
	</table>
	
	<!-- paging navigation -->
	<div class="pagination">
		<ul>
		<ui:pagination paginationInfo="${paginationInfo}" type="image" jsFunction="fn_egov_select_linkPage"/>
		</ul>
	</div>
	
	
</div>

<input name="newsId" type="hidden" value="<c:out value='${newsVO.newsId}'/>">
<input name="pageIndex" type="hidden" value="<c:out value='${newsVO.pageIndex}'/>">
</form:form>

</body>
</html>