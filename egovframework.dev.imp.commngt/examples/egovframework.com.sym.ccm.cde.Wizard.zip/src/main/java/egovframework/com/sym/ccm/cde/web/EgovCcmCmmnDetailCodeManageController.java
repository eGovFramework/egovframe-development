package egovframework.com.sym.ccm.cde.web;

import egovframework.com.cmm.annotation.RequireAdmin;

import java.util.List;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.service.CmmnDetailCode;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.sym.ccm.cca.service.CmmnCodeVO;
import egovframework.com.sym.ccm.cca.service.EgovCcmCmmnCodeManageService;
import egovframework.com.sym.ccm.ccc.service.CmmnClCodeVO;
import egovframework.com.sym.ccm.ccc.service.EgovCcmCmmnClCodeManageService;
import egovframework.com.sym.ccm.cde.service.CmmnDetailCodeVO;
import egovframework.com.sym.ccm.cde.service.EgovCcmCmmnDetailCodeManageService;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 * 공통상세코드에 관한 요청을 받아 서비스 클래스로 요청을 전달하고 서비스클래스에서 처리한 결과를 웹 화면으로 전달을 위한
 * Controller를 정의한다
 * 
 * @author 공통서비스 개발팀 이중호
 * @since 2009.04.01
 * @version 1.0
 * @see
 *
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.03.20  홍길동          최초 생성
 *   2009.04.01  이중호          최초 생성
 *   2011.08.26  정진오          IncludedInfo annotation 추가
 *   2017.08.08  이정은          표준프레임워크 v3.7 개선
 *   2024.10.29  이백행          검색조건 유지
 *   2025.07.08  이백행          2025년 컨트리뷰션 PMD로 소프트웨어 보안약점 진단하고 제거하기-LocalVariableNamingConventions(final이 아닌 변수는 밑줄을 포함할 수 없음)
 *
 *      </pre>
 */
@Controller
public class EgovCcmCmmnDetailCodeManageController {

	@Resource(name = "CmmnDetailCodeManageService")
	private EgovCcmCmmnDetailCodeManageService cmmnDetailCodeManageService;

	@Resource(name = "CmmnClCodeManageService")
	private EgovCcmCmmnClCodeManageService cmmnClCodeManageService;

	@Resource(name = "CmmnCodeManageService")
	private EgovCcmCmmnCodeManageService cmmnCodeManageService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	/**
	 * 공통상세코드 목록을 조회한다.
	 * 
	 * @param loginVO
	 * @param searchVO
	 * @param model
	 * @return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeList"
	 * @throws Exception
	 */
	@IncludedInfo(name = "공통상세코드", listUrl = "/sym/ccm/cde/SelectCcmCmmnDetailCodeList.do", order = 970, gid = 60)
	@RequestMapping(value = "/sym/ccm/cde/SelectCcmCmmnDetailCodeList.do")
	public String selectCmmnDetailCodeList(@ModelAttribute("loginVO") LoginVO loginVO,
			@ModelAttribute("searchVO") CmmnDetailCodeVO searchVO, ModelMap model) throws Exception {

		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<CmmnDetailCodeVO> resultList = cmmnDetailCodeManageService.selectCmmnDetailCodeList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = cmmnDetailCodeManageService.selectCmmnDetailCodeListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeList";
	}

	/**
	 * 공통상세코드 상세항목을 조회한다.
	 * 
	 * @param loginVO
	 * @param cmmnDetailCodeVO
	 * @param model
	 * @return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeDetail"
	 * @throws Exception
	 */
	@PostMapping("/sym/ccm/cde/SelectCcmCmmnDetailCodeDetail.do")
	@RequireAdmin
	public String selectCmmnDetailCodeDetail(@ModelAttribute("loginVO") LoginVO loginVO,
			CmmnDetailCodeVO cmmnDetailCodeVO, ModelMap model) throws Exception {
		CmmnDetailCode vo = cmmnDetailCodeManageService.selectCmmnDetailCodeDetail(cmmnDetailCodeVO);
		model.addAttribute("result", vo);

		return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeDetail";
	}

	/**
	 * 공통상세코드를 삭제한다.
	 * 
	 * @param loginVO
	 * @param cmmnDetailCodeVO
	 * @param model
	 * @return "forward:/sym/ccm/cde/EgovCcmCmmnDetailCodeList.do"
	 * @throws Exception
	 */
	@PostMapping("/sym/ccm/cde/RemoveCcmCmmnDetailCode.do")
	@RequireAdmin
	public String deleteCmmnDetailCode(@ModelAttribute("loginVO") LoginVO loginVO, CmmnDetailCodeVO cmmnDetailCodeVO,
			ModelMap model, RedirectAttributes redirectAttributes) throws Exception {
		cmmnDetailCodeManageService.deleteCmmnDetailCode(cmmnDetailCodeVO);

		redirectAttributes.addAttribute("searchCondition", cmmnDetailCodeVO.getSearchCondition());
		redirectAttributes.addAttribute("searchKeyword", cmmnDetailCodeVO.getSearchKeyword());
		redirectAttributes.addAttribute("pageIndex", cmmnDetailCodeVO.getPageIndex());

		return "redirect:/sym/ccm/cde/SelectCcmCmmnDetailCodeList.do";
	}

	/**
	 * 공통상세코드 등록을 위한 등록페이지로 이동한다.
	 *
	 * @param cmmnDetailCodeVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/sym/ccm/cde/RegistCcmCmmnDetailCodeView.do")
	@RequireAdmin
	public String insertCmmnDetailCodeView(@ModelAttribute("loginVO") LoginVO loginVO,
			@ModelAttribute("cmmnCodeVO") CmmnCodeVO cmmnCodeVO,
			@ModelAttribute("cmmnDetailCodeVO") CmmnDetailCodeVO cmmnDetailCodeVO, ModelMap model) throws Exception {

		addCodeSelectLists(cmmnCodeVO.getClCode(), model);

		return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeRegist";
	}

	private void addCodeSelectLists(String clCode, ModelMap model) throws Exception {
		CmmnClCodeVO searchClCodeVO = new CmmnClCodeVO();
		searchClCodeVO.setFirstIndex(0);
		List<CmmnClCodeVO> clCodeList = cmmnClCodeManageService.selectCmmnClCodeList(searchClCodeVO);
		model.addAttribute("clCodeList", clCodeList);

		if (!"".equals(clCode)) {

			CmmnCodeVO searchCodeVO = new CmmnCodeVO();
			searchCodeVO.setRecordCountPerPage(999999);
			searchCodeVO.setFirstIndex(0);
			searchCodeVO.setSearchCondition("clCode");
			searchCodeVO.setSearchKeyword(clCode);

			List<CmmnCodeVO> codeList = cmmnCodeManageService.selectCmmnCodeList(searchCodeVO);
			model.addAttribute("codeList", codeList);
		}
	}

	/**
	 * 공통상세코드를 등록한다.
	 *
	 * @param CmmnDetailCodeVO
	 * @param CmmnDetailCodeVO
	 * @param status
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/sym/ccm/cde/RegistCcmCmmnDetailCode.do")
	@RequireAdmin
	public String insertCmmnDetailCode(@Valid @ModelAttribute("cmmnDetailCodeVO") CmmnDetailCodeVO cmmnDetailCodeVO,
			BindingResult bindingResult, ModelMap model, RedirectAttributes redirectAttributes) throws Exception {

		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		if (bindingResult.hasErrors()) {

			addCodeSelectLists(cmmnDetailCodeVO.getClCode(), model);

			return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeRegist";
		}

		if (cmmnDetailCodeVO.getCodeId() != null) {

			CmmnDetailCode vo = cmmnDetailCodeManageService.selectCmmnDetailCodeDetail(cmmnDetailCodeVO);
			if (vo != null) {
				model.addAttribute("message", egovMessageSource.getMessage("comSymCcmCde.validate.codeCheck"));

				addCodeSelectLists(cmmnDetailCodeVO.getClCode(), model);

				return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeRegist";
			}
		}

		cmmnDetailCodeVO.setFrstRegisterId((user == null || user.getUniqId() == null) ? "" : user.getUniqId());
		cmmnDetailCodeManageService.insertCmmnDetailCode(cmmnDetailCodeVO);

		redirectAttributes.addAttribute("searchCondition", cmmnDetailCodeVO.getSearchCondition());
		redirectAttributes.addAttribute("searchKeyword", cmmnDetailCodeVO.getSearchKeyword());
		redirectAttributes.addAttribute("pageIndex", cmmnDetailCodeVO.getPageIndex());

		return "redirect:/sym/ccm/cde/SelectCcmCmmnDetailCodeList.do";
	}

	/**
	 * 공통상세코드 수정을 위한 수정페이지로 이동한다.
	 *
	 * @param cmmnDetailCodeVO
	 * @param model
	 * @return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeUpdt"
	 * @throws Exception
	 */
	@PostMapping("/sym/ccm/cde/UpdateCcmCmmnDetailCodeView.do")
	@RequireAdmin
	public String updateCmmnDetailCodeView(@ModelAttribute("loginVO") LoginVO loginVO,
			@ModelAttribute("cmmnDetailCodeVO") CmmnDetailCodeVO cmmnDetailCodeVO, ModelMap model) throws Exception {

		CmmnDetailCode result = cmmnDetailCodeManageService.selectCmmnDetailCodeDetail(cmmnDetailCodeVO);
		model.addAttribute("cmmnDetailCodeVO", result);

		return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeUpdt";
	}

	/**
	 * 공통상세코드를 수정한다.
	 *
	 * @param cmmnDetailCodeVO
	 * @param model
	 * @return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeUpdt",
	 *         "/sym/ccm/cde/SelectCcmCmmnDetailCodeList.do"
	 * @throws Exception
	 */
	@PostMapping("/sym/ccm/cde/UpdateCcmCmmnDetailCode.do")
	@RequireAdmin
	public String updateCmmnDetailCode(@Valid @ModelAttribute("cmmnDetailCodeVO") CmmnDetailCodeVO cmmnDetailCodeVO,
			ModelMap model, BindingResult bindingResult, RedirectAttributes redirectAttributes) throws Exception {

		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();


		if (bindingResult.hasErrors()) {
			CmmnDetailCode result = cmmnDetailCodeManageService.selectCmmnDetailCodeDetail(cmmnDetailCodeVO);
			model.addAttribute("cmmnDetailCodeVO", result);

			return "egovframework/com/sym/ccm/cde/EgovCcmCmmnDetailCodeUpdt";
		}

		cmmnDetailCodeVO.setLastUpdusrId((user == null || user.getUniqId() == null) ? "" : user.getUniqId());
		cmmnDetailCodeManageService.updateCmmnDetailCode(cmmnDetailCodeVO);

		redirectAttributes.addAttribute("searchCondition", cmmnDetailCodeVO.getSearchCondition());
		redirectAttributes.addAttribute("searchKeyword", cmmnDetailCodeVO.getSearchKeyword());
		redirectAttributes.addAttribute("pageIndex", cmmnDetailCodeVO.getPageIndex());

		return "redirect:/sym/ccm/cde/SelectCcmCmmnDetailCodeList.do";
	}

}
