/**
 * 개요
 * - 메인화면이미지에 대한 DAO 클래스를 정의한다.
 * 
 * 상세내용
 * - 메인화면이미지에 대한 등록, 수정, 삭제, 조회, 반영확인 기능을 제공한다.
 * - 메인화면이미지의 조회기능은 목록조회, 상세조회로 구분된다.
 * @author 이문준
 * @version 1.0
 * @created 03-8-2009 오후 2:08:58
 */

package egovframework.com.uss.ion.msi.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.FileVO;
import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.com.uss.ion.msi.service.MainImageVO;

@Repository("mainImageDAO")
public class MainImageDAO extends EgovComAbstractDAO {
	
	/**
	 * 메인화면이미지정보를 관리하기 위해 등록된 메인화면이미지 목록을 조회한다.
	 * @param mainImageVO - 메인이미지 VO
	 * @return List - 메인이미지 목록
	 */
	public List<MainImageVO> selectMainImageList(MainImageVO mainImageVO) {
		return selectList("mainImageDAO.selectMainImageList", mainImageVO);
	}

    /**
	 * 메인화면이미지목록 총 개수를 조회한다.
	 * @param mainImageVO - 메인화면이미지 VO
	 * @return int
	 */
    public int selectMainImageListTotCnt(MainImageVO mainImageVO) {
        return (Integer)selectOne("mainImageDAO.selectMainImageListTotCnt", mainImageVO);
    }

	/**
	 * 등록된 메인화면이미지의 상세정보를 조회한다.
	 * @param mainImageVO - 메인이미지 VO
	 * @return MainImageVO - 메인이미지 VO
	 */
	public MainImageVO selectMainImage(MainImageVO mainImageVO) {
		return (MainImageVO) selectOne("mainImageDAO.selectMainImage", mainImageVO);
	}

	/**
	 * 메인화면이미지정보를 신규로 등록한다.
	 * @param mainImage - 메인이미지 model
	 */
	public void insertMainImage(MainImageVO mainImageVO) {
		insert("mainImageDAO.insertMainImage", mainImageVO);
	}

	/**
	 * 기 등록된 메인화면이미지정보를 수정한다.
	 */
	public void updateMainImage(MainImageVO mainImageVO) {
		update("mainImageDAO.updateMainImage", mainImageVO);
	}

	/**
	 * 기 등록된 메인화면이미지정보를 삭제한다.
	 */
	public void deleteMainImage(MainImageVO mainImageVO) {
		delete("mainImageDAO.deleteMainImage", mainImageVO);
	}

	/**
	 * 기 등록된 메인화면이미지정보의 이미지파일을 삭제하기 위해 파일정보를 조회한다.
	 */
	public FileVO selectMainImageFile(MainImageVO mainImageVO) {
		return (FileVO) selectOne("mainImageDAO.selectMainImageFile", mainImageVO);
	}

	/**
	 * 메인화면이미지가 특정화면에 반영된 결과를 조회한다.
	 * @param mainImageVO - 메인이미지 VO
	 * @return MainImageVO - 메인이미지 VO
	 */
	public List<MainImageVO> selectMainImageResult(MainImageVO mainImageVO) {
		return selectList("mainImageDAO.selectMainImageResult", mainImageVO);
	}
}
