package egovframework.com.cop.scp.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.cmmn.exception.BaseRuntimeException;
import org.egovframe.rte.fdl.cmmn.exception.FdlException;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cop.scp.service.EgovArticleScrapService;
import egovframework.com.cop.scp.service.Scrap;
import egovframework.com.cop.scp.service.ScrapVO;
import jakarta.annotation.Resource;

@Service("EgovArticleScrapService")
public class EgovArticleScrapServiceImpl extends EgovAbstractServiceImpl implements EgovArticleScrapService{

	@Resource(name = "EgovArticleScrapDAO")
    private EgovArticleScrapDAO egovArticleScrapDao;

    @Resource(name="egovScrapIdGnrService")
    private EgovIdGnrService idgenService;

	@Override
	public Map<String, Object> selectArticleScrapList(ScrapVO scrapVO) {
		List<ScrapVO> result = egovArticleScrapDao.selectArticleScrapList(scrapVO);
		int cnt = egovArticleScrapDao.selectArticleScrapListCnt(scrapVO);

		Map<String, Object> map = new HashMap<>();

		map.put("resultList", result);
		map.put("resultCnt", Integer.toString(cnt));

		return map;
	}

	@Override
	public void insertArticleScrap(Scrap scrap) {

		String scrapId;
		try {
			scrapId = idgenService.getNextStringId();
		} catch (FdlException e) {
			throw new BaseRuntimeException(e);
		}
		scrap.setScrapId(scrapId);

		egovArticleScrapDao.insertArticleScrap(scrap);
	}

	@Override
	public ScrapVO selectArticleScrapDetail(ScrapVO scrapVO) {
		return egovArticleScrapDao.selectArticleScrapDetail(scrapVO);
	}

	@Override
	public void deleteArticleScrap(ScrapVO scrapVO) {
		egovArticleScrapDao.deleteArticleScrap(scrapVO);
	}

	@Override
	public void updateArticleScrap(Scrap scrap) {
		egovArticleScrapDao.updateArticleScrap(scrap);
	}

}
