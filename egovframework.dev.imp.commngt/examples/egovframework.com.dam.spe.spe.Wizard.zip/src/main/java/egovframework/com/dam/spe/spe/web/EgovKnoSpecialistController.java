package egovframework.com.dam.spe.spe.web;

import egovframework.com.cmm.annotation.RequireAdmin;

import java.util.List;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.dam.map.mat.service.EgovMapMaterialService;
import egovframework.com.dam.map.mat.service.MapMaterial;
import egovframework.com.dam.map.mat.service.MapMaterialVO;
import egovframework.com.dam.map.tea.service.EgovMapTeamService;
import egovframework.com.dam.map.tea.service.MapTeamVO;
import egovframework.com.dam.spe.spe.service.EgovKnoSpecialistService;
import egovframework.com.dam.spe.spe.service.KnoSpecialist;
import egovframework.com.dam.spe.spe.service.KnoSpecialistVO;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 * <pre>
 * 개요
 * - 지식전문가에 대한 controller 클래스를 정의한다.
 *
 * 상세내용
 * - 지식전문가에 대한 등록, 수정, 삭제, 조회 기능을 제공한다.
 * - 지식전문가의 조회기능은 목록조회, 상세조회로 구분된다.
 * </pre>
 * 
 * @author 박종선
 * @since 2010.08.12
 * @version 1.0
 * @see
 * 
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2010.08.12  박종선          최초 생성
 *   2011.08.26  정진오          IncludedInfo annotation 추가
 *   2025.06.19  이백행          PMD로 소프트웨어 보안약점 진단하고 제거하기-LocalVariableNamingConventions(지역 변수 명명 규칙)
 *
 *      </pre>
 */
@Controller
public class EgovKnoSpecialistController {

	@Resource(name = "MapMaterialService")
	public EgovMapMaterialService mapMaterialService;

	@Resource(name = "MapTeamService")
	private EgovMapTeamService mapTeamService;

	@Resource(name = "KnoSpecialistService")
	private EgovKnoSpecialistService knoSpecialistService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	/**
	 * 등록된 지식전문가 정보를 조회 한다.
	 * 
	 * @param KnoSpecialistVO- 지식전문가 VO
	 * @return String - 리턴 Url
	 *
	 * @param KnoSpecialistVO
	 */
	@IncludedInfo(name = "지식전문가관리", listUrl = "/dam/spe/spe/EgovComDamSpecialistList.do", order = 1270, gid = 80)
	@RequestMapping(value = "/dam/spe/spe/EgovComDamSpecialistList.do")
	public String selectKnoSpecialistList(@ModelAttribute("loginVO") LoginVO loginVO,
			@ModelAttribute("searchVO") KnoSpecialistVO searchVO, ModelMap model) throws Exception {

		/** EgovPropertyService.mapMaterial */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** paging */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<KnoSpecialistVO> resultList = knoSpecialistService.selectKnoSpecialistList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = knoSpecialistService.selectKnoSpecialistTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/dam/spe/spe/EgovComDamSpecialistList";
	}

	/**
	 * 지식전문가 상세 정보를 조회 한다.
	 *
	 * @param knoSpecialist - 지식전문가 model
	 * @param model
	 * @return String - 리턴 Url
	 */
	@RequestMapping(value = "/dam/spe/spe/EgovComDamSpecialist.do")
	@RequireAdmin
	public String selectKnoSpecialist(KnoSpecialist knoSpecialist, ModelMap model) throws Exception {
		KnoSpecialist vo = knoSpecialistService.selectKnoSpecialist(knoSpecialist);
		model.addAttribute("result", vo);
		return "egovframework/com/dam/spe/spe/EgovComDamSpecialistDetail";
	}

	/**
	 * 지식전문가 등록 화면으로 이동한다.
	 *
	 * @param mapMaterial - 지식맵(유형) model
	 * @param model
	 * @return String - 리턴 Url
	 */
	@PostMapping("/dam/spe/spe/EgovComDamSpecialistRegistView.do")
	@RequireAdmin
	public String selectKnoSpecialistRegistView(@ModelAttribute("knoSpecialist") KnoSpecialist knoSpecialist,
			@ModelAttribute("mapMaterial") MapMaterial mapMaterial, ModelMap model,
			RedirectAttributes redirectAttributes) throws Exception {

		// Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			redirectAttributes.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		MapTeamVO searchVO = new MapTeamVO();
		searchVO.setRecordCountPerPage(999999);
		searchVO.setFirstIndex(0);
		searchVO.setSearchCondition("MaterialList");
		List<MapTeamVO> mapTeamList = mapTeamService.selectMapTeamList(searchVO);
		model.addAttribute("mapTeamList", mapTeamList);

		MapMaterialVO searchMatVO = new MapMaterialVO();
		searchMatVO.setRecordCountPerPage(999999);
		searchMatVO.setFirstIndex(0);
		searchMatVO.setSearchCondition("orgnztId");
		searchMatVO.setSearchKeyword(mapMaterial.getOrgnztId());

		List<MapMaterialVO> mapMaterialList = mapMaterialService.selectMapMaterialList(searchMatVO);
		model.addAttribute("mapMaterialList", mapMaterialList);

		return "egovframework/com/dam/spe/spe/EgovComDamSpecialistRegist";
	}

	/**
	 * 지식전문가 정보를 신규로 등록한다.
	 *
	 * @param knoSpecialist - 지식전문가 model
	 * @param bindingResult
	 * @param mapMaterial - 지식맵(유형) model
	 * @param model
	 * @return String - 리턴 Url
	 */
	@PostMapping("/dam/spe/spe/EgovComDamSpecialistRegist.do")
	@RequireAdmin
	public String insertKnoSpecialist(@ModelAttribute("mapMaterial") MapMaterial mapMaterial,
			@Valid @ModelAttribute("knoSpecialist") KnoSpecialist knoSpecialist, BindingResult bindingResult,
			ModelMap model, RedirectAttributes redirectAttributes) throws Exception {

		// Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			redirectAttributes.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		// 로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		if (bindingResult.hasErrors()) {
			MapTeamVO searchVO = new MapTeamVO();
			searchVO.setRecordCountPerPage(999999);
			searchVO.setFirstIndex(0);
			searchVO.setSearchCondition("MaterialList");
			List<MapTeamVO> mapTeamList = mapTeamService.selectMapTeamList(searchVO);
			model.addAttribute("mapTeamList", mapTeamList);

			MapMaterialVO searchMatVO = new MapMaterialVO();
			searchMatVO.setRecordCountPerPage(999999);
			searchMatVO.setFirstIndex(0);
			searchMatVO.setSearchCondition("orgnztId");

			/*
			if (mapMaterial.getOrgnztId() == null || mapMaterial.getOrgnztId().equals("")) {
				if (!mapTeamList.isEmpty()) {
					MapTeamVO emp = mapTeamList.get(0);
					mapMaterial.setOrgnztId(emp.getOrgnztId());
				}
			}
			*/
			
			searchMatVO.setSearchKeyword(mapMaterial.getOrgnztId());

			List<MapMaterialVO> mapMaterialList = mapMaterialService.selectMapMaterialList(searchMatVO);
			model.addAttribute("mapMaterialList", mapMaterialList);

			return "egovframework/com/dam/spe/spe/EgovComDamSpecialistRegist";
		}

		// 아이디 설정
		knoSpecialist.setFrstRegisterId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));
		knoSpecialist.setLastUpdusrId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));

		knoSpecialistService.insertKnoSpecialist(knoSpecialist);
		return "forward:/dam/spe/spe/EgovComDamSpecialistList.do";
	}

	/**
	 * 지식전문가 수정 화면으로 이동한다.
	 *
	 * @param knoSpecialist - 지식전문가 model
	 * @param model
	 * @return String - 리턴 Url
	 */
	@PostMapping("/dam/spe/spe/EgovComDamSpecialistModifyView.do")
	@RequireAdmin
	public String selectKnoSpecialistModifyView(@ModelAttribute("knoSpecialist") KnoSpecialist knoSpecialist,
			ModelMap model) throws Exception {

		KnoSpecialist vo = EgovAuthorizationHelper.requireTarget(knoSpecialistService.selectKnoSpecialist(knoSpecialist));
		model.addAttribute("knoSpecialist", vo);
		return "egovframework/com/dam/spe/spe/EgovComDamSpecialistModify";
	}

	/**
	 * 기 등록 된 지식전문가 정보를 수정 한다.
	 *
	 * @param knoSpecialist - 지식전문가 model
	 * @param bindingResult
	 * @param model
	 * @return String - 리턴 Url
	 */
	@PostMapping("/dam/spe/spe/EgovComDamSpecialistModify.do")
	@RequireAdmin
	public String updateKnoSpecialist(@Valid @ModelAttribute("knoSpecialist") KnoSpecialist knoSpecialist,
			BindingResult bindingResult, ModelMap model) throws Exception {

		// 로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();


		if (bindingResult.hasErrors()) {
			//KnoSpecialist vo = knoSpecialistService.selectKnoSpecialist(knoSpecialist);
			//model.addAttribute("knoSpecialist", vo);
			return "egovframework/com/dam/spe/spe/EgovComDamSpecialistModify";
		}

		// 아이디 설정
		knoSpecialist.setFrstRegisterId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));
		knoSpecialist.setLastUpdusrId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));

		knoSpecialistService.updateKnoSpecialist(knoSpecialist);
		return "forward:/dam/spe/spe/EgovComDamSpecialistList.do";
	}

	/**
	 * 기 등록된 지식전문가 정보를 삭제한다.
	 * 
	 * @param siteUrl - 지식전문가 model
	 * @return String - 리턴 Url
	 *
	 * @param speNm
	 */
	@PostMapping("/dam/spe/spe/EgovComDamSpecialistRemove.do")
	@RequireAdmin
	public String deleteKnoSpecialist(@ModelAttribute("loginVO") LoginVO loginVO, KnoSpecialist knoSpecialist,
			ModelMap model) throws Exception {
		knoSpecialistService.deleteKnoSpecialist(knoSpecialist);
		return "forward:/dam/spe/spe/EgovComDamSpecialistList.do";
	}

}