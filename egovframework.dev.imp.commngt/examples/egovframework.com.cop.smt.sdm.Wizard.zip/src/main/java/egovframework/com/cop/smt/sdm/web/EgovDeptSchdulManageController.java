package egovframework.com.cop.smt.sdm.web;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.psl.dataaccess.util.EgovMap;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.annotation.RequireAdmin;
import egovframework.com.cmm.service.CmmnDetailCode;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.EgovFileMngUtil;
import egovframework.com.cmm.service.FileVO;
import egovframework.com.cmm.util.EgovAttachmentGrants;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.cop.smt.sdm.service.DeptSchdulSearchVO;
import egovframework.com.cop.smt.sdm.service.DeptSchdulManageVO;
import egovframework.com.cop.smt.sdm.service.EgovDeptSchdulManageService;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

/**
 * 부서일정관리를 처리하는 Controller Class 구현
 * 
 * @author 공통서비스 장동한
 * @since 2009.04.10
 * @version 1.0
 * @see
 * 
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.04.10  장동한          최초 생성
 *   2011.08.26  정진오          IncludedInfo annotation 추가
 *	 2011.09.01  정진오          10월 주별 달력 테이블에 날짜가 이상하게 나와서 수정함
 *   2025.06.11  이백행          PMD로 소프트웨어 보안약점 진단하고 제거하기-LocalVariableNamingConventions(지역 변수 명명 규칙)
 *
 *      </pre>
 */
@Controller
public class EgovDeptSchdulManageController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovDeptSchdulManageController.class);

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	@Resource(name = "egovDeptSchdulManageService")
	private EgovDeptSchdulManageService egovDeptSchdulManageService;

	@Resource(name = "EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	// 첨부파일 관련
	@Resource(name = "EgovFileMngService")
	private EgovFileMngService fileMngService;

	@Resource(name = "EgovFileMngUtil")
	private EgovFileMngUtil fileUtil;

	/**
	 * 개별 배포시 메인메뉴를 조회한다.
	 * 
	 * @param model
	 * @return "/cop/smt/sdm/EgovMain"
	 */
	@RequestMapping(value = "/cop/smt/EgovMain.do")
	@RequireAdmin
	public String egovMain(ModelMap model) {
		return "egovframework/com/cop/smt/sdm/EgovMain";
	}

	/**
	 * 메뉴를 조회한다.
	 * 
	 * @param model
	 * @return "/cop/smt/sdm/EgovLeft"
	 */
	@RequestMapping(value = "/cop/smt/EgovLeft.do")
	@RequireAdmin
	public String egovLeft(ModelMap model) {
		return "egovframework/com/cop/smt/sdm/EgovLeft";
	}

	/**
	 * 부서목록을 조회한다.
	 * 
	 * @param searchVO
	 * @param commandMap
	 * @param model
	 * @return "uss/olp/mgt/EgovDeptSchdulManageAuthorGroupPopup"
	 */
	@RequestMapping(value = "/cop/smt/sdm/EgovDeptSchdulManageAuthorGroupPopup.do")
	@RequireAdmin
	public String egovMeetingManageLisAuthorGroupPopupPost(@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<?, ?> commandMap, ModelMap model) {

		List<EgovMap> resultList = egovDeptSchdulManageService.selectDeptSchdulManageAuthorGroupPopup(searchVO);
		model.addAttribute("resultList", resultList);

		return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageAuthorGroupPopup";
	}

	/**
	 * 회원목록을 조회한다.
	 * 
	 * @param searchVO
	 * @param commandMap
	 * @param model
	 * @return "/uss/olp/mgt/EgovMeetingManageLisEmpLyrPopup"
	 */
	@RequestMapping(value = "/cop/smt/sdm/EgovDeptSchdulManageEmpLyrPopup.do")
	@RequireAdmin
	public String egovMeetingManageLisEmpLyrPopupPost(@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<?, ?> commandMap, ModelMap model) {

		List<EgovMap> resultList = egovDeptSchdulManageService.selectDeptSchdulManageEmpLyrPopup(searchVO);
		model.addAttribute("resultList", resultList);

		return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageEmpLyrPopup";
	}

	/**
	 * 메인페이지/부서일정관리조회
	 * 
	 * @param commandMap
	 * @param model
	 * @return "egovframework/com/cop/smt/sim/EgovIndvdlSchdulManageMainList"
	 */
	@RequestMapping(value = "/cop/smt/sdm/EgovDeptSchdulManageMainList.do")
	public String egovDeptSchdulManageList(@RequestParam Map<?, ?> commandMap, ModelMap model) {

		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		// 로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		if (loginVO == null) {
			loginVO = new LoginVO();
		}

		Map<String, String> hmParam = new HashMap<>();

		hmParam.put("uniqId", loginVO.getUniqId());

		List<EgovMap> reusltList = egovDeptSchdulManageService.selectDeptSchdulManageMainList(hmParam);

		model.addAttribute("resultList", reusltList);

		return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageMainList";

	}

	/**
	 * 일지관리 목록을 조회한다.
	 * 
	 * @param searchVO
	 * @param model
	 * @return "egovframework/com/cop/smt/dsm/EgovDiaryManageList"
	 */
	@RequestMapping(value = "/cop/smt/sdm/EgovDeptSchdulManageListPopup.do")
	public String egovDeptSchdulManageListPopup(@ModelAttribute("searchVO") DeptSchdulSearchVO searchVO, ModelMap model) {

		// 일지를 등록하는 사용자 본인이 등록한 일정만 보여준다 (요청 값은 신뢰하지 않고 로그인 사용자로 고정)
		searchVO.setFrstRegisterId(EgovAuthorizationHelper.assertLoginUser().getUniqId());

		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<EgovMap> resultList = egovDeptSchdulManageService.selectDeptSchdulManageList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = egovDeptSchdulManageService.selectDeptSchdulManageListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageListPopup";
	}

	/**
	 * 부서일정(일별) 목록을 조회한다.
	 * 
	 * @param searchVO
	 * @param commandMap
	 * @param deptSchdulManageVO
	 * @param model
	 * @return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageDailyList"
	 */
	@RequestMapping(value = "/cop/smt/sdm/EgovDeptSchdulManageDailyList.do")
	@RequireAdmin
	public String egovDeptSchdulManageDailyList(@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<String, String> commandMap, DeptSchdulManageVO deptSchdulManageVO, ModelMap model) {

		// 검색 유지
		model.addAttribute("searchKeyword",
				commandMap.get("searchKeyword") == null ? "" : (String) commandMap.get("searchKeyword"));
		model.addAttribute("searchCondition",
				commandMap.get("searchCondition") == null ? "" : (String) commandMap.get("searchCondition"));

		// 공통코드 부서일정종류
		ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
		voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM030");
		List<CmmnDetailCode> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("schdulSe", listComCode);

		/* *****************************************************************
    	// 캘런더 설정 로직
		****************************************************************** */
		Calendar calNow = Calendar.getInstance();

		String strYear = commandMap.get("year");
		String strMonth = commandMap.get("month");
		String strDay = commandMap.get("day");
		String strSearchDay = "";
		int iNowYear = calNow.get(Calendar.YEAR);
		int iNowMonth = calNow.get(Calendar.MONTH);
		int iNowDay = calNow.get(Calendar.DATE);

		if (strYear != null) {
			iNowYear = Integer.parseInt(strYear);
			iNowMonth = Integer.parseInt(strMonth);
			iNowDay = Integer.parseInt(strDay);
		}

		strSearchDay = Integer.toString(iNowYear);
		strSearchDay += dateTypeIntForString(iNowMonth + 1);
		strSearchDay += dateTypeIntForString(iNowDay);

		commandMap.put("searchMode", "DAILY");
		commandMap.put("searchDay", strSearchDay);

		model.addAttribute("year", iNowYear);
		model.addAttribute("month", iNowMonth);
		model.addAttribute("day", iNowDay);

		List<EgovMap> resultList = egovDeptSchdulManageService.selectDeptSchdulManageRetrieve(commandMap);
		model.addAttribute("resultList", resultList);

		return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageDailyList";
	}

	/**
	 * 부서일정(주간별) 목록을 조회한다.
	 * 
	 * @param searchVO
	 * @param commandMap
	 * @param deptSchdulManageVO
	 * @param model
	 * @return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageWeekList"
	 */
	@RequestMapping(value = "/cop/smt/sdm/EgovDeptSchdulManageWeekList.do")
	@RequireAdmin
	public String egovDeptSchdulManageWeekList(@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<String, String> commandMap, DeptSchdulManageVO deptSchdulManageVO, ModelMap model) {

		// 일정구분 검색 유지
		model.addAttribute("searchKeyword",
				commandMap.get("searchKeyword") == null ? "" : (String) commandMap.get("searchKeyword"));
		model.addAttribute("searchCondition",
				commandMap.get("searchCondition") == null ? "" : (String) commandMap.get("searchCondition"));

		// 공통코드 부서일정종류
		ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
		voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM030");
		List<CmmnDetailCode> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("schdulSe", listComCode);

		/* *****************************************************************
    	// 캘런더 설정 로직
		****************************************************************** */
		Calendar calNow = Calendar.getInstance();
		Calendar calBefore = Calendar.getInstance();
		Calendar calNext = Calendar.getInstance();

		String strYear = commandMap.get("year");
		String strMonth = commandMap.get("month");
		String strWeek = commandMap.get("week");

		int iNowYear = calNow.get(Calendar.YEAR);
		int iNowMonth = calNow.get(Calendar.MONTH);
		int iNowDate = calNow.get(Calendar.DATE);
		int iNowWeek = 0;

		if (strYear != null) {
			iNowYear = Integer.parseInt(strYear);
			iNowMonth = Integer.parseInt(strMonth);
			iNowWeek = Integer.parseInt(strWeek);
		}

		// 연도/월 셋팅
		calNow.set(iNowYear, iNowMonth, 1);
		calBefore.set(iNowYear, iNowMonth, 1);
		calNext.set(iNowYear, iNowMonth, 1);

		calBefore.add(Calendar.MONTH, -1);
		calNext.add(Calendar.MONTH, +1);

//		int startDay = calNow.getMinimum(Calendar.DATE);
		int endDay = calNow.getActualMaximum(Calendar.DAY_OF_MONTH);
		int startWeek = calNow.get(Calendar.DAY_OF_WEEK);

		List<List<String>> listWeekGrop = new ArrayList<>();
		List<String> listWeekDate = new ArrayList<>();

		String sUseDate = "";

		calBefore.add(Calendar.DATE, calBefore.getActualMaximum(Calendar.DAY_OF_MONTH) - (startWeek - 1));
		for (int i = 1; i < startWeek; i++) {
			sUseDate = Integer.toString(calBefore.get(Calendar.YEAR));
			sUseDate += dateTypeIntForString(calBefore.get(Calendar.MONTH) + 1);
			sUseDate += dateTypeIntForString(calBefore.get(Calendar.DATE));

			listWeekDate.add(sUseDate);
			calBefore.add(Calendar.DATE, +1);
		}

		int iBetweenCount = startWeek;

		// 주별로 자른다. BETWEEN 구하기
		for (int i = 1; i <= endDay; i++) {
			sUseDate = Integer.toString(iNowYear);
			// sUseDate += Integer.toString(iNowMonth).length() == 1 ? "0" +
			// Integer.toString(iNowMonth+1) : Integer.toString(iNowMonth+1);
			// (2011.9.1 수정사항) 10월의 주별 날짜가 이상하게 나와서 LeaderSchedule 보고 수정함. 위의 코드가 원래 코드
			sUseDate += Integer.toString(iNowMonth + 1).length() == 1 ? "0" + Integer.toString(iNowMonth + 1)
					: Integer.toString(iNowMonth + 1);
			sUseDate += Integer.toString(i).length() == 1 ? "0" + Integer.toString(i) : Integer.toString(i);

			listWeekDate.add(sUseDate);

			if (iBetweenCount % 7 == 0) {
				listWeekGrop.add(listWeekDate);
				listWeekDate = new ArrayList<>();

				if (strYear == null && i < iNowDate) {
					iNowWeek++;

				}
			}

			// 미지막 7일 자동계산
			if (i == endDay) {

				for (int j = listWeekDate.size(); j < 7; j++) {
					String sUseNextDate = Integer.toString(calNext.get(Calendar.YEAR));
					sUseNextDate += dateTypeIntForString(calNext.get(Calendar.MONTH) + 1);
					sUseNextDate += dateTypeIntForString(calNext.get(Calendar.DATE));
					listWeekDate.add(sUseNextDate);
					calNext.add(Calendar.DATE, +1);
				}

				listWeekGrop.add(listWeekDate);
			}

			iBetweenCount++;
		}

		model.addAttribute("year", iNowYear);
		model.addAttribute("month", iNowMonth);
		model.addAttribute("week", iNowWeek);

		model.addAttribute("listWeekGrop", listWeekGrop);

		// 2026.09.01 인덱스 사용 전 범위 검증(IndexOutOfBoundsException 방지)
		if (iNowWeek < 0 || iNowWeek >= listWeekGrop.size()) {
			iNowWeek = 0;
			model.addAttribute("week", iNowWeek);
		}

		List<String> listWeek = listWeekGrop.get(iNowWeek);
		commandMap.put("searchMode", "WEEK");
		commandMap.put("schdulBgnde", listWeek.get(0));
		commandMap.put("schdulEndde", listWeek.get(listWeek.size() - 1));

		List<?> resultList = egovDeptSchdulManageService.selectDeptSchdulManageRetrieve(commandMap);
		model.addAttribute("resultList", resultList);

		return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageWeekList";
	}

	/**
	 * 부서일정(월별) 목록을 조회한다.
	 * 
	 * @param searchVO
	 * @param commandMap
	 * @param deptSchdulManageVO
	 * @param model
	 * @return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageMonthList"
	 */
	@RequestMapping(value = "/cop/smt/sdm/EgovDeptSchdulManageMonthList.do")
	public String egovDeptSchdulManageMonthList(@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@RequestParam Map<String, String> commandMap, DeptSchdulManageVO deptSchdulManageVO, ModelMap model) {

		// 일정구분 검색 유지
		model.addAttribute("searchKeyword",
				commandMap.get("searchKeyword") == null ? "" : (String) commandMap.get("searchKeyword"));
		model.addAttribute("searchCondition",
				commandMap.get("searchCondition") == null ? "" : (String) commandMap.get("searchCondition"));

		java.util.Calendar cal = java.util.Calendar.getInstance();

		String sYear = commandMap.get("year");
		String sMonth = commandMap.get("month");

		int iYear = cal.get(java.util.Calendar.YEAR);
		int iMonth = cal.get(java.util.Calendar.MONTH);
//		int iDate = cal.get(java.util.Calendar.DATE);

		// 검색 설정
		String sSearchDate = "";
		if (sYear == null || sMonth == null) {
			sSearchDate += Integer.toString(iYear);
			sSearchDate += Integer.toString(iMonth + 1).length() == 1 ? "0" + Integer.toString(iMonth + 1)
					: Integer.toString(iMonth + 1);
		} else {
			iYear = Integer.parseInt(sYear);
			iMonth = Integer.parseInt(sMonth);
			sSearchDate += sYear;
			sSearchDate += Integer.toString(iMonth + 1).length() == 1 ? "0" + Integer.toString(iMonth + 1)
					: Integer.toString(iMonth + 1);
		}

		commandMap.put("searchMonth", sSearchDate);

		// 공통코드 부서일정종류
		ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
		voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM030");
		List<CmmnDetailCode> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("schdulSe", listComCode);

		commandMap.put("searchMode", "MONTH");
		List<EgovMap> resultList = egovDeptSchdulManageService.selectDeptSchdulManageRetrieve(commandMap);
		model.addAttribute("resultList", resultList);

		return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageMonthList";
	}

	/**
	 * 부서일정 목록을 조회한다.
	 * 
	 * @return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageList"
	 */
	@IncludedInfo(name = "부서일정관리", order = 320, gid = 40)
	@RequestMapping(value = "/cop/smt/sdm/EgovDeptSchdulManageList.do")
	public String egovDeptSchdulManageList() {
		return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageList";
	}

	/**
	 * 부서일정 목록을 상세조회 조회한다.
	 * 
	 * @param searchVO
	 * @param deptSchdulManageVO
	 * @param model
	 * @return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageDetail"
	 */
	@GetMapping("/cop/smt/sdm/EgovDeptSchdulManageDetail.do")
	@RequireAdmin
	public String egovDeptSchdulManageDetail(@ModelAttribute("searchVO") ComDefaultVO searchVO,
			DeptSchdulManageVO deptSchdulManageVO, ModelMap model) {

		// 관리자 전용 — 다른 부서 일정도 조회한다. 없는 일정은 거부
		requireDeptSchdul(deptSchdulManageVO);

		// 공통코드 중요도 조회
		ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM019");
		List<CmmnDetailCode> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("schdulIpcrCode", listComCode);
		// 공통코드 일정구분 조회
		voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM030");
		listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("schdulSe", listComCode);
		// 공통코드 반복구분 조회
		voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM031");
		listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("reptitSeCode", listComCode);

		List<EgovMap> resultList = egovDeptSchdulManageService.selectDeptSchdulManageDetail(deptSchdulManageVO);
		model.addAttribute("resultList", resultList);

		return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageDetail";
	}

	/**
	 * 부서일정을 삭제한다.
	 * 
	 * @param deptSchdulManageVO
	 * @return redirect:/cop/smt/sdm/EgovDeptSchdulManageList.do
	 */
	@PostMapping(value = "/cop/smt/sdm/EgovDeptSchdulManageDetail.do", params = "cmd=del")
	@RequireAdmin
	public String egovDeptSchdulManageDelete(DeptSchdulManageVO deptSchdulManageVO) {

		// 같은 부서 일정만 삭제한다 (다른 부서 일정은 관리자도 불가)
		DeptSchdulManageVO stored = requireDeptSchdul(deptSchdulManageVO);
		EgovAuthorizationHelper.assertSameDept(stored == null ? null : stored.getSchdulDeptId());

		egovDeptSchdulManageService.deleteDeptSchdulManage(deptSchdulManageVO);
		return "redirect:/cop/smt/sdm/EgovDeptSchdulManageList.do";
	}

	/**
	 * 부서일정를 수정 폼
	 * 
	 * @param searchVO
	 * @param commandMap
	 * @param deptSchdulManageVO
	 * @param bindingResult
	 * @param model
	 * @return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageModify"
	 */
	@PostMapping("/cop/smt/sdm/EgovDeptSchdulManageModify.do")
	@RequireAdmin
	public String deptSchdulManageModify(@ModelAttribute("searchVO") ComDefaultVO searchVO,
			DeptSchdulManageVO deptSchdulManageVO, ModelMap model, HttpServletRequest request) {
		// 2026.07.13 KISA 보안취약점 조치
		LoginVO _loginVO = EgovAuthorizationHelper.assertLoginUser();

		// 같은 부서 일정만 수정폼에 접근한다 (다른 부서 일정은 관리자도 불가)
		DeptSchdulManageVO resultDeptSchdulManageVOReuslt = requireDeptSchdul(deptSchdulManageVO);
		EgovAuthorizationHelper.assertSameDept(resultDeptSchdulManageVOReuslt == null ? null : resultDeptSchdulManageVOReuslt.getSchdulDeptId());
		EgovAttachmentGrants.allowDelete(request, resultDeptSchdulManageVOReuslt.getAtchFileId());

		String sLocationUrl = "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageModify";

		// 공통코드 중요도 조회
		ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM019");
		List<CmmnDetailCode> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("schdulIpcrCode", listComCode);
		// 공통코드 일정구분 조회
		voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM030");
		listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("schdulSe", listComCode);
		// 공통코드 반복구분 조회
		voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM031");
		listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("reptitSeCode", listComCode);

		// 일정시작일자(시)
		model.addAttribute("schdulBgndeHH", getTimeHH());
		// 일정시작일자(분)
		model.addAttribute("schdulBgndeMM", getTimeMM());
		// 일정종료일자(시)
		model.addAttribute("schdulEnddeHH", getTimeHH());
		// 일정종료일자(분)
		model.addAttribute("schdulEnddeMM", getTimeMM());

		String sSchdulBgnde = resultDeptSchdulManageVOReuslt.getSchdulBgnde();
		String sSchdulEndde = resultDeptSchdulManageVOReuslt.getSchdulEndde();

		resultDeptSchdulManageVOReuslt.setSchdulBgndeYYYMMDD(
				sSchdulBgnde.substring(0, 4) + "-" + sSchdulBgnde.substring(4, 6) + "-" + sSchdulBgnde.substring(6, 8));
		resultDeptSchdulManageVOReuslt.setSchdulBgndeHH(sSchdulBgnde.substring(8, 10));
		resultDeptSchdulManageVOReuslt.setSchdulBgndeMM(sSchdulBgnde.substring(10, 12));

		resultDeptSchdulManageVOReuslt.setSchdulEnddeYYYMMDD(
				sSchdulEndde.substring(0, 4) + "-" + sSchdulEndde.substring(4, 6) + "-" + sSchdulEndde.substring(6, 8));
		resultDeptSchdulManageVOReuslt.setSchdulEnddeHH(sSchdulEndde.substring(8, 10));
		resultDeptSchdulManageVOReuslt.setSchdulEnddeMM(sSchdulEndde.substring(10, 12));

		model.addAttribute("deptSchdulManageVO", resultDeptSchdulManageVOReuslt);

		return sLocationUrl;
	}

	/**
	 * 부서일정를 수정 처리 한다.
	 * 
	 * @param multiRequest
	 * @param commandMap
	 * @param deptSchdulManageVO
	 * @param bindingResult
	 * @param model
	 * @return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageModify"
	 */
	@PostMapping("/cop/smt/sdm/EgovDeptSchdulManageModifyActor.do")
	@RequireAdmin
	public String deptSchdulManageModifyActor(final MultipartHttpServletRequest multiRequest,
			@RequestParam Map<String, String> commandMap,
			@Valid @ModelAttribute("deptSchdulManageVO") DeptSchdulManageVO deptSchdulManageVO, BindingResult bindingResult,
			ModelMap model, RedirectAttributes redirectAttributes) {

		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			redirectAttributes.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		// 로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		// 같은 부서 일정만 수정한다 (다른 부서 일정은 관리자도 불가). 부서는 저장된 값으로 고정해 다른 부서로 옮기지 못하게 한다
		DeptSchdulManageVO storedBeforeUpdate = requireDeptSchdul(deptSchdulManageVO);
		EgovAuthorizationHelper.assertSameDept(storedBeforeUpdate == null ? null : storedBeforeUpdate.getSchdulDeptId());
		deptSchdulManageVO.setSchdulDeptId(storedBeforeUpdate.getSchdulDeptId());
		// 첨부 그룹은 요청값이 아니라 소유권을 확인한 원본의 것만 쓴다(남의 첨부 ID 저장 → 삭제 허가 우회 차단)
		deptSchdulManageVO.setAtchFileId(Objects.toString(storedBeforeUpdate.getAtchFileId(), ""));

		String sLocationUrl = "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageModify";

		String sCmd = commandMap.get("cmd");

		if ("save".equals(sCmd)) {
			if (bindingResult.hasErrors()) {

				// 공통코드 중요도 조회
				ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
				voComCode.setCodeId("COM019");
				List<CmmnDetailCode> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
				model.addAttribute("schdulIpcrCode", listComCode);
				// 공통코드 일정구분 조회
				voComCode = new ComDefaultCodeVO();
				voComCode.setCodeId("COM030");
				listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
				model.addAttribute("schdulSe", listComCode);
				// 공통코드 반복구분 조회
				voComCode = new ComDefaultCodeVO();
				voComCode.setCodeId("COM031");
				listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
				model.addAttribute("reptitSeCode", listComCode);

				// 일정시작일자(시)
				model.addAttribute("schdulBgndeHH", getTimeHH());
				// 일정시작일자(분)
				model.addAttribute("schdulBgndeMM", getTimeMM());
				// 일정종료일자(시)
				model.addAttribute("schdulEnddeHH", getTimeHH());
				// 일정종료일자(분)
				model.addAttribute("schdulEnddeMM", getTimeMM());

				return sLocationUrl;
			}
			/*
			 * ***************************************************************** // 아이디 설정
			 */
			deptSchdulManageVO.setFrstRegisterId(loginVO.getUniqId());
			deptSchdulManageVO.setLastUpdusrId(loginVO.getUniqId());
			/*
			 * ***************************************************************** // 첨부파일 관련
			 * ID 생성 start....
			 */
			String atchFileId = deptSchdulManageVO.getAtchFileId();

			// final Map<String, MultipartFile> files = multiRequest.getFileMap();
			final List<MultipartFile> files = multiRequest.getFiles("file_1");

			if (!files.isEmpty()) {
				String atchFileAt = commandMap.get("atchFileAt");
				if ("N".equals(atchFileAt) || "".equals(atchFileAt)) {
					List<FileVO> fvoList = fileUtil.parseFileInf(files, "DSCH_", 0, atchFileId, "");
					atchFileId = fileMngService.insertFileInfs(fvoList);

					// 첨부파일 ID 셋팅
					deptSchdulManageVO.setAtchFileId(atchFileId); // 첨부파일 ID
				} else {
					FileVO fvo = new FileVO();
					fvo.setAtchFileId(atchFileId);
					int fileKeyParam = fileMngService.getMaxFileSN(fvo);
					List<FileVO> fvoList = fileUtil.parseFileInf(files, "DSCH_", fileKeyParam, atchFileId, "");
					fileMngService.updateFileInfs(fvoList);
				}
			}

			/*
			 * ***************************************************************** // 일정관리정보
			 * 업데이트 처리
			 */
			deptSchdulManageVO.setSchdulKindCode("1");
			egovDeptSchdulManageService.updateDeptSchdulManage(deptSchdulManageVO);
			sLocationUrl = "redirect:/cop/smt/sdm/EgovDeptSchdulManageList.do";
		}

		return sLocationUrl;
	}

	/**
	 * 부서일정를 등록한다. / 등록 초기페이지
	 * 
	 * @param searchVO
	 * @param deptSchdulManageVO
	 * @param model
	 * @return "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageRegist"
	 */
	@PostMapping("/cop/smt/sdm/EgovDeptSchdulManageRegist.do")
	@RequireAdmin
	public String deptSchdulManageRegist(@ModelAttribute("searchVO") ComDefaultVO searchVO,
			@ModelAttribute("deptSchdulManageVO") DeptSchdulManageVO deptSchdulManageVO, ModelMap model,
			RedirectAttributes redirectAttributes) {

		String sLocationUrl = "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageRegist";

		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			redirectAttributes.addFlashAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		// 공통코드 중요도 조회
		ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM019");
		List<CmmnDetailCode> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("schdulIpcrCode", listComCode);
		// 공통코드 일정구분 조회
		voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM030");
		listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("schdulSe", listComCode);
		// 공통코드 반복구분 조회
		voComCode = new ComDefaultCodeVO();
		voComCode.setCodeId("COM031");
		listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
		model.addAttribute("reptitSeCode", listComCode);

		// 일정시작일자(시)
		model.addAttribute("schdulBgndeHH", getTimeHH());
		// 일정시작일자(분)
		model.addAttribute("schdulBgndeMM", getTimeMM());
		// 일정종료일자(시)
		model.addAttribute("schdulEnddeHH", getTimeHH());
		// 일정종료일자(분)
		model.addAttribute("schdulEnddeMM", getTimeMM());

		return sLocationUrl;

	}

	/**
	 * 부서일정를 등록한다. / 등록 처리 한다.
	 * 
	 * @param multiRequest
	 * @param searchVO
	 * @param commandMap
	 * @param deptSchdulManageVO
	 * @param bindingResult
	 * @param model
	 * @return "/cop/smt/sdm/EgovDeptSchdulManageRegist"
	 */
	@PostMapping("/cop/smt/sdm/EgovDeptSchdulManageRegistActor.do")
	@RequireAdmin
	public String deptSchdulManageRegistActor(final MultipartHttpServletRequest multiRequest,
			@ModelAttribute("searchVO") ComDefaultVO searchVO, @RequestParam Map<?, ?> commandMap,
			@Valid @ModelAttribute("deptSchdulManageVO") DeptSchdulManageVO deptSchdulManageVO, BindingResult bindingResult,
			ModelMap model) {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		// 로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		String sLocationUrl = "egovframework/com/cop/smt/sdm/EgovDeptSchdulManageRegist";

		String sCmd = commandMap.get("cmd") == null ? "" : (String) commandMap.get("cmd");
		LOGGER.info("cmd => {}", sCmd);

		if (sCmd.equals("save")) {
			// 일정 부서는 자기 부서만 (다른 부서 일정 등록 차단)
			EgovAuthorizationHelper.assertSameDept(deptSchdulManageVO.getSchdulDeptId());
			if (bindingResult.hasErrors()) {
				// 공통코드 중요도 조회
				ComDefaultCodeVO voComCode = new ComDefaultCodeVO();
				voComCode.setCodeId("COM019");
				List<CmmnDetailCode> listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
				model.addAttribute("schdulIpcrCode", listComCode);
				// 공통코드 일정구분 조회
				voComCode = new ComDefaultCodeVO();
				voComCode.setCodeId("COM030");
				listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
				model.addAttribute("schdulSe", listComCode);
				// 공통코드 반복구분 조회
				voComCode = new ComDefaultCodeVO();
				voComCode.setCodeId("COM031");
				listComCode = cmmUseService.selectCmmCodeDetail(voComCode);
				model.addAttribute("reptitSeCode", listComCode);

				// 일정시작일자(시)
				model.addAttribute("schdulBgndeHH", getTimeHH());
				// 일정시작일자(분)
				model.addAttribute("schdulBgndeMM", getTimeMM());
				// 일정종료일자(시)
				model.addAttribute("schdulEnddeHH", getTimeHH());
				// 일정종료일자(분)
				model.addAttribute("schdulEnddeMM", getTimeMM());

				return sLocationUrl;
			}

			// 첨부파일 관련 첨부파일ID 생성
			List<FileVO> fvoList = null;
			String atchFileId = "";

			// final Map<String, MultipartFile> files = multiRequest.getFileMap();
			final List<MultipartFile> files = multiRequest.getFiles("file_1");

			if (!files.isEmpty()) {
				fvoList = fileUtil.parseFileInf(files, "DSCH_", 0, "", "");
				atchFileId = fileMngService.insertFileInfs(fvoList); // 파일이 생성되고나면 생성된 첨부파일 ID를 리턴한다.
			}

			// 리턴받은 첨부파일ID를 셋팅한다..
			deptSchdulManageVO.setAtchFileId(atchFileId); // 첨부파일 ID

			// 아이디 설정
			deptSchdulManageVO
					.setFrstRegisterId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));
			deptSchdulManageVO
					.setLastUpdusrId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));

			// 부서일정(1)으로 고정한다. 개인일정(2)은 개인일정 경로로만 등록한다
			deptSchdulManageVO.setSchdulKindCode("1");
			egovDeptSchdulManageService.insertDeptSchdulManage(deptSchdulManageVO);
			sLocationUrl = "redirect:/cop/smt/sdm/EgovDeptSchdulManageList.do";
		}

		return sLocationUrl;

	}

	/**
	 * 시간을 LIST를 반환한다.
	 * 
	 * @return List
	 */
	private List<ComDefaultCodeVO> getTimeHH() {
    	ArrayList<ComDefaultCodeVO> listHH = new ArrayList<>();
		for (int i = 0; i <= 24; i++) {
			String sHH = "";
			String strI = String.valueOf(i);
			if (i < 10) {
				sHH = "0" + strI;
			} else {
				sHH = strI;
			}

			ComDefaultCodeVO codeVO = new ComDefaultCodeVO();
			codeVO.setCode(sHH);
			codeVO.setCodeNm(sHH);

			listHH.add(codeVO);
		}

		return listHH;
	}

	/**
	 * 분을 LIST를 반환한다.
	 * 
	 * @return List
	 */
	@SuppressWarnings({ "rawtypes", "unused", "unchecked" })
	private List getTimeMM() {
		ArrayList listMM = new ArrayList();
		HashMap hmHHMM;
		for (int i = 0; i <= 60; i++) {

			String sMM = "";
			String strI = String.valueOf(i);
			if (i < 10) {
				sMM = "0" + strI;
			} else {
				sMM = strI;
			}

			ComDefaultCodeVO codeVO = new ComDefaultCodeVO();
			codeVO.setCode(sMM);
			codeVO.setCodeNm(sMM);

			listMM.add(codeVO);
		}
		return listMM;
	}

	/**
	 * 0을 붙여 반환
	 * 
	 * @return String
	 */
	public String dateTypeIntForString(int iInput) {
		String sOutput = "";
		if (Integer.toString(iInput).length() == 1) {
			sOutput = "0" + Integer.toString(iInput);
		} else {
			sOutput = Integer.toString(iInput);
		}

		return sOutput;
	}

	/**
	 * 부서일정(종류 1)만 돌려준다. 같은 테이블의 개인일정(종류 2)이나 없는 일정이면 거부한다
	 * (부서일정 경로로 같은 부서원의 개인일정을 수정·삭제하는 것 차단).
	 */
	private DeptSchdulManageVO requireDeptSchdul(DeptSchdulManageVO deptSchdulManageVO) {
		DeptSchdulManageVO stored = egovDeptSchdulManageService.selectDeptSchdulManageDetailVO(deptSchdulManageVO);
		return EgovAuthorizationHelper.requireTarget(stored != null && "1".equals(stored.getSchdulKindCode()) ? stored : null);
	}
}
