package egovframework.com.sym.sym.srv.web;
import java.util.List;

import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.annotation.RequireAdmin;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.sym.sym.srv.service.EgovServerService;
import egovframework.com.sym.sym.srv.service.Server;
import egovframework.com.sym.sym.srv.service.ServerEqpmn;
import egovframework.com.sym.sym.srv.service.ServerEqpmnRelate;
import egovframework.com.sym.sym.srv.service.ServerEqpmnRelateVO;
import egovframework.com.sym.sym.srv.service.ServerEqpmnVO;
import egovframework.com.sym.sym.srv.service.ServerVO;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 * <pre>
 * 개요
 * - 서버정보관리에 대한 controller 클래스를 정의한다.
 *
 * 상세내용
 * - 서버정보관리에 대한 등록, 수정, 삭제, 조회 등의 기능을 제공한다.
 * - 서버정보관리의 조회기능은 목록조회, 상세조회로 구분된다.
 * </pre>
 * 
 * @author 이문준
 * @since 2010.06.28
 * @version 1.0
 * @see
 *
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2010.06.28  이문준          최초 생성
 *   2011.08.26  정진오          IncludedInfo annotation 추가
 *   2025.07.25  이백행          2025년 컨트리뷰션 PMD로 소프트웨어 보안약점 진단하고 제거하기-FieldNamingConventions(변수명에 밑줄 사용)
 *
 *      </pre>
 */
@Controller
public class EgovServerController {

	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	@Resource(name = "egovServerService")
	private EgovServerService egovServerService;

	/** ID Generation */
	@Resource(name = "egovServerEqpmnIdGnrService")
	private EgovIdGnrService egovServerEqpmnIdGnrService;

	/** ID Generation */
	@Resource(name = "egovServerIdGnrService")
	private EgovIdGnrService egovServerIdGnrService;

	@Resource(name = "EgovCmmUseService")
	private EgovCmmUseService egovCmmUseService;

	/**
	 * 서버장비관리 목록화면으로 이동
	 * 
	 * @return String
	 */
	@RequestMapping(value = "/sym/sym/srv/selectServerEqpmnListView.do")
	@RequireAdmin
	public String selectServerEqpmnListView() throws Exception {
		return "forward:/sym/sym/srv/selectServerEqpmnList.do";
	}

	/**
	 * 서버장비를 관리하기 위해 등록된 서버장비목록을 조회한다.
	 * 
	 * @param serverEqpmnVO - 서버장비 Vo
	 * @return String - 리턴 Url
	 *
	 * @param serverEqpmnVO
	 */
	@IncludedInfo(name = "서버정보관리", order = 1170, gid = 60)
	@RequestMapping(value = "/sym/sym/srv/selectServerEqpmnList.do")
	public String selectServerEqpmnList(@ModelAttribute("serverEqpmnVO") ServerEqpmnVO serverEqpmnVO, ModelMap model)
			throws Exception {

		/** paging */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(serverEqpmnVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(serverEqpmnVO.getPageUnit());
		paginationInfo.setPageSize(serverEqpmnVO.getPageSize());

		serverEqpmnVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		serverEqpmnVO.setLastIndex(paginationInfo.getLastRecordIndex());
		serverEqpmnVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		serverEqpmnVO.setServerEqpmnList(egovServerService.selectServerEqpmnList(serverEqpmnVO));

		model.addAttribute("serverEqpmnList", serverEqpmnVO.getServerEqpmnList());

		int totCnt = egovServerService.selectServerEqpmnListTotCnt(serverEqpmnVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

		return "egovframework/com/sym/sym/srv/EgovServerEqpmnList";
	}

	/**
	 * 등록된 서버장비의 상세정보를 조회한다.
	 * 
	 * @param serverEqpmnVO - 서버장비 Vo
	 * @return String - 리턴 Url
	 *
	 * @param serverEqpmnVO
	 */
	@RequestMapping(value = "/sym/sym/srv/getServerEqpmn.do")
	@RequireAdmin
	public String selectServerEqpmn(@RequestParam("serverEqpmnId") String serverEqpmnId,
			@ModelAttribute("serverEqpmnVO") ServerEqpmnVO serverEqpmnVO, Model model) throws Exception {
		serverEqpmnVO.setServerEqpmnId(serverEqpmnId);
		model.addAttribute("serverEqpmn", egovServerService.selectServerEqpmn(serverEqpmnVO));
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

		return "egovframework/com/sym/sym/srv/EgovServerEqpmnDetail";
	}

	/**
	 * 서버장비정보 등록 화면으로 이동한다.
	 * 
	 * @param serverEqpmnVO - 서버장비 Vo
	 * @return String - 리턴 Url
	 */
	@PostMapping("/sym/sym/srv/addViewServerEqpmn.do")
	@RequireAdmin
	public String insertViewServerEqpmn(@ModelAttribute("serverEqpmnVO") ServerEqpmnVO serverEqpmnVO, ModelMap model)
			throws Exception {

		model.addAttribute("serverEqpmn", serverEqpmnVO);
		return "egovframework/com/sym/sym/srv/EgovServerEqpmnRegist";
	}

	/**
	 * 서버장비정보를 신규로 등록한다.
	 * 
	 * @param serverEqpmn - 서버장비 model
	 * @return String - 리턴 Url
	 *
	 * @param serverEqpmn
	 */
	@PostMapping("/sym/sym/srv/addServerEqpmn.do")
	@RequireAdmin
	public String insertServerEqpmn(@ModelAttribute("serverEqpmnVO") ServerEqpmnVO serverEqpmnVO,
			@Valid @ModelAttribute("serverEqpmn") ServerEqpmn serverEqpmn, BindingResult bindingResult, ModelMap model)
			throws Exception {

		if (bindingResult.hasErrors()) {
			model.addAttribute("serverEqpmnVO", serverEqpmnVO);
			return "egovframework/com/sym/sym/srv/EgovServerEqpmnRegist";
		} else {
			LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
			serverEqpmn.setFrstRegisterId(user == null ? "" : EgovStringUtil.isNullToString(user.getId()));
			serverEqpmn.setLastUpdusrId(user == null ? "" : EgovStringUtil.isNullToString(user.getId()));
			serverEqpmn.setServerEqpmnId(egovServerEqpmnIdGnrService.getNextStringId());
			model.addAttribute("serverEqpmn", egovServerService.insertServerEqpmn(serverEqpmn, serverEqpmnVO));
			model.addAttribute("message", egovMessageSource.getMessage("success.common.insert"));
			return "egovframework/com/sym/sym/srv/EgovServerEqpmnDetail";
		}
	}

	/**
	 * 서버장비정보 수정 화면으로 이동한다.
	 * 
	 * @param serverEqpmnVO - 서버장비 Vo
	 * @return String - 리턴 Url
	 */
	@PostMapping("/sym/sym/srv/updtViewServerEqpmn.do")
	@RequireAdmin
	public String updateViewServerEqpmn(@RequestParam("serverEqpmnId") String serverEqpmnId,
			@ModelAttribute("serverEqpmnVO") ServerEqpmnVO serverEqpmnVO, ModelMap model) throws Exception {

		serverEqpmnVO.setServerEqpmnId(serverEqpmnId);
		ServerEqpmnVO stored = egovServerService.selectServerEqpmn(serverEqpmnVO);
		model.addAttribute("serverEqpmn", stored);
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));
		return "egovframework/com/sym/sym/srv/EgovServerEqpmnUpdt";
	}

	/**
	 * 기 등록된 서버장비정보를 수정한다.
	 * 
	 * @param serverEqpmn - 서버장비 model
	 * @return String - 리턴 Url
	 *
	 * @param serverEqpmn
	 */
	@PostMapping("/sym/sym/srv/updtServerEqpmn.do")
	@RequireAdmin
	public String updateServerEqpmn(@ModelAttribute("serverEqpmnVO") ServerEqpmnVO serverEqpmnVO,
			@Valid @ModelAttribute("serverEqpmn") ServerEqpmn serverEqpmn, BindingResult bindingResult,
			SessionStatus status, ModelMap model) throws Exception {


		if (bindingResult.hasErrors()) {
			return "egovframework/com/sym/sym/srv/EgovServerEqpmnUpdt";
		} else {
			LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
			serverEqpmnVO.setLastUpdusrId(user == null ? "" : EgovStringUtil.isNullToString(user.getId()));
			egovServerService.updateServerEqpmn(serverEqpmnVO);
			status.setComplete();
			model.addAttribute("message", egovMessageSource.getMessage("success.common.update"));
			return "forward:/sym/sym/srv/getServerEqpmn.do";
		}
	}

	/**
	 * 기 등록된 서버장비정보를 삭제한다.
	 *
	 * @param serverEqpmn - 서버장비 model
	 * @return String - 리턴 Url
	 *
	 * @param serverEqpmn
	 */
	@PostMapping("/sym/sym/srv/removeServerEqpmn.do")
	@RequireAdmin
	public String deleteServerEqpmn(@RequestParam("serverEqpmnId") String serverEqpmnId,
			@ModelAttribute("serverEqpmn") ServerEqpmn serverEqpmn, ModelMap model) throws Exception {
		// 2026.07.13 KISA 보안취약점 조치
		LoginVO _loginVO = EgovAuthorizationHelper.assertLoginUser();

		serverEqpmn.setServerEqpmnId(serverEqpmnId);
		egovServerService.deleteServerEqpmn(serverEqpmn);
		model.addAttribute("message", egovMessageSource.getMessage("success.common.delete"));
		return "forward:/sym/sym/srv/selectServerEqpmnList.do";
	}

	/**
	 * 서버장비를 참조하는 서버S/W 목록을 조회한다. (Ajax 용)
	 *
	 * @param serverEqpmnId - 서버장비 ID
	 * @return List - 서버 목록
	 */
	@RequestMapping(value = "/sym/sym/srv/checkServerEqpmnRelations.do")
	@ResponseBody
	@RequireAdmin
	public List<ServerVO> checkServerEqpmnRelations(@RequestParam("serverEqpmnId") String serverEqpmnId)
			throws Exception {
		return egovServerService.selectRelatedServersByEqpmnId(serverEqpmnId);
	}

	/**
	 * 서버정보관리 목록화면으로 이동
	 * 
	 * @return String
	 */
	@RequestMapping(value = "/sym/sym/srv/selectServerListView.do")
	@RequireAdmin
	public String selectServerListView() throws Exception {
		return "forward:/sym/sym/srv/selectServerList.do";
	}

	/**
	 * 서버정보를 관리하기 위해 등록된 서버목록을 조회한다.
	 * 
	 * @param serverVO - 서버 Vo
	 * @return String - 리턴 Url
	 *
	 * @param serverVO
	 */
	@IncludedInfo(name = "서버(S/W)목록", order = 1171, gid = 60)
	@RequestMapping(value = "/sym/sym/srv/selectServerList.do")
	public String selectServerList(@ModelAttribute("serverVO") ServerVO serverVO, ModelMap model) throws Exception {

		/** paging */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(serverVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(serverVO.getPageUnit());
		paginationInfo.setPageSize(serverVO.getPageSize());

		serverVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		serverVO.setLastIndex(paginationInfo.getLastRecordIndex());
		serverVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		serverVO.setServerList(egovServerService.selectServerList(serverVO));

		model.addAttribute("serverList", serverVO.getServerList());

		int totCnt = egovServerService.selectServerListTotCnt(serverVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

		return "egovframework/com/sym/sym/srv/EgovServerList";
	}

	/**
	 * 등록된 서버의 상세정보를 조회한다.
	 * 
	 * @param serverVO - 서버 Vo
	 * @return String - 리턴 Url
	 *
	 * @param serverVO
	 */
	@RequestMapping(value = "/sym/sym/srv/getServer.do")
	@RequireAdmin
	public String selectServer(@RequestParam("serverId") String serverId, @ModelAttribute("serverVO") ServerVO serverVO,
			Model model) throws Exception {

		serverVO.setServerId(serverId);
		model.addAttribute("server", egovServerService.selectServer(serverVO));
		model.addAttribute("serverEqpmnRelateDetailList", egovServerService.selectServerEqpmnRelateDetail(serverVO));
		model.addAttribute("serverEqpmnRelateDetailCount",
				egovServerService.selectServerEqpmnRelateDetailTotCnt(serverVO));
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

		return "egovframework/com/sym/sym/srv/EgovServerDetail";
	}

	/**
	 * 서버정보 등록 화면으로 이동한다.
	 * 
	 * @param serverVO - 서버 Vo
	 * @return String - 리턴 Url
	 */
	@PostMapping("/sym/sym/srv/addViewServer.do")
	@RequireAdmin
	public String insertViewServer(@ModelAttribute("serverVO") ServerVO serverVO, ModelMap model) throws Exception {

		model.addAttribute("cmmCodeDetailList", getCmmCodeDetailList(new ComDefaultCodeVO(), "COM064"));
		model.addAttribute("server", serverVO);
		return "egovframework/com/sym/sym/srv/EgovServerRegist";
	}

	/**
	 * 서버정보를 신규로 등록한다.
	 * 
	 * @param server - 서버 model
	 * @return String - 리턴 Url
	 *
	 * @param server
	 */
	@PostMapping("/sym/sym/srv/addServer.do")
	@RequireAdmin
	public String insertServer(@ModelAttribute("serverVO") ServerVO serverVO,
			@Valid @ModelAttribute("server") Server server, BindingResult bindingResult,
			ModelMap model) throws Exception {

		if (bindingResult.hasErrors()) {
			model.addAttribute("cmmCodeDetailList", getCmmCodeDetailList(new ComDefaultCodeVO(), "COM064"));
			return "egovframework/com/sym/sym/srv/EgovServerRegist";
		} else {
			LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
			server.setFrstRegisterId(user == null ? "" : EgovStringUtil.isNullToString(user.getId()));
			server.setLastUpdusrId(user == null ? "" : EgovStringUtil.isNullToString(user.getId()));
			server.setServerId(egovServerIdGnrService.getNextStringId());
			model.addAttribute("server", egovServerService.insertServer(server, serverVO));
			model.addAttribute("message", egovMessageSource.getMessage("success.common.insert"));
			return "egovframework/com/sym/sym/srv/EgovServerDetail";
		}
	}

	/**
	 * 서버정보 수정 화면으로 이동한다.
	 * 
	 * @param serverVO - 서버 Vo
	 * @return String - 리턴 Url
	 */
	@PostMapping("/sym/sym/srv/updtViewServer.do")
	@RequireAdmin
	public String updateViewServer(@RequestParam("serverId") String serverId,
			@ModelAttribute("serverVO") ServerVO serverVO, ModelMap model) throws Exception {

		serverVO.setServerId(serverId);
		ServerVO stored = egovServerService.selectServer(serverVO);
		model.addAttribute("server", stored);
		model.addAttribute("cmmCodeDetailList", getCmmCodeDetailList(new ComDefaultCodeVO(), "COM064"));
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));
		return "egovframework/com/sym/sym/srv/EgovServerUpdt";
	}

	/**
	 * 기 등록된 서버정보를 수정한다.
	 * 
	 * @param server - 서버 model
	 * @return String - 리턴 Url
	 *
	 * @param server
	 */
	@PostMapping("/sym/sym/srv/updtServer.do")
	@RequireAdmin
	public String updateServer(@ModelAttribute("serverVO") ServerVO serverVO,
			@Valid @ModelAttribute("server") Server server, BindingResult bindingResult,
			SessionStatus status, ModelMap model) throws Exception {


		if (bindingResult.hasErrors()) {
			model.addAttribute("cmmCodeDetailList", getCmmCodeDetailList(new ComDefaultCodeVO(), "COM064"));
			return "egovframework/com/sym/sym/srv/EgovServerUpdt";
		} else {
			LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
			server.setLastUpdusrId(user == null ? "" : EgovStringUtil.isNullToString(user.getId()));
			egovServerService.updateServer(server);
			status.setComplete();
			model.addAttribute("message", egovMessageSource.getMessage("success.common.update"));
			return "forward:/sym/sym/srv/getServer.do";
		}
	}

	/**
	 * 기 등록된 서버정보를 삭제한다.
	 * 
	 * @param server - 서버 model
	 * @return String - 리턴 Url
	 *
	 * @param server
	 */
	@PostMapping("/sym/sym/srv/removeServer.do")
	@RequireAdmin
	public String deleteServer(@RequestParam("serverId") String serverId, @ModelAttribute("server") Server server,
			ModelMap model) throws Exception {
		// 2026.07.13 KISA 보안취약점 조치
		LoginVO _loginVO = EgovAuthorizationHelper.assertLoginUser();


		server.setServerId(serverId);
		egovServerService.deleteServer(server);
		model.addAttribute("message", egovMessageSource.getMessage("success.common.delete"));
		return "forward:/sym/sym/srv/selectServerList.do";
	}

	/**
	 * 서버장비관계정보를 관리하기 위해 대상 서버장비목록을 조회한다.
	 * 
	 * @param serverEqpmnRelateVO - 서버장비관계 Vo
	 * @return String - 리턴 Url
	 *
	 * @param serverEqpmnRelateVO
	 */
	@RequestMapping(value = "/sym/sym/srv/selectServerEqpmnRelateList.do")
	@RequireAdmin
	public String selectServerEqpmnRelateList(@RequestParam("strServerId") String strServerId,
			@ModelAttribute("serverVO") ServerVO serverVO,
			@ModelAttribute("serverEqpmnRelateVO") ServerEqpmnRelateVO serverEqpmnRelateVO, ModelMap model)
			throws Exception {

		/** paging */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(serverEqpmnRelateVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(serverEqpmnRelateVO.getPageUnit());
		paginationInfo.setPageSize(serverEqpmnRelateVO.getPageSize());

		serverEqpmnRelateVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		serverEqpmnRelateVO.setLastIndex(paginationInfo.getLastRecordIndex());
		serverEqpmnRelateVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		serverEqpmnRelateVO.setServerId(strServerId);
		serverVO.setServerId(strServerId);

		serverEqpmnRelateVO
				.setServerEqpmnRelateList(egovServerService.selectServerEqpmnRelateList(serverEqpmnRelateVO));

		model.addAttribute("serverEqpmnRelateList", serverEqpmnRelateVO.getServerEqpmnRelateList());
		model.addAttribute("server", egovServerService.selectServer(serverVO));

		int totCnt = egovServerService.selectServerEqpmnRelateListTotCnt(serverEqpmnRelateVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		model.addAttribute("message", egovMessageSource.getMessage("success.common.select"));

		return "egovframework/com/sym/sym/srv/EgovServerEqpmnRelateRegist";
	}

	/**
	 * 서버장비관계정보를 등록 또는 삭제처리한다.
	 * 
	 * @param serverEqpmnRelate - 서버장비관계 model
	 * @return String - 리턴 Url
	 *
	 * @param serverEqpmnRelate
	 */
	@PostMapping("/sym/sym/srv/saveServerEqpmnRelate.do")
	@RequireAdmin
	public String saveServerEqpmnRelate(@RequestParam("serverId") String serverId,
			@RequestParam("serverEqpmnIds") String serverEqpmnIds, @RequestParam("regYns") String regYns,
			@ModelAttribute("serverEqpmnRelate") ServerEqpmnRelate serverEqpmnRelate, SessionStatus status,
			ModelMap model) throws Exception {
		
		// 2026.03.23 kisa 보안점검 대응 조치
		 if (ObjectUtils.isEmpty(serverEqpmnIds) || ObjectUtils.isEmpty(regYns)) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.insert"));
			return "forward:/sym/sym/srv/selectServerEqpmnRelateList.do";
		 }
			String[] strServerEqpmnIds = serverEqpmnIds.split(";");
			String[] strRegYns = regYns.split(";");
	
			serverEqpmnRelate.setServerId(serverId);
	
			for (int i = 0; i < strServerEqpmnIds.length; i++) {
				serverEqpmnRelate.setServerId(serverId);
				serverEqpmnRelate.setServerEqpmnId(strServerEqpmnIds[i]);
				if (strRegYns[i].equals("Y")) {
					egovServerService.insertServerEqpmnRelate(serverEqpmnRelate);
				} else {
					egovServerService.deleteServerEqpmnRelate(serverEqpmnRelate);
				}
			}
		 
		status.setComplete();
		model.addAttribute("message", egovMessageSource.getMessage("success.common.insert"));
		return "forward:/sym/sym/srv/selectServerEqpmnRelateList.do";
	}

	/**
	 * 공통코드 호출
	 * 
	 * @param comDefaultCodeVO ComDefaultCodeVO
	 * @param codeId           String
	 * @return List
	 * @exception Exception
	 */
	public List<?> getCmmCodeDetailList(ComDefaultCodeVO comDefaultCodeVO, String codeId) throws Exception {
		comDefaultCodeVO.setCodeId(codeId);
		return egovCmmUseService.selectCmmCodeDetail(comDefaultCodeVO);
	}

}