package egovframework.com.uss.ion.rec.service;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.exception.FdlException;

public interface EgovRecomendSiteService {

	List<RecomendSiteVO> selectRecomendSiteList(RecomendSiteVO recomendSiteVO);

	int selectRecomendSiteListCnt(RecomendSiteVO recomendSiteVO);

	void insertRecomendSite(RecomendSiteVO recomendSiteVO) throws FdlException;

	RecomendSiteVO selectRecomendSiteDetail(RecomendSiteVO recomendSiteVO) throws Exception;

	void updateRecomendSite(RecomendSiteVO recomendSiteVO);

	void deleteRecomendSite(RecomendSiteVO recomendSiteVO);

}
