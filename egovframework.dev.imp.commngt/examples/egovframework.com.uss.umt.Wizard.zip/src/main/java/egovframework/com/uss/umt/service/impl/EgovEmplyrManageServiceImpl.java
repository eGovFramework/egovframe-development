package egovframework.com.uss.umt.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.egovframe.rte.psl.dataaccess.util.EgovMap;
import org.springframework.stereotype.Service;

import egovframework.com.uss.umt.service.EgovEmplyrManageService;
import egovframework.com.uss.umt.service.UserDefaultVO;
import egovframework.com.uss.umt.service.EmplyrManageVO;
import egovframework.com.uss.umt.service.EmplyrPasswordManageVO;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import egovframework.com.utl.sim.service.EgovFileScrty;
import jakarta.annotation.Resource;

/**
 * 사용자관리에 관한 비지니스 클래스를 정의한다.
 * @author 공통서비스 개발팀 조재영
 * @since 2009.04.10
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.04.10  조재영          최초 생성
 *   2014.12.08	 이기하			암호화방식 변경(EgovFileScrty.encryptPassword)
 *   2017.07.21  장동한 			로그인인증제한 작업
 *
 * </pre>
 */
@Service("emplyrManageService")
public class EgovEmplyrManageServiceImpl extends EgovAbstractServiceImpl implements EgovEmplyrManageService {

	/** emplyrManageDAO */
	@Resource(name="emplyrManageDAO")
	private EmplyrManageDAO emplyrManageDAO;

	/** mberManageDAO */
	@Resource(name="mberManageDAO")
	private MberManageDAO mberManageDAO;

	/** entrprsManageDAO */
	@Resource(name="entrprsManageDAO")
	private EntrprsManageDAO entrprsManageDAO;

	/** egovUsrCnfrmIdGnrService */
	@Resource(name="egovUsrCnfrmIdGnrService")
	private EgovIdGnrService idgenService;

	/**
	 * 입력한 사용자아이디의 중복여부를 체크하여 사용가능여부를 확인
	 * @param checkId 중복여부 확인대상 아이디
	 * @return 사용가능여부(아이디 사용회수 int)
	 * @throws Exception
	 */
	@Override
	public int checkIdDplct(String checkId) {
		return emplyrManageDAO.checkIdDplct(checkId);
	}

	/**
	 * 화면에 조회된 사용자의 정보를 데이터베이스에서 삭제
	 * @param checkedIdForDel 삭제대상 업무사용자아이디
	 * @throws Exception
	 */
	@Override
	public void deleteEmplyr(String checkedIdForDel) {
		//KISA 보안약점 조치 (2018-10-29, 윤창원)
		String [] delId = EgovStringUtil.isNullToString(checkedIdForDel).split(",");
		for (String element : delId) {
			String [] id = element.split(":");
			if (id[0].equals("USR03")){
		        //업무사용자(직원)삭제
				emplyrManageDAO.deleteEmplyr(id[1]);
			}else if(id[0].equals("USR01")){
				//일반회원삭제
				mberManageDAO.deleteMber(id[1]);
			}else if(id[0].equals("USR02")){
				//기업회원삭제
				entrprsManageDAO.deleteEntrprsmber(id[1]);
			}
		}
	}

	/**
	 * @param userManageVO 업무사용자 등록정보
	 * @return result 등록결과
	 * @throws Exception
	 */
	@Override
	public String insertEmplyr(EmplyrManageVO emplyrManageVO) throws Exception {
		//고유아이디 셋팅
		String uniqId = idgenService.getNextStringId();
		emplyrManageVO.setUniqId(uniqId);
		//패스워드 암호화
		String pass = EgovFileScrty.encryptPassword(emplyrManageVO.getPassword(), EgovStringUtil.isNullToString(emplyrManageVO.getEmplyrId()));//KISA 보안약점 조치 (2018-10-29, 윤창원)
		emplyrManageVO.setPassword(pass);
		String result = emplyrManageDAO.insertEmplyr(emplyrManageVO);
		return result;
	}

	/**
	 * 기 등록된 사용자 중 검색조건에 맞는 사용자의 정보를 데이터베이스에서 읽어와 화면에 출력
	 * @param uniqId 상세조회대상 업무사용자 아이디
	 * @return userManageVO 업무사용자 상세정보
	 * @throws Exception
	 */
	@Override
	public EmplyrManageVO selectEmplyr(String uniqId) {
		EmplyrManageVO emplyrManageVO = emplyrManageDAO.selectEmplyr(uniqId);
		return emplyrManageVO;
	}

	/**
	 * 기 등록된 특정 사용자의 정보를 데이터베이스에서 읽어와 화면에 출력
	 * @param userSearchVO 검색조건
	 * @return List<UserManageVO> 업무사용자 목록정보
	 * @throws Exception
	 */
	@Override
	public List<EgovMap> selectEmplyrList(UserDefaultVO userSearchVO) {
		List<EgovMap> result = emplyrManageDAO.selectEmplyrList(userSearchVO);
		return result;
	}

	/**
	 * 기 등록된 특정 사용자목록의 전체수를 확인
	 * @param userSearchVO 검색조건
	 * @return 총사용자개수(int)
	 * @throws Exception
	 */
	@Override
	public int selectEmplyrListTotCnt(UserDefaultVO userSearchVO) {
		return emplyrManageDAO.selectEmplyrListTotCnt(userSearchVO);
	}

	/**
	 * 화면에 조회된 사용자의 기본정보를 수정하여 항목의 정합성을 체크하고 수정된 데이터를 데이터베이스에 반영
	 * @param userManageVO 업무사용자 수정정보
	 * @throws Exception
	 */
	@Override
	public void updateEmplyr(EmplyrManageVO emplyrManageVO) throws Exception {
		//패스워드 암호화
		String pass = EgovFileScrty.encryptPassword(emplyrManageVO.getPassword(), EgovStringUtil.isNullToString(emplyrManageVO.getEmplyrId()));//KISA 보안약점 조치 (2018-10-29, 윤창원)
		emplyrManageVO.setPassword(pass);

		emplyrManageDAO.updateEmplyr(emplyrManageVO);
	}

	/**
	 * 사용자정보 수정시 히스토리 정보를 추가
	 * @param userManageVO 업무사용자 수정정보
	 * @return result 등록결과
	 * @throws Exception
	 */
	@Override
	public String insertEmplyrHistory(EmplyrManageVO emplyrManageVO) {
		return emplyrManageDAO.insertEmplyrHistory(emplyrManageVO);
	}

	/**
	 * 업무사용자 암호 수정
	 * @param emplyrPasswordManageVO 업무사용자 비밀번호 수정정보
	 * @throws Exception
	 */
	@Override
	public void updatePassword(EmplyrPasswordManageVO emplyrPasswordManageVO) {
		emplyrManageDAO.updatePassword(emplyrPasswordManageVO);
	}

	/**
	 * 사용자가 비밀번호를 기억하지 못할 때 비밀번호를 찾을 수 있도록 함
	 * @param emplyrPasswordManageVO 업무사용자 암호 조회조건정보
	 * @return emplyrPasswordManageVO 업무사용자 암호정보
	 * @throws Exception
	 */
	@Override
	public EmplyrPasswordManageVO selectPassword(EmplyrPasswordManageVO emplyrPasswordManageVO) {
		EmplyrPasswordManageVO result = emplyrManageDAO.selectPassword(emplyrPasswordManageVO);
		return result;
	}


	/**
	 * 로그인인증제한 해제
	 * @param userManageVO 업무사용자 수정정보
	 * @return void
	 * @throws Exception
	 */
	@Override
	public void updateLockIncorrect(EmplyrManageVO emplyrManageVO) throws Exception {
		emplyrManageDAO.updateLockIncorrect(emplyrManageVO);
	}



}