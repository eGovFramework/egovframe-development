package egovframework.com.uss.sam.cpy.web;

import egovframework.com.cmm.annotation.RequireAdmin;

import java.util.List;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.psl.dataaccess.util.EgovMap;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.uss.sam.cpy.service.CpyrhtPrtcPolicyDefaultVO;
import egovframework.com.uss.sam.cpy.service.CpyrhtPrtcPolicyVO;
import egovframework.com.uss.sam.cpy.service.EgovCpyrhtPrtcPolicyService;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;

/**
 *
 * 저작권보호정책내용을 처리하는 컨트롤러 클래스
 *
 * @author 공통서비스 개발팀 박정규
 * @since 2009.04.01
 * @version 1.0
 * @see
 *
 *      <pre>
 * << 개정이력(Modification Information) >>
 *
 *   수정일          수정자       수정내용
 *  -----------    --------    ---------------------------
 *   2009.04.01     박정규       최초 생성
 *   2011.08.26     정진오       IncludedInfo annotation 추가
 *   2026.07.10     유지보수     NCSC 보안점검 반영 (삭제 시 존재·인증 검증)
 *   2026.07.13     유지보수     IDOR 보완 (삭제 시 소유권/관리자 권한 검증)
 *
 *      </pre>
 */
@Controller
public class EgovCpyrhtPrtcPolicyController {

	@Resource(name = "CpyrhtPrtcPolicyService")
	private EgovCpyrhtPrtcPolicyService cpyrhtPrtcPolicyService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;

	/**
	 * 개별 배포시 메인메뉴를 조회한다.
	 *
	 * @param model
	 * @return "/uss/sam/cpy/"
	 * @throws Exception
	 */
	@RequestMapping(value = "/uss/sam/cpy/EgovMain.do")
	@RequireAdmin
	public String egovMain(ModelMap model) throws Exception {
		return "egovframework/com/uss/sam/cpy/EgovMain";
	}

	/**
	 * 메뉴를 조회한다.
	 *
	 * @param model
	 * @return "/uss/sam/cpy/EgovLeft"
	 * @throws Exception
	 */
	@RequestMapping(value = "/uss/sam/cpy/EgovLeft.do")
	@RequireAdmin
	public String egovLeft(ModelMap model) throws Exception {
		return "egovframework/com/uss/sam/cpy/EgovLeft";
	}

	/**
	 * 저작권보호정책 목록을 조회한다. (pageing)
	 *
	 * @param searchVO
	 * @param model
	 * @return "/uss/sam/cpy/EgovCpyrhtPrtcPolicyListInqire"
	 * @throws Exception
	 */
	@IncludedInfo(name = "저작권보호정책", order = 500, gid = 50)
	@RequestMapping("/uss/sam/cpy/CpyrhtPrtcPolicyListInqire.do")
	public String selectCpyrhtPrtcPolicyList(@ModelAttribute("searchVO") CpyrhtPrtcPolicyDefaultVO searchVO,
			ModelMap model) throws Exception {

		/** EgovPropertyService.SiteList */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<EgovMap> resultList = cpyrhtPrtcPolicyService.selectCpyrhtPrtcPolicyList(searchVO);
		model.addAttribute("resultList", resultList);

		int totCnt = cpyrhtPrtcPolicyService.selectCpyrhtPrtcPolicyListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/uss/sam/cpy/EgovCpyrhtPrtcPolicyListInqire";
	}

	/**
	 * 저작권보호정책 목록에 대한 상세정보를 조회한다.
	 *
	 * @param cpyrhtPrtcPolicyVO
	 * @param searchVO
	 * @param model
	 * @return "/uss/sam/cpy/EgovCpyrhtPrtcPolicyDetailInqire"
	 * @throws Exception
	 */
	@PostMapping("/uss/sam/cpy/CpyrhtPrtcPolicyDetailInqire.do")
	@RequireAdmin
	public String selectCpyrhtPrtcPolicyDetail(CpyrhtPrtcPolicyVO cpyrhtPrtcPolicyVO,
			@ModelAttribute("searchVO") CpyrhtPrtcPolicyDefaultVO searchVO, ModelMap model) throws Exception {

		CpyrhtPrtcPolicyVO vo = cpyrhtPrtcPolicyService.selectCpyrhtPrtcPolicyDetail(cpyrhtPrtcPolicyVO);

		model.addAttribute("result", vo);

		return "egovframework/com/uss/sam/cpy/EgovCpyrhtPrtcPolicyDetailInqire";
	}

	/**
	 * 저작권보호정책를 등록하기 위한 전 처리
	 *
	 * @param searchVO
	 * @param model
	 * @return "/uss/sam/cpy/EgovCpyrhtPrtcPolicyCnRegist"
	 * @throws Exception
	 */
	@PostMapping("/uss/sam/cpy/CpyrhtPrtcPolicyCnRegistView.do")
	@RequireAdmin
	public String insertCpyrhtPrtcPolicyCnView(@ModelAttribute("searchVO") CpyrhtPrtcPolicyDefaultVO searchVO,
			Model model) throws Exception {

		model.addAttribute("cpyrhtPrtcPolicyVO", new CpyrhtPrtcPolicyVO());

		return "egovframework/com/uss/sam/cpy/EgovCpyrhtPrtcPolicyCnRegist";

	}

	/**
	 * 저작권보호정책를 등록한다.
	 *
	 * @param searchVO
	 * @param cpyrhtPrtcPolicyVO
	 * @param bindingResult
	 * @return "forward:/uss/sam/cpy/CpyrhtPrtcPolicyListInqire.do"
	 * @throws Exception
	 */
	@PostMapping("/uss/sam/cpy/CpyrhtPrtcPolicyCnRegist.do")
	@RequireAdmin
	public String insertCpyrhtPrtcPolicyCn(
		@ModelAttribute("searchVO") CpyrhtPrtcPolicyDefaultVO searchVO,
			@Valid @ModelAttribute("cpyrhtPrtcPolicyVO") CpyrhtPrtcPolicyVO cpyrhtPrtcPolicyVO,
			BindingResult bindingResult) throws Exception {

		if (bindingResult.hasErrors()) {

			return "egovframework/com/uss/sam/cpy/EgovCpyrhtPrtcPolicyCnRegist";

		}

		// 로그인VO에서 사용자 정보 가져오기
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		String frstRegisterId = loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId());

		cpyrhtPrtcPolicyVO.setFrstRegisterId(frstRegisterId); // 최초등록자ID
		cpyrhtPrtcPolicyVO.setLastUpdusrId(frstRegisterId); // 최종수정자ID

		cpyrhtPrtcPolicyService.insertCpyrhtPrtcPolicyCn(cpyrhtPrtcPolicyVO);

		return "forward:/uss/sam/cpy/CpyrhtPrtcPolicyListInqire.do";
	}

	/**
	 * 저작권보호정책를 수정하기 위한 전 처리
	 *
	 * @param cpyrhtId
	 * @param searchVO
	 * @param model
	 * @return "/uss/sam/cpy/EgovCpyrhtPrtcPolicyCnUpdt"
	 * @throws Exception
	 */
	@PostMapping("/uss/sam/cpy/CpyrhtPrtcPolicyCnUpdtView.do")
	@RequireAdmin
	public String updateCpyrhtPrtcPolicyCnView(@RequestParam("cpyrhtId") String cpyrhtId,
			@ModelAttribute("searchVO") CpyrhtPrtcPolicyDefaultVO searchVO, ModelMap model) throws Exception {

		CpyrhtPrtcPolicyVO cpyrhtPrtcPolicyVO = new CpyrhtPrtcPolicyVO();

		// Primary Key 값 세팅
		cpyrhtPrtcPolicyVO.setCpyrhtId(cpyrhtId);


		// 변수명은 CoC 에 따라
		model.addAttribute(selectCpyrhtPrtcPolicyDetail(cpyrhtPrtcPolicyVO, searchVO, model));

		// 변수명은 CoC 에 따라 JSTL사용을 위해
		model.addAttribute("cpyrhtPrtcPolicyVO",
				cpyrhtPrtcPolicyService.selectCpyrhtPrtcPolicyDetail(cpyrhtPrtcPolicyVO));

		return "egovframework/com/uss/sam/cpy/EgovCpyrhtPrtcPolicyCnUpdt";
	}

	/**
	 * 저작권보호정책를 수정처리한다.
	 *
	 * @param searchVO
	 * @param cpyrhtPrtcPolicyVO
	 * @param bindingResult
	 * @return "forward:/uss/sam/cpy/CpyrhtPrtcPolicyListInqire.do"
	 * @throws Exception
	 */
	@PostMapping("/uss/sam/cpy/CpyrhtPrtcPolicyCnUpdt.do")
	@RequireAdmin
	public String updateCpyrhtPrtcPolicyCn(
		@ModelAttribute("searchVO") CpyrhtPrtcPolicyDefaultVO searchVO,
			@Valid @ModelAttribute("cpyrhtPrtcPolicyVO") CpyrhtPrtcPolicyVO cpyrhtPrtcPolicyVO,
			BindingResult bindingResult) throws Exception {


		if (bindingResult.hasErrors()) {

			return "egovframework/com/uss/sam/cpy/EgovCpyrhtPrtcPolicyCnUpdt";

		}

		// 로그인VO에서 사용자 정보 가져오기
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		String lastUpdusrId = loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId());

		cpyrhtPrtcPolicyVO.setLastUpdusrId(lastUpdusrId); // 최종수정자ID

		cpyrhtPrtcPolicyService.updateCpyrhtPrtcPolicyCn(cpyrhtPrtcPolicyVO);

		return "forward:/uss/sam/cpy/CpyrhtPrtcPolicyListInqire.do";

	}

	/**
	 * 저작권보호정책를 삭제처리한다.
	 *
	 * @param cpyrhtPrtcPolicyVO
	 * @param searchVO
	 * @return "forward:/uss/sam/cpy/CpyrhtPrtcPolicyListInqire.do"
	 * @throws Exception
	 */
	@PostMapping("/uss/sam/cpy/CpyrhtPrtcPolicyCnDelete.do")
	@RequireAdmin
	public String deleteCpyrhtPrtcPolicyCn(CpyrhtPrtcPolicyVO cpyrhtPrtcPolicyVO,
			@ModelAttribute("searchVO") CpyrhtPrtcPolicyDefaultVO searchVO, ModelMap model) throws Exception {

		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "redirect:/uat/uia/egovLoginUsr.do";
		}

		if (EgovStringUtil.isEmpty(cpyrhtPrtcPolicyVO.getCpyrhtId())) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.delete"));
			return "forward:/uss/sam/cpy/CpyrhtPrtcPolicyListInqire.do";
		}

		CpyrhtPrtcPolicyVO existing = cpyrhtPrtcPolicyService.selectCpyrhtPrtcPolicyDetail(cpyrhtPrtcPolicyVO);
		if (existing == null || EgovStringUtil.isEmpty(existing.getCpyrhtId())) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.delete"));
			return "forward:/uss/sam/cpy/CpyrhtPrtcPolicyListInqire.do";
		}


		cpyrhtPrtcPolicyService.deleteCpyrhtPrtcPolicyCn(cpyrhtPrtcPolicyVO);

		model.addAttribute("message", egovMessageSource.getMessage("success.common.delete"));
		return "forward:/uss/sam/cpy/CpyrhtPrtcPolicyListInqire.do";
	}

}
