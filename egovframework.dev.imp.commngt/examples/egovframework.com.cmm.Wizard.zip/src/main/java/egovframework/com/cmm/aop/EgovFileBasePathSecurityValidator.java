package egovframework.com.cmm.aop;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.springframework.util.ObjectUtils;

import egovframework.com.cmm.service.EgovProperties;
import lombok.extern.slf4j.Slf4j;

/**
 * EgovFileBasePathSecurityValidator Class 구현
 * 
 * @author 표준프레임워크 신용호
 * @since 2025.04.01
 * @version 4.3
 * @see
 * 
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *  수정일        수정자      수정내용
 *  ----------  --------  ---------------------------
 *  2025.04.01  신용호      최초 생성
 *  2025.05.22  이백행      PMD로 소프트웨어 보안약점 진단하고 제거하기-InefficientEmptyStringCheck(비효율적인 빈 문자열 검사), SimplifyBooleanExpressions(부울 표현식 단순화)
 *  2026.01.27  신용호      KISA 취약점 조치
 *
 *      </pre>
 * 
 *      <pre>
 *  - String basePath 파라미터에 대해 보안강화 체크를 한다.
 *  - 보안성을 위해 basePath는 ROOT Path를 지정할수 없다.
 *  - basePath에 대해 다음 경로가 추가되어 화이트리스트 방식으로 점검한다. (필요시 화이트리스트를 추가한다)
 *    basePath가 다음 제한된 경로의 하위에 위치하는지 점검한다.
 *    1) Globals.fileStorePath # 파일 업로드 경로
 *    2) Globals.SynchrnServerPath # 파일 동기화 컴포넌트에서 사용할 파일 업로드 경로
 *      </pre>
 */

@Slf4j
public class EgovFileBasePathSecurityValidator {

	public static boolean validate(String basePath) {

		boolean validateResult = false;

		ArrayList<String> whiteList = new ArrayList<String>();
		// 파일 업로드 경로
		whiteList.add(EgovProperties.getProperty("Globals.fileStorePath"));
		// 파일 동기화 컴포넌트에서 사용할 파일 업로드 경로
		whiteList.add(EgovProperties.getProperty("Globals.SynchrnServerPath"));
		// 테스트용 Base Path - Windows OS
		// whiteList.add("D:/TEMP/");
		// 테스트용 Base Path - Linux, Mac OS
		// whiteList.add("/Users/EgovStoredFiles");

		if (ObjectUtils.isEmpty(basePath)) {
			log.error("ERROR : The base path is empty.");
			return false;
		}

		String normalizedBasePath = basePath.trim().replace("\\", "/"); // 윈도우 경로도 동일하게 처리

		// 루트 경로 제한 (리눅스 / 또는 윈도우 드라이브 루트 경로들)
		if (normalizedBasePath.matches("(?i)^[a-z]:/$") || normalizedBasePath.equals("/")) {
			log.error("ERROR : Root base paths are not allowed. basePath = {}", basePath);
			return false;
		}

		try {
			// 입력 경로 정규화 (Canonical Path로 변환)
			File base = new File(normalizedBasePath).getCanonicalFile();

			// 허용된 디렉토리 내인지 검증
			for (String whiteBasePath : whiteList) {
				File file = new File(whiteBasePath).getCanonicalFile();
				if (base.getPath().startsWith(file.getPath())) {
					validateResult = true;
				}
			}
		} catch (IOException e) {
			log.error("Base Path IO Exception!");
		}

		if (!validateResult) {
			log.error("ERROR : Unacceptable base path: {} ", basePath);
		}

		return validateResult;
	}
}
