package egovframework.com.cop.cmy.service.impl;

import java.util.List;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.fdl.idgnr.EgovIdGnrService;
import org.springframework.stereotype.Service;

import egovframework.com.cop.bbs.service.BoardMasterVO;
import egovframework.com.cop.cmy.service.EgovCommuBBSMasterService;
import jakarta.annotation.Resource;

@Service("EgovCommuBBSMasterService")
public class EgovCommuBBSMasterServiceImpl extends EgovAbstractServiceImpl implements EgovCommuBBSMasterService {

	@Resource(name = "EgovCommuBBSMasterDAO")
    private EgovCommuBBSMasterDAO egovCommuBBSMasterDao;

	@Resource(name = "egovBBSMstrIdGnrService")
    private EgovIdGnrService idgenService;

	@Override
	public List<BoardMasterVO> selectCommuBBSMasterListMain(BoardMasterVO boardMasterVO) {
		return egovCommuBBSMasterDao.selectCommuBBSMasterListMain(boardMasterVO);
	}


}
