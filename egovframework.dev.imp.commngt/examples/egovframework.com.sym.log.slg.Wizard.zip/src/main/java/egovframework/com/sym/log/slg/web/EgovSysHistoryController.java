package egovframework.com.sym.log.slg.web;

import egovframework.com.cmm.annotation.RequireAdmin;

import java.util.List;
import java.util.Objects;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.service.CmmnDetailCode;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.EgovFileMngUtil;
import egovframework.com.cmm.service.FileVO;
import egovframework.com.cmm.util.EgovAttachmentGrants;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.sym.log.slg.service.EgovSysHistoryService;
import egovframework.com.sym.log.slg.service.SysHistory;
import egovframework.com.sym.log.slg.service.SysHistoryVO;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

/**
 * 시스템 이력관리를 위한 웹 컨트롤러 클래스
 * 
 * @author 공통 서비스 개발팀 이삼섭
 * @since 2009.03.09
 * @version 1.0
 * @see
 *
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.03.09  이삼섭          최초 작성
 *   2011.08.26  정진오          IncludedInfo annotation 추가
 *   2018.09.28  정진오          updateSysHistory validation처리시 예외 수정
 *   2025.07.14  이백행          2025년 컨트리뷰션 PMD로 소프트웨어 보안약점 진단하고 제거하기-LocalVariableNamingConventions(final이 아닌 변수는 밑줄을 포함할 수 없음)
 *
 *      </pre>
 */
@Controller
public class EgovSysHistoryController {

	@Resource(name = "EgovSysHistoryService")
	private EgovSysHistoryService sysHistoryService;

	@Resource(name = "EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	@Resource(name = "propertiesService")
	protected EgovPropertyService propertyService;

	@Resource(name = "EgovFileMngService")
	private EgovFileMngService fileMngService;

	@Resource(name = "EgovFileMngUtil")
	private EgovFileMngUtil fileUtil;

	@Resource(name = "egovMessageSource")
	protected EgovMessageSource egovMessageSource;

	/**
	 * 시스템이력 등록
	 *
	 * @param history
	 * @param status
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/sym/log/slg/InsertSysHistory.do")
	@RequireAdmin
	public String insertSysHistory(final MultipartHttpServletRequest multiRequest,
			@Valid @ModelAttribute("history") SysHistory history, BindingResult bindingResult, SessionStatus status,
			ModelMap model) throws Exception {

		if (bindingResult.hasErrors()) {
			ComDefaultCodeVO vo = new ComDefaultCodeVO();
			vo.setCodeId("COM002");
			List<CmmnDetailCode> resultCOM002List = cmmUseService.selectCmmCodeDetail(vo);
			model.addAttribute("resultList", resultCOM002List);
			return "egovframework/com/sym/log/slg/EgovSysHistRegist";
		}

		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		if (loginVO != null) {
			List<FileVO> fvoList = null;
			String atchFileId = "";
			// final Map<String, MultipartFile> files = multiRequest.getFileMap();
			final List<MultipartFile> files = multiRequest.getFiles("file_1");
			if (!files.isEmpty()) {
				fvoList = fileUtil.parseFileInf(files, "SHF_", 0, "", "");
				atchFileId = fileMngService.insertFileInfs(fvoList);
			}
			history.setFrstRegisterId(loginVO.getUniqId());
			history.setAtchFileId(atchFileId);
			sysHistoryService.insertSysHistory(history);
		}

		status.setComplete();
		return "forward:/sym/log/slg/SelectSysHistoryList.do";
	}

	/**
	 * 시스템이력 등록 화면
	 *
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/sym/log/slg/AddSysHistory.do")
	@RequireAdmin
	public String addSysHistory(@ModelAttribute("searchVO") SysHistoryVO historyVO, ModelMap model) throws Exception {

		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		vo.setCodeId("COM002");
		List<CmmnDetailCode> resultCOM002List = cmmUseService.selectCmmCodeDetail(vo);
		model.addAttribute("resultList", resultCOM002List);
		return "egovframework/com/sym/log/slg/EgovSysHistRegist";
	}

	/**
	 * 시스템이력 수정
	 *
	 * @param history
	 * @param status
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/sym/log/slg/UpdateSysHistory.do")
	@RequireAdmin
	public String updateSysHistory(final MultipartHttpServletRequest multiRequest,
			@ModelAttribute("searchVO") SysHistoryVO historyVO, @Valid @ModelAttribute("history") SysHistory history,
			BindingResult bindingResult, SessionStatus status, ModelMap model) throws Exception {

		SysHistoryVO stored = EgovAuthorizationHelper.requireTarget(sysHistoryService.selectSysHistory(historyVO));
		// 첨부 그룹은 요청값이 아니라 저장된 원본의 것만 쓴다(남의 첨부 ID 저장 → 삭제 허가 우회 차단)
		history.setAtchFileId(Objects.toString(stored.getAtchFileId(), ""));

		if (bindingResult.hasErrors()) {

			model.addAttribute("history", history);
			ComDefaultCodeVO vo = new ComDefaultCodeVO();
			vo.setCodeId("COM002");
			List<CmmnDetailCode> resultCOM002List = cmmUseService.selectCmmCodeDetail(vo);
			model.addAttribute("resultList", resultCOM002List);
			return "egovframework/com/sym/log/slg/EgovSysHistUpdt";
		}

		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		if (loginVO != null) {
			String atchFileId = history.getAtchFileId();
			// final Map<String, MultipartFile> files = multiRequest.getFileMap();
			final List<MultipartFile> files = multiRequest.getFiles("file_1");
			if (!files.isEmpty()) {
				if ("".equals(atchFileId)) {
					List<FileVO> fvoList = fileUtil.parseFileInf(files, "SHF_", 0, atchFileId, "");
					atchFileId = fileMngService.insertFileInfs(fvoList);
					history.setAtchFileId(atchFileId);
				} else {
					FileVO fvo = new FileVO();
					fvo.setAtchFileId(atchFileId);
					int fileKeyParam = fileMngService.getMaxFileSN(fvo);
					List<FileVO> fvoList = fileUtil.parseFileInf(files, "SHF_", fileKeyParam, atchFileId, "");
					fileMngService.updateFileInfs(fvoList);
				}
			}
			// model.addAttribute("history", history);
			sysHistoryService.updateSysHistory(history);
		}

		status.setComplete();

		return "forward:/sym/log/slg/SelectSysHistoryList.do";
	}

	/**
	 * 시스템이력 수정 화면
	 *
	 * @param historyVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/sym/log/slg/ModifySysHistory.do")
	@RequireAdmin
	public String modifySysHistory(@ModelAttribute("searchVO") SysHistoryVO historyVO, ModelMap model, HttpServletRequest request)
			throws Exception {

		SysHistoryVO history = EgovAuthorizationHelper.requireTarget(sysHistoryService.selectSysHistory(historyVO));
		EgovAttachmentGrants.allowDelete(request, history.getAtchFileId());
		model.addAttribute("history", history);
		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		vo.setCodeId("COM002");
		List<CmmnDetailCode> resultCOM002List = cmmUseService.selectCmmCodeDetail(vo);
		model.addAttribute("resultList", resultCOM002List);
		return "egovframework/com/sym/log/slg/EgovSysHistUpdt";
	}

	/**
	 * 시스템이력 삭제
	 *
	 * @param history
	 * @param status
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/sym/log/slg/DeleteSysHistory.do")
	@RequireAdmin
	public String deleteSysHistory(@ModelAttribute("history") SysHistory history, SessionStatus status, ModelMap model)
			throws Exception {

		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		if (loginVO != null) {
			// 첨부파일 ID는 삭제 폼에 실려오지 않으므로 저장본에서 가져온다.
			SysHistoryVO searchVO = new SysHistoryVO();
			searchVO.setHistId(history.getHistId());
			SysHistoryVO storedHistory = EgovAuthorizationHelper.requireTarget(sysHistoryService.selectSysHistory(searchVO));
			String atchFileId = storedHistory == null ? "" : storedHistory.getAtchFileId();

			sysHistoryService.deleteSysHistory(history);

			// 첨부파일을 삭제하기 위한 Vo
			FileVO fvo = new FileVO();
			fvo.setAtchFileId(atchFileId);

			fileMngService.deleteAllFileInf(fvo);
		}

		status.setComplete();
		return "forward:/sym/log/slg/SelectSysHistoryList.do";
	}

	/**
	 * 시스템이력 목록 조회
	 *
	 * @param history
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@IncludedInfo(name = "시스템이력관리", listUrl = "/sym/log/slg/SelectSysHistoryList.do", order = 1060, gid = 60)
	@RequestMapping(value = "/sym/log/slg/SelectSysHistoryList.do")
	public String selectSysHistoryList(@ModelAttribute("searchVO") SysHistoryVO historyVO, ModelMap model)
			throws Exception {

		historyVO.setPageUnit(propertyService.getInt("pageUnit"));
		historyVO.setPageSize(propertyService.getInt("pageSize"));

		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(historyVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(historyVO.getPageUnit());
		paginationInfo.setPageSize(historyVO.getPageSize());

		historyVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		historyVO.setLastIndex(paginationInfo.getLastRecordIndex());
		historyVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		sysHistoryService.selectSysHistoryList(historyVO, model);
		int totCnt = (Integer) model.get("resultCnt");

		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/com/sym/log/slg/EgovSysHistList";
	}

	/**
	 * 시스템이력 상세 조회
	 *
	 * @param historyVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sym/log/slg/InqireSysHistory.do")
	@RequireAdmin
	public String selectSysHistory(@ModelAttribute("searchVO") SysHistoryVO historyVO,
			@RequestParam("histId") String histId, ModelMap model) throws Exception {
		// 2026.03.23 kisa 보안점검 대응 조치
		if (ObjectUtils.isEmpty(histId)) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.request.msg"));
			return "forward:/sym/log/slg/SelectSysHistoryList.do";
		}
			historyVO.setHistId(histId.trim());
		
		SysHistoryVO vo = sysHistoryService.selectSysHistory(historyVO);
		model.addAttribute("result", vo);
		return "egovframework/com/sym/log/slg/EgovSysHistInqire";
	}

}
