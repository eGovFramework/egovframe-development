package egovframework.com.uss.ion.wik.bmk.web;
import java.util.List;
import java.util.Map;

import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.com.cmm.annotation.RequireAdmin;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.exception.EgovAccessDeniedException;
import egovframework.com.cmm.util.EgovAuthorizationHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.uss.ion.wik.bmk.service.EgovWikiBookmarkService;
import egovframework.com.uss.ion.wik.bmk.service.WikiBookmark;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import jakarta.annotation.Resource;

/**
 * 위키북마크를 처리하는 Controller Class 구현
 * @author 공통콤포넌트 장동한
 * @since 2010.10.20
 * @version 1.0
 * @see
 * <pre>
 * &lt;&lt; 개정이력(Modification Information) &gt;&gt;
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2010.10.20  장동한          최초 생성
 *   2011.8.26	정진오			IncludedInfo annotation 추가
 *
 * </pre>
 */
@Controller
public class EgovWikiBookmarkController {

    /** EgovMessageSource */
    @Resource(name = "egovMessageSource")
    EgovMessageSource egovMessageSource;

    /** egovOnlinePollService */
    @Resource(name = "egovWikiBookmarkService")
    private EgovWikiBookmarkService egovWikiBookmarkService;

    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovWikiBookmarkController.class);

    /**
     * 위키북마크 목록을 조회한다.
     * @param searchVO -위키북마크 model
     * @param searchVO -위키북마크 model
     * @param commandMap -Request Variable
     * @param model -Spring 제공하는 ModelMap
     * @return String -리턴 URL
     * @throws Exception
     */
    @IncludedInfo(name="Wiki기능", order = 810 ,gid = 50)
    @RequestMapping("/uss/ion/wik/bmk/listWikiBookmark.do")
    public String EgovWikiBookmarkList(
    		@ModelAttribute("searchVO") WikiBookmark searchVO,
    		WikiBookmark wikiBookmark,
    		@RequestParam Map<?, ?> commandMap,
    		@RequestParam(value = "checkList", required=false) List<String> checkList,
            ModelMap model) throws Exception {

    	//변수 설정
    	String sCmd = commandMap.get("cmd") == null ? "" : (String) commandMap.get("cmd");

		//Spring Security 사용자권한 처리
	    Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
	    if (!isAuthenticated) {
	        model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
	        return "redirect:/uat/uia/egovLoginUsr.do";
	    }

        //로그인 객체 선언
        LoginVO loginVO = (LoginVO)EgovUserDetailsHelper.getAuthenticatedUser();

        //삭제 모드로 실행시
        if(sCmd.equals("del")){
			// 진입점은 개방, 삭제는 관리자 전용 유지
			EgovAuthorizationHelper.assertAdmin();
			// 2026.07.13 KISA 보안취약점 조치 - 삭제는 POST만 허용
			jakarta.servlet.http.HttpServletRequest _req = ((org.springframework.web.context.request.ServletRequestAttributes) org.springframework.web.context.request.RequestContextHolder.currentRequestAttributes()).getRequest();
			if (!"POST".equalsIgnoreCase(_req.getMethod())) {
				throw new org.springframework.web.HttpRequestMethodNotSupportedException(_req.getMethod());
			}

			// 일괄 삭제: 모든 건이 작성자 본인 것인지 먼저 확인한 뒤 삭제한다.
			String loginUniqId = loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId());
			for(String checkData : checkList) {
				WikiBookmark ownershipCheck = new WikiBookmark();
				ownershipCheck.setWikiBkmkId(checkData);
				ownershipCheck.setFrstRegisterId(loginUniqId);
				boolean owns = egovWikiBookmarkService.selectWikiBookmarkListCnt(ownershipCheck) > 0;
				EgovAuthorizationHelper.assertOwner(owns ? loginUniqId : null);
			}

        	for(String checkData : checkList) {
        		LOGGER.debug("===>>> checkData = "+checkData);

                wikiBookmark.setWikiBkmkId(checkData);
	            egovWikiBookmarkService.deleteWikiBookmark(wikiBookmark);
            }

	        //페이지 인텍스 설정
	        searchVO.setPageIndex(1);

	        return "redirect:/uss/ion/wik/bmk/listWikiBookmark.do";
        }


        /** EgovPropertyService.sample */
        searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
        searchVO.setPageSize(propertiesService.getInt("pageSize"));

        /** pageing */
        PaginationInfo paginationInfo = new PaginationInfo();
        paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
        paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
        paginationInfo.setPageSize(searchVO.getPageSize());

        searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
        searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
        searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        searchVO.setFrstRegisterId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));

        List<?> reusltList = egovWikiBookmarkService.selectWikiBookmarkList(searchVO);
        model.addAttribute("resultList", reusltList);

        model.addAttribute("searchKeyword", commandMap.get("searchKeyword") == null ? "" : (String) commandMap.get("searchKeyword"));
        model.addAttribute("searchCondition", commandMap.get("searchCondition") == null ? "" : (String) commandMap.get("searchCondition"));

        int totCnt = egovWikiBookmarkService.selectWikiBookmarkListCnt(searchVO);
        paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);

    	return "egovframework/com/uss/ion/wik/bmk/EgovWikiBookmarkList";
	}

    /**
     * 위키북마크를 등록 한다.
     * @param wikiBookmark -위키북마크 model
     * @param model -Spring 제공하는 ModelMap
     * @return String -리턴 URL
     * @throws Exception
     */
    @PostMapping("/uss/ion/wik/bmk/registWikiBookmark.do")
    @RequireAdmin
    public String EgovWikiBookmarkRegist(
    		WikiBookmark wikiBookmark,
            ModelMap model) throws Exception {

    	String sDupl = "N";

    	LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
    	if (loginVO == null || loginVO.getUniqId() == null) {
    		throw new EgovAccessDeniedException("인증 정보가 없습니다.");
    	}
    	// 2026.07.13 KISA 보안취약점 조치 - usid는 로그인 사용자로 고정
    	wikiBookmark.setUsid(loginVO.getUniqId());
    	wikiBookmark.setFrstRegisterId(EgovStringUtil.isNullToString(loginVO.getUniqId()));

    	if(wikiBookmark.getWikiBkmkNm() != null){
    		if(egovWikiBookmarkService.selectWikiBookmarkDuplicationCnt(wikiBookmark) > 0){
    			sDupl = "Y";
    		}else{
    			egovWikiBookmarkService.insertWikiBookmark(wikiBookmark);
    		}
    	}
    	//log.debug("Controller EgovWikiBookmarkRegist.WikiBookmark>" + wikiBookmark);
    	//중복 설정
    	model.addAttribute("S_DUPL", sDupl);
    	return "egovframework/com/uss/ion/wik/bmk/EgovWikiBookmarkRegist";
	}


}
