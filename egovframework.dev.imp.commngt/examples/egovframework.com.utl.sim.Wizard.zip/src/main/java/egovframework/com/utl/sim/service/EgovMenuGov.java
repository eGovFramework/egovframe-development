/**
 *  Class Name : EgovMenuGov.java
 *  Description : 
 *  Modification Information
 *
 *     수정일         수정자                   수정내용
 *   -------    --------    ---------------------------

 *

 *  @version 1.0
 *  @see
 *
 *  Copyright (C) 2009 by EGOV  All rights reserved.
 */
package egovframework.com.utl.sim.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;
import java.util.Vector;

/**
 * 메뉴관리 Business Interface class
 * 
 * @author 공통컴포넌트 개발팀 홍길동
 * @author 공통 서비스 개발팀 이용
 * @since 2009.02.02
 * @see
 *
 *      <pre>
 *  == 개정이력(Modification Information) ==
 *
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2009.02.02  이용           최초 생성
 *   2022.11.11  김혜준          시큐어코딩 처리
 *   2025.09.10  이백행          2025년 컨트리뷰션 PMD로 소프트웨어 보안약점 진단하고 제거하기-LocalVariableNamingConventions(final이 아닌 변수는 밑줄을 포함할 수 없음)
 *   2025.09.10  이백행          2025년 컨트리뷰션 PMD로 소프트웨어 보안약점 진단하고 제거하기-CloseResource(부적절한 자원 해제)
 *
 *      </pre>
 */
public class EgovMenuGov {

	// 파일구분자
	static final char FILE_SEPARATOR = File.separatorChar;

	/**
	 * <pre>
	 * Comment : DAT 파일을 파싱하여 메뉴관리화면에 리턴.
	 * </pre>
	 * 
	 * @param parFile  DAT파일명
	 * @param parChar  구분자
	 * @param parField 필드수
	 * @return Vector list
	 * @version 1.0 (2009.02.04.)
	 * @see
	 */
	public static Vector<List<String>> parsFileByMenuChar(String basePath, String parFile, String parChar, int parField)
			throws Exception {
		Vector<List<String>> list = null;

		File file = new File(parFile.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR));

		// 파일이며, 존재하면 파싱 시작
		if (file.exists() && file.isFile()) {
			list = EgovFileTool.parsFileByChar(basePath, parFile, parChar, parField);
		} else {
			list = new Vector<List<String>>();
		}

		return list;
	}

	/**
	 * <pre>
	 * Comment : 메뉴관리 화면의 데이타를 DAT 파일로 생성.
	 * </pre>
	 * 
	 * @param menuIDArray    ID Array
	 * @param menuNameArray  Name Array
	 * @param menuLevelArray Lefel Array
	 * @param menuURLArray   URL Array
	 * @return boolean true/false
	 * @version 1.0 (2009.02.04.)
	 * @see
	 */
	public static boolean setDataByDATFile(String parFile, String[] menuIDArray, String[] menuNameArray,
			String[] menuLevelArray, String[] menuURLArray) throws Exception {
		boolean success = false;

		File file = new File(parFile.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR));

		try (BufferedWriter out = new BufferedWriter(new FileWriter(file));) {

			for (int i = 0; i < menuIDArray.length; i++) { // nodeId | parentNodeId | nodeName | nodeUrl
				out.write(menuIDArray[i] + "|" + menuLevelArray[i] + "|" + menuNameArray[i] + "|" + menuURLArray[i]
						+ "|");
				out.newLine();
			}
			success = true;
		}
		return success;
	}

}
